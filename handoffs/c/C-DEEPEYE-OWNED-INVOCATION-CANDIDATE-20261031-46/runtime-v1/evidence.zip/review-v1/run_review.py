import hashlib,json,subprocess,sys,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
D=HERE.parent/'implementation-v1'
B=HERE.parent.parent
def pin(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
assert pin(D/'FINAL.json')['sha256']=='c014738445bb187174f05fc0e423c02e0a75a6be0d1fe673b4eb31a54fbdb502'
files=json.loads((D/'freeze.json').read_text(encoding='utf-8-sig'))['files']
verified=[]
for item in files:
 p=D/item['path'];actual=pin(p)
 assert actual['bytes']==item['bytes'] and actual['sha256']==item['sha256'],item['path']
 verified.append(actual)
deps=[B/'C43-20261031/implementation-v1/patched/integration/host_envelope.py',B/'C43-20261031/implementation-v1/completion_interval.py',B/'C45-20261031/implementation-v1/patched/candidate_mailbox.py']
verified += [pin(p) for p in deps]+[pin(D/'FINAL.json'),pin(D/'freeze.json')]
(HERE/'source-pins-before.json').write_text(json.dumps(verified,indent=2)+'\n',encoding='utf-8')
cmd=[sys.executable,'-I','-B',str(HERE/'independent_serial_checks.py'),str(D),str(B/'C43-20261031/implementation-v1'),str(B/'C45-20261031/implementation-v1'),str(HERE/'run02.input-output.json')]
started=time.time()
result=subprocess.run(cmd,cwd=HERE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=25)
(HERE/'run02.stdout').write_bytes(result.stdout)
(HERE/'run02.stderr').write_bytes(result.stderr)
record=dict(command=cmd,timeout_seconds=25,exit_code=result.returncode,elapsed_seconds=time.time()-started,
 script=pin(HERE/'independent_serial_checks.py'),stdout=pin(HERE/'run02.stdout'),stderr=pin(HERE/'run02.stderr'))
(HERE/'run02.command-exit.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(verified_freeze_files=len(files),exit_code=result.returncode,elapsed_seconds=record['elapsed_seconds'],stdout=result.stdout.decode(),stderr=result.stderr.decode())))
sys.exit(result.returncode)
