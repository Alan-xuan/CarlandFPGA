"""One NEW two-invocation pure control; no original actor, projection or core execution.

CLI: python -I -B independent_serial_checks.py C46_IMPLEMENTATION C43_IMPLEMENTATION C45_IMPLEMENTATION OUTPUT_JSON
Injected identities/receipts/I/O/projection are synthetic, not authentication.
"""
import ast
import copy
import dataclasses
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import types

D, C43, C45, OUT = map(Path, sys.argv[1:])
P = D / 'package/owned_invocation_v1'
BASE = (1 << 61) + 765432101
CONTEXT = dict(session=13, source_id=1, topology_id=2, acquisition_profile_id=1,
               transport_profile_id=1, config_epoch=5, boot_sha256='d'*64)
S = types.SimpleNamespace
evidence = {'scope': 'synthetic AST-bound adapter; no actual provider/OS/core', 'invocations': []}

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod

def extract(path, names, ns):
    tree = ast.parse(path.read_text(encoding='utf-8-sig'))
    nodes = [x for x in tree.body if isinstance(x, (ast.ClassDef, ast.FunctionDef)) and x.name in names]
    assert {x.name for x in nodes} == set(names)
    exec(compile(ast.Module(body=nodes, type_ignores=[]), str(path), 'exec'), ns)

M = load('independent_c46_mechanics', P/'mechanics.py')
V = load('independent_c44_verifier', P/'fixed/c44_pair_verifier_v1.py')
Motion = load('independent_original_motion_numeric', D/'source/competition/deepeye/integration/motion.py')
sys.path.insert(0, str(C43/'dependencies/attempt02/vendor'))
Host = load('independent_fixed_host', C43/'patched/integration/host_envelope.py')
Interval = load('independent_fixed_interval', C43/'completion_interval.py')

class Clock:
    now = BASE
    def __call__(self): return self.now
    def _check(self): pass
class Composition: pass
class Actor: pass
class Record: pass
class Series: pass
class Session: pass
class Producer: pass
@dataclasses.dataclass(frozen=True)
class Observation:
    boot: object
    raw: bytes
    sample_lower_ns: int
@dataclasses.dataclass(frozen=True)
class Identity:
    operation_id: str
    request_hash: str
    tested_commit: str
    package_manifest_sha256: str
    run_id: str
    invocation_id: int
    actor_instance_id: str
@dataclasses.dataclass(frozen=True)
class Limits:
    max_invocations: int
    max_total_request_bytes: int
    max_total_output_bytes: int
    max_total_reads: int
    response_mode: str

A = types.ModuleType('independent_c46_adapter')
sys.modules[A.__name__] = A
ns = A.__dict__
ns.update(dataclass=dataclasses.dataclass, BootBinding=object,
          mailbox=S(ObservedIntervalBoundsV2=object))
extract(D/'patched/competition/deepeye/simulation/authority/candidate_owner.py',
        {'_InputTransaction', '_CompletedInference'}, ns)
extract(C45/'patched/candidate_mailbox.py', {'ObservedIntervalBoundsV2'}, ns)
extract(D/'source/competition/deepeye/simulation/authority/source_projection_v1/assembler.py',
        {'_root', '_pose'}, ns)
for name in ('need','uint','encode','pair_state','quantize_target','BASIS'):
    ns[name] = getattr(M, name)
ns.update(verifier=V, host_clock=S(QpcHostClock=Clock), host_envelope=Host,
          completion_interval=Interval, motion=Motion,
          candidate_mailbox=S(ObservedIntervalBoundsV2=ns['ObservedIntervalBoundsV2']),
          InvocationIdentity=Identity, _ActorRecord=Record, ActorOwner=Actor,
          SerialInvocationLimits=Limits, _OriginalSerialSeries=Series,
          VerifiedObservation=Observation, ProjectionSession=Session,
          Producer=Producer, ActorComposition=Composition)
class IsolateImports(ast.NodeTransformer):
    def visit_ImportFrom(self, node):
        return None if node.level else node
tree = IsolateImports().visit(ast.parse((P/'adapter.py').read_text(encoding='utf-8-sig')))
ast.fix_missing_locations(tree)
exec(compile(tree, str(P/'adapter.py'), 'exec'), ns)

pose = dict(position_m=[0,0,0], orientation_xyzw=[0,0,0,1])
clock = Clock()
owner = Composition()
owner._busy = True
owner._state = 'ACTIVE'
owner._clock = owner._host_clock = clock
owner._channels = object()
owner._active = lambda: None
owner._checkpoint = lambda *args: None
owner._progress_time = clock
owner._boot = S(run_id='independent-two-call', context_json=M.encode(CONTEXT), generation=4)
owner._runtime = S(_observations={}, _age_cap=100_000_000)
owner._progress = S(bound=None)
root = S(revision=2, pose_revision=2, revoke_generation=0, pose=S(**copy.deepcopy(pose)))
owner._executor = S(_root=root)
session = Session()
session._check = lambda: None
session._book = S(_root=root)
session._producer = Producer()
session._producer._captures = []
session._link = owner._world_action_link = S(composition=owner, executor=owner._executor)
policy = A.OwnedInvocationPolicy('independent-serial', '3'*64, '4'*40, 2, 4, 8, 12)
actor_policy = S(executable='runtime/python.exe', files=tuple(A.FILES.items()),
                 arguments=('-I','-B','c37_entry.py','--actor-stdio-v2','--max-invocations','2','--request-bytes','16384'))
owner._config = S(owned_invocation_v1=policy, actor_policy=actor_policy,
                  enable_completion_interval_v2=True, progress_max_age_ns=100_000_000,
                  ai_model_sha256=A.FILES['frozen_c28.py'])
actor = owner._actor = Actor()
actor._registry = owner._registry = S(_clock_binding=clock, _contains=lambda x: x is actor)
actor._policy, actor._boot = actor_policy, owner._boot
actor._runtime_owner, actor._executor_owner = owner._runtime, owner._executor
actor._run_deadline, actor.instance_id = BASE+95_000_000, 'independent-actor'
actor._invocation = actor._invocation_series = None
actor._pending_io = S(all_settled=True)
counts = dict(first=0, next=0, write=0, read=0, seal=0)
wires = []
def lifetime():
    assert clock.now < actor._run_deadline
    if actor._invocation is not None:
        assert clock.now < actor._invocation.deadline
actor._invocation_check = lifetime
def series_start(limits):
    assert limits.max_invocations == 2 and limits.max_total_request_bytes == 32768
    series = Series()
    series.ledger = S(tickets=[])
    series._known_io = lambda r: None
    actor._invocation_series = series
actor.begin_serial_invocations = series_start
def prepare(identity, following, **kw):
    if following:
        lifetime()
        assert actor._invocation_series.ledger.tickets[-1].sealed_pair is not None
    counts['next' if following else 'first'] += 1
    r = Record()
    r.owner, r.identity, r.request = actor, identity, kw['request_raw']
    r.deadline, r.dispatch, r.reads = kw['io_deadline_ns'], None, []
    r._close_attempted, r._close_error = False, None
    assert len(r.request) == 16384 and kw['max_output_bytes'] == 18440
    actor._invocation = r
    actor._invocation_series.ledger.tickets.append(S(record=r, sealed_frame=None, sealed_pair=None, observed_qpc_ns=None))
    wires.append(r.request)
actor.prepare_invocation = lambda identity, **kw: prepare(identity, False, **kw)
actor.prepare_next_invocation = lambda identity, **kw: prepare(identity, True, **kw)
def offset(): return (actor._invocation.identity.invocation_id-1)*20_000_000
def dispatch():
    counts['write'] += 1
    assert actor._invocation.dispatch is None
    actor._invocation.dispatch = {'raw_call_bracket_ns':[BASE+offset()+1_000_000, BASE+offset()+2_000_000]}
actor.dispatch_invocation_once = dispatch
actor.poll_invocation = lambda: None
def response(request):
    pub, ids = request['input'], request['echo_ids']
    obs = pub['observation']
    advice = dict(schema_version=1, planner_id='candidate_four_channel_planner_v1',
                  candidate_only=True, authorization='none', status='ADVISE',
                  reason='bounded_observation_goal_search', risk=.2, uncertainty=.2,
                  direction_world=[0,0,1], speed_limit_m_s=.0626,
                  observation=copy.deepcopy(obs), map_cells=[dict(sample_id=obs['sample_id'],
                  em_qpc_ns=obs['em_qpc_ns'], pose=copy.deepcopy(pose), risk=.2)], independent_em_count=1)
    common = dict(abi=V.ABI, echo_ids=ids, request_wire_sha256=hashlib.sha256(actor._invocation.request).hexdigest(), authority='none')
    ready = dict(common, kind='READY', core_sha256=V.CORE_SHA256)
    result = dict(common, kind='RESULT', status='RESULT', core_ran=True,
                  completion_grant=False, result=advice, reason=advice['reason'])
    return V.frame(M.encode(ready), 2048)+V.frame(M.encode(result))
def read():
    counts['read'] += 1
    r = actor._invocation
    raw = response(V.decode_request(r.request))
    assert len(r.reads) < 2
    part = raw[:7] if not r.reads else raw[7:]
    r.reads.append(dict(raw_hex=part.hex(), raw_call_bracket_ns=[BASE+offset()+4_000_000, BASE+offset()+5_000_000]))
actor.read_invocation_once = read
def seal():
    counts['seal'] += 1
    r, ticket = actor._invocation, actor._invocation_series.ledger.tickets[-1]
    ticket.sealed_frame = b''.join(bytes.fromhex(row['raw_hex']) for row in r.reads)
    ticket.sealed_pair = ('synthetic-ready', 'synthetic-result')
    ticket.observed_qpc_ns = BASE+offset()+11_000_000
    r._close_attempted = True
actor.seal_serial_invocation_response_pair = seal
adapter = A._from_composition(owner)
events = []
try:
    for index in (1,2):
        origin = BASE+(index-1)*20_000_000
        clock.now = origin+15_000_000
        capture, sample, event = object(), object(), object()
        raw_capture = M.encode(dict(synthetic_capture=index, counts=[1401+index,1999,2001,3])).decode()
        digest = hashlib.sha256(raw_capture.encode()).hexdigest()
        candidate = dict(channel_counts=[1401+index,1999,2001,3], quality=15,
                         observation_identity=dict(capture_sha256=digest))
        history = tuple(row[0] for row in session._producer._captures)
        session._producer._captures.append((capture,sample,candidate,dict(capture_raw=raw_capture)))
        public = dict(schema_version=1, projection_id='c36_c28_public_view_v1', enabled=True,
                      now_qpc_ns=clock.now, pose=copy.deepcopy(pose), goal_m=[0,0,12],
                      observation=dict(sample_id=digest, counts=candidate['channel_counts'], quality=15,
                      adc_qpc_ns=origin, em_qpc_ns=origin, adc_pose=copy.deepcopy(pose), em_pose=copy.deepcopy(pose)),
                      history=[], executed_actions=[])
        session.export = lambda **kw: dict(status='ASSEMBLED_UNVALIDATED', proof={'candidate':candidate})
        A.projection = S(project_interval_json=lambda raw: M.encode(dict(input_status='PROJECTED',
                         core_ran=False, authorization='none', public_input=public)))
        record = Observation(owner._boot, M.encode(dict(kind='telem_observation', context=CONTEXT, observed_seq=30+index)), origin)
        tx = A._InputTransaction('observation', original_event=event)
        owner._input_transaction = tx
        A._retain_original_association(owner,event,record,session=session,capture_ref=capture,
            sample_ref=sample,current_read=object(),registry_ref=object(),history_refs=history,
            mapping_receipt=object(),source_bound_receipt=object(),dispatch_bound_receipt=object(),
            source_deadline_ns=BASE+90_000_000,dispatch_deadline_ns=BASE+80_000_000,
            previous_action=None,previous_deadline_ns=None)
        tx.observation_record = record
        owner._runtime._observations[30+index] = S(raw=record.raw, sample_lower_ns=origin)
        assert adapter.begin(tx) == 'PENDING'
        owner._input_transaction = None
        assert adapter.advance() == 'PENDING'
        assert adapter.advance() == 'PENDING'
        completion = adapter.advance()
        events.append(completion)
        finite = adapter.inspect_candidate(completion, owner._boot)
        assert finite.deadline_ns == clock.now+12_000_000
        proof = adapter.verify_completion(completion, owner._boot)
        document = json.loads(proof.candidate_raw)
        assert proof.completion_lower_ns == origin+4_000_000
        assert proof.completion_upper_ns == origin+11_000_000
        assert document['completion_observed_interval_ns'] == dict(lower_ns=origin+1_000_000, upper_ns=origin+11_000_000)
        assert document['candidate_id'] == index and document['observation']['observed_seq'] == 30+index
        assert document['target']['duration_ms'] == 12 and document['target']['action'] == 1
        evidence['invocations'].append(dict(index=index, original_observation=json.loads(record.raw),
            original_capture_utf8=raw_capture, request_hex=wires[-1].hex(),
            response_hex=actor._invocation_series.ledger.tickets[-1].sealed_frame.hex(),
            candidate=document, finite_deadline_ns=finite.deadline_ns))
    assert wires[0] != wires[1] and events[0] is not events[1]
    assert counts == dict(first=1,next=1,write=2,read=4,seal=2)
    before = counts.copy()
    try:
        adapter.verify_completion(events[0], owner._boot)
    except ValueError as exc:
        evidence['old_event_rejection'] = str(exc)
    else:
        raise AssertionError('old event unexpectedly accepted')
    assert counts == before and adapter.failed and adapter.pending is None and adapter.ready is None
    assert adapter._retained is None
    assert not any(name.startswith('competition.deepeye.simulation') for name in sys.modules)
    assert not any('c28' in name.lower() or 'c37' in name.lower() for name in sys.modules)
    evidence.update(passed=True, counts=counts, core_calls=0, native_calls=0, c36_calls=0)
    print(json.dumps({k:evidence[k] for k in ('passed','counts','old_event_rejection','core_calls','native_calls','c36_calls')}, sort_keys=True))
finally:
    OUT.write_text(json.dumps(evidence, indent=2, ensure_ascii=True)+'\n', encoding='utf-8')
