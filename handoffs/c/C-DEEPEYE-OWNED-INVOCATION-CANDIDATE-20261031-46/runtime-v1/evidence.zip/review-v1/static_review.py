"""Read-only source/evidence audit; no product imports or test execution."""
import ast,difflib,hashlib,json
from pathlib import Path
H=Path(__file__).resolve().parent;D=H.parent/'implementation-v1';B=H.parent.parent
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
result={'source_only':True,'source_pins':[],'phases':[],'integration':[]}
for item in read(D/'source-pins.json'):
 raw=(D/'source'/item['path']).read_bytes()
 get=read(D/item['get_record'])
 assert sha(raw)==item['sha256']==get['sha256'] and len(raw)==item['bytes']==get['bytes']
 assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==item['blob']==get['blob']
 assert item['commit']==get['commit']=='aa314dcb953e1aac799b43c5f8a080fa18edf09f'
 assert item['exit_code']==get['exit_code']==0
 result['source_pins'].append(item)
patch=[]
for name in ('candidate_owner.py','actor_composition.py'):
 oldpath=B/'C45-20261031/implementation-v1/patched'/name
 newpath=D/'patched/competition/deepeye/simulation/authority'/name
 old,new=oldpath.read_text(encoding='utf-8'),newpath.read_text(encoding='utf-8')
 path='competition/deepeye/simulation/authority/'+name
 patch.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+path,tofile='b/'+path))
 def symbols(s):
  tree=ast.parse(s);out={}
  for node in tree.body:
   if isinstance(node,(ast.ClassDef,ast.FunctionDef)):
    out[node.name]=ast.dump(node,include_attributes=False)
  return out
 a,b=symbols(old),symbols(new)
 result['integration'].append(dict(path=path,old_sha256=sha(oldpath.read_bytes()),new_sha256=sha(newpath.read_bytes()),changed_top_level=[k for k in a.keys()|b.keys() if a.get(k)!=b.get(k)]))
 if name=='actor_composition.py':
  assert a['_production_channels']==b['_production_channels'] and a['_entry']==b['_entry']
  def fragment(s,n):return next(ast.get_source_segment(s,x) for x in ast.parse(s).body if isinstance(x,ast.FunctionDef) and x.name==n)
  assert fragment(old,'_production_channels')==fragment(new,'_production_channels')
assert ''.join(patch)==(D/'c46-owned-invocation.patch').read_text(encoding='utf-8')
result['patch_exact_from_C45']=True
for n in range(1,8):
 phase='run%02d'%n;r=read(D/(phase+'.command-exit.json'))
 for stream in ('stdout','stderr'):
  assert sha((D/(phase+'.'+stream)).read_bytes())==r[stream+'_sha256']
 if n in range(2,7):
  snap=D/'versions'/phase
  assert sha((snap/'test_c46_new.py').read_bytes())==r['script_sha256']
  for path,digest in r['source_pins'].items():assert sha((snap/path).read_bytes())==digest,(phase,path)
  if n>=5:
   for path,digest in r['source_pins'].items():assert sha((D/path).read_bytes())==digest
 result['phases'].append(dict(phase=phase,exit_code=r['exit_code'],script_sha256=r['script_sha256'],command=r['argv'],versioned_product_verified=n in range(2,7)))
result['run01_evidence_limit']='Two pre-build adapter/mechanics snapshots absent; construction script not a functional run and imports neither. Script/raw logs/exit retained. No retrospective pass attributed.'
result['default_gate_unchanged']=True
result['full_final_author_suite_run']=False
result['new_independent_product_run']={'script':'independent_serial_checks.py','run02_exit_code':read(H/'run02.command-exit.json')['exit_code'],'scope':'one new combined pure control, two invocations and old event rejection'}
result['original_source_callsite_lines']={
 'actor_composition.py':[165,240,286], 'actor_owner.py':[567,619,650,682],
 'actor_invocation_series.py':[239,255,278], 'motion/kinematics.py':[107,111,116]}
(H/'static-review.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(source_pins=len(result['source_pins']),phase_exits=[x['exit_code'] for x in result['phases']],patch_exact=True,default_gate_unchanged=True,product_imports=0)))
