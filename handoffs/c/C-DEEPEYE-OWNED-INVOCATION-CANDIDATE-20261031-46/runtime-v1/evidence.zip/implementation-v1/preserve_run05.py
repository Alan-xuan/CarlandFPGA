from pathlib import Path
import shutil,hashlib,json
D=Path(__file__).resolve().parent;p=D/'versions/run05';p.mkdir()
for folder in ('package','patched'):shutil.copytree(D/folder,p/folder)
for n in ('test_c46_new.py','c46-owned-invocation.patch'):shutil.copyfile(D/n,p/n)
r=json.loads((D/'run05.command-exit.json').read_text())
for n,h in r['source_pins'].items():assert hashlib.sha256((p/n).read_bytes()).hexdigest()==h
assert hashlib.sha256((p/'test_c46_new.py').read_bytes()).hexdigest()==r['script_sha256']
print('run05 complete source version preserved and matched')
