from pathlib import Path
import ast,datetime,difflib,hashlib,json,shutil
D=Path(__file__).resolve().parent;B=D.parent.parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(n,v):(D/n).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
# Final production source is exactly the version exercised by runs05/06.
for phase in ('run05','run06'):
 r=json.loads((D/(phase+'.command-exit.json')).read_text())
 for name,h in r['source_pins'].items():assert sha((D/name).read_bytes())==h,(phase,name)
snap=D/'versions/run06';snap.mkdir()
for folder in ('package','patched'):shutil.copytree(D/folder,snap/folder)
for n in ('test_c46_new.py','c46-owned-invocation.patch'):shutil.copyfile(D/n,snap/n)
r=json.loads((D/'run06.command-exit.json').read_text());assert sha((snap/'test_c46_new.py').read_bytes())==r['script_sha256']
patch=[];integration=[]
for name in ('candidate_owner.py','actor_composition.py'):
 base=B/'C45-20261031/implementation-v1/patched'/name;target=D/'patched/competition/deepeye/simulation/authority'/name
 old=base.read_text(encoding='utf-8');new=target.read_text(encoding='utf-8');path='competition/deepeye/simulation/authority/'+name
 patch.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+path,tofile='b/'+path))
 integration.append(dict(path=path,baseline_sha256=sha(base.read_bytes()),candidate_sha256=sha(target.read_bytes())))
 if name=='actor_composition.py':
  def fn(s,n):return next(ast.get_source_segment(s,x) for x in ast.parse(s).body if isinstance(x,ast.FunctionDef) and x.name==n)
  assert fn(old,'_production_channels')==fn(new,'_production_channels')
assert ''.join(patch)==(D/'c46-owned-invocation.patch').read_text(encoding='utf-8')
for folder in ('package','patched'):
 for p in (D/folder).rglob('*.py'):compile(p.read_bytes(),str(p),'exec')
sources=[]
for p in sorted((D/'source').rglob('*.get.json')):
 r=json.loads(p.read_text());source=p.with_suffix('').with_suffix('.py')
 assert r['exit_code']==0 and r['commit']=='aa314dcb953e1aac799b43c5f8a080fa18edf09f'
 raw=source.read_bytes();assert sha(raw)==r['sha256'] and len(raw)==r['bytes']
 assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==r['blob']
 sources.append(dict(path=source.relative_to(D/'source').as_posix(),**{k:r[k] for k in ('commit','sha256','blob','bytes','exit_code')},get_record=p.relative_to(D).as_posix()))
write('source-pins.json',sources)
deps=[]
for rel in ('C43-20261031/implementation-v1/completion_interval.py','C43-20261031/implementation-v1/completion_interval.schema.json','C43-20261031/implementation-v1/patched/integration/host_envelope.py','C45-20261031/implementation-v1/patched/actor_composition.py','C45-20261031/implementation-v1/patched/candidate_owner.py','C45-20261031/implementation-v1/patched/candidate_mailbox.py'):
 p=B/rel;deps.append(dict(source=rel,sha256=sha(p.read_bytes()),bytes=p.stat().st_size))
for p in sorted((D/'package/owned_invocation_v1/fixed').rglob('*')):
 if p.is_file():deps.append(dict(source=p.relative_to(D).as_posix(),sha256=sha(p.read_bytes()),bytes=p.stat().st_size))
write('dependencies.json',dict(apply_order=['C43','C45','C46 patch and new package'],dependencies=deps,integration=integration,c42_four_pins_unchanged=True,core_executed=False,native_executed=False))
api=[]
for p in sorted((D/'package/owned_invocation_v1').glob('*.py')):
 tree=ast.parse(p.read_text(encoding='utf-8'))
 for node in tree.body:
  if isinstance(node,(ast.FunctionDef,ast.ClassDef)):api.append(dict(file=p.relative_to(D).as_posix(),symbol=node.name,line=node.lineno,signature=ast.unparse(node.args) if isinstance(node,ast.FunctionDef) else None))
write('API.json',dict(default_enabled=False,production_provider_installed=False,authority='none',api=api,original_admission_callsite='original channels.verify_observation inside ActorComposition.accept_observation transaction, before returning exact VerifiedObservation',public_composition_calls=['accept_observation','poll_owned_invocation','inspect_owned_candidate','accept_completion'],second_h12_implemented=False))
write('control-inputs.json',dict(synthetic_only=True,source_ns=(1<<62)+123000000,completion_observed_delta_ns=20000000,first_read_lower_delta_ns=3000000,original_read_call_upper_delta_ns=4000000,dispatch_lower_delta_ns=1000000,initial_now_delta_ns=25000000,source_cap_delta_ns=90000000,dispatch_cap_delta_ns=80000000,prospective_duration_ms=10,original_provider_objects='fake types injected into exact adapter AST',C36_projection='fake only in controls',C44_verifier='actual fixed pure source',C43_interval='actual fixed runtime plus real jsonschema',native_or_core_execution=False))
write('static-delivery-result.json',dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_count=len(sources),exact_get_bytes_verified=True,package_syntax='PASS_NO_IMPORT',minimal_patch='PASS_EXACT_C45_BASE',default_production_gate='UNCHANGED',final_product_matches=['run05','run06'],older_controls_not_rerun=True,core_calls=0,native_calls=0))
print(json.dumps(dict(source_count=len(sources),syntax='PASS',patch='EXACT',default_gate='UNCHANGED',final_product_matches=['run05','run06'],source_execution=False)))
