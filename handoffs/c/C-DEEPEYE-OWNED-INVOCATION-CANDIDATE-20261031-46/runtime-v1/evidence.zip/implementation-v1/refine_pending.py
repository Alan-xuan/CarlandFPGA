from pathlib import Path
import shutil,json,hashlib,difflib
D=Path(__file__).resolve().parent;P=D/'package/owned_invocation_v1';B=D.parent.parent
# Preserve the precise two executed versions before any production edits.
snap=D/'versions/run03';snap.mkdir(parents=True)
for folder in ('package','patched'):shutil.copytree(D/folder,snap/folder)
for name in ('test_c46_new.py','c46-owned-invocation.patch'):shutil.copyfile(D/name,snap/name)
old=D/'versions/run02';shutil.copytree(snap,old)
shutil.copyfile(D/'test_c46_new.run02-original.py',old/'test_c46_new.py')
for label in ('run02','run03'):
 rec=json.loads((D/(label+'.command-exit.json')).read_text())
 for name,h in rec['source_pins'].items():assert hashlib.sha256((D/'versions'/label/name).read_bytes()).hexdigest()==h
 assert hashlib.sha256((D/'versions'/label/'test_c46_new.py').read_bytes()).hexdigest()==rec['script_sha256']
f=P/'adapter.py';s=f.read_text(encoding='utf-8')
s=s.replace('from ..source_projection_v1.assembler import Producer','from ..source_projection_v1.assembler import Producer,_root')
start=s.index('class _CompletionEvent:');end=s.index('\ndef _retain_original_association',start)
s=s[:start]+'''class _CompletionEvent:
    __slots__=()
    def __init__(self,key):need(key is _KEY,'original pair required')

def _root_guard(owner,association):
    session=association.session;session._check()
    link=session._link;book=session._book;executor=link.executor;root=executor._root
    need(link is owner._world_action_link and link.composition is owner and executor is owner._executor,'original Root/link/executor')
    need(book._root is root and root is not None,'original current Root required')
    return (link,book,executor,root,encode(_root(root)))

def _same_root(owner,association,guard):
    actual=_root_guard(owner,association)
    need(all(x is y for x,y in zip(actual[:4],guard[:4])) and actual[4]==guard[4],'pending Root/pose/revocation changed')

'''+s[end:]
s=s.replace('self.pending=None;self.ready=None;', 'self.pending=None;self.ready=None;self._retained=None;')
s=s.replace("            assembled=a.session.export", "            guard=_root_guard(o,a)\n            assembled=a.session.export")
s=s.replace("            public=projected['public_input'];verifier.validate_public(public)","            _same_root(o,a,guard)\n            public=projected['public_input'];verifier.validate_public(public)")
s=s.replace("caps=(a.source_deadline_ns,a.dispatch_deadline_ns,a.previous_deadline_ns),polls=0)","caps=(a.source_deadline_ns,a.dispatch_deadline_ns,a.previous_deadline_ns),guard=guard,polls=0)")
s=s.replace("            self.actor.poll_invocation()", "            _same_root(self.owner,a,p['guard'])\n            self.actor.poll_invocation()")
s=s.replace("            pair=verifier.verify_pair", "            _same_root(self.owner,a,p['guard'])\n            pair=verifier.verify_pair")
s=s.replace("            self.ready=_CompletionEvent(_KEY,self,r,proof,finite);self.pending=None", "            _same_root(self.owner,a,p['guard'])\n            self.ready=_CompletionEvent(_KEY)\n            self._retained=(self.ready,r,proof,finite,p,candidate_raw,bounds)\n            self.pending=None")
start=s.index('    def verify_completion(');end=s.index('\ndef _from_composition',start)
s=s[:start]+'''    def _completion(self,event,boot):
        try:
            now=self._check();held=self._retained
            need(held is not None and type(event) is _CompletionEvent and event is self.ready is held[0] and boot is self.owner._boot,'exact unused original completion event')
            _,record,proof,finite,p,raw,bounds=held
            need(record is self.records[-1] is self.actor._invocation and record.request==p['wire'] and proof.boot is boot and proof.source is self.source and proof.clock is self.clock and proof.candidate_raw==raw and proof.observed_interval_v2 is bounds,'independent retained completion changed')
            _same_root(self.owner,p['association'],p['guard'])
            need(now<min(x for x in p['caps'] if x is not None),'original completion cap expired')
            return proof,finite
        except BaseException:
            self.retire();raise

    def inspect_candidate(self,event,boot):
        return self._completion(event,boot)[1]

    def verify_completion(self,event,boot):
        proof,_=self._completion(event,boot)
        self.ready=None;self._retained=None
        return proof

    def retire(self):
        self.failed=True;self.pending=None;self.ready=None;self._retained=None

'''+s[end:]
# All exceptional transitions discard the opaque event and pending state.
s=s.replace('            self.failed=True;raise','            self.retire();raise')
f.write_text(s,encoding='utf-8',newline='\n')
f=D/'patched/competition/deepeye/simulation/authority/actor_composition.py';s=f.read_text(encoding='utf-8')
needle='    @_entry\n    def poll_owned_invocation(self):'
s=s.replace(needle,'''    @_entry
    def inspect_owned_candidate(self, event):
        self._active(); self._channel_health()
        if self._owned_invocations is None:
            raise ValueError('owned invocation adapter is disabled')
        return self._owned_invocations.inspect_candidate(event, self._boot)

'''+needle)
f.write_text(s,encoding='utf-8',newline='\n')
patch=[]
for name in ('candidate_owner.py','actor_composition.py'):
 old=(B/'C45-20261031/implementation-v1/patched'/name).read_text(encoding='utf-8');new=(D/'patched/competition/deepeye/simulation/authority'/name).read_text(encoding='utf-8');path='competition/deepeye/simulation/authority/'+name
 patch.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+path,tofile='b/'+path))
(D/'c46-owned-invocation.patch').write_text(''.join(patch),encoding='utf-8',newline='\n')
print('run02/run03 complete sources matched actual phase hashes; Root guard and opaque completion applied')
