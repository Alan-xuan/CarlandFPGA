from pathlib import Path
import shutil,json,hashlib
D=Path(__file__).resolve().parent;snap=D/'versions/run04';snap.mkdir()
for folder in ('package','patched'):shutil.copytree(D/folder,snap/folder)
for name in ('test_c46_new.py','c46-owned-invocation.patch'):shutil.copyfile(D/name,snap/name)
r=json.loads((D/'run04.command-exit.json').read_text())
for n,h in r['source_pins'].items():assert hashlib.sha256((snap/n).read_bytes()).hexdigest()==h
assert hashlib.sha256((snap/'test_c46_new.py').read_bytes()).hexdigest()==r['script_sha256']
f=D/'package/owned_invocation_v1/adapter.py';s=f.read_text(encoding='utf-8')
s=s.replace("            now=self._check();held=self._retained", "            self.actor._invocation_check()\n            now=self._check();held=self._retained")
s=s.replace("            return proof,finite", "            need(now<finite.candidate.valid_until_ns,'candidate dispatch-age validity expired')\n            need(finite.deadline_ns is None or now<finite.deadline_ns,'fixed finite action duration expired')\n            return proof,finite")
f.write_text(s,encoding='utf-8',newline='\n')
print('preserved exact run04; fixed candidate/action expiration and original lifetime recheck')
