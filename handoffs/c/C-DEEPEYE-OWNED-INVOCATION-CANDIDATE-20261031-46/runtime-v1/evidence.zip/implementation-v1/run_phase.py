from pathlib import Path
import subprocess,sys,json,hashlib,datetime
D=Path(__file__).resolve().parent;label=sys.argv[1];script=sys.argv[2]
sha=lambda b:hashlib.sha256(b).hexdigest();argv=[sys.executable,'-I','-B',str(D/script)]+sys.argv[3:]
r={'argv':argv,'cwd':str(D),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'timeout_seconds':25,'script_sha256':sha((D/script).read_bytes()),'source_pins':{p.relative_to(D).as_posix():sha(p.read_bytes()) for folder in ('package','patched') for p in (D/folder).rglob('*') if p.is_file()}}
try:
 p=subprocess.run(argv,cwd=D,capture_output=True,timeout=25);out,err=p.stdout,p.stderr;r.update(exit_code=p.returncode,timed_out=False)
except subprocess.TimeoutExpired as e:out,err=e.stdout or b'',e.stderr or b'';r.update(exit_code=None,timed_out=True)
(D/(label+'.stdout')).write_bytes(out);(D/(label+'.stderr')).write_bytes(err);r.update(ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),stdout_sha256=sha(out),stderr_sha256=sha(err));(D/(label+'.command-exit.json')).write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in r.items() if k!='source_pins'}));print(out.decode(errors='replace'));print(err.decode(errors='replace'));raise SystemExit(r['exit_code'] if r['exit_code'] is not None else 124)
