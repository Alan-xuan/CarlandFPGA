from pathlib import Path
import hashlib,json,difflib,datetime
D=Path(__file__).resolve().parent;B=D.parent.parent;P=D/'package/owned_invocation_v1'
sha=lambda b:hashlib.sha256(b).hexdigest()
f=P/'mechanics.py';f.write_text(f.read_text(encoding='utf-8-sig').replace("=='ADVISORY'","=='ADVISE'"),encoding='utf-8',newline='\n')
f=P/'adapter.py';s=f.read_text(encoding='utf-8-sig');s=s.replace("class _Association:\n    def __init__", "class _Association:\n    def __setattr__(self,name,value):raise AttributeError('retained association is immutable')\n    def __init__");s=s.replace("class _CompletionEvent:\n    def __init__", "class _CompletionEvent:\n    def __setattr__(self,name,value):raise AttributeError('retained completion is immutable')\n    def __init__");s=s.replace("        self.adapter,self.record,self.proof,self.finite=adapter,record,proof,finite\n        self.consumed=False", "        self.__dict__.update(adapter=adapter,record=record,proof=proof,finite=finite)");s=s.replace("and not event.consumed and event.record", "and event.record").replace("        event.consumed=True;self.ready=None", "        self.ready=None").replace(" and not a.used and a.record", " and not any(a is x for x in self.associations) and a.record").replace("            a.used=True;self.associations.append(a)","            self.associations.append(a)")
s += '''\n\ndef _validate_config(config,binding):
    policy=config.owned_invocation_v1
    need(type(policy) is OwnedInvocationPolicy,'exact default-off owned policy')
    policy.check();need(type(binding) is host_clock.QpcHostClock,'original fixed QPC required')
    need(config.enable_completion_interval_v2 is True and 0<config.progress_max_age_ns<=100_000_000,'explicit C45 interval policy')
    need(config.ai_model_sha256==FILES['frozen_c28.py'],'fixed C28 model identity')
    staged=dict(config.actor_policy.files)
    need(all(staged.get(k)==v for k,v in FILES.items()),'fixed C44 manifest/package/core required')
    need(config.actor_policy.executable=='runtime/python.exe' and config.actor_policy.arguments==('-I','-B','c37_entry.py','--actor-stdio-v2','--max-invocations',str(policy.max_invocations),'--request-bytes','16384'),'fixed original package entry')
'''
f.write_text(s,encoding='utf-8',newline='\n')
# Pin/copy only the fixed host-only dependency closure. No C28 or actor import.
fixed=P/'fixed';(fixed/'c36').mkdir(parents=True,exist_ok=True)
for n in ('host_projection.py','request.schema.json','public-view.schema.json','frozen_source_predicates.py'):
 source=B/'C36-20261031/a108-v2'/n;(fixed/'c36'/n).write_bytes(source.read_bytes())
(fixed/'c44_pair_verifier_v1.py').write_bytes((B/'C44-20261031/implementation-v1/c44_pair_verifier_v1.py').read_bytes())
base=B/'C45-20261031/implementation-v1/patched';patches=[]
for name in ('candidate_owner.py','actor_composition.py'):
 old=(base/name).read_text(encoding='utf-8');new=old
 if name=='candidate_owner.py':
  new=new.replace('    request_raw: bytes | None = None\n','    request_raw: bytes | None = None\n    original_event: object = None\n    owned_association: object = None\n')
 else:
  new=new.replace('    enable_completion_interval_v2: bool = False\n','    enable_completion_interval_v2: bool = False\n    owned_invocation_v1: object = None\n',1)
  new=new.replace('        self._candidates = self._input_transaction = None\n','        self._candidates = self._input_transaction = None\n        self._owned_invocations = None\n')
  new=new.replace("        self._retired = True  # Gate first, before callbacks or cleanup.\n", "        self._retired = True  # Gate first, before callbacks or cleanup.\n        if self._owned_invocations is not None:\n            self._owned_invocations.retire()\n")
  new=new.replace('        self._actor = self._registry.launch(config.actor_policy)\n','        launch = (self._registry.launch if config.owned_invocation_v1 is None\n                  else self._registry.launch_overlapped)\n        self._actor = launch(config.actor_policy)\n')
  new=new.replace("        self._state = 'ACTIVE'\n", "        self._state = 'ACTIVE'\n        if self._config.owned_invocation_v1 is not None:\n            from .owned_invocation_v1.adapter import _from_composition\n            self._owned_invocations = _from_composition(self)\n",1)
  new=new.replace("        self._input_transaction = _InputTransaction('observation')\n", "        self._input_transaction = _InputTransaction('observation', original_event=event)\n")
  new=new.replace('        self._candidates.observe(transaction.observation_record, now)\n','        self._candidates.observe(transaction.observation_record, now)\n        if self._owned_invocations is not None:\n            return self._owned_invocations.begin(transaction)\n')
  new=new.replace('        proof = self._channels.verify_completion(event, self._boot)\n','        proof = (self._channels.verify_completion(event, self._boot)\n                 if self._owned_invocations is None\n                 else self._owned_invocations.verify_completion(event, self._boot))\n')
  new=new.replace('    @_entry\n    def accept_command(self, event, *, slot_event=None):', '''    @_entry
    def poll_owned_invocation(self):
        self._active(); self._channel_health()
        if self._owned_invocations is None:
            raise ValueError('owned invocation adapter is disabled')
        return self._owned_invocations.advance()

    @_entry
    def accept_command(self, event, *, slot_event=None):''')
  # Both factories: validate before production gate/native construction.
  needle='    channels = _production_channels(config'
  lines=new.splitlines(True);out=[]
  for line in lines:
   if line.startswith(needle):out+=['    if config.owned_invocation_v1 is not None:\n','        from .owned_invocation_v1.adapter import _validate_config\n','        _validate_config(config, binding)\n']
   out.append(line)
  new=''.join(out)
 target=D/'patched/competition/deepeye/simulation/authority'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(new,encoding='utf-8',newline='\n')
 path='competition/deepeye/simulation/authority/'+name
 patches.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+path,tofile='b/'+path))
(D/'c46-owned-invocation.patch').write_text(''.join(patches),encoding='utf-8',newline='\n')
print(json.dumps({'patch_sha256':sha((D/'c46-owned-invocation.patch').read_bytes()),'package_files':len(list(P.rglob('*'))),'core_calls':0}))
