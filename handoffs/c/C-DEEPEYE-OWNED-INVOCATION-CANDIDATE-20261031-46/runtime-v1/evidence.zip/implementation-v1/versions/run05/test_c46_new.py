"""NEW C46 fake original-object mechanics; never imports native actor or C28."""
import ast,copy,dataclasses,hashlib,importlib.util,json,math,sys,types,unittest
from pathlib import Path
D=Path(__file__).resolve().parent;B=D.parent.parent;P=D/'package/owned_invocation_v1'
NS=(1<<62)+123000000
CTX=dict(session=7,source_id=1,topology_id=2,acquisition_profile_id=1,transport_profile_id=1,config_epoch=2,boot_sha256='a'*64)
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m
M=load('c46_mechanics',P/'mechanics.py');V=load('c46_verifier',P/'fixed/c44_pair_verifier_v1.py')
Motion=load('c46_motion',D/'source/competition/deepeye/integration/motion.py')
sys.path.insert(0,str(B/'C43-20261031/implementation-v1/dependencies/attempt02/vendor'))
Host=load('c46_host',B/'C43-20261031/implementation-v1/patched/integration/host_envelope.py')
Interval=load('c46_interval',B/'C43-20261031/implementation-v1/completion_interval.py')
class Qpc:
 def __call__(self):return NS+25_000_000
 def _check(self):pass
class Composition:pass
class Actor:pass
class Record:pass
class Series:pass
class Producer:pass
class Session:pass
@dataclasses.dataclass(frozen=True)
class Observation:
 boot:object
 raw:bytes
 sample_lower_ns:int
@dataclasses.dataclass(frozen=True)
class Identity:
 operation_id:str;request_hash:str;tested_commit:str;package_manifest_sha256:str;run_id:str;invocation_id:int;actor_instance_id:str
@dataclasses.dataclass(frozen=True)
class Limits:
 max_invocations:int;max_total_request_bytes:int;max_total_output_bytes:int;max_total_reads:int;response_mode:str

def extracted(path,names,namespace):
 tree=ast.parse(path.read_text(encoding='utf-8-sig'));nodes=[x for x in tree.body if isinstance(x,(ast.ClassDef,ast.FunctionDef)) and x.name in names]
 exec(compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec'),namespace)
N={'__name__':'c46_extracted_types','dataclass':dataclasses.dataclass,'BootBinding':object,'mailbox':types.SimpleNamespace(ObservedIntervalBoundsV2=object)}
sys.modules[N['__name__']]=types.ModuleType(N['__name__'])
extracted(D/'patched/competition/deepeye/simulation/authority/candidate_owner.py',{'_InputTransaction','_CompletedInference'},N)
extracted(B/'C45-20261031/implementation-v1/patched/candidate_mailbox.py',{'ObservedIntervalBoundsV2'},N)
class RemoveRelative(ast.NodeTransformer):
 def visit_ImportFrom(self,n):return None if n.level else n
A=types.ModuleType('c46_adapter_extracted');sys.modules[A.__name__]=A
extracted(D/'source/competition/deepeye/simulation/authority/source_projection_v1/assembler.py',{'_root','_pose'},A.__dict__)
A.__dict__.update(N);A.__dict__.update({n:getattr(M,n) for n in ('need','uint','encode','pair_state','quantize_target','BASIS')})
A.__dict__.update(projection=None,verifier=V,host_clock=types.SimpleNamespace(QpcHostClock=Qpc),host_envelope=Host,completion_interval=Interval,motion=Motion,candidate_mailbox=types.SimpleNamespace(ObservedIntervalBoundsV2=N['ObservedIntervalBoundsV2']),InvocationIdentity=Identity,_ActorRecord=Record,ActorOwner=Actor,SerialInvocationLimits=Limits,_OriginalSerialSeries=Series,VerifiedObservation=Observation,ProjectionSession=Session,Producer=Producer,ActorComposition=Composition)
tree=RemoveRelative().visit(ast.parse((P/'adapter.py').read_text(encoding='utf-8-sig')));ast.fix_missing_locations(tree);exec(compile(tree,'C46_exact_adapter_AST','exec'),A.__dict__)

POSE=dict(position_m=[0,0,0],orientation_xyzw=[0,0,0,1])
def public():
 obs=dict(sample_id='b'*64,counts=[1000,2048,2048,1],quality=15,adc_qpc_ns=NS,em_qpc_ns=NS,adc_pose=copy.deepcopy(POSE),em_pose=copy.deepcopy(POSE))
 return dict(schema_version=1,projection_id='c36_c28_public_view_v1',enabled=True,now_qpc_ns=NS+1,pose=copy.deepcopy(POSE),goal_m=[0,0,10],observation=obs,history=[],executed_actions=[])
def advise(pub,direction=(0,0,1),speed=.1):
 return dict(schema_version=1,planner_id='candidate_four_channel_planner_v1',candidate_only=True,authorization='none',status='ADVISE',reason='bounded_observation_goal_search',risk=.1,uncertainty=.1,direction_world=list(direction),speed_limit_m_s=speed,observation=copy.deepcopy(pub['observation']),map_cells=[dict(sample_id=pub['observation']['sample_id'],em_qpc_ns=NS,pose=copy.deepcopy(POSE),risk=.1)],independent_em_count=1)
def pair(wire,ids,pub):
 common=dict(abi=V.ABI,echo_ids=ids,request_wire_sha256=hashlib.sha256(wire).hexdigest(),authority='none')
 r=dict(common,kind='READY',core_sha256=V.CORE_SHA256);q=dict(common,kind='RESULT',status='RESULT',core_ran=True,completion_grant=False,result=advise(pub),reason='bounded_observation_goal_search')
 return V.frame(M.encode(r),2048)+V.frame(M.encode(q))

def setup():
 o=Composition();o._busy=True;o._state='ACTIVE';o._channels=object();o._clock=o._host_clock=Qpc();o._veto=0
 o._active=lambda:None;o._checkpoint=lambda *a:None;o._progress_time=o._clock
 o._boot=types.SimpleNamespace(run_id='synthetic',context_json=M.encode(CTX),generation=1)
 policy=A.OwnedInvocationPolicy('synthetic','1'*64,'2'*40,2,8,20,10)
 ap=types.SimpleNamespace(executable='runtime/python.exe',arguments=('-I','-B','c37_entry.py','--actor-stdio-v2','--max-invocations','2','--request-bytes','16384'),files=tuple(A.FILES.items()))
 o._config=types.SimpleNamespace(owned_invocation_v1=policy,actor_policy=ap,enable_completion_interval_v2=True,progress_max_age_ns=100_000_000,ai_model_sha256=A.FILES['frozen_c28.py'])
 o._runtime=types.SimpleNamespace(_observations={},_age_cap=1_500_000_000);o._executor=object();o._progress=types.SimpleNamespace(bound=None)
 actor=Actor();actor._registry=o._registry=types.SimpleNamespace(_clock_binding=o._clock,_contains=lambda a:a is actor)
 actor._policy=ap;actor._boot=o._boot;actor._runtime_owner=o._runtime;actor._executor_owner=o._executor;actor._run_deadline=NS+200_000_000;actor.instance_id='synthetic-actor'
 o._actor=actor;actor._invocation=None;actor._invocation_series=None;actor.write_calls=0;actor.read_calls=0;actor._pending_io=types.SimpleNamespace(all_settled=True)
 actor._invocation_check=lambda:None
 def begin(limits):
  s=Series();s.ledger=types.SimpleNamespace(tickets=[]);s._known_io=lambda r:None;actor._invocation_series=s
 actor.begin_serial_invocations=begin
 def prepare(identity,**kw):
  r=Record();r.owner=actor;r.identity=identity;r.request=kw['request_raw'];r.deadline=kw['io_deadline_ns'];r.dispatch=None;r.reads=[];r._close_attempted=False;r._close_error=None;actor._invocation=r
  actor._invocation_series.ledger.tickets.append(types.SimpleNamespace(record=r,sealed_frame=None,sealed_pair=None,observed_qpc_ns=None))
 actor.prepare_invocation=actor.prepare_next_invocation=prepare
 def write():actor.write_calls+=1;actor._invocation.dispatch={'raw_call_bracket_ns':[NS+1_000_000,NS+2_000_000]}
 actor.dispatch_invocation_once=write;actor.poll_invocation=lambda:None
 def read():
  actor.read_calls+=1;r=actor._invocation;req=V.decode_request(r.request);wire=pair(r.request,req['echo_ids'],req['input']);chunks=[wire[:3],wire[3:]]
  part=chunks[len(r.reads)];r.reads.append(dict(raw_hex=part.hex(),raw_call_bracket_ns=[NS+3_000_000,NS+4_000_000]))
 actor.read_invocation_once=read
 def seal():
  r=actor._invocation;t=actor._invocation_series.ledger.tickets[-1];raw=b''.join(bytes.fromhex(x['raw_hex']) for x in r.reads);t.sealed_frame=raw;t.sealed_pair=(b'fake retained frame1',b'fake retained frame2');t.observed_qpc_ns=NS+20_000_000;r._close_attempted=True
 actor.seal_serial_invocation_response_pair=seal
 root=types.SimpleNamespace(revision=1,pose_revision=1,revoke_generation=0,pose=types.SimpleNamespace(**copy.deepcopy(POSE)))
 o._executor=types.SimpleNamespace(_root=root);actor._executor_owner=o._executor
 session=Session();prod=Producer();session._producer=prod;session._check=lambda:None;session._book=types.SimpleNamespace(_root=root);session._link=o._world_action_link=types.SimpleNamespace(composition=o,executor=o._executor)
 capture=object();sample=object();current=object();registry=object();raw='{"synthetic":"original capture bytes"}'
 pub=public();pub['observation']['sample_id']=hashlib.sha256(raw.encode()).hexdigest()
 candidate=dict(channel_counts=pub['observation']['counts'],quality=15,observation_identity=dict(capture_sha256=pub['observation']['sample_id'],context={'different':'raw4 namespace'}))
 prod._captures=[(capture,sample,candidate,{'capture_raw':raw})]
 full={'candidate':candidate};session.export=lambda **k:dict(status='ASSEMBLED_UNVALIDATED',proof=full)
 A.projection=types.SimpleNamespace(project_interval_json=lambda b:M.encode(dict(input_status='PROJECTED',core_ran=False,authorization='none',public_input=pub)))
 event=object();rec=Observation(o._boot,M.encode(dict(kind='telem_observation',context=CTX,observed_seq=1)),NS)
 tx=N['_InputTransaction']('observation',original_event=event);o._input_transaction=tx
 A._retain_original_association(o,event,rec,session=session,capture_ref=capture,sample_ref=sample,current_read=current,registry_ref=registry,history_refs=(),mapping_receipt=object(),source_bound_receipt=object(),dispatch_bound_receipt=object(),source_deadline_ns=NS+90_000_000,dispatch_deadline_ns=NS+80_000_000,previous_action=None,previous_deadline_ns=None)
 tx.observation_record=rec;o._runtime._observations[1]=types.SimpleNamespace(raw=rec.raw,sample_lower_ns=NS)
 adapter=A._from_composition(o)
 return o,adapter,tx,session,pub

class New(unittest.TestCase):
 def test01_real_verifier_advise_and_quantizer(self):
  p=public();ids=dict(operation_id='synthetic',run_id='r',actor_instance_id='a',invocation_id=1,tested_commit='1'*40,package_manifest_sha256=A.MANIFEST)
  wire=V.fixed_request(M.encode(dict(abi=V.ABI,kind='recommend',echo_ids=ids,enabled=True,input=p)))
  out=V.verify_pair(wire,pair(wire,ids,p),expected_ids=ids)
  target=M.quantize_target(out.result['result'],p,'fast_9600',10,Motion)
  self.assertEqual(target['action'],1);self.assertEqual(target['yaw_q'],0);self.assertEqual(target['pitch_q'],0)
  self.assertLessEqual(float(Motion.SPEED_STEP['fast_9600'])*target['speed_code'],.1)
 def test02_axes_roll_and_combined_rom(self):
  p=public()
  for x,y in ((.1,0),(-.1,0),(0,.1),(0,-.1),(.1,.1)):
   direction=[x,y,math.sqrt(1-x*x-y*y)];t=M.quantize_target(advise(p,direction),p,'fast_9600',10,Motion)
   self.assertEqual((t['yaw_q']>0)-(t['yaw_q']<0),(x>0)-(x<0));self.assertEqual((t['pitch_q']>0)-(t['pitch_q']<0),(y>0)-(y<0))
   self.assertLessEqual(t['yaw_q']**2+t['pitch_q']**2,Motion.curvature_limit_squared('fast_9600',t['speed_code']))
  p['pose']['orientation_xyzw']=[0,0,math.sqrt(.5),math.sqrt(.5)]
  t=M.quantize_target(advise(p,[0,.1,math.sqrt(.99)]),p,'fast_9600',10,Motion);self.assertGreater(t['yaw_q'],0);self.assertEqual(t['pitch_q'],0)
 def test03_speed_zero_and_duration_exact(self):
  p=public()
  self.assertEqual(M.quantize_target(advise(p,speed=.01249),p,'fast_9600',10,Motion)['action'],0)
  for speed in (.0125,.05,.1,.25):
   t=M.quantize_target(advise(p,speed=speed),p,'fast_9600',10,Motion);self.assertLessEqual(float(Motion.SPEED_STEP['fast_9600'])*t['speed_code'],speed);self.assertEqual(t['duration_ms'],10)
  with self.assertRaises(ValueError):M.quantize_target(advise(p),p,'fast_9600',101,Motion)
 def test04_finite_pair_boundaries(self):
  raw=V.frame(b'{}',2048)+V.frame(b'{}')
  for n in range(len(raw)):self.assertEqual(M.pair_state(raw[:n]),'PARTIAL')
  self.assertEqual(M.pair_state(raw),'COMPLETE')
  for bad in (raw+b'x',(2049).to_bytes(4,'little'),b'x'*18441):
   with self.assertRaises(ValueError):M.pair_state(bad)
 def test05_real_interval_candidate_complete_fake_owned_path(self):
  o,a,tx,s,p=setup();self.assertEqual(a.begin(tx),'PENDING');o._input_transaction=None
  self.assertEqual(a.advance(),'PENDING');self.assertEqual(a.advance(),'PENDING');event=a.advance()
  self.assertEqual(o._actor.write_calls,1);self.assertEqual(o._actor.read_calls,2)
  finite=a.inspect_candidate(event,o._boot);self.assertEqual(finite.deadline_ns,NS+35_000_000)
  proof=a.verify_completion(event,o._boot)
  self.assertEqual(proof.completion_upper_ns,NS+20_000_000);self.assertEqual(proof.completion_lower_ns,NS+3_000_000)
  doc=json.loads(proof.candidate_raw);self.assertEqual(doc['completion_observed_interval_ns']['lower_ns'],NS+1_000_000);self.assertNotIn('completed_monotonic_ns',doc);self.assertEqual(doc['target']['action'],1)
  with self.assertRaises(ValueError):a.verify_completion(event,o._boot)
  self.assertIsNone(o._input_transaction)
 def test06_tx_exit_replacement_and_observation_mismatch(self):
  for change in ('exit','replace','record','runtime'):
   o,a,tx,s,p=setup()
   if change=='exit':o._input_transaction=None
   elif change=='replace':o._input_transaction=N['_InputTransaction']('observation')
   elif change=='record':tx.observation_record=Observation(o._boot,b'{}',NS)
   else:o._runtime._observations[1].raw=b'{}'
   with self.assertRaises(ValueError):a.begin(tx)
   self.assertEqual(o._actor.write_calls,0);self.assertTrue(a.failed)
 def test07_unrelated_capture_and_projection(self):
  for change in ('capture','projection'):
   o,a,tx,s,p=setup()
   if change=='capture':s._producer._captures[0][2]['quality']=0
   else:p['observation']['sample_id']='c'*64
   with self.assertRaises(ValueError):a.begin(tx)
   self.assertEqual(o._actor.write_calls,0)
 def test08_pending_before_pair_and_failed_no_resend(self):
  o,a,tx,s,p=setup();a.begin(tx);o._input_transaction=None;o._actor._pending_io.all_settled=False
  self.assertEqual(a.advance(),'PENDING');self.assertEqual(o._actor.read_calls,0)
  with self.assertRaises(ValueError):a.verify_completion(object(),o._boot)
  o._actor._pending_io.all_settled=True
  def fail():raise OSError('synthetic uncertain original OS poll')
  o._actor.poll_invocation=fail
  with self.assertRaises(OSError):a.advance()
  with self.assertRaises(ValueError):a.begin(tx)
  self.assertEqual(o._actor.write_calls,1)
 def test09_cap_change_and_foreign_event(self):
  o,a,tx,s,p=setup();a.begin(tx)
  # Trusted-process tampering control: even object.__setattr__ cannot silently renew stored caps.
  object.__setattr__(tx.owned_association,'dispatch_deadline_ns',NS+100_000_000)
  with self.assertRaises(ValueError):a.advance()
  self.assertEqual(o._actor.write_calls,1)
 def test10_policy_k_and_pins(self):
  o,a,tx,s,p=setup();A._validate_config(o._config,o._clock)
  with self.assertRaises(ValueError):dataclasses.replace(a.policy,max_invocations=1).check()
  o._config.actor_policy.files=tuple((k,'0'*64 if k=='package-manifest.json' else v) for k,v in A.FILES.items())
  with self.assertRaises(ValueError):A._validate_config(o._config,o._clock)
 def test11_static_defaults_frozen_gates_and_no_source_execution(self):
  source=(D/'patched/competition/deepeye/simulation/authority/actor_composition.py').read_text(encoding='utf-8');old=(B/'C45-20261031/implementation-v1/patched/actor_composition.py').read_text(encoding='utf-8')
  def part(s,name):return next(ast.get_source_segment(s,x) for x in ast.parse(s).body if isinstance(x,ast.FunctionDef) and x.name==name)
  self.assertEqual(part(source,'_production_channels'),part(old,'_production_channels'))
  self.assertIn('owned_invocation_v1: object = None',source);self.assertIn('self._input_transaction = None',source)
  for file in (D/'package').rglob('*.py'):compile(file.read_bytes(),str(file),'exec')
  self.assertNotIn('competition.deepeye.simulation.isolation.actor_owner',sys.modules)
  self.assertNotIn('_c37_fixed_package',sys.modules)
 def test12_pending_root_continuity(self):
  for change in ('same_pose_new_root','revision','revoke','pose','book','link','executor'):
   o,a,tx,s,p=setup();a.begin(tx);o._input_transaction=None
   if change=='same_pose_new_root':o._executor._root=copy.deepcopy(o._executor._root);s._book._root=o._executor._root
   elif change=='revision':o._executor._root.pose_revision+=1
   elif change=='revoke':o._executor._root.revoke_generation+=1
   elif change=='pose':o._executor._root.pose.position_m[0]=1
   elif change=='book':s._book=types.SimpleNamespace(_root=o._executor._root)
   elif change=='link':s._link=o._world_action_link=types.SimpleNamespace(composition=o,executor=o._executor)
   else:o._executor=types.SimpleNamespace(_root=o._executor._root)
   with self.assertRaises(ValueError):a.advance()
   self.assertTrue(a.failed);self.assertIsNone(a.pending);self.assertEqual(o._actor.write_calls,1);self.assertEqual(o._actor.read_calls,0)
  o,a,tx,s,p=setup();a.begin(tx);a.advance();a.advance();event=a.advance();o._executor._root.pose_revision+=1
  with self.assertRaises(ValueError):a.verify_completion(event,o._boot)
  self.assertIsNone(a.ready);self.assertIsNone(a._retained)
 def test13_opaque_event_and_independent_proof(self):
  o,a,tx,s,p=setup();a.begin(tx);a.advance();a.advance();event=a.advance()
  for name in ('proof','record','finite','adapter'):
   with self.assertRaises(AttributeError):setattr(event,name,object())
   with self.assertRaises(AttributeError):object.__setattr__(event,name,object())
  self.assertFalse(hasattr(event,'__dict__'));finite=a.inspect_candidate(event,o._boot)
  with self.assertRaises(dataclasses.FrozenInstanceError):finite.deadline_ns=NS+999_000_000
  with self.assertRaises(ValueError):a.verify_completion(A._CompletionEvent(A._KEY),o._boot)
  self.assertTrue(a.failed);self.assertIsNone(a.pending);self.assertIsNone(a._retained)
  with self.assertRaises(ValueError):a.verify_completion(event,o._boot)
  self.assertEqual(o._actor.write_calls,1)
 def test14_exact_finite_expiry_and_original_lifetime(self):
  for delta in (-1,0,1):
   o,a,tx,s,p=setup();a.begin(tx);a.advance();a.advance();event=a.advance();finite=a.inspect_candidate(event,o._boot)
   o._progress_time=lambda:finite.deadline_ns+delta
   if delta<0:self.assertIs(a.inspect_candidate(event,o._boot),finite)
   else:
    with self.assertRaises(ValueError):a.inspect_candidate(event,o._boot)
    self.assertTrue(a.failed);self.assertIsNone(a._retained)
   self.assertEqual(o._actor.write_calls,1)
  o,a,tx,s,p=setup();a.begin(tx);a.advance();a.advance();event=a.advance()
  def dead():raise ValueError('synthetic original retained process terminated')
  o._actor._invocation_check=dead
  with self.assertRaises(ValueError):a.verify_completion(event,o._boot)
  self.assertIsNone(a.ready);self.assertIsNone(a.pending)
if __name__=='__main__':unittest.main(verbosity=2)
