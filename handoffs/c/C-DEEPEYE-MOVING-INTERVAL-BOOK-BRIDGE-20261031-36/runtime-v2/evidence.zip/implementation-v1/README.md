# C36 host interval projection implementation v1

Entry: `host_projection.project_interval_json(full_proof: bytes) -> bytes`.
All product files here are PRIVATE CANDIDATES. Main owns independent review and publication. No original service, A actor, model, native process, board or Git mutation was performed.

## Selected boundary

Host full-proof validation is pure and default off. The call reads no clocks/files/network and never loads or invokes C28. Module initialization reads only the adjacent hash-pinned finite schemas and exact C32 pure-predicate excerpts. Host accepts at most1048576 strict UTF-8 JSON bytes, validates every supplied field/crosscheck before missing/defaultoff/stale classification, and returns a finite projection result with `core_ran=false`, `authorization=none`, numerical-only claim and false native interval atomicity.

The input is the exact main addendum1 grammar SHA360b0b1d8115d5fdebee9f62137f49b50641bdcd71a3db41694b89de89848da6. It preserves real read Root/revoke/postcheck, source-bin/opened times and original ADC completion metadata. A full supplied source-prefix EM quantization/held check runs even when a source sample is not selected for the child. Missing receipts do not remove actual raw/counter/namespace/known-time/revision checks.

The output public view is exactly schema SHA046b863c6bc07bbaa5396c5b7dfc55fb1febf7bbd0bda29ef79cbd5119f981ed. C37 alone owns the later same-core child call. The view preserves actual original uint63 nanoseconds, counts/quality/poses/history and completed STEP displacements. It contains no action.at, full proof, private book data or authority token. Outer C37 serialized frame still must fit16384 including its4-byte prefix; public object<=16380 alone is not enough to claim a dispatch fits. No source admissions/history/actions are truncated.

## Semantic details

- Frozen H01-H15 and requirements hash c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804 remain unchanged. Exact C28 core SHA70b317681fee8c9182c342fe8d2f94eaecc957c62231a74a080d213bb5e0eab4 is identity only here; this implementation never executes it.
- Strict numerical span boundaries remain intact. Old usable endpoints must precede the real earliest transition; new spans must begin no earlier than real completion. The e794 reserve span through==lower cannot pass a nonspatial strict boundary. No clipping, minus1ns, fakeCAS or timestamp reset.
- Empty complete transition ledgers cannot explain multiple observed Root revisions. BOOT/COMMAND equal pose still needs exact nonspatial lineage. Partial nullable closed spans remain unavailable after all supplied known facts are checked.
- Native/scoped EM call and native ADC wire capture are separate. Original EM span covers its original actual EM call/scope close, not a later ADC call. The ADC original capture association remains independently mandatory. Held values retain original read/span/pose/Root/revoke/capture/receipt IDs and flags.
- Original quality/null/validzero/C3 startup, candidate calibration and exact100ms inclusion/+1ns expiry are preserved. Retained source admission receive times and original anchors are never rewritten.
- Structural errors raise `Rejected` with a fixed literal diagnostic (no input identity/value text). Missing/gap/stale proofs return STOP with no public input. Default-off validates all supplied structure first, then returns DISABLED only when no earlier missing fact exists.

## Explicitly NOT verified by C36 structural projection

The runtime constant `NOT_VERIFIED_BY_C36_STRUCTURAL_PROJECTION` lists: actual original receipt-digest/getter binding; live owner/source/BOOT/capture authentication; actual dispatch/read/completion freshness and one-use invocation association. JSON presence, hashes, enabled flags and synthetic receipts cannot satisfy them. A's original provider retains and independently verifies the actual objects/bytes/process/pipe/transcript before any real acceptance. C38 R1 remains separate and production channels remain unavailable.

Exact digest preimage limitation: A e794 original_world_actor_link.py340-345 hashes `kind,run_id,generation,context_sha256,command_sha256,command_seq,pose_revision,start_ns,end_ns,deadline_ns,freeze_id`. Selected public StepReceipt/Publication grammar does not contain the actual original run_id, full context_json or deadline. The host checks supplied public hash format, operation/revision/readback identities and known time consistency but DOES NOT recompute or authenticate that original digest. It does not infer run_id from boot_id or insert a replacement preimage.

## Versioned NEW focused evidence

All executions use the included `run_focused.py`, an explicit Python executable with `-I -S -B -X utf8`, timeout30seconds, no real external credentials/network. Each run retains exact source/schema/test snapshots, argv, cwd, stdout, stderr and exit. `focused-evidence.zip` is an additional lossless copy; original raw run directories remain.

| Run | Exit | Actual scope/result |
|---|---:|---|
| run01-red | 1 | One initial missing-input control against a deliberately unimplemented new stub; RED retained. |
| run02-new-controls | 1 | Eleven new controls; eight passed, three positive/default/age paths failed because EM scope span was incorrectly asked to cover later ADC call. |
| run03-em-call-fix | 0 | Only those three affected controls; true original EM call/span separated from independent ADC capture. |
| run04-new-held-lineage | 1 | Six new held/BOOT/records-only/cap/effect controls; five passed; held-positive fixture incorrectly replaced original span receipt ID. |
| run05-held-fixture-fix | 0 | Only held-positive fixture repair; runtime unchanged. |
| run06-supplied-identities-red | 1 | Two new static-gap probes exposed missing actual step BOOT/context and unselected prefix EM-value checks. |
| run07-supplied-identities-fix | 0 | Those two repairs plus affected two-revision/held positives (four controls). |
| run08-final-partial-red | 1 | Two new probes exposed empty-ledger cross-Root and nullable closed-span classification gaps. |
| run09-final-partial-fix | 0 | Those two repairs plus affected two-revision and nonspatial-boundary controls (four controls). |
| run10-large-integer-red | 1 | New main-review malformed-number probe: in-budget JSON integer 10**1000 exposed OverflowError before field bounds. |
| run11-large-integer-fix | 0 | Only that new probe; integer finite-range comparison precedes any float conversion; math.isfinite only receives floats. Existing field bounds remain unchanged. |

22 distinct NEW controls have passing evidence across explicitly versioned runs. The entire22-control set was NOT replayed on the final version; only the new malformed-number control ran on the final version in run11. Earlier results are not relabelled as final-source executions. No old C28-C35 suites were executed.

An initial static extraction attempted the old C34 author hash against its subsequently reviewed public file and failed assertion(exit1). It was corrected by reading the preserved original run10 snapshot and proving the two selected raw/counter predicate source segments byte-identical to current public SHA849d083885875668f2701fedd1c855e88c81174f312c6e0cfb0619706ef5e336. No changed C34 module was imported. See C34-pure-extraction.json; original failure remains in native tool history.

Next gate: main independent exact-source review and selected new controls. This package provides no physical, native, authenticated or formal acceptance claim.
