# C36 partial consistency repair v1

Private candidate, e794 source target. Entry remains `project_interval_json(full_proof: bytes) -> bytes`; pure host validation/projection, default off, core loads/calls zero. Main owns acceptance/publication. Input schema SHA360b0b1d8115d5fdebee9f62137f49b50641bdcd71a3db41694b89de89848da6 and child schema SHA046b863c6bc07bbaa5396c5b7dfc55fb1febf7bbd0bda29ef79cbd5119f981ed remain unchanged. A108 grammar is not adopted.

## Narrow repair

R1 checks actual supplied STEP getter times against original lower/pre-CAS/post-CAS observations independently of config presence. Original e794 `original_world_actor_link.py`281-301 retains the return and samples post-CAS;321-347 requires that observation before publication;395-427 checks the associated original readback. Therefore post-CAS <= getter is necessary. Equal QPC ticks remain allowed. No exact CAS, new clock observation, missing receipt or digest preimage is inferred.

R2 compares supplied STEP successor representations independently of `to_root`: candidate, completed transition, returned receipt, publication and custody. Actual Root/pose successors must satisfy original before+1, and STEP retains revoke generation. `_consistent_supplied` only compares present operands and never fills any absent object. A consistent missing-to-root input remains INPUT_UNAVAILABLE.

R3 compares the supplied custody pose_book_id, owner_binding_id, actor_composition_id and original_world_actor_link_id pairwise within the single composition registry, even without config/book. This is internal label consistency, not identity authentication or a replacement config.

All previous numeric/shape/budget/time/quality/held-original and strict interval boundaries remain unchanged. Missing proofs are unavailable after decidable checks; no synthetic receipts or action.at. PROJECTED is structural/numerical only, authorization none. Original receipt digest/getter binding, live source/BOOT/capture provenance, inherited process custody and one-use dispatch freshness remain independently verified A-provider obligations. This repair grants no execution authority.

## Exact extraction wording

Pinned original source, AST-equivalent extracted pure predicates; newline formatting differs. The 40 selected C32 definitions/constants and two selected C34 functions were rechecked statically for AST equivalence (42 total), and whole source hashes were verified separately. C32 fragments are not byte-identical text. No original C32/C34 module import or C28 load occurred. Earlier strict extraction comparison failures remain in the original implementation/review evidence, which was not rewritten.

## Focused evidence

Original independent seven-case run remains in `../review-implementation-v1`: exit1, five actual RED inputs and two passing controls. All seven retained input bytes exactly match this repair replay.

- `run01-review-seven`: seven affected reviewer cases, exit0, all pass.
- `run02-direct-boundaries`: eight direct checks, exit0: getter post-CAS minus1/equality, publication revision without book/candidate/to_root, custody successor without book/to_root, three other custody ID conflicts, and consistent missing-to_root.

Both runs have a30s child timeout, actual duration under1s, exact argv/stdout/stderr/exit and source snapshots. Additional checks use the explicitly pinned original reviewer synthetic partial input; no real auth or actor execution is implied. The old22 author controls and old groups were not rerun. Runtime is unchanged across both runs. Source and evidence hashes are recorded in FINAL.json and evidence-manifest.json. Original implementation artifacts were independently rehashed unchanged at sealing.

H01-H15 and fixed requirements SHA c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804 remain unchanged; original29 and physical/native/formal acceptance remain uncompleted by this work. Board authority is A only.
