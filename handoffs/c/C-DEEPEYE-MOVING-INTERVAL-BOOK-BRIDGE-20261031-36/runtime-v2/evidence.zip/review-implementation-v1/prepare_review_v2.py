import ast, hashlib, json, pathlib
D=pathlib.Path(__file__).resolve().parent;A=D.parent/'implementation-v1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
f=json.loads((A/'FINAL.json').read_bytes());assert sha(A/'FINAL.json')=='5ca4f47d5a0b86205a2e0c39d9245a335dba14dd10dfa49a44ad7f6a446be53d'
for p in f['artifacts']:assert (A/p['file']).stat().st_size==p['bytes'] and sha(A/p['file'])==p['sha256']
(D/'source-pins-before.json').write_text(json.dumps(f['artifacts'],indent=2),encoding='utf8')
ex=json.loads((A/'predicate-extraction.json').read_bytes());orig=pathlib.Path(ex['source']);assert sha(orig)==ex['source_sha256']
def nodes(path):
    text=path.read_text(encoding='utf8');tree=ast.parse(text);out={}
    for n in tree.body:
        if isinstance(n,(ast.FunctionDef,ast.ClassDef)):out[n.name]=ast.get_source_segment(text,n)
        elif isinstance(n,ast.Assign):
            for t in n.targets:
                if isinstance(t,ast.Name):out[t.id]=ast.get_source_segment(text,n)
    return out
left,right=nodes(orig),nodes(A/'frozen_source_predicates.py');exact={}
for name in ex['definitions']+ex['constants']:
    assert ast.dump(ast.parse(left[name]), include_attributes=False)==ast.dump(ast.parse(right[name]), include_attributes=False),name
    exact[name]=hashlib.sha256(left[name].encode()).hexdigest()
old=json.loads((A/'C34-pure-extraction.json').read_bytes());c34=pathlib.Path(old['saved_source']);left=nodes(c34);right=nodes(A/'host_projection.py')
for name in old['definitions']:assert ast.dump(ast.parse(left[name]), include_attributes=False)==ast.dump(ast.parse(right[name]), include_attributes=False),name;exact[name]=hashlib.sha256(left[name].encode()).hexdigest()
(D/'extraction-verification.json').write_text(json.dumps({'source_text_comparison':'AST equivalent selected segments; C32 extraction adds blank lines and is NOT byte-exact source text; original file hashes separately verified','segments':exact,'core_imports':0},indent=2),encoding='utf8')
index=json.loads((A/'run-index.json').read_bytes());runs=[]
for r in index:
    run=A/r['directory'];logs={p.name:p.read_text(encoding='utf8') for p in run.glob('*.txt')}
    runs.append({'directory':r['directory'],'exit_code':r['exit_code'],'logs':logs,'source_pins':r['source_pins']})
(D/'author-versioned-raw-review.json').write_text(json.dumps(runs,indent=2),encoding='utf8')
# Reuse only the documented synthetic fixture generator, not imports or any tests.
# New mutations run later from the retained JSON baseline, with no author-test dependency.
testsource=(A/'test_host_projection.py').read_text(encoding='utf8');tree=ast.parse(testsource)
parts=[ast.get_source_segment(testsource,n) for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ('raw','fixture')]
assert len(parts)==2
source='import copy, hashlib, json\n'+ '\n\n'.join(parts)+'\n'
(D/'fixture-builder-excerpt.py').write_text(source,encoding='utf8')
namespace={};exec(compile(source,'synthetic_fixture_builder_excerpt','exec'),namespace)
baseline=namespace['fixture'](origin=(1<<60)+987654321,last_tick=100)
(D/'baseline-synthetic.json').write_bytes(namespace['raw'](baseline))
print(json.dumps({'frozen_artifacts':len(f['artifacts']),'exact_segments':len(exact),'versioned_runs_read':len(runs),'author_tests_executed':0,'baseline':'synthetic generator excerpt only; distinct absolute origin'}))

