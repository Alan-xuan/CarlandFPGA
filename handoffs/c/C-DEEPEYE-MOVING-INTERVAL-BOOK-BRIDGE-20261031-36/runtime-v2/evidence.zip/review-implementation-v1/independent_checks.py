"""New C36 review probes. Retained synthetic JSON data, no author test import."""
import argparse,copy,hashlib,importlib.util,json,pathlib,sys
def main():
    ap=argparse.ArgumentParser();ap.add_argument('implementation',type=pathlib.Path);ap.add_argument('baseline',type=pathlib.Path);ap.add_argument('output',type=pathlib.Path)
    a=ap.parse_args();a.output.mkdir(exist_ok=False)
    spec=importlib.util.spec_from_file_location('c36_review_candidate',a.implementation/'host_projection.py')
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    base=json.loads(a.baseline.read_bytes());origin=base['actor_book']['source_origin_qpc_ns']
    def assoc(x):return x['root_receipt']['actor_registry']['associations'][0]
    def trans(x):return x['actor_book']['actor_pose_intervals']['transitions'][0]
    def bad_getter(x):
        trans(x)['getter_readback_qpc_ns']=origin+60_000_000
        assoc(x)['publication']['getter_readback_qpc_ns']=origin+60_000_000
    def bad_candidate(x):
        assoc(x)['to_root']=None
        assoc(x)['candidate_root']['root_revision']=3
        assoc(x)['candidate_root']['pose_revision']=3
    def wrong_returned_pose(x):
        assoc(x)['to_root']=None
        assoc(x)['step_receipt']['pose_revision']=3
    def custody_pair(x,conflict=False):
        template=copy.deepcopy(assoc(x)['custody'])
        x.update(candidate=None,history=[],actor_book=None,enabled=False)
        root=x['root_receipt'];root.update(config=None,captures=None,current_pose=None,source_admissions=None)
        items=[]
        for i in range(2):
            custody=copy.deepcopy(template);custody.update(before_root_revision=0,after_root_revision=0,successor_state='original_nonspatial')
            if i and conflict:custody['owner_binding_id']='different-supplied-owner'
            items.append(dict(receipt_id=None,action_id=None,transition_key=dict(kind='COMMAND',before_root_revision=0,from_pose_revision=0,lower_observed_qpc_ns=origin+10+i),
                observation_capture_sha256=None,from_root=None,to_root=None,candidate_root=None,custody=custody,step_receipt=None,publication=None,nonspatial_receipt=None))
        root['actor_registry']['associations']=items
    cases=[]
    def add(name,expected,change):
        x=copy.deepcopy(base);change(x);cases.append((name,expected,x))
    add('new-origin-complete-control','PROJECTED',lambda x:None)
    add('getter-before-transition-lower','REJECTED',bad_getter)
    add('getter-before-transition-with-missing-config','REJECTED',lambda x:(bad_getter(x),x['root_receipt'].update(config=None)))
    add('candidate-successor-skips-root-with-missing-to-root','REJECTED',bad_candidate)
    add('returned-revision-conflicts-with-candidate-missing-to-root','REJECTED',wrong_returned_pose)
    add('partial-two-custodies-same-owner','INPUT_UNAVAILABLE',custody_pair)
    add('partial-two-custodies-conflicting-owner','REJECTED',lambda x:custody_pair(x,True))
    rows=[]
    for name,expected,x in cases:
        raw=json.dumps(x,sort_keys=True,separators=(',',':')).encode();(a.output/(name+'.input.json')).write_bytes(raw)
        try:
            output=m.project_interval_json(raw);observed=json.loads(output)['input_status'];details=json.loads(output)
        except m.Rejected as exc:
            observed='REJECTED';details={'exception':'Rejected','reason':str(exc)};output=json.dumps(details).encode()
        except Exception as exc:
            observed='UNEXPECTED_EXCEPTION';details={'exception':type(exc).__name__,'reason':str(exc)};output=json.dumps(details).encode()
        (a.output/(name+'.output.json')).write_bytes(output)
        row=dict(name=name,expected=expected,observed=observed,passed=expected==observed,input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(output).hexdigest(),details=details)
        rows.append(row);print(json.dumps(row),flush=True)
    assert not any('frozen_c28' in k or '_c37' in k for k in sys.modules)
    (a.output/'results.json').write_text(json.dumps(rows,indent=2),encoding='utf8')
    return 0 if all(r['passed'] for r in rows) else 1
if __name__=='__main__':raise SystemExit(main())
