import datetime,hashlib,json,pathlib,subprocess,sys
D=pathlib.Path(__file__).resolve().parent;A=D.parent/'implementation-v1'
argv=[sys.executable,'-I','-B',str(D/'independent_checks.py'),str(A),str(D/'baseline-synthetic.json'),str(D/'new-evidence')]
start=datetime.datetime.now(datetime.timezone.utc).isoformat();r=subprocess.run(argv,capture_output=True,cwd=D,timeout=30)
(D/'new.stdout').write_bytes(r.stdout);(D/'new.stderr').write_bytes(r.stderr)
row=dict(argv=argv,timeout_seconds=30,started_utc=start,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=r.returncode,stdout_sha256=hashlib.sha256(r.stdout).hexdigest(),stderr_sha256=hashlib.sha256(r.stderr).hexdigest())
(D/'new.command-exit.json').write_text(json.dumps(row,indent=2),encoding='utf8');print(json.dumps(row))
print(json.dumps([{k:x[k]for k in ('name','expected','observed','passed')} for x in json.loads((D/'new-evidence/results.json').read_bytes())]))
raise SystemExit(r.returncode)
