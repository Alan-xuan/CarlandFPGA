# C36 A108 host v2 private implementation

Explicit adaptation of repaired runtime123180e6296c395e5eb9569ca755247ae5565ffae8b8682cf666a8b01c344dd6 to original A108 target51c48e106c76f3e4d18000da61be17dd8a4b6623. See ABI.md for exact original-to-host field mapping and remaining provider proof. Earlier implementation/repair directories are immutable. Main owns independent acceptance and publication.

New host schema SHA ab1b432e9f337523fd75057fec4647f5eda2569de308e7c777507e05907bdd70. Child schema remains SHA046b863c6bc07bbaa5396c5b7dfc55fb1febf7bbd0bda29ef79cbd5119f981ed. No core call, model, native actor, board or service execution occurred. Only one exact read-only GET fetched target51c root_source_book.py; Git blob/path/size checks and raw response/exit are preserved. A108 custody source was copied from the previously verified read-only cache and checked against A's exact SHA0cb3438533a7fec25ac4dc7c0072de7c6de7e3acff5a84ecaf7d1636614ed671.

## Bounded NEW adaptation evidence

- run01-new-span-red: exit1, one strict STEP new-schema input against the not-yet-adapted old equality mapping; actual RED retained.
- run02-new-adaptation: exit0,13 new adaptation controls: strict STEP/BOOT/COMMAND; all three ties; late endpoint; missingoldspan; Root identity mismatch despite missingconfig; closedspan mismatch; interval-only export without actualgetter; missingactualread; getter validspan endpoint mismatch.
- run03-missing-span-red: exit1, one new same-path combination showed that absent old_pose_span could hide an incompatible supplied closed-span tie.
- run04-missing-span-fix: exit0, only that negative plus consistent-null and strictSTEP positives. Necessary compatible-closed-span checks do not fill missing proof.

14 distinct new controls have version-specific evidence. Final runtime executed only the three run04 controls; run02 is not relabelled as final-source testing. The original22 controls and prior15 repair controls were not rerun. All runs have30s subprocess bounds and exact argv/cwd/source snapshots/stdout/stderr/exit. Synthetic fixture alterations use explicit synthetic timestamps and labels; no actual historic record was upgraded or renewed. The test named current-getter-span-after-real-read actually supplies through=at-1, testing equality rejection; the exact raw input is authoritative.

Pinned original source and AST-equivalent extracted pure predicates remain unchanged; newline formatting differs, so copied C32 fragments are not claimed byte-identical source text. R1/R2/R3 source predicates remain present and the previous repair's files were rehashed unchanged. Raw full implementation and schema diffs are included.

H01-H15 requirements SHA c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804 remains fixed. No formal/physical/native acceptance or production authorization is asserted. Scope releases with empty jobs/subprocesses for independent main review.
