"""NEW synthetic C36 -> delivered C37 -> original C28 boundary check.

Usage: python -I -S -B independent_boundary_checks.py C36_DIR C37_DIR INPUT_DIR OUTPUT_DIR
Uses JSON fixture data only. No author tests, actor, transport, native API or A module.
The dispatch counter denotes a local process_wire function call, not real dispatch.
"""
import copy,hashlib,importlib.util,json,pathlib,sys
from fractions import Fraction
hostdir,childdir,inputs,out=map(pathlib.Path,sys.argv[1:]);out.mkdir(exist_ok=False)
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(name,obj):
 b=json.dumps(obj,sort_keys=True,separators=(',',':'),allow_nan=False).encode();(out/name).write_bytes(b);return b
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
assert sha((hostdir/'host_projection.py').read_bytes())=='7defaee9318f9a33a0586628661d054c028b5952584030ebc3b771a479a8982e'
assert sha((childdir/'c37_package.py').read_bytes())=='fa04f09e655ab514a7d7569bec4583e326006312c245e08ec44f21a7e6191b07'
assert sha((childdir/'frozen_c28.py').read_bytes())=='70b317681fee8c9182c342fe8d2f94eaecc957c62231a74a080d213bb5e0eab4'
host_core_calls=[]
def hostprofile(frame,event,arg):
 if event=='call' and frame.f_code.co_name=='recommend':host_core_calls.append(frame.f_code.co_filename)
sys.setprofile(hostprofile)
host=load('independent_c36',hostdir/'host_projection.py')
full=(inputs/'complete-synthetic.input.json').read_bytes();missing=(inputs/'missing-current.input.json').read_bytes()
projectedraw=host.project_interval_json(full);missingraw=host.project_interval_json(missing)
sys.setprofile(None)
(out/'complete.projection.json').write_bytes(projectedraw);(out/'missing.projection.json').write_bytes(missingraw)
projected=json.loads(projectedraw);unavailable=json.loads(missingraw)
assert host_core_calls==[]
assert not any('c28' in name.lower() for name in sys.modules)
assert projected['input_status']=='PROJECTED' and projected['core_ran'] is False
assert unavailable['input_status']=='INPUT_UNAVAILABLE' and unavailable['status']=='STOP'
assert unavailable['reason']=='MISSING_CURRENT_READ' and unavailable['public_input'] is None and unavailable['core_ran'] is False
child=load('independent_c37',childdir/'c37_package.py')
assert child._CORE.__code__ is child._FROZEN.recommend.__code__
assert set(child._CORE.__globals__)==set(child._FROZEN.recommend.__globals__)
changed=[k for k in child._CORE.__globals__ if child._CORE.__globals__[k] is not child._FROZEN.recommend.__globals__[k]]
assert changed==['_validate'],changed
original_globals=child._FROZEN.recommend.__globals__.copy();local_globals=child._CORE.__globals__.copy()
ids=dict(operation_id='C36-A108-INDEPENDENT-SYNTHETIC',run_id='synthetic-run-boundary',actor_instance_id='synthetic-no-process',invocation_id=1,tested_commit='5'*40,package_manifest_sha256=sha((childdir/'package-manifest.json').read_bytes()))
counts={'serialization':0,'local_process_wire':0};core_calls=[];internal_observations=[]
def coreprofile(frame,event,arg):
 if event=='call' and frame.f_code is child._CORE.__code__:
  core_calls.append(frame.f_code.co_filename)
  internal=frame.f_locals['request']
  assert type(internal['now_tick_ms']) is Fraction
  assert internal['now_tick_ms']*1_000_000==projected['public_input']['now_qpc_ns']
  for public,private in zip(projected['public_input']['history']+[projected['public_input']['observation']],internal['history']+[internal['observation']]):
   assert private['em_pose']==public['em_pose'] and private['adc_pose']==public['adc_pose']
   for key in ('adc','em'):
    if public[key+'_qpc_ns'] is None:assert private[key+'_tick_ms'] is None
    else:assert type(private[key+'_tick_ms']) is Fraction and private[key+'_tick_ms']*1_000_000==public[key+'_qpc_ns']
   internal_observations.append(dict(sample_id=public['sample_id'],adc_qpc_ns=public['adc_qpc_ns'],em_qpc_ns=public['em_qpc_ns'],em_pose=public['em_pose']))
def local_gate(result):
 if result['input_status']!='PROJECTED':return None
 counts['serialization']+=1
 wire=child.make_request(ids,result['public_input'],enabled=True)
 assert len(wire)<=16384 and int.from_bytes(wire[:4],'little')==len(wire)-4
 (out/'request.wire').write_bytes(wire);dump('request.envelope.json',json.loads(wire[4:]))
 counts['local_process_wire']+=1
 return child.process_wire(wire)
assert local_gate(unavailable) is None and counts=={'serialization':0,'local_process_wire':0}
missing_result=dict(case='missing-original-current-read-local-gate',passed=True,host_core_calls=0,serialization_calls=0,local_process_wire_calls=0,actual_provider_dispatch='NOT_RUN',input_sha256=sha(missing))
print(json.dumps(missing_result),flush=True)
before_public=copy.deepcopy(projected)
sys.setprofile(coreprofile)
response=local_gate(projected)
sys.setprofile(None)
assert len(core_calls)==1 and counts=={'serialization':1,'local_process_wire':1}
assert child._FROZEN.recommend.__globals__==original_globals and child._CORE.__globals__==local_globals
assert projected==before_public
frames=[];offset=0
while offset<len(response):
 size=int.from_bytes(response[offset:offset+4],'little');assert size>0 and offset+4+size<=len(response)
 frames.append(json.loads(response[offset+4:offset+4+size]));offset+=4+size
assert len(frames)==2 and [x['kind']for x in frames]==['READY','RESULT']
wire=(out/'request.wire').read_bytes()
for f in frames:assert f['echo_ids']==ids and f['request_wire_sha256']==sha(wire) and f['authority']=='none'
r=frames[1];assert r['status']=='RESULT' and r['core_ran'] is True and r['completion_grant'] is False
assert r['result']['observation']==projected['public_input']['observation']
by_id={o['sample_id']:o for o in projected['public_input']['history']+[projected['public_input']['observation']]}
for cell in r['result']['map_cells']:assert cell['em_qpc_ns']==by_id[cell['sample_id']]['em_qpc_ns']
assert full==(inputs/'complete-synthetic.input.json').read_bytes() and missing==(inputs/'missing-current.input.json').read_bytes()
(out/'response.wire').write_bytes(response);dump('response.frames.json',frames);dump('observed-original-times-poses.json',internal_observations)
complete_result=dict(case='complete-projection-exact-c37-single-c28',passed=True,host_core_calls=0,child_original_core_calls=1,original_code_object_identical=True,changed_global_keys=changed,globals_stable=True,wire_bytes=len(wire),response_bytes=len(response),wire_sha256=sha(wire),input_sha256=sha(full),core_result_status=r['result']['status'],core_result_reason=r['result']['reason'],exact_original_qpc_pose=True,actual_actor_native_board='NOT_RUN')
print(json.dumps(complete_result),flush=True);dump('results.json',[missing_result,complete_result])
