from pathlib import Path
import sys,subprocess,json,hashlib,time
p=Path(__file__).resolve().parent;r=p/sys.argv[1];r.mkdir(exist_ok=False)
files=['test_progress.py','run_checks.py','prepare_patch.py']+['patched/'+n for n in ('actor_composition.py','candidate_owner.py','candidate_mailbox.py')]
for name in files:
 f=r/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes((p/name).read_bytes())
argv=[sys.executable,'-I','-B','-X','utf8',str(p/'test_progress.py'),'-v']+sys.argv[2:];start=time.monotonic()
try:q=subprocess.run(argv,cwd=p,timeout=30,capture_output=True);code=q.returncode;out=q.stdout;err=q.stderr
except subprocess.TimeoutExpired as e:code=124;out=e.stdout or b'';err=e.stderr or b''
(r/'stdout.txt').write_bytes(out);(r/'stderr.txt').write_bytes(err)
result=dict(argv=argv,cwd=str(p),timeout_s=30,elapsed_s=time.monotonic()-start,exit_code=code,pins={n:hashlib.sha256((p/n).read_bytes()).hexdigest()for n in files})
(r/'command.json').write_text(json.dumps(result,indent=2),encoding='utf8');print(json.dumps(result));print(err.decode('utf8',errors='replace'));raise SystemExit(code)
