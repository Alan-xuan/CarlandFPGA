from pathlib import Path
import ast,hashlib,json
P=Path(__file__).resolve().parent
allowed={
 'actor_composition.py':{'AuthorityConfig','_BoundProgress','_ProgressGate.__init__','_ProgressGate._admit','ActorComposition.accept_boot','create_authority','_create_authority_for_original_world'},
 'candidate_owner.py':{'_CompletedInference','_CandidateOwner.__init__','_CandidateOwner.offer'},
 'candidate_mailbox.py':{'ObservedIntervalBoundsV2','_validate_interval_candidate','Completion','LatestCompletedMailbox.activate','LatestCompletedMailbox.complete'}}
def blocks(tree):
 out={}
 for n in tree.body:
  if isinstance(n,ast.FunctionDef):out[n.name]=ast.dump(n,include_attributes=False)
  elif isinstance(n,ast.ClassDef):
   methods=[x for x in n.body if isinstance(x,ast.FunctionDef)]
   if methods:
    for x in methods:out[n.name+'.'+x.name]=ast.dump(x,include_attributes=False)
    n.body=[x for x in n.body if not isinstance(x,ast.FunctionDef)]
   out[n.name]=ast.dump(n,include_attributes=False)
 return out
report={}
for name,expected in allowed.items():
 a=blocks(ast.parse((P/'inputs'/name).read_text()));b=blocks(ast.parse((P/'patched'/name).read_text()))
 changed={k for k in a.keys()|b.keys()if a.get(k)!=b.get(k)}
 assert changed==expected,(name,changed,expected)
 report[name]={'changed_ast_blocks':sorted(changed),'unchanged_blocks':sorted(a.keys()-changed),'input_sha256':hashlib.sha256((P/'inputs'/name).read_bytes()).hexdigest(),'patched_sha256':hashlib.sha256((P/'patched'/name).read_bytes()).hexdigest()}
c43=P.parents[1]/'C43-20261031/implementation-v1'
pins={'completion_interval.py':'05da98393d47f3eaf4690d8979d2e37d2e4f1e0b00c801177a3fb6a3f84bbe96','patched/integration/host_envelope.py':'20b2221491825964f91381f68053a13bf3867347d35896ce1dd132c4a8972c3b','completion-interval-successor.patch':'37f6b42d5d7a662a86d1e787b63896ae36ab0fee868fc0ef48c65ea6ba4fb22d'}
for n,pin in pins.items():assert hashlib.sha256((c43/n).read_bytes()).hexdigest()==pin
report['C43_required_unchanged']=pins
print(json.dumps(report,indent=2))
