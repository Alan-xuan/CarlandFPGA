from pathlib import Path
import difflib,json,hashlib
P=Path(__file__).resolve().parent
def replace(s,a,b):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,b)
texts={n:(P/'inputs'/n).read_text(encoding='utf8')for n in ('actor_composition.py','candidate_owner.py','candidate_mailbox.py')}
s=texts['candidate_mailbox.py']
s=replace(s,'@dataclass(frozen=True)\nclass Completion:', '''@dataclass(frozen=True)
class ObservedIntervalBoundsV2:
    """Original verifier-retained lifetime bounds; labels/types grant no authority."""
    max_age_ns: int
    source_deadline_ns: int
    dispatch_deadline_ns: int
    previous_deadline_ns: int | None


def _validate_interval_candidate(record, context, now, max_age=None):
    bounds = record.observed_interval_v2
    if type(bounds) is not ObservedIntervalBoundsV2:
        raise ValueError('original observed-interval bounds required')
    age = _integer(bounds.max_age_ns, 'max_age_ns', 1, 100_000_000)
    if max_age is not None and age != max_age:
        raise ValueError('original configured progress age differs')
    _integer(bounds.source_deadline_ns, 'source_deadline_ns')
    _integer(bounds.dispatch_deadline_ns, 'dispatch_deadline_ns')
    if bounds.previous_deadline_ns is not None:
        _integer(bounds.previous_deadline_ns, 'previous_deadline_ns')
    dispatch = _integer(record.dispatch_lower_ns, 'dispatch_lower_ns')
    lower = _integer(record.completion_lower_ns, 'completion_lower_ns')
    upper = _integer(record.completion_upper_ns, 'completion_upper_ns')
    if not dispatch <= lower <= upper <= now:
        raise ValueError('original observed interval is not ordered')
    parsed = envelope.validate_message(record.candidate_raw, producer='ai_controller',
        consumer='control_broker', context=context, now_ns=now,
        enable_completion_interval=True, completion_bounds=dict(max_age_ns=age,
            source_deadline_ns=bounds.source_deadline_ns,
            dispatch_deadline_ns=bounds.dispatch_deadline_ns,
            previous_deadline_ns=bounds.previous_deadline_ns))
    doc = parsed.document
    if (doc['basis'] != 'host_dispatch_to_complete_result_observed_v1' or
            doc['completion_observed_interval_ns']['lower_ns'] != dispatch or
            doc['completion_observed_interval_ns']['upper_ns'] != upper):
        raise ValueError('candidate differs from retained original dispatch/RESULT bounds')
    return parsed


@dataclass(frozen=True)
class Completion:''')
s=replace(s,'    deadline_ns: int\n\n\n@dataclass(frozen=True)\nclass SlotGrant:', '    deadline_ns: int\n    observed_interval_v2: ObservedIntervalBoundsV2 | None = None\n\n\n@dataclass(frozen=True)\nclass SlotGrant:')
s=replace(s,'clock_domain, bounds, now_ns, pc_direct_window_v2=None):','clock_domain, bounds, now_ns, pc_direct_window_v2=None,\n                 enable_completion_interval_v2=False):')
s=replace(s,"        self._halt('activation_replaced')\n        now", "        self._halt('activation_replaced')\n        if type(enable_completion_interval_v2) is not bool:\n            raise ValueError('strict interval opt-in required')\n        self._enable_completion_interval_v2 = enable_completion_interval_v2\n        now")
s=replace(s,"        parsed = envelope.validate_message(record.candidate_raw, producer='ai_controller',\n            consumer='control_broker', context=self._context, now_ns=now)","""        if self._enable_completion_interval_v2:
            parsed = _validate_interval_candidate(record, self._context, now)
            if record.deadline_ns != parsed.valid_until_ns:
                raise ValueError('completion deadline differs from retained original caps')
        else:
            if record.observed_interval_v2 is not None:
                raise ValueError('observed interval requires explicit activation opt-in')
            parsed = envelope.validate_message(record.candidate_raw, producer='ai_controller',
                consumer='control_broker', context=self._context, now_ns=now)""")
s=replace(s,'        last = self._completed\n', '        if self._enable_completion_interval_v2:\n            fingerprint += (record.observed_interval_v2,)\n        last = self._completed\n')
s=replace(s,"        if not (self._started <= record.dispatch_lower_ns <= record.completion_lower_ns\n                <= doc['completed_monotonic_ns'] <= record.completion_upper_ns <= now", """        if self._enable_completion_interval_v2:
            if observation.sample_lower_ns is None:
                raise ValueError('original observation acquisition bound unavailable')
            source_cap = _integer(observation.sample_lower_ns + self._age_cap, 'source cap')
            if record.observed_interval_v2.source_deadline_ns > source_cap:
                raise ValueError('source bound exceeds original observation lifetime')
            completion_ordered = record.completion_lower_ns <= record.completion_upper_ns
        else:
            completion_ordered = record.completion_lower_ns <= doc['completed_monotonic_ns'] <= record.completion_upper_ns
        if not (self._started <= record.dispatch_lower_ns <= record.completion_lower_ns
                and completion_ordered and record.completion_upper_ns <= now""")
texts['candidate_mailbox.py']=s
s=texts['candidate_owner.py']
s=replace(s,'    completion_upper_ns: int\n', '    completion_upper_ns: int\n    observed_interval_v2: mailbox.ObservedIntervalBoundsV2 | None = None\n')
s=replace(s,'activation, now, *, pc_direct_window_v2=None):','activation, now, *, pc_direct_window_v2=None,\n                 enable_completion_interval_v2=False):')
s=replace(s,'        self._pending = self._current = None\n        self._retired',"        if type(enable_completion_interval_v2) is not bool:\n            raise ValueError('strict interval opt-in required')\n        self._enable_completion_interval_v2 = enable_completion_interval_v2\n        self._pending = self._current = None\n        self._retired")
s=replace(s,'            pc_direct_window_v2=pc_direct_window_v2)','            pc_direct_window_v2=pc_direct_window_v2,\n            enable_completion_interval_v2=enable_completion_interval_v2)')
s=replace(s,"        parsed = host_envelope.validate_message(proof.candidate_raw,producer='ai_controller',\n            consumer='control_broker',context=self._context,now_ns=now)","""        if self._enable_completion_interval_v2:
            parsed = mailbox._validate_interval_candidate(proof, self._context, now, self._age)
        else:
            if proof.observed_interval_v2 is not None:
                raise ValueError('observed interval requires explicit owner opt-in')
            parsed = host_envelope.validate_message(proof.candidate_raw,producer='ai_controller',
                consumer='control_broker',context=self._context,now_ns=now)""")
s=replace(s,"        claimed = _bounded(parsed.document['completed_monotonic_ns'])\n        if not self._started <= dispatch <= lower <= claimed <= upper <= now:\n            raise ValueError('original ordered completion timeline required')\n        deadline = _bounded(lower + self._age)","""        if self._enable_completion_interval_v2:
            if not self._started <= dispatch <= lower <= upper <= now:
                raise ValueError('original ordered observation timeline required')
            deadline = _bounded(parsed.valid_until_ns)
        else:
            claimed = _bounded(parsed.document['completed_monotonic_ns'])
            if not self._started <= dispatch <= lower <= claimed <= upper <= now:
                raise ValueError('original ordered completion timeline required')
            deadline = _bounded(lower + self._age)""")
s=replace(s,'            proof.candidate_raw,invocation,dispatch,lower,upper,deadline)','            proof.candidate_raw,invocation,dispatch,lower,upper,deadline,proof.observed_interval_v2)')
texts['candidate_owner.py']=s
s=texts['actor_composition.py']
s=replace(s,'from ...integration.candidate_mailbox import PcDirectWindowV2','from ...integration.candidate_mailbox import PcDirectWindowV2, _validate_interval_candidate')
s=replace(s,'    pc_direct_window_v2: PcDirectWindowV2 | None = None\n','    pc_direct_window_v2: PcDirectWindowV2 | None = None\n    enable_completion_interval_v2: bool = False\n')
s=replace(s,'    deadline_ns: int\n','    deadline_ns: int\n    observed_interval_v2: object = None\n')
s=replace(s,'def __init__(self, boot, source, clock_domain, model_hash, max_age, now):','def __init__(self, boot, source, clock_domain, model_hash, max_age, now, *,\n                 enable_completion_interval_v2=False):')
s=replace(s,'        self.boot, self.source, self.clock_domain = boot, source, clock_domain',"        if type(enable_completion_interval_v2) is not bool:\n            raise ValueError('strict interval opt-in required')\n        self.enable_completion_interval_v2 = enable_completion_interval_v2\n        self.boot, self.source, self.clock_domain = boot, source, clock_domain")
s=replace(s,"        candidate = host_envelope.validate_message(proof.candidate_raw, producer='ai_controller',\n            consumer='control_broker', context=self.context, now_ns=now)","""        if self.enable_completion_interval_v2:
            candidate = _validate_interval_candidate(proof, self.context, now, self.max_age)
        else:
            if proof.observed_interval_v2 is not None:
                raise ValueError('observed interval requires explicit progress opt-in')
            candidate = host_envelope.validate_message(proof.candidate_raw, producer='ai_controller',
                consumer='control_broker', context=self.context, now_ns=now)
        interval_deadline = candidate.valid_until_ns if self.enable_completion_interval_v2 else None""")
s=replace(s,"        claimed = _bounded(candidate['completed_monotonic_ns'])\n",'')
s=replace(s,"        if not self.started <= dispatch <= lower <= claimed <= upper <= issue <= now:\n            raise ValueError('completion interval lacks ordered original host-time bounds')\n        deadline = _bounded(lower + self.max_age)","""        if self.enable_completion_interval_v2:
            if not self.started <= dispatch <= lower <= upper <= issue <= now:
                raise ValueError('observation interval lacks ordered original host-time bounds')
            deadline = _bounded(interval_deadline)
        else:
            claimed = _bounded(candidate['completed_monotonic_ns'])
            if not self.started <= dispatch <= lower <= claimed <= upper <= issue <= now:
                raise ValueError('completion interval lacks ordered original host-time bounds')
            deadline = _bounded(lower + self.max_age)""")
s=replace(s,'            invocation, dispatch, lower, upper, deadline)','            invocation, dispatch, lower, upper, deadline, proof.observed_interval_v2)')
s=replace(s,'            self._config.ai_model_sha256, self._config.progress_max_age_ns, self._clock())','            self._config.ai_model_sha256, self._config.progress_max_age_ns, self._clock(),\n            enable_completion_interval_v2=self._config.enable_completion_interval_v2)')
s=replace(s,'            pc_direct_window_v2=self._config.pc_direct_window_v2)','            pc_direct_window_v2=self._config.pc_direct_window_v2,\n            enable_completion_interval_v2=self._config.enable_completion_interval_v2)')
# Both existing factories retain their original gates; add strict config type checking.
anchor='    _bounded(config.progress_max_age_ns, 1)\n';assert s.count(anchor)==2
s=s.replace(anchor,anchor+"    if type(config.enable_completion_interval_v2) is not bool:\n        raise CompositionRejected('strict interval opt-in required')\n")
texts['actor_composition.py']=s
(P/'patched').mkdir(exist_ok=True)
for name,text in texts.items():
 (P/'patched'/name).write_text(text,encoding='utf8',newline='\n')
 old=(P/'inputs'/name).read_text(encoding='utf8');kind='integration'if name=='candidate_mailbox.py'else'simulation/authority'
 (P/(name+'.patch')).write_text(''.join(difflib.unified_diff(old.splitlines(True),text.splitlines(True),fromfile='a/competition/deepeye/'+kind+'/'+name,tofile='b/competition/deepeye/'+kind+'/'+name)),encoding='utf8')
print(json.dumps({n:hashlib.sha256((P/'patched'/n).read_bytes()).hexdigest()for n in texts}))
