"""NEW C45 pure extracted branch controls; no original factory/native activation."""
import ast,copy,dataclasses,hashlib,importlib.util,json,sys,types,unittest
from pathlib import Path
from collections import OrderedDict
from fractions import Fraction
from functools import wraps
P=Path(__file__).resolve().parent;C43=P.parents[1]/'C43-20261031/implementation-v1'
BASELINE='--baseline'in sys.argv
if BASELINE:sys.argv.remove('--baseline')
sys.path.insert(0,str(C43/'dependencies/attempt02/vendor'))
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
assert hashlib.sha256((C43/'patched/integration/host_envelope.py').read_bytes()).hexdigest()=='20b2221491825964f91381f68053a13bf3867347d35896ce1dd132c4a8972c3b'
assert hashlib.sha256((C43/'completion_interval.py').read_bytes()).hexdigest()=='05da98393d47f3eaf4690d8979d2e37d2e4f1e0b00c801177a3fb6a3f84bbe96'
host=load('c45_host',C43/'patched/integration/host_envelope.py')
def extract(name,file,names=None,**supplied):
 source=(P/('inputs'if BASELINE else'patched')/file).read_text();tree=ast.parse(source)
 nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))and(names is None or n.name in names)]
 mod=types.ModuleType(name);sys.modules[name]=mod;mod.__dict__.update(dataclass=dataclasses.dataclass,wraps=wraps,OrderedDict=OrderedDict,Fraction=Fraction,json=json,Path=Path,MAX_TIME=(1<<63)-1,_MAX_NS=(1<<63)-1,NS_PER_MS=1_000_000,MAX_OBSERVATIONS=4,MAX_ACTIVATIONS=64,**supplied)
 exec(compile(ast.Module(body=nodes,type_ignores=[]),str(P/file),'exec'),mod.__dict__);return mod
mail=extract('c45_mail','candidate_mailbox.py',envelope=host,boot=types.SimpleNamespace())
owner=extract('c45_owner','candidate_owner.py',mailbox=mail,host_envelope=host,BootBinding=object,boot_profile=types.SimpleNamespace())
progress=extract('c45_progress','actor_composition.py',names={'_bounded','_BoundProgress','_ProgressGate'},host_envelope=host,_CompletedInference=owner._CompletedInference,_validate_interval_candidate=getattr(mail,'_validate_interval_candidate',None))
B=(1<<60)+987654321;MS=1_000_000
CTX=dict(session=9,config_epoch=1,boot_sha256='a'*64,transport_profile_id=1,source_id=1,topology_id=2,acquisition_profile_id=1)
def raw(x):return json.dumps(x,sort_keys=True,separators=(',',':')).encode()
def document(dispatch=B+10*MS,upper=B+20*MS,cid=5,v2=True):
 c=dict(schema_version=2 if v2 else 1,context=copy.deepcopy(CTX),kind='model_candidate',candidate_id=cid,model_sha256='b'*64,observation=dict(context=copy.deepcopy(CTX),observed_seq=7),target=dict(action=1,yaw_q=0,pitch_q=0,speed_code=1,duration_ms=10))
 if v2:c.update(completion_observed_interval_ns=dict(lower_ns=dispatch,upper_ns=upper),basis='host_dispatch_to_complete_result_observed_v1')
 else:c['completed_monotonic_ns']=upper
 return c
def request(c,seq=1,issue=B+25*MS):return raw(dict(schema_version=1,kind='motion_request',context=copy.deepcopy(CTX),command_seq=seq,candidate_id=c['candidate_id'],observation=c['observation'],target=c['target'],host_issue_monotonic_ns=issue))
def fixture(v2=True):
 boot=types.SimpleNamespace(context_json=raw(CTX),generation=1);source=object();clock=object()
 mb=object.__new__(mail.LatestCompletedMailbox);mb.__dict__.update(_context=CTX,_context_raw=boot.context_json,_generation=1,_source=source,_clock_domain=clock,_stopped=False,_time_high=B,_started=B,_observations={7:mail._Observation(b'new-synthetic-observation',B,B+5*MS)},_completed=None,_pending=None,_age_cap=1500*MS,_enable_completion_interval_v2=v2,_origin=B,_window_first=25*MS,_window_period=200*MS,_pc_direct_window_v2=mail.PcDirectWindowV2(20*MS),_last_slot=-1,_bounds=mail.TransferBounds(0,0),_mode='PC_DIRECT')
 co=object.__new__(owner._CandidateOwner);co.__dict__.update(_boot=boot,_source=source,_clock=clock,_model='b'*64,_age=100*MS,_started=B,_pending=None,_current=None,_retired=False,_context=CTX,_mailbox=mb,_pc_direct_window_v2=mb._pc_direct_window_v2,_enable_completion_interval_v2=v2)
 kwargs={}if BASELINE else dict(enable_completion_interval_v2=v2)
 gate=progress._ProgressGate(boot,source,clock,'b'*64,100*MS,B,**kwargs)
 return co,gate
def proof(co,c=None,*,v2=True,lower=B+15*MS,dispatch=B+10*MS,upper=B+20*MS,invocation=1,bounds=None):
 c=document(dispatch,upper,v2=v2)if c is None else c
 args=(co._boot,co._source,co._clock,raw(c),invocation,dispatch,lower,upper)
 if BASELINE:return owner._CompletedInference(*args)
 if v2 and bounds is None:bounds=mail.ObservedIntervalBoundsV2(100*MS,B+1400*MS,dispatch+100*MS,None)
 return owner._CompletedInference(*args,observed_interval_v2=bounds)
class ChangedBranch(unittest.TestCase):
 def test_real_three_stage_path_and_duplicate(self):
  co,gate=fixture();p=proof(co);now=B+25*MS;c=document();r=request(c)
  self.assertTrue(co.offer(p,now));self.assertIs(co._pending,p)
  selected=co.select(r,owner._VerifiedSlot(co._boot,co._source,co._clock,0),now);self.assertIs(selected,p)
  gate.admit(selected,r,now);co.commit(r,p);self.assertIs(co.duplicate_proof(r),p)
  self.assertEqual(gate.bound.dispatch_lower_ns,B+10*MS);self.assertEqual(gate.bound.completion_lower_ns,B+15*MS);self.assertEqual(gate.bound.deadline_ns,B+110*MS)
  gate.admit(p,r,now+MS);self.assertEqual(gate.bound.deadline_ns,B+110*MS)
  self.assertFalse(co.offer(p,now+MS));self.assertIsNone(co._mailbox._pending)
 def test_exact_observed_fields_and_basis(self):
  for field in ('lower_ns','upper_ns','basis'):
   co,g=fixture();c=document()
   if field=='basis':c[field]='not-original'
   else:c['completion_observed_interval_ns'][field]+=1
   p=proof(co,c)
   with self.subTest(field=field):
    with self.assertRaises(ValueError):co.offer(p,B+25*MS)
    with self.assertRaises(ValueError):g.admit(p,request(c),B+25*MS)
 def test_dispatch_not_read_lower_expiry(self):
  co,g=fixture();p=proof(co,lower=B+99*MS,upper=B+105*MS);c=document(upper=B+105*MS);p=dataclasses.replace(p,candidate_raw=raw(c))
  self.assertTrue(co.offer(p,B+110*MS-1))
  co,g=fixture()
  with self.assertRaises(ValueError):co.offer(dataclasses.replace(p,boot=co._boot,source=co._source,clock_domain=co._clock),B+110*MS)
 def test_default_v1_unchanged(self):
  co,g=fixture(False);p=proof(co,v2=False);c=document(v2=False);r=request(c)
  self.assertTrue(co.offer(p,B+25*MS));sel=co.select(r,owner._VerifiedSlot(co._boot,co._source,co._clock,0),B+25*MS);g.admit(sel,r,B+25*MS);self.assertEqual(g.bound.deadline_ns,B+115*MS)
  co,g=fixture(False)
  with self.assertRaises(ValueError):co.offer(proof(co),B+25*MS)
 def test_caps_missing_clipping_and_source_limit(self):
  for name in ('source_deadline_ns','dispatch_deadline_ns','previous_deadline_ns'):
   co,g=fixture();p=proof(co);caps=dataclasses.replace(p.observed_interval_v2,**{name:B+30*MS});p=dataclasses.replace(p,observed_interval_v2=caps)
   self.assertTrue(co.offer(p,B+25*MS));g.admit(p,request(document()),B+25*MS);self.assertEqual(g.bound.deadline_ns,B+30*MS)
  for name in ('source_deadline_ns','dispatch_deadline_ns'):
   co,g=fixture();p=proof(co);p=dataclasses.replace(p,observed_interval_v2=dataclasses.replace(p.observed_interval_v2,**{name:None}))
   with self.assertRaises(ValueError):co.offer(p,B+25*MS)
  co,g=fixture();p=proof(co);p=dataclasses.replace(p,observed_interval_v2=dataclasses.replace(p.observed_interval_v2,source_deadline_ns=B+1500*MS+1))
  with self.assertRaises(ValueError):co.offer(p,B+25*MS)
 def test_changed_duplicate_caps_and_fresh_invocation(self):
  co,g=fixture();p=proof(co);r=request(document());g.admit(p,r,B+25*MS)
  changed=dataclasses.replace(p,observed_interval_v2=dataclasses.replace(p.observed_interval_v2,source_deadline_ns=B+1300*MS))
  with self.assertRaises(ValueError):g.admit(changed,r,B+26*MS)
  co,g=fixture();p=proof(co);g.admit(p,r,B+25*MS)
  c=document(B+40*MS,B+50*MS,cid=6);fresh=proof(co,c,dispatch=B+40*MS,lower=B+45*MS,upper=B+50*MS,invocation=2);g.admit(fresh,request(c,seq=2,issue=B+55*MS),B+55*MS);self.assertEqual(g.bound.deadline_ns,B+140*MS)
 def test_original_identity_and_issue_fences(self):
  for field in ('boot','source','clock_domain'):
   co,g=fixture();p=dataclasses.replace(proof(co),**{field:object()})
   with self.assertRaises(ValueError):co.offer(p,B+25*MS)
   with self.assertRaises(ValueError):g.admit(p,request(document()),B+25*MS)
  co,g=fixture()
  with self.assertRaises(ValueError):g.admit(proof(co),request(document(),issue=B+19*MS),B+25*MS)
 def test_strict_opt_in_and_configured_age(self):
  co,g=fixture()
  with self.assertRaises(ValueError):progress._ProgressGate(co._boot,co._source,co._clock,'b'*64,100*MS,B,enable_completion_interval_v2=1)
  p=proof(co);p=dataclasses.replace(p,observed_interval_v2=dataclasses.replace(p.observed_interval_v2,max_age_ns=99*MS))
  with self.assertRaises(ValueError):co.offer(p,B+25*MS)
  with self.assertRaises(ValueError):g.admit(p,request(document()),B+25*MS)
 def test_mailbox_caps_duplicate_and_missing_acquisition(self):
  co,g=fixture();p=proof(co);self.assertTrue(co.offer(p,B+25*MS))
  changed=dataclasses.replace(p,observed_interval_v2=dataclasses.replace(p.observed_interval_v2,source_deadline_ns=B+1300*MS))
  with self.assertRaises(ValueError):co.offer(changed,B+26*MS)
  self.assertTrue(co._mailbox._stopped)
  co,g=fixture();co._mailbox._observations[7]=mail._Observation(b'unknown-acquisition',None,B+5*MS)
  with self.assertRaises(ValueError):co.offer(proof(co),B+25*MS)
if __name__=='__main__':unittest.main()
