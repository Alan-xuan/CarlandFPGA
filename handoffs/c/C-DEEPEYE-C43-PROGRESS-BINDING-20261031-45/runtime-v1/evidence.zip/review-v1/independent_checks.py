"""NEW isolated pure-block C45 controls. CLI C45_IMPL C43_IMPL OUTPUT_DIR."""
import ast,copy,dataclasses,hashlib,importlib.util,json,pathlib,sys,types
from collections import OrderedDict
from fractions import Fraction
from functools import wraps
S,C,O=map(pathlib.Path,sys.argv[1:]);O.mkdir(exist_ok=False)
expected={'actor_composition.py':'3318a39ae1f7631d8fa4872e4bc3386c6cf46010857f837fe19f6c9e6bda71ba','candidate_owner.py':'9e820722944cda450d3d16eca69e3bc8e8e5618919e2ea5e4b36f9d5a3fa2d29','candidate_mailbox.py':'02d9af273d1de99b53a1f613ddb5bd84c132604a037e53db140e405a173e1e97'}
for f,h in expected.items():assert hashlib.sha256((S/'patched'/f).read_bytes()).hexdigest()==h
assert hashlib.sha256((C/'completion_interval.py').read_bytes()).hexdigest()=='05da98393d47f3eaf4690d8979d2e37d2e4f1e0b00c801177a3fb6a3f84bbe96'
sys.path.insert(0,str(C/'dependencies/attempt02/vendor'));sp=importlib.util.spec_from_file_location('ind_c45_host',C/'patched/integration/host_envelope.py');host=importlib.util.module_from_spec(sp);sys.modules[sp.name]=host;sp.loader.exec_module(host)
def blocks(label,file,names=None,**bindings):
 tree=ast.parse((S/'patched'/file).read_text());nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))and(names is None or n.name in names)]
 m=types.ModuleType(label);sys.modules[label]=m;m.__dict__.update(dataclass=dataclasses.dataclass,wraps=wraps,OrderedDict=OrderedDict,Fraction=Fraction,json=json,MAX_TIME=(1<<63)-1,_MAX_NS=(1<<63)-1,NS_PER_MS=1_000_000,MAX_OBSERVATIONS=4,MAX_ACTIVATIONS=64,**bindings);exec(compile(ast.Module(body=nodes,type_ignores=[]),str(S/'patched'/file),'exec'),m.__dict__);return m
mail=blocks('ind_c45_mail','candidate_mailbox.py',envelope=host,boot=types.SimpleNamespace())
owner=blocks('ind_c45_owner','candidate_owner.py',mailbox=mail,host_envelope=host,BootBinding=object,boot_profile=types.SimpleNamespace())
gate=blocks('ind_c45_gate','actor_composition.py',{'_bounded','_BoundProgress','_ProgressGate'},host_envelope=host,_CompletedInference=owner._CompletedInference,_validate_interval_candidate=mail._validate_interval_candidate)
N=(1<<59)+112233445;M=1_000_000;CTX=dict(session=31,config_epoch=14,boot_sha256='5'*64,transport_profile_id=1,source_id=1,topology_id=2,acquisition_profile_id=1)
raw=lambda d:json.dumps(d,sort_keys=True,separators=(',',':')).encode()
def fixture(sample=N):
 boot=types.SimpleNamespace(context_json=raw(CTX),generation=6);src=object();clock=object();mb=object.__new__(mail.LatestCompletedMailbox)
 mb.__dict__.update(_context=CTX,_generation=6,_source=src,_clock_domain=clock,_stopped=False,_time_high=N,_started=N,_observations={12:mail._Observation(b'new-read-only-synthetic',sample,N+5*M)},_completed=None,_pending=None,_age_cap=1500*M,_enable_completion_interval_v2=True)
 co=object.__new__(owner._CandidateOwner);co.__dict__.update(_boot=boot,_source=src,_clock=clock,_model='6'*64,_age=100*M,_started=N,_pending=None,_current=None,_retired=False,_context=CTX,_mailbox=mb,_enable_completion_interval_v2=True)
 g=gate._ProgressGate(boot,src,clock,'6'*64,100*M,N,enable_completion_interval_v2=True);return co,g
trace=[]
def proof(co,dispatch=10,read=15,upper=20,seq=12,cid=21,inv=1,source=N+1400*M,cap=N+40*M,previous=None):
 d=dict(schema_version=2,context=copy.deepcopy(CTX),kind='model_candidate',candidate_id=cid,model_sha256='6'*64,observation=dict(context=copy.deepcopy(CTX),observed_seq=seq),target=dict(action=1,yaw_q=0,pitch_q=0,speed_code=1,duration_ms=1),completion_observed_interval_ns=dict(lower_ns=N+dispatch*M,upper_ns=N+upper*M),basis='host_dispatch_to_complete_result_observed_v1')
 caps=mail.ObservedIntervalBoundsV2(100*M,source,cap,previous);p=owner._CompletedInference(co._boot,co._source,co._clock,raw(d),inv,N+dispatch*M,N+read*M,N+upper*M,caps);trace.append(dict(candidate=d,dispatch=p.dispatch_lower_ns,read_lower=p.completion_lower_ns,read_upper=p.completion_upper_ns,bounds=dataclasses.asdict(caps),invocation=inv));return p,d

def req(d,seq,issue):return raw(dict(schema_version=1,context=copy.deepcopy(CTX),kind='motion_request',command_seq=seq,candidate_id=d['candidate_id'],observation=d['observation'],target=d['target'],host_issue_monotonic_ns=N+issue*M))
def refused(fn):
 try:fn()
 except ValueError as e:return str(e)
 raise AssertionError('expected refusal')
rows=[]
def run(name,fn):
 trace.clear()
 try:result=fn();ok=True
 except Exception as e:result=dict(exception=type(e).__name__,reason=str(e));ok=False
 (O/(name+'.input.json')).write_bytes(raw(trace));(O/(name+'.output.json')).write_bytes(raw(result));row=dict(case=name,passed=ok,input_sha256=hashlib.sha256(raw(trace)).hexdigest(),output_sha256=hashlib.sha256(raw(result)).hexdigest());rows.append(row);print(json.dumps(row),flush=True)
def source_boundary():
 co,g=fixture(N-1450*M);p,d=proof(co,source=N+50*M);assert co.offer(p,N+25*M);g.admit(p,req(d,1,25),N+25*M);assert g.bound.deadline_ns==N+40*M and g.bound.completion_lower_ns==N+15*M
 co2,g2=fixture(N-1450*M);bad,d2=proof(co2,source=N+50*M+1);reason=refused(lambda:co2.offer(bad,N+25*M));assert co2._mailbox._stopped
 return dict(exact_profile_source_cap_passed=True,nonbinding_dispatch_cap=N+40*M,over_profile_by_one_ns=reason,mailbox_halted=True)
run('nonbinding-source-cap-exact-profile-limit',source_boundary)
def fresh_then_changed_duplicate():
 co,g=fixture();p,d=proof(co,cap=N+50*M);assert co.offer(p,N+25*M);g.admit(p,req(d,1,25),N+25*M)
 co._mailbox._observations[13]=mail._Observation(b'new-fresh-synthetic',N+25*M,N+30*M)
 fresh,doc=proof(co,dispatch=32,read=35,upper=38,seq=13,cid=22,inv=2,cap=N+80*M,source=N+1400*M)
 assert co.offer(fresh,N+40*M);r=req(doc,2,40);g.admit(fresh,r,N+40*M);assert g.bound.deadline_ns==N+80*M;assert not co.offer(fresh,N+41*M);g.admit(fresh,r,N+41*M)
 changed=dataclasses.replace(fresh,observed_interval_v2=dataclasses.replace(fresh.observed_interval_v2,source_deadline_ns=N+1399*M));trace.append(dict(changed_duplicate_bounds=dataclasses.asdict(changed.observed_interval_v2)))
 reason=refused(lambda:g.admit(changed,r,N+42*M));assert g.revoked
 return dict(fresh_deadline=N+80*M,exact_duplicate_unchanged=True,changed_nonbinding_cap_refused=reason,revoked=True)
run('fresh-progression-and-nonbinding-cap-duplicate',fresh_then_changed_duplicate)
def exact_type():
 co,g=fixture();p,d=proof(co)
 class Lookalike(mail.ObservedIntervalBoundsV2):pass
 p=dataclasses.replace(p,observed_interval_v2=Lookalike(**dataclasses.asdict(p.observed_interval_v2)));trace.append(dict(bounds_type='subclass-not-original-exact-type'))
 a=refused(lambda:co.offer(p,N+25*M));b=refused(lambda:g.admit(p,req(d,1,25),N+25*M));assert g.revoked and co._pending is None
 return dict(owner_reject=a,gate_reject=b,no_pending=True,gate_revoked=True)
run('bounds-subclass-cannot-satisfy-original-record-type',exact_type)
assert not any(n.startswith('competition.')or 'frozen_c28'in n or n.startswith('_c37')for n in sys.modules)
(O/'results.json').write_text(json.dumps(rows,indent=2),encoding='utf8');raise SystemExit(0 if all(r['passed']for r in rows)else 1)
