"""Verify fixed input bytes, audit evidence, then one new bounded pure control."""
import ast,hashlib,json,subprocess,sys,time
from pathlib import Path
H=Path(__file__).resolve().parent;D=H.parent/'implementation-v1';B=H.parent.parent
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def pin(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def write(n,v):(H/n).write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
assert sha((D/'FINAL.json').read_bytes())=='23652dd222d328f41ea87925a3351e5a620ca1a25a57f04508e22084e3ed5904'
freeze=read(D/'freeze.json')['files'];pins=[]
for row in freeze:
 p=D/row['path'];a=pin(p)
 assert a['sha256']==row['sha256'] and a['bytes']==row['bytes'],row['path']
 pins.append(a)
sources=read(D/'source-pins.json')
for row in sources['inputs']:
 b=(D/'inputs'/row['path']).read_bytes()
 assert len(b)==row['bytes'] and sha(b)==row['sha256']
 assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==row['git_blob']
for path,digest in sources['C46_dependencies'].items():
 p=B/'C46-20261031/implementation-v1'/path
 assert sha(p.read_bytes())==digest
 pins.append(pin(p))
phases=[]
for i in range(1,9):
 p=D/'runs'/('run%02d'%i);cmd=read(p/'command.json');ex=read(p/'exit.json')
 for name,digest in cmd['source_sha256'].items():assert sha((p/'source'/name).read_bytes())==digest
 phases.append(dict(phase=p.name,exit=ex,command=cmd,stdout=pin(p/'stdout.txt'),stderr=pin(p/'stderr.txt')))
assert [x['exit']['exit_code'] for x in phases]==[1,0,1,0,1,0,1,0]
source=D/'package/competition/deepeye/tools/finite_actor_bootstrap_v1.py'
assert sha(source.read_bytes())=='ff43023110394b8efe7080518f7843634b8458f2837cacdc2a2b9c0b4f58a4dd'
assert source.read_bytes()==(D/'runs/run08/source/package/competition/deepeye/tools/finite_actor_bootstrap_v1.py').read_bytes()
patch=(D/'c47-finite-bootstrap.patch').read_text(encoding='utf-8')
added=''.join(line[1:] for line in patch.splitlines(keepends=True) if line.startswith('+') and not line.startswith('+++'))
assert added==source.read_text(encoding='utf-8')
host=ast.parse((D/'inputs/competition/deepeye/integration/host_envelope.py').read_bytes())
validate=next(n for n in host.body if isinstance(n,ast.FunctionDef) and n.name=='validate_message')
assert "importlib.import_module('.completion_interval', __package__)" in ast.unparse(validate)
adapter=B/'C46-20261031/implementation-v1/package/owned_invocation_v1/adapter.py'
at=ast.parse(adapter.read_bytes())
assert any(isinstance(n,ast.ImportFrom) and n.level==4 and n.module=='integration' and 'completion_interval' in [a.name for a in n.names] for n in at.body)
pins += [pin(adapter),pin(D/'FINAL.json'),pin(D/'freeze.json')]
write('source-pins-before.json',pins)
write('static-review.json',dict(frozen_files=len(freeze),original_source_pins=len(sources['inputs']),
 source_commit=sources['A_commit'],phases=phases,patch_addition_exact=True,
 canonical_identity='Static: host __package__ competition.deepeye.integration and C46 level4 integration both import competition.deepeye.integration.completion_interval. No alias repair/module replacement or full original import executed.',
 current_product_matches='run08',author_final_full_suite=False))
cmd=[sys.executable,'-I','-B',str(H/'independent_lifecycle_check.py'),str(D),str(H/'run01.input-output.json')]
t=time.monotonic();p=subprocess.run(cmd,cwd=H,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=25)
(H/'run01.stdout').write_bytes(p.stdout);(H/'run01.stderr').write_bytes(p.stderr)
write('run01.command-exit.json',dict(command=cmd,timeout_seconds=25,exit_code=p.returncode,
 elapsed_seconds=time.monotonic()-t,script=pin(H/'independent_lifecycle_check.py'),stdout=pin(H/'run01.stdout'),stderr=pin(H/'run01.stderr')))
print(json.dumps(dict(frozen_files=len(freeze),sources=len(sources['inputs']),exit=p.returncode,stdout=p.stdout.decode(),stderr=p.stderr.decode())))
sys.exit(p.returncode)
