"""One NEW combined failure control. CLI: SCRIPT C47_IMPLEMENTATION OUTPUT_JSON.
Exact helper AST; all original resource/lifecycle identities are synthetic.
No author fixtures, original provider, native actor, core or model imports.
"""
import ast
from dataclasses import dataclass
import json
from pathlib import Path
import sys
import threading
import types

D, OUT = map(Path, sys.argv[1:])
source = D/'package/competition/deepeye/tools/finite_actor_bootstrap_v1.py'
S = types.SimpleNamespace
calls = dict(activation=0, acquisition=0, source_start=0, close=0, actor_method=0)
original_error = RuntimeError('NEW independent activation failed after retained composition')
cleanup_error = OSError('NEW independent original world close outcome unknown')
class Clock: pass
class Policy:
    def _validate(self): pass
class OwnedPolicy: pass
@dataclass(frozen=True)
class Config:
    actor_policy: object
    enable_completion_interval_v2: bool
    owned_invocation_v1: object
class Actor:
    _state = 'RELEASE_UNKNOWN'
    _cleanup_attempted = True
    def diagnostics(self):
        calls['actor_method'] += 1
        raise AssertionError('effectful diagnostics must never be called')
    def close(self, *args):
        calls['actor_method'] += 1
        raise AssertionError('no actor cleanup retry')
    @property
    def state(self):
        calls['actor_method'] += 1
        raise AssertionError('no actor property call')
class Source:
    def __init__(self, clock):
        self.clock, self._thread = clock, threading.get_ident()
        self._activation_attempted = self._start_attempted = False
        self.composition = None
    def activate_original_authority(self, config):
        calls['activation'] += 1
        self._activation_attempted = True
        calls['acquisition'] += 1
        self.composition = S(_registry=S(_owners=[Actor()]))
        raise original_error
    def start(self):
        calls['source_start'] += 1
        raise AssertionError('failed activation cannot start source')
class World:
    def __init__(self):
        self.clock = Clock()
        self.source = Source(self.clock)
        self._thread = threading.get_ident()
        self._close_attempted = False
    def close(self, reason):
        calls['close'] += 1
        self._close_attempted = True
        raise cleanup_error
canonical = object()  # identity-only sentinel; no fake claim about actual imports
def validate(config, clock):
    assert type(config) is Config and type(config.actor_policy) is Policy
    assert type(config.owned_invocation_v1) is OwnedPolicy and type(clock) is Clock
    assert config.enable_completion_interval_v2 is True
mod = types.ModuleType('c47_independent_exact_helper')
sys.modules[mod.__name__] = mod
mod.__dict__.update(FunctionalWorld=World,FunctionalSource=Source,
    actor_composition=S(AuthorityConfig=Config), ActorOwner=Actor, ActorPolicy=Policy,
    adapter=S(completion_interval=canonical,OwnedInvocationPolicy=OwnedPolicy,_validate_config=validate),
    completion_interval=canonical,host_clock=S(QpcHostClock=Clock))
tree = ast.parse(source.read_bytes())
tree.body = [n for n in tree.body if not(isinstance(n,ast.ImportFrom) and n.level)]
exec(compile(tree,str(source),'exec'),mod.__dict__)
world = World()
config = Config(Policy(),True,OwnedPolicy())
limits = mod.FiniteLimits(3,2,True)
run = mod.FiniteActorBootstrap(world,config,limits=limits)
out = {'scope':'one new synthetic combined partial-activation/cleanup-uncertainty/alias/read-only-budget control'}
try:
    try: run.start()
    except RuntimeError as caught: assert caught is original_error
    else: raise AssertionError('original activation error lost')
    assert run.errors == [original_error,cleanup_error]
    assert run._state == 'RETIRED' and not run._busy
    assert len(mod._RETAINED_CLOSE_OWNERS) == 1
    assert mod._RETAINED_CLOSE_OWNERS[0] == (world,world.source,run)
    alias = World()
    alias.clock,alias.source = world.clock,world.source
    try: mod.FiniteActorBootstrap(alias,config,limits=limits)
    except ValueError as caught:
        assert 'already has a bootstrap close owner' in str(caught)
        out['alias_refusal'] = str(caught)
    else: raise AssertionError('failed owner relationship was stolen')
    assert alias._close_attempted is False
    first = run.observe_teardown()
    assert first == ({'state':'RELEASE_UNKNOWN','cleanup_attempted':True,
                      'observation':'retained_fields_only','resource_confirmation':False},)
    retained_actor = world.source.composition._registry._owners[0]
    retained_actor._state = 'QUARANTINED'
    second = run.observe_teardown()
    assert second[0]['state'] == 'QUARANTINED' and not second[0]['resource_confirmation']
    try: run.observe_teardown()
    except ValueError as caught:
        assert 'budget exhausted' in str(caught)
        out['budget_refusal'] = str(caught)
    else: raise AssertionError('unbounded retained observations')
    run.close('do not retry unknown cleanup')
    try: run.start()
    except ValueError: pass
    else: raise AssertionError('retired lifecycle restarted')
    assert not run._busy and run.errors == [original_error,cleanup_error]
    assert calls == dict(activation=1,acquisition=1,source_start=0,close=1,actor_method=0)
    assert not any(n.startswith('competition.') for n in sys.modules)
    out.update(passed=True,calls=calls,observations=[first,second],
               retained_errors=[type(x).__name__ for x in run.errors],original_calls=False)
    print(json.dumps(out,sort_keys=True))
finally:
    OUT.write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
