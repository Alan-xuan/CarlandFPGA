"""Preserve each actual NEW control command, input versions and raw exit."""
from pathlib import Path
import hashlib, json, shutil, subprocess, sys, time

here = Path(__file__).resolve().parent
run = here/'runs'/sys.argv[1]
run.mkdir(parents=True, exist_ok=False)
paths = ['test_finite_bootstrap.py', 'run_control.py',
         'package/competition/deepeye/tools/finite_actor_bootstrap_v1.py']
pins = {}
for name in paths:
    source = here/name
    target = run/'source'/name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)
    pins[name] = hashlib.sha256(source.read_bytes()).hexdigest()
command = [sys.executable, '-B', str(here/'test_finite_bootstrap.py'), *sys.argv[2:]]
(run/'command.json').write_text(json.dumps(dict(command=command, cwd=str(here),
    timeout_seconds=30, source_sha256=pins), indent=2)+'\n', encoding='utf-8')
started = time.monotonic()
with (run/'stdout.txt').open('wb') as stdout, (run/'stderr.txt').open('wb') as stderr:
    try:
        result = subprocess.run(command, cwd=here, stdout=stdout, stderr=stderr,
                                timeout=30, check=False)
        exit_code, timed_out = result.returncode, False
    except subprocess.TimeoutExpired:
        exit_code, timed_out = None, True
record = dict(exit_code=exit_code, timed_out=timed_out,
              elapsed_seconds=time.monotonic()-started)
(run/'exit.json').write_text(json.dumps(record, indent=2)+'\n', encoding='utf-8')
print(json.dumps(record))
print((run/'stderr.txt').read_text(encoding='utf-8'))
sys.exit(124 if timed_out else exit_code)
