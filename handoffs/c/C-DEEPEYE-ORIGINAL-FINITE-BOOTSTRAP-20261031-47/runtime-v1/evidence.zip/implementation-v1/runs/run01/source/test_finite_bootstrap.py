"""NEW C47 controls. AST local-import substitution; no original native imports.

Original production refusal and host canonical import branch are executed from
the pinned AST. All lifecycle/provider objects are explicit synthetic fakes.
This checks wiring only and cannot qualify a provider or physical BOOT.
"""
import ast
from dataclasses import dataclass
import importlib
from pathlib import Path
import sys
import threading
import types
import unittest

HERE = Path(__file__).resolve().parent
SOURCE = HERE/'package/competition/deepeye/tools/finite_actor_bootstrap_v1.py'
INPUT = HERE/'inputs/competition/deepeye'


def definition(path, name):
    return next(n for n in ast.parse(path.read_bytes()).body
                if isinstance(n, (ast.FunctionDef, ast.ClassDef)) and n.name == name)


pkg = types.ModuleType('c47_actual_integration')
pkg.__path__ = [str(INPUT/'integration')]
sys.modules[pkg.__name__] = pkg
canonical = importlib.import_module('.completion_interval', pkg.__name__)


class Clock: pass
class Policy:
    def __init__(self): self.validations = 0
    def _validate(self): self.validations += 1
class OwnedPolicy: pass
class Unavailable(ValueError): pass


@dataclass(frozen=True)
class Config:
    actor_policy: object
    marker: object
    enable_completion_interval_v2: bool = False
    owned_invocation_v1: object = None


class Actor:
    state = 'QUARANTINED'
    _pending_io = object()
    _cleanup_attempted = True
    def __init__(self): self.side_effect_calls = 0
    def poll_teardown(self): self.side_effect_calls += 1
    def diagnostics(self): return {'state': self.state, 'cleanup_complete': False}


class Composition:
    def __init__(self):
        self.state = 'RUNNING_UNBOUND'
        self._registry = types.SimpleNamespace(_owners=[])
        self.events = []
        self.boot_error = None
        self.polls = self.owned_polls = 0
    def status(self): return types.SimpleNamespace(state=self.state)
    def accept_boot(self, event):
        self.events.append(event)
        if self.boot_error: raise self.boot_error
        self.state = 'ACTIVE'
    def poll(self): self.polls += 1
    def poll_owned_invocation(self):
        self.owned_polls += 1
        return 'synthetic original completion'


gate = types.ModuleType('c47_original_gate')
gate.ActivationUnavailable = Unavailable
exec(compile(ast.Module(body=[definition(INPUT/'simulation/authority/actor_composition.py',
     '_production_channels')], type_ignores=[]), 'exact_A0a3_production_gate', 'exec'), gate.__dict__)


class Source:
    def __init__(self, clock):
        self.clock = clock
        self._thread = threading.get_ident()
        self._activation_attempted = self._start_attempted = False
        self.composition = None
        self.activations = self.starts = self.acquisitions = 0
        self.synthetic_ready = False
        self.after_acquire_error = None
    def activate_original_authority(self, config):
        self.activations += 1
        self._activation_attempted = True
        if not self.synthetic_ready:
            gate._production_channels(config, host_clock=self.clock)
        self.acquisitions += 1
        self.composition = Composition()
        if self.after_acquire_error: raise self.after_acquire_error
        return self.composition
    def start(self):
        assert self.composition.state == 'ACTIVE'
        self._start_attempted = True
        self.starts += 1


class World:
    def __init__(self):
        self.clock = Clock()
        self.source = Source(self.clock)
        self._thread = threading.get_ident()
        self._close_attempted = False
        self.closes = 0
        self.close_error = None
    def close(self, reason):
        self.closes += 1
        self._close_attempted = True
        if self.close_error: raise self.close_error


checks = []
def validate_config(config, clock):
    checks.append((config, clock))
    assert type(config.owned_invocation_v1) is OwnedPolicy
    assert config.enable_completion_interval_v2 is True


module = types.ModuleType('c47_synthetic_lifecycle')
sys.modules[module.__name__] = module
module.__dict__.update(FunctionalWorld=World, FunctionalSource=Source,
    actor_composition=types.SimpleNamespace(AuthorityConfig=Config),
    adapter=types.SimpleNamespace(OwnedInvocationPolicy=OwnedPolicy,
        _validate_config=validate_config, completion_interval=canonical),
    ActorPolicy=Policy, ActorOwner=Actor, completion_interval=canonical,
    host_clock=types.SimpleNamespace(QpcHostClock=Clock))
tree = ast.parse(SOURCE.read_bytes())
tree.body = [n for n in tree.body if not (isinstance(n, ast.ImportFrom) and n.level)]
exec(compile(tree, str(SOURCE), 'exec'), module.__dict__)


def prepared(*, ready=False, max_polls=2):
    world = World()
    world.source.synthetic_ready = ready
    base = Config(Policy(), object())
    limits = module.FiniteLimits(max_polls, 2, True)
    config = module.prepare_config(base, OwnedPolicy(), clock=world.clock, limits=limits)
    return world, module.FiniteActorBootstrap(world, config, limits=limits), base, config


class ChangedLifecycle(unittest.TestCase):
    def test_default_off_strict_config_and_original_identity(self):
        world = World()
        base = Config(Policy(), object())
        for enabled in (False, 1, 'true'):
            with self.assertRaises(ValueError):
                module.prepare_config(base, OwnedPolicy(), clock=world.clock,
                    limits=module.FiniteLimits(2, 2, enabled))
        self.assertEqual(world.source.acquisitions, 0)
        world, run, base, config = prepared()
        self.assertIs(config.marker, base.marker)
        self.assertIs(config.actor_policy, base.actor_policy)
        self.assertIsNone(base.owned_invocation_v1)
        run.close('unused prepared root')

    def test_real_refusal_before_acquisition_and_no_retry(self):
        world, run, _, _ = prepared()
        with self.assertRaises(Unavailable): run.start()
        self.assertEqual((world.source.activations, world.source.acquisitions,
                          world.source.starts, world.closes), (1, 0, 0, 1))
        with self.assertRaises(ValueError): run.start()
        run.close('again')
        self.assertEqual(world.closes, 1)

    def test_partial_start_original_and_cleanup_errors_preserved(self):
        world, run, _, _ = prepared(ready=True)
        original = RuntimeError('synthetic original partial start failure')
        cleanup = RuntimeError('synthetic original cleanup uncertainty')
        world.source.after_acquire_error, world.close_error = original, cleanup
        with self.assertRaises(RuntimeError) as raised: run.start()
        self.assertIs(raised.exception, original)
        self.assertIsNotNone(world.source.composition)
        self.assertEqual(run.errors, [original, cleanup])
        run.close('must not retry')
        self.assertEqual(world.closes, 1)

    def test_boot_original_event_then_source_once(self):
        world, run, _, _ = prepared(ready=True)
        run.start()
        self.assertEqual(world.source.starts, 0)
        event = object()
        run.accept_boot(event)
        self.assertIs(world.source.composition.events[0], event)
        self.assertEqual(world.source.starts, 1)
        with self.assertRaises(ValueError): run.accept_boot(event)
        self.assertEqual(world.source.starts, 1)
        self.assertEqual(run.poll(owned_invocation=True), 'synthetic original completion')
        run.close('finished')

    def test_rejected_boot_never_starts_source(self):
        world, run, _, _ = prepared(ready=True)
        run.start()
        world.source.composition.boot_error = ValueError('synthetic rejected opaque BOOT')
        with self.assertRaises(ValueError): run.accept_boot(object())
        self.assertEqual((world.source.starts, world.closes), (0, 1))

    def test_finite_poll_exhaustion_closes_once(self):
        world, run, _, _ = prepared(ready=True, max_polls=1)
        run.start()
        run.poll()
        with self.assertRaises(ValueError): run.poll()
        self.assertEqual(world.source.composition.polls, 1)
        self.assertEqual(world.closes, 1)

    def test_observation_is_read_only_and_preserves_unknown(self):
        world, run, _, _ = prepared(ready=True)
        run.start()
        actor = Actor()
        world.source.composition._registry._owners.append(actor)
        run.close('one original cleanup')
        for _ in range(2):
            self.assertEqual(run.observe_teardown()[0]['state'], 'QUARANTINED')
        with self.assertRaises(ValueError): run.observe_teardown()
        self.assertEqual(actor.side_effect_calls, 0)
        self.assertEqual(world.closes, 1)

    def test_canonical_actual_class_with_existing_foreign_alias(self):
        host = types.ModuleType(pkg.__name__ + '.host_envelope_branch')
        host.__package__ = pkg.__name__
        host.__dict__.update(importlib=importlib, sys=sys)
        sys.modules[host.__name__] = host
        exec(compile(ast.Module(body=[definition(INPUT/'integration/host_envelope.py',
             'validate_message')], type_ignores=[]), 'exact_host_import_branch', 'exec'), host.__dict__)
        returned = canonical.IntervalCandidate('model_candidate', 'pc_ai', None,
                                              False, {}, 1, 0, {})
        original = canonical.validate_message
        alias = sys.modules.get('deepeye_completion_interval')
        foreign = types.ModuleType('foreign_legacy_alias')
        sys.modules['deepeye_completion_interval'] = foreign
        seen = []
        def synthetic_validation(*args, **kwargs):
            seen.append(kwargs['legacy'])
            return returned
        canonical.validate_message = synthetic_validation
        try:
            actual = host.validate_message(b'{}', producer='pc_ai', context={}, now_ns=0,
                                           enable_completion_interval=True)
            self.assertIs(type(actual), canonical.IntervalCandidate)
            self.assertIs(type(actual), module.adapter.completion_interval.IntervalCandidate)
            self.assertIs(seen[0], host)
            self.assertIs(sys.modules['deepeye_completion_interval'], foreign)
        finally:
            canonical.validate_message = original
            if alias is None: sys.modules.pop('deepeye_completion_interval', None)
            else: sys.modules['deepeye_completion_interval'] = alias


if __name__ == '__main__': unittest.main(verbosity=2)
