"""Source-only pin/diff/ownership verification. No product imports or tests."""
from pathlib import Path
import ast, difflib, hashlib, json

HERE = Path(__file__).resolve().parent
W = HERE.parent.parent
ROOT = W.parent.parent
def sha(raw): return hashlib.sha256(raw).hexdigest()
def save(name, value):
    (HERE/name).write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')

scope_path = ROOT/'.local/plan-20261014-final-c/immutable-f5989cd/immutable_scope.json'
scope = json.loads(scope_path.read_bytes())
contract = sha(json.dumps(scope['requirements'], sort_keys=True,
    separators=(',', ':'), ensure_ascii=False).encode())
assert contract == 'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
tree = json.loads((HERE/'tree.json').read_bytes())
assert tree['truncated'] is False
blobs = {row['path']:row['sha'] for row in tree['tree'] if row['type']=='blob'}
inputs = []
for path in sorted((HERE/'inputs').rglob('*')):
    if not path.is_file(): continue
    raw = path.read_bytes(); name = path.relative_to(HERE/'inputs').as_posix()
    blob = hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
    assert blobs[name] == blob, name
    inputs.append(dict(path=name, bytes=len(raw), sha256=sha(raw), git_blob=blob))
c46 = W/'C46-20261031/implementation-v1'
deps = {
    'patched/competition/deepeye/simulation/authority/actor_composition.py':
    '3765ba5e68942dc888b0235792c63963e6e29fb5be66a4f14226e0c0ba29203a',
    'patched/competition/deepeye/simulation/authority/candidate_owner.py':
    '563c7ad8e1bba496db85357884fa4832e39927333e4ec1a54a11e2d4b352c6a2',
    'FINAL.json':'c014738445bb187174f05fc0e423c02e0a75a6be0d1fe673b4eb31a54fbdb502'}
for name, expected in deps.items(): assert sha((c46/name).read_bytes()) == expected, name
original = ast.parse((c46/'patched/competition/deepeye/simulation/authority/actor_composition.py').read_bytes())
factory = next(n for n in original.body if isinstance(n,ast.FunctionDef)
               and n.name=='_create_authority_for_original_world')
calls = [(n.lineno,ast.unparse(n.func)) for n in ast.walk(factory) if isinstance(n,ast.Call)]
positions = {name:line for line,name in calls}
assert positions['_production_channels'] < positions['capability._claim'] < positions['owner._start']
gate = next(n for n in original.body if isinstance(n,ast.FunctionDef) and n.name=='_production_channels')
assert isinstance(gate.body[-1],ast.Raise)
adapter_ast = ast.parse((c46/'package/owned_invocation_v1/adapter.py').read_bytes())
assert any(isinstance(n,ast.ImportFrom) and n.level==4 and n.module=='integration'
           and any(a.name=='completion_interval' for a in n.names) for n in adapter_ast.body)
relative = 'competition/deepeye/tools/finite_actor_bootstrap_v1.py'
product = HERE/'package'/relative
product_ast = ast.parse(product.read_bytes())
observer = next(n for n in ast.walk(product_ast) if isinstance(n,ast.FunctionDef)
                and n.name=='observe_teardown')
owner_calls = [ast.unparse(n.func) for n in ast.walk(observer) if isinstance(n,ast.Call)
               and ast.unparse(n.func).startswith('owner.')]
assert not owner_calls
patch = ''.join(difflib.unified_diff([],product.read_text(encoding='utf-8').splitlines(True),
    fromfile='/dev/null',tofile='b/'+relative))
(HERE/'c47-finite-bootstrap.patch').write_text(patch,encoding='utf-8',newline='\n')
save('source-pins.json',dict(A_commit='0a3cd027b234374519110b67894c94db4cfe9e74',
    A_tree_sha=tree['sha'], inputs=inputs, C46_dependencies=deps,
    contract_requirements_sha256=contract))
save('API.json',dict(schema=1, status='PARTIAL_IMPLEMENTATION_PRODUCTION_UNAVAILABLE',
    module='competition.deepeye.tools.finite_actor_bootstrap_v1',
    callsites=[
      'FiniteLimits(max_polls:int[1..65536],max_teardown_observations:int[1..256],enabled:bool=False)',
      'prepare_config(base:AuthorityConfig,owned_policy:OwnedInvocationPolicy,*,clock:QpcHostClock,limits:FiniteLimits)->AuthorityConfig',
      'FiniteActorBootstrap(world:FunctionalWorld,config:AuthorityConfig,*,limits:FiniteLimits)',
      'start()->None', 'accept_boot(original_event)->None',
      'poll(*,owned_invocation:bool=False)->original C46 result or None',
      'close(reason:str)->None', 'observe_teardown()->tuple[retained scalar observation]'],
    grants_authority=False, installs_provider=False, changes_original_sources=False,
    retained_contexts=['BootBinding.context_json (legacy)', 'C42 proof Context (separate)'],
    missing_original_producer_facts=[
      'Concrete same-handshake receipt type and allocation, absent at pinned A source',
      'Original receipt verifier binding legacy BOOT and C42 context without merging them',
      'Fixed production channel constructor backed by actual original allocations',
      'Actual BOOT event for newly acquired original ActorOwner instance',
      'Actual original observation/source/dispatch/previous-action attachments and deadlines'],
    existing_attachment_path='Original channels.verify_observation inside accept_observation -> C46 _retain_original_association before returning exact VerifiedObservation',
    no_new_authority_receipt=True, actual_provider_factory='unchanged _production_channels raises ActivationUnavailable',
    native_resources_confirmed=False))
exits=[]
for path in sorted((HERE/'runs').glob('run*/exit.json')):
    item=json.loads(path.read_bytes()); assert item['timed_out'] is False
    exits.append(item['exit_code'])
assert exits==[1,0,1,0,1,0]
save('static-result.json',dict(status='PASS', product_sha256=sha(product.read_bytes()),
    patch_sha256=sha((HERE/'c47-finite-bootstrap.patch').read_bytes()),
    requirements_sha256=contract, input_files=len(inputs),
    original_gate_before_claim_and_start=True, observer_owner_method_calls=owner_calls,
    C46_canonical_package_import_unchanged=True, control_exit_codes=exits,
    independent_review='PENDING', production_functionality='UNAVAILABLE'))
print(json.dumps(json.loads((HERE/'static-result.json').read_bytes()),indent=2))
