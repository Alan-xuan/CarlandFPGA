"""Bounded raw evidence runner for newly assigned local scripts only."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
phase, script, *options = sys.argv[1:]
if script not in ('inventory_runtime.py', 'test_c37_new.py') or not phase.isalnum():
    raise ValueError('explicit new local phase required')
prefix = root / phase
if prefix.with_suffix('.command-exit.json').exists():
    raise ValueError('preserve previous phase evidence')
argv = [sys.executable, '-I', '-B', str(root / script), *options]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
pins = {}
for path in (root / 'c37-owned-cpu-package').iterdir():
    if path.is_file():
        pins[path.name] = hashlib.sha256(path.read_bytes()).hexdigest()
try:
    result = subprocess.run(argv, cwd=root, capture_output=True, timeout=25)
    stdout, stderr, exit_code, timed_out = result.stdout, result.stderr, result.returncode, False
except subprocess.TimeoutExpired as error:
    stdout, stderr, exit_code, timed_out = error.stdout or b'', error.stderr or b'', None, True
prefix.with_suffix('.stdout').write_bytes(stdout)
prefix.with_suffix('.stderr').write_bytes(stderr)
record = dict(argv=argv, cwd=str(root), started_utc=started,
              finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              timeout_seconds=25, timed_out=timed_out, exit_code=exit_code, source_pins_before=pins,
              stdout_sha256=hashlib.sha256(stdout).hexdigest(), stderr_sha256=hashlib.sha256(stderr).hexdigest())
prefix.with_suffix('.command-exit.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record))
print(stdout.decode('utf-8',errors='replace'))
print(stderr.decode('utf-8',errors='replace'))
raise SystemExit(124 if timed_out else exit_code)
