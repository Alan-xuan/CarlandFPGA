# C37 finite owned-child package, private implementation v1

Work C37-OWNED-PACKAGE-IMPLEMENT-v1; operation C-DEEPEYE-OWNED-C28-CPU-PACKAGE-20261031-37. This is a default-off software candidate for main's independent review, not production acceptance or original actor/model/board evidence.

## Implemented

`c37-owned-cpu-package/c37_entry.py` accepts only the frozen first-invocation command, verifies the three fixed package source hashes, loads the fixed package, signals the inherited original native event and reads exactly the trusted request byte count. Child pipe endpoints are synchronous according to pinned A actor_pipe_io.py:134-147; only parent endpoints are overlapped. The native implementation calls SetEvent/ReadFile/WriteFile/CloseHandle on the three supplied inherited handles. It does not import or launch A's ActorRegistry, SDK, model, controller or board code. Actual native calls were not executed here; NEW controls use FakeTransport.

`c37_package.py` performs strict framing/JSON/compact projection validation, converts absolute uint63 QPC ns to exact Fraction(ns,1000000) internally, and creates one private FunctionType with the original C28 recommend.__code__. The original module globals are shallow-copied and exactly `_validate` is replaced. Numerical functions/constants/builtins are unchanged; the shared original globals are never modified. `frozen_c28.py` is an exact byte copy with SHA256 70b317681fee8c9182c342fe8d2f94eaecc957c62231a74a080d213bb5e0eab4. The NEW test profiles actual frames to verify one original-code entry and checks the sole globals difference.

The compact ABI is distinct from old recommend_json: no binding/BOOT/exact action.at or rounded tick is invented. Source model startup tick and full original admission/capture/interval/custody proofs are host-only facts and cannot be inferred from absolute QPC values. Child checks its public shape, numeric/count/null/quality/held/order consistency. Held native pose/count/saturation/time is preserved; fault cannot revive into held. All supplied compact fields validate before disabled return. Source-invalid/C3-null/saturation values retain conservative C28 STOP semantics. Existing C28 applicability limits, calibration, goal sensitivity and map/risk logic remain untouched.

Only enabled input that passes local consistency calls the core once. Disabled or malformed compact input calls it zero times. Source age upper bounds stay inclusive100ms; current-age>100ms yields the original expired STOP. Output times are restored exactly to original QPC ns; no Fraction/legacy fake-ms escapes JSON. Post-core output failure keeps core_ran=true. The first protocol emits no child timestamps, and host original elapsed/freshness checks remain independent.

## Host obligation and honest unavailable boundary

C36's host `project_interval_json` is a separate implementation and must call C28 zero times. Full verified proof stays with A's original owner/provider, which alone binds proof, exact request bytes, owned process/package/pipe, one-use transcript, original host timing and output to _CompletedInference. The child neither sees nor authenticates that proof. There is no JSON authority boolean or self-claimed completion grant.

`make_request` is a serialization-only helper and performs no transport action. A missing public projection cannot produce request bytes. Test12 verifies that narrow boundary and zero fake dispatch; it does **not** prove A's real missing-proof gate, C36 full-proof correctness, source authentication or original provider integration. No fake host association is shipped as production proof. Current C38-R1/original external/current/capture/admission/BOOT/provider prerequisites remain unresolved by this package. A must never dispatch an eligible planner invocation when host proof is missing. A complete compact object alone is only a software diagnostic input, never authenticated provenance.

## Exact invocation and budgets

After separately materializing and approving an exact source tree:

`runtime/python.exe -I -B c37_entry.py --actor-stdio-v1 --max-invocations 1 --request-bytes N READY_HANDLE INPUT_HANDLE OUTPUT_HANDLE`

ActorPolicy arguments stop at N; the original actor appends the last three decimal handles. N is the host-retained actual full request byte count, 5..16384. The generic LE4 frame length accepts <=16384 payload, but a request JSON payload is <=16380 because the original request cap includes its prefix. No EOF wait, additional request, retry, remainder, resynchronization or pipeline. Counts>1 return exit64 before native acquisition. Future finite serial16 remains a specification only and cannot be enabled by a flag.

Envelope: abi='c37-owned-cpu-package/v1', kind='recommend', echo_ids, optional outer enabled (false default), input. Projected enabled is required and must equal effective outer enabled. Input follows frozen c36_c28_public_view_v1 with exactly9 top-level fields, observations7/action3. Strict duplicate keys, unknown/hidden fields, invalid bool/int types, nonfinite values, count/null and supplied contradictions reject. Combined candidate+history+actions<=32; JSON depth<=24/nodes<=4096; all ordinary arrays<=32.

No unsolicited stdout: after the complete original request, one request-hash-correlated READY then one RESULT. READY is <=2048 payload; RESULT<=16384; total<=18440, chunks<=8192. Original host recorder settings: max_output_bytes18440, max_reads64, read_size8192; original ActorPolicy cleanup output_limit<=8192 is a separate bound. A full malformed request gets bounded rejection with null/untrusted labels as appropriate; a short stream or failing initialization exits65 without traceback/private diagnostics. Short child output is terminal with no remainder. Rejection after core preserves core_ran. Every result has authority='none', completion_grant=false. Actual owner process terminal/cleanup must be checked independently by A.

## Existing runtime inventory and staging limits

`runtime-inventory.json` hashes633 actual existing CPython3.12.14 files, 35,473,690 bytes, including python.exe/python312.dll/python3.dll/VC runtime DLLs, standard Lib/DLLs and LICENSE.txt. Package files are listed separately. This is below ActorPolicy's268,435,456-byte stage bound. The venv launcher is not a portable closure: its pyvenv.cfg points to the recorded Codex runtime base, so the manifest uses that actual base executable and files. Third-party site-packages/test/demo/UI directories and pycache are excluded as recorded. Standard Windows system DLL/API-set dependencies remain OS prerequisites, not secretly copied files.

`stage_package.py` can explicitly materialize the exact hash-checked files into a **new** directory, emit the complete ActorPolicy file/hash list and entry template, and never launches an actor. It does no overwrite/delete, network/download or service operation. Runtime binaries were not copied or bundled; only their inventory and existing license hash are handed off. Runtime redistribution/license approval and A's actual approved version/OS/ACL staging are not inferred from software tests.

Precise remaining staging gap: the selected runtime has been inventoried, but this helper and a relocated isolated interpreter were **not executed**, and the native inherited-event/pipe entry was **not exercised** by an original owner. No completed portable closure/OS policy qualification is claimed. A must supply the exact inventoried bytes (or a newly reviewed replacement manifest), materialize/verify all import paths under the approved stage and system OS, and qualify original process/endpoint/dependency custody. Missing any exact runtime artifact fails staging; the entry cannot fall back to a runtime/plugin path from request JSON. The original host fixed policy still supplies system_root/local_appdata, immutable manifest, ready/lifetime/sample/probe deadlines and its existing registry checks.

## New validation evidence

run00 inventory: exit0, timeout25s, actual633 file hashes, no copied binaries. run01 new offline controls: exit0, 16 methods passed, actual unittest duration0.126s; subprocess duration under1s. Raw stdout/stderr, argv, exit and per-phase package hashes are retained. No failed candidate control or repair iteration occurred. These are new changed-path tests only; no historical suites were imported or replayed.

Coverage: original code object and exactly-one core call; high-QPC100ms/+1ns; legal fault/nullC3 and C3 non-fullscale saturation STOP; held one-cell history and no revival; disabled validation/required inner enabled;16384 full-wire boundary/trailing/truncated/invalid lengths; duplicate/nonfinite/BOM/type/conflicting enable;32/33 combined budget; fake fragmented read/no EOF/no unsolicited output; terminal short read/write and count>1 refusal; missing projection zero byte generation/dispatch; turn180 STOP/roll support; encoder oversize fault injection truthful core flag; exact output QPC/wire hash/large identity; fixed-core hash failure before import. The encoder injection only replaces the test encoder, never a core helper. Synthetic fixtures are explicitly labeled and do not imply actual Root/source/model proof.

## Preserved contract

DEEPEYE-HUMAN-LOCK-20261014/revision1, source f5989cd5defce561f9ba98e6b18fc2682945f0a2, requirements SHA c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804, fixed design1011259415a0916054eb580687612580bc1e5f09. H01-H15/original29/both H12/final100MHz/timing/1%/100ms unchanged. Common ABI freeze SHA bc9252ef38c3f55fd995406eabf4afb05f4ad7ed7c1befb85cc61f6a96ca4090. Main verifies public copying, independent review, Git and publication; this worker writes only implementation-v1.
