"""New bounded staging alias controls; no actor/native-handle/planner execution."""
import argparse, hashlib, importlib.util, json, pathlib, subprocess, sys

def main():
    ap=argparse.ArgumentParser();ap.add_argument('author',type=pathlib.Path);ap.add_argument('output',type=pathlib.Path)
    a=ap.parse_args();a.output.mkdir(exist_ok=False)
    spec=importlib.util.spec_from_file_location('stage_under_review',a.author/'stage_package.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    real=a.output/'real';real.mkdir();package=a.output/'package';package.mkdir()
    (real/'Lib').mkdir();payload=b'bounded synthetic staging bytes\n';(real/'Lib'/'item.py').write_bytes(payload)
    inventory={'files':[{'path':'runtime/Lib/item.py','bytes':len(payload),'sha256':hashlib.sha256(payload).hexdigest()}],'package_files':[]}
    (a.output/'input-inventory.json').write_text(json.dumps(inventory,indent=2),encoding='utf8')
    def junction(name,target):
        path=a.output/name
        proc=subprocess.run(['cmd','/c','mklink','/J',str(path),str(target)],capture_output=True,timeout=5)
        (a.output/(name+'.junction.stdout')).write_bytes(proc.stdout)
        (a.output/(name+'.junction.stderr')).write_bytes(proc.stderr)
        assert proc.returncode==0,proc.stderr
        assert path.is_junction()
        return path
    root_alias=junction('root-alias',real)
    package_alias=junction('package-alias',package)
    nested=a.output/'nested';nested.mkdir()
    proc=subprocess.run(['cmd','/c','mklink','/J',str(nested/'Lib'),str(real/'Lib')],capture_output=True,timeout=5)
    (a.output/'nested-junction.stdout').write_bytes(proc.stdout);(a.output/'nested-junction.stderr').write_bytes(proc.stderr)
    assert proc.returncode==0 and (nested/'Lib').is_junction()
    rows=[]
    for name,r,p,reject in [('ordinary-source',real,package,False),('root-junction',root_alias,package,True),
                           ('package-root-junction',real,package_alias,True),('intermediate-junction',nested,package,True)]:
        dest=a.output/('staged-'+name)
        try:
            result=module.materialize(r,p,inventory,dest);outcome='ACCEPTED'
        except ValueError as exc:
            result={'error':str(exc)};outcome='REJECTED'
        row={'name':name,'runtime_root':str(r),'package_root':str(p),'expected':'REJECTED' if reject else 'ACCEPTED',
             'observed':outcome,'result':result,'destination_created':dest.exists()}
        row['passed']=row['expected']==outcome;rows.append(row);print(json.dumps(row),flush=True)
    (a.output/'results.json').write_text(json.dumps(rows,indent=2),encoding='utf8')
    return 0 if all(x['passed'] for x in rows) else 1
if __name__=='__main__':raise SystemExit(main())
