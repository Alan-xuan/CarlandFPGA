"""One NEW synthetic relocated-interpreter/package smoke; no native transport."""
import argparse, copy, hashlib, importlib.util, json, pathlib, sys

def main():
    ap=argparse.ArgumentParser();ap.add_argument('stage',type=pathlib.Path);ap.add_argument('output',type=pathlib.Path)
    a=ap.parse_args();stage=a.stage.resolve();a.output.mkdir(exist_ok=False)
    assert sys.flags.isolated==1 and sys.flags.dont_write_bytecode==1
    assert pathlib.Path(sys.executable).resolve()==stage/'runtime/python.exe'
    assert pathlib.Path(sys.prefix).resolve()==stage/'runtime'
    spec=importlib.util.spec_from_file_location('relocated_entry',stage/'c37_entry.py')
    entry=importlib.util.module_from_spec(spec);spec.loader.exec_module(entry);p=entry.load_package()
    assert p._CORE.__code__ is p._FROZEN.recommend.__code__
    before=p._FROZEN.__dict__.copy()
    assert set(p._CORE.__globals__)==set(before)
    assert [k for k in before if p._CORE.__globals__[k] is not before[k]]==['_validate']
    now=(1<<63)-1; origin=now-100_000_000
    def pose(x=0,roll=False):return dict(position_m=[x,0,0],orientation_xyzw=[0,0,1,0] if roll else [0,0,0,1])
    old=dict(sample_id='1'*64,counts=[1740,2048,2048,0],quality=15,adc_qpc_ns=origin,em_qpc_ns=origin,adc_pose=pose(),em_pose=pose())
    current=copy.deepcopy(old);current.update(sample_id='2'*64,quality=0x70f,adc_qpc_ns=now-1,adc_pose=pose(.125))
    view=dict(schema_version=1,projection_id='c36_c28_public_view_v1',enabled=True,now_qpc_ns=now,pose=pose(.125,True),
              goal_m=[.125,0,8],observation=current,history=[old],executed_actions=[])
    ids=dict(operation_id='C37-independent-relocation',run_id='synthetic',actor_instance_id='not-owned',invocation_id=1,
             tested_commit='d'*40,package_manifest_sha256=hashlib.sha256((stage/'package-manifest.json').read_bytes()).hexdigest())
    snapshot=copy.deepcopy(view);wire=p.make_request(ids,view,enabled=True)
    (a.output/'request.bin').write_bytes(wire);(a.output/'request.json').write_bytes(wire[4:])
    calls=[]
    def profile(frame,event,arg):
        if event=='call' and frame.f_code is p._FROZEN.recommend.__code__:calls.append(frame.f_globals is p._CORE.__globals__)
    sys.setprofile(profile)
    try:raw=p.process_wire(wire)
    finally:sys.setprofile(None)
    (a.output/'response.bin').write_bytes(raw)
    replies=[];offset=0
    while offset<len(raw):
        n=int.from_bytes(raw[offset:offset+4],'little');replies.append(json.loads(raw[offset+4:offset+4+n]));offset+=4+n
    (a.output/'response.json').write_text(json.dumps(replies,indent=2),encoding='utf8')
    assert offset==len(raw) and len(replies)==2 and calls==[True]
    result=replies[1];assert result['status']=='RESULT' and result['core_ran'] is True
    assert result['result']['status']=='ADVISE' and result['result']['independent_em_count']==1
    assert result['result']['map_cells'][0]['em_qpc_ns']==origin
    assert result['result']['map_cells'][0]['pose']==old['em_pose']
    assert result['result']['observation']==current and result['echo_ids']==ids
    assert result['completion_grant'] is False and result['authority']=='none'
    assert 'tick_ms' not in json.dumps(replies) and view==snapshot
    assert set(before)==set(p._FROZEN.__dict__) and all(p._FROZEN.__dict__[k] is v for k,v in before.items())
    modules=[]
    for name,module in sorted(sys.modules.items()):
        source=getattr(module,'__file__',None)
        if not source or name=='__main__':continue
        path=pathlib.Path(source).resolve()
        assert path.is_relative_to(stage),(name,str(path))
        modules.append({'module':name,'path':path.relative_to(stage).as_posix(),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
    (a.output/'loaded-modules.json').write_text(json.dumps(modules,indent=2),encoding='utf8')
    print(json.dumps({'case':'NEW-relocated-uint63-held-roll-smoke','passed':True,'runtime':sys.version,
        'core_entries':len(calls),'module_origins_under_stage':len(modules),'input_unchanged':True,
        'request_sha256':hashlib.sha256(wire).hexdigest(),'response_sha256':hashlib.sha256(raw).hexdigest(),
        'actor_native_model_board_runs':0,'host_provenance_verified':False}))
if __name__=='__main__':main()
