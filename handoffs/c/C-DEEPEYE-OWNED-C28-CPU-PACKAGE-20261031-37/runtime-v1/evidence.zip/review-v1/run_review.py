import datetime, hashlib, json, pathlib, subprocess, sys
D=pathlib.Path(__file__).resolve().parent;A=D.parent/'implementation-v1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(A/'FINAL.json')=='0b56a0fb857119011c9c2a6385af69b381d9310d4b08f720785cfe216ecc33e9'
assert sha(A/'freeze.json')=='e348bbd037c8bef665ad60ca1cef1285153bff9179ebc3f549dc3983fefcef17'
freeze=json.loads((A/'freeze.json').read_bytes())
for pin in freeze['artifacts']:
    f=A/pin['file'];assert f.stat().st_size==pin['bytes'] and sha(f)==pin['sha256']
(D/'source-pins-before.json').write_text(json.dumps(freeze,indent=2),encoding='utf8')
inventory=json.loads((A/'runtime-inventory.json').read_bytes())
phases=[('alias-controls',[sys.executable,'-I','-B',str(D/'independent_stage_checks.py'),str(A),str(D/'alias-evidence')]),
        ('runtime-stage',[sys.executable,'-I','-B',str(A/'stage_package.py'),'--runtime-root',inventory['runtime_original_root'],
            '--package-root',str(A/'c37-owned-cpu-package'),'--inventory',str(A/'runtime-inventory.json'),'--destination',str(D/'runtime-stage')]),
        ('relocated-smoke',[str(D/'runtime-stage/runtime/python.exe'),'-I','-B',str(D/'relocated_smoke.py'),str(D/'runtime-stage'),str(D/'smoke-evidence')])]
rows=[]
for label,argv in phases:
    started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    try:
        result=subprocess.run(argv,cwd=D,capture_output=True,timeout=30)
        stdout,stderr,exitcode,timedout=result.stdout,result.stderr,result.returncode,False
    except subprocess.TimeoutExpired as exc:
        stdout,stderr,exitcode,timedout=exc.stdout or b'',exc.stderr or b'',None,True
    (D/(label+'.stdout')).write_bytes(stdout);(D/(label+'.stderr')).write_bytes(stderr)
    row=dict(label=label,argv=argv,cwd=str(D),started_utc=started,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
             timeout_seconds=30,timed_out=timedout,exit_code=exitcode,stdout_sha256=hashlib.sha256(stdout).hexdigest(),stderr_sha256=hashlib.sha256(stderr).hexdigest())
    (D/(label+'.command-exit.json')).write_text(json.dumps(row,indent=2),encoding='utf8');rows.append(row)
    print(json.dumps(row),flush=True)
    if label=='runtime-stage' and exitcode!=0:break
for pin in freeze['artifacts']:assert sha(A/pin['file'])==pin['sha256']
(D/'source-pins-after.json').write_text(json.dumps(freeze,indent=2),encoding='utf8')
raise SystemExit(1 if any(x['exit_code']!=0 for x in rows) else 0)
