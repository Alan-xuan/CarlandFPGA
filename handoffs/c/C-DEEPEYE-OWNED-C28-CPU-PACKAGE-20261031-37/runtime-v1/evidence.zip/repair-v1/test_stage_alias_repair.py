"""Only C37-R1 lexical alias controls; no package/planner/runtime smoke."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
from unittest.mock import patch

HERE = Path(__file__).absolute().parent
OLD = HERE.parent / 'review-implementation-v1' / 'alias-evidence'
OUT = HERE / 'new-controls'
OUT.mkdir(exist_ok=False)
spec = importlib.util.spec_from_file_location('repaired_stage', HERE/'stage_package.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
inventory = json.loads((OLD/'input-inventory.json').read_text(encoding='utf-8'))
original_results = json.loads((OLD/'results.json').read_text(encoding='utf-8'))
links, rows = [], []


def link(name, target, directory=True):
    path = OUT / name
    argv = ['cmd', '/c', 'mklink'] + (['/J'] if directory else []) + [str(path), str(target)]
    process = subprocess.run(argv, capture_output=True, timeout=5)
    (OUT/(name+'.link.stdout')).write_bytes(process.stdout)
    (OUT/(name+'.link.stderr')).write_bytes(process.stderr)
    record = dict(path=str(path), target=str(target), argv=argv, exit_code=process.returncode,
                  directory_junction=directory)
    links.append(record)
    (OUT/'links.json').write_text(json.dumps(links,indent=2)+'\n',encoding='utf-8')
    if process.returncode:
        raise RuntimeError('link control could not be created: '+name)
    assert path.lstat().st_file_attributes & 0x400
    return path


def case(name, runtime, package, inv, *, destination=None, reject=True):
    destination = destination or OUT/('staged-'+name)
    existed = destination.exists()
    actual_reads = []
    original_read = Path.read_bytes
    def audited_read(path):
        actual_reads.append(str(path))
        return original_read(path)
    try:
        with patch.object(Path, 'read_bytes', audited_read):
            result = helper.materialize(runtime, package, inv, destination)
        observed = 'ACCEPTED'
    except ValueError as error:
        result, observed = {'error':str(error)}, 'REJECTED'
    passed = observed == ('REJECTED' if reject else 'ACCEPTED')
    if reject:
        passed = passed and not actual_reads and destination.exists() == existed
    else:
        target = destination/'runtime/Lib/item.py'
        passed = passed and hashlib.sha256(target.read_bytes()).hexdigest() == inv['files'][0]['sha256']
    row = dict(name=name, runtime_root=str(runtime), package_root=str(package),
               destination=str(destination), expected='REJECTED' if reject else 'ACCEPTED',
               observed=observed, source_data_reads=actual_reads,
               destination_existed_before=existed, destination_exists_after=destination.exists(),
               result=result, passed=passed)
    rows.append(row)
    print(json.dumps(row), flush=True)
    (OUT/'results.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')


# Reuse the exact original reviewer inputs read-only, never its destinations.
for original in original_results:
    case('original-'+original['name'], Path(original['runtime_root']), Path(original['package_root']),
         inventory, reject=original['expected']=='REJECTED')

runtime, package = OLD/'real', OLD/'package'
root_parent = link('runtime-ancestor', OLD)
case('runtime-ancestor-component', root_parent/'real', package, inventory)
package_parent = link('package-ancestor', OLD)
case('package-ancestor-component', runtime, package_parent/'package', inventory)

package2 = OUT/'ordinary-package'; package2.mkdir()
pkg_link = link('package-intermediate-target', runtime/'Lib')
# Place the junction itself under the package root, without moving old evidence.
package_inventory = {'files':[], 'package_files':[dict(inventory['files'][0], path='package-intermediate-target/item.py')]}
case('package-intermediate-component', runtime, OUT, package_inventory)

leaf = link('final-source-file', runtime/'Lib/item.py', directory=False)
leaf_inventory = {'files':[], 'package_files':[dict(inventory['files'][0], path=leaf.name)]}
case('final-file-symlink', runtime, OUT, leaf_inventory)

leaf_directory = link('final-source-junction', runtime/'Lib')
directory_inventory = {'files':[], 'package_files':[dict(inventory['files'][0], path=leaf_directory.name)]}
case('final-source-reparse-junction', runtime, OUT, directory_inventory)

dest_target = OUT/'ordinary-destination-parent'; dest_target.mkdir()
dest_parent = link('destination-parent-alias', dest_target)
case('destination-parent-component', runtime, package, inventory, destination=dest_parent/'new-stage')
dest_leaf = link('destination-final-alias', dest_target)
case('destination-final-component', runtime, package, inventory, destination=dest_leaf)
case('lexical-parent-traversal', root_parent/'..'/'real', package, inventory)

print(json.dumps({'controls':len(rows),'passed':sum(x['passed'] for x in rows),
                  'original_RED_replayed':3,'core_runs':0,'relocated_smoke_runs':0}))
raise SystemExit(0 if all(x['passed'] for x in rows) else 1)
