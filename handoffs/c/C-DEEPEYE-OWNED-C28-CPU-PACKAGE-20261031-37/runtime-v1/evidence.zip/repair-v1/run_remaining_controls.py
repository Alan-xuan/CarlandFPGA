"""Bounded continuation only, preserving run01 and every passed case."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys

root=Path(__file__).absolute().parent
argv=[sys.executable,'-I','-B',str(root/'test_stage_remaining.py')]
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
try:
    r=subprocess.run(argv,cwd=root,capture_output=True,timeout=25)
    out,err,code,timed_out=r.stdout,r.stderr,r.returncode,False
except subprocess.TimeoutExpired as e:
    out,err,code,timed_out=e.stdout or b'',e.stderr or b'',None,True
(root/'run02.stdout').write_bytes(out);(root/'run02.stderr').write_bytes(err)
record=dict(argv=argv,cwd=str(root),started_utc=started,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            timeout_seconds=25,timed_out=timed_out,exit_code=code,
            helper_sha256=hashlib.sha256((root/'stage_package.py').read_bytes()).hexdigest(),
            test_sha256=hashlib.sha256((root/'test_stage_remaining.py').read_bytes()).hexdigest())
(root/'run02.command-exit.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record));print(out.decode('utf-8',errors='replace'));print(err.decode('utf-8',errors='replace'))
raise SystemExit(124 if timed_out else code)
