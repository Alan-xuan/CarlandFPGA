# C37-R1 narrow staging helper repair

Work C37-STAGE-ALIAS-REPAIR-v1; actual agent /root/c28_planner_author, thread01a18676-bad1-7031-b26e-7da2ef7dc2dc. Only repair-stage-v1 is written. Original author/reviewer directories, package/entry/core and frozen evidence remain unchanged. This repair is ready for main's independent verification, not production acceptance.

Original helper SHA256: 7cbe995fefefd42fdf603ee7ad8b8c559e80381071387a35603e2459b5d7f276. New helper SHA256: 07293493207c19f7b39297165907c28e221797b0b2c037e9b1c85d28a3597c14. Exact original bytes are retained as stage_package.original.py, and stage_package.diff is the complete change.

The old helper resolved supplied roots before inspecting them, hiding root aliases, and checked only the final source is_symlink. The repair keeps absolute lexical paths without resolve, rejects lexical `..`, and checks components from volume/root to leaf using lstat. A symlink mode or any Windows FILE_ATTRIBUTE_REPARSE_POINT (0x400), including directory junctions, rejects before traversal into that component. Both supplied source roots are checked even when their file lists are empty. Every selected source component is checked before its read_bytes call. Destination ancestors/final component are checked before input reads and again immediately before mkdir; only a missing final destination is allowed. Missing intermediate parents still refuse.

Original byte/hash checks, duplicate-case/256MiB aggregate budget, new-destination requirement, exact output source-file manifest and single-invocation entry template are unchanged. No planner/core/ABI or runtime file changes. This is a lexical preflight repair, not a proof against concurrent filesystem replacement; A's original retained owner/ACL/staging continuity checks remain necessary.

## Actual new evidence

run01 used the original reviewer inventory and exact ordinary/root-junction/package-root-junction/intermediate-junction fixtures read-only, with new private output destinations. All four passed: normal bytes copied exactly, three original RED inputs rejected with zero source-data reads and no destination creation. Three further actual controls passed for a runtime-root ancestor junction, package-root ancestor junction, and intermediate package source junction.

run01 then exited1 while constructing the next fixture: Windows `cmd /c mklink` refused an actual file symlink with "You do not have sufficient privilege to perform this operation." The command, stdout/stderr, exit and traceback are preserved. This is a fixture capability failure, not an observed helper failure. No elevation or retry was attempted; the seven passed cases were not rerun.

run02, same unchanged repaired helper, ran only five remaining controls and exited0: an actual final-source directory junction/reparse point; actual destination-parent and final-destination junctions; lexical parent traversal; and an explicitly simulated final file-symlink stat-mode branch. All rejected before source-data reads and before any new destination creation. The existing destination-junction control left the original junction unchanged. The simulated mode control is not labeled actual Windows file-symlink evidence. Actual file-symlink fixture execution remains NOT_RUN due to privilege denial.

Across both phases:12 distinct completed controls pass, including three exact original RED closures;11 use actual paths and one is a simulated stat branch. Both subprocesses were bounded25s and returned in under1s; all link subprocesses were bounded5s and closed. Raw results, argv, exit codes and per-phase helper/test hashes are retained. No author16 rerun, relocated runtime smoke, core/model/original actor/board execution or service/Git action occurred.

Small new alias fixtures are retained under new-controls and remaining-controls. The freeze records their reparse metadata/targets without traversing them. No recursive cleanup is performed; original review aliases and all old failure evidence remain intact.

Contract DEEPEYE-HUMAN-LOCK-20261014/revision1, source f5989cd5defce561f9ba98e6b18fc2682945f0a2, requirements SHA c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804, fixed design1011259415a0916054eb580687612580bc1e5f09. H01-H15/original29/both H12/final100MHz/timing/1%/100ms unchanged. Main owns independent acceptance and publication.
