"""One bounded alias-only phase with raw output and immutable source pins."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).absolute().parent
argv = [sys.executable, '-I', '-B', str(root/'test_stage_alias_repair.py')]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
try:
    result = subprocess.run(argv, cwd=root, capture_output=True, timeout=25)
    out, err, code, timed_out = result.stdout, result.stderr, result.returncode, False
except subprocess.TimeoutExpired as error:
    out, err, code, timed_out = error.stdout or b'', error.stderr or b'', None, True
(root/'run01.stdout').write_bytes(out)
(root/'run01.stderr').write_bytes(err)
record = dict(argv=argv, cwd=str(root), started_utc=started,
              finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              timeout_seconds=25, timed_out=timed_out, exit_code=code,
              helper_sha256=hashlib.sha256((root/'stage_package.py').read_bytes()).hexdigest(),
              test_sha256=hashlib.sha256((root/'test_stage_alias_repair.py').read_bytes()).hexdigest())
(root/'run01.command-exit.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record))
print(out.decode('utf-8',errors='replace'))
print(err.decode('utf-8',errors='replace'))
raise SystemExit(124 if timed_out else code)
