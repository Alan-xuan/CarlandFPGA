"""Only remaining new alias controls after run01 file-symlink capability failure."""
import hashlib
import importlib.util
import json
from pathlib import Path
import stat
import subprocess
import types
from unittest.mock import patch

HERE = Path(__file__).absolute().parent
OLD = HERE.parent/'review-implementation-v1/alias-evidence'
OUT = HERE/'remaining-controls'
OUT.mkdir(exist_ok=False)
spec = importlib.util.spec_from_file_location('repaired_stage', HERE/'stage_package.py')
helper = importlib.util.module_from_spec(spec); spec.loader.exec_module(helper)
inventory = json.loads((OLD/'input-inventory.json').read_text(encoding='utf-8'))
runtime, package = OLD/'real', OLD/'package'
rows, links = [], []


def link(name, target):
    path = OUT/name
    argv = ['cmd','/c','mklink','/J',str(path),str(target)]
    proc = subprocess.run(argv,capture_output=True,timeout=5)
    (OUT/(name+'.link.stdout')).write_bytes(proc.stdout)
    (OUT/(name+'.link.stderr')).write_bytes(proc.stderr)
    links.append(dict(argv=argv,exit_code=proc.returncode,path=str(path),target=str(target)))
    (OUT/'links.json').write_text(json.dumps(links,indent=2)+'\n',encoding='utf-8')
    assert proc.returncode==0 and path.lstat().st_file_attributes & 0x400
    return path


def case(name, r, q, inv, destination=None, simulated_file=None):
    dest = destination or OUT/('staged-'+name)
    existed = dest.exists(); reads=[]
    original_read, original_lstat = Path.read_bytes, Path.lstat
    def read(path):
        reads.append(str(path)); return original_read(path)
    def lstat(path, *args, **kwargs):
        info = original_lstat(path,*args,**kwargs)
        if simulated_file is not None and path == simulated_file:
            return types.SimpleNamespace(st_mode=stat.S_IFLNK|0o777,st_file_attributes=0)
        return info
    try:
        with patch.object(Path,'read_bytes',read), patch.object(Path,'lstat',lstat):
            helper.materialize(r,q,inv,dest)
        observed,error='ACCEPTED',None
    except ValueError as exc:
        observed,error='REJECTED',str(exc)
    row=dict(name=name,expected='REJECTED',observed=observed,error=error,
             source_data_reads=reads,destination_existed_before=existed,destination_exists_after=dest.exists(),
             simulated_file_symlink_stat=simulated_file is not None,
             passed=observed=='REJECTED' and not reads and dest.exists()==existed)
    rows.append(row); print(json.dumps(row),flush=True)
    (OUT/'results.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')


leaf = link('final-source-junction',runtime/'Lib')
inv={'files':[],'package_files':[dict(inventory['files'][0],path=leaf.name)]}
case('final-source-reparse-junction',runtime,OUT,inv)
target=OUT/'destination-parent'; target.mkdir()
parent=link('destination-parent-alias',target)
case('destination-parent-component',runtime,package,inventory,destination=parent/'new-stage')
leaf_dest=link('destination-final-alias',target)
case('destination-final-component',runtime,package,inventory,destination=leaf_dest)
case('lexical-parent-traversal',HERE/'new-controls/runtime-ancestor/../real',package,inventory)

# The preceding real mklink file-symlink attempt was denied. This is an explicit
# unit stat-branch check, not a claim of actual Windows file-symlink creation.
test_file=OUT/'synthetic-file'; test_file.write_bytes(b'bounded synthetic staging bytes\n')
inv={'files':[],'package_files':[dict(inventory['files'][0],path=test_file.name)]}
case('simulated-final-file-symlink-mode',runtime,OUT,inv,simulated_file=test_file)
print(json.dumps({'remaining_controls':len(rows),'passed':sum(r['passed'] for r in rows),
                  'actual_file_symlink_control':'NOT_RUN_mklink_privilege_denied_run01',
                  'planner_actor_relocation_runs':0}))
raise SystemExit(0 if all(r['passed'] for r in rows) else 1)
