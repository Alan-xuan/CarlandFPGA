from pathlib import Path
import ast,difflib,hashlib,json,shutil
D=Path(__file__).resolve().parent;W=D.parent;A=W/'repair-v1';B=W/'implementation-v1';OLD=W/'independent-review-v1';R=W.parents[2]
def sha(b):return hashlib.sha256(b).hexdigest()
def pin(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def check(root,rows):
 for r in rows:
  p=root/r['path'];b=p.read_bytes();assert len(b)==r['bytes']and sha(b)==r['sha256'],p
 return len(rows)
assignment=W/'main/repair-review-assignment-v1.json'
assert sha(assignment.read_bytes())=='3eb4fbaa1cd843766e3026760e61e8cff76a51b7996014666e2b8c37e7a4b3f1'
assert sha((A/'FINAL.json').read_bytes())=='34bbc28d5abbd4f7f1c22e332f958033577785458f274173f05ecbacdfc0c2c8'
assert sha((A/'freeze.json').read_bytes())=='a933efc7024d98acd46af7ae0e3ae870138cf27e59e281aadc9541e403cbc577'
count=check(A,json.loads((A/'freeze.json').read_bytes())['files'])
old_count=check(OLD,json.loads((OLD/'freeze.json').read_bytes())['files'])
assert sha((OLD/'FINAL.json').read_bytes())=='1a33a33a0aea03bcc2c478af2282cfeee4c84d656ec59c7b0413fd8cca1f82aa'
changed=[];pins=[]
for sub in ('candidate','deps','inputs'):
 before={p.relative_to(B/sub).as_posix():p for p in (B/sub).rglob('*')if p.is_file()}
 after={p.relative_to(A/sub).as_posix():p for p in (A/sub).rglob('*')if p.is_file()}
 assert before.keys()==after.keys(),sub
 for name,p in after.items():
  pins.append(pin(p))
  if p.read_bytes()!=before[name].read_bytes():changed.append(sub+'/'+name)
target='candidate/competition/deepeye/simulation/authority/raw4_owned_join_v1.py';assert changed==[target],changed
assert sha((A/target).read_bytes())=='109d246f826d9484e278ae919042c1ce6e86d3eece7ca4f1ecdbbada71b1fd34'
assert (A/'test_join_new.py').read_bytes()==(B/'test_join_new.py').read_bytes()
control=OLD/'independent_history_check.py';assert control.read_bytes()==(A/control.name).read_bytes()
assert sha(control.read_bytes())=='b94983cbd5ad185519b1fad63258c87f54f4f9a29c7273671b8fa887de05438a'
shutil.copyfile(control,D/control.name)
diff=''.join(difflib.unified_diff((B/target).read_text().splitlines(True),(A/target).read_text().splitlines(True),fromfile='rejected/'+target,tofile='repaired/'+target))
assert diff==(A/'repair.patch').read_text()
shutil.copyfile(A/'repair.patch',D/'exact-repair.patch')
def symbols(p):
 t=ast.parse(p.read_bytes());out={}
 for n in t.body:
  if isinstance(n,ast.FunctionDef):out[n.name]=ast.dump(n,include_attributes=False)
  if isinstance(n,ast.ClassDef):
   for f in n.body:
    if isinstance(f,ast.FunctionDef):out[n.name+'.'+f.name]=ast.dump(f,include_attributes=False)
 return out
before=symbols(B/target);after=symbols(A/target)
ast_changed=sorted(k for k in before.keys()|after.keys()if before.get(k)!=after.get(k))
assert ast_changed==['Raw4Session._check_export','Raw4Session._check_retention','Raw4Session.check_entry','Raw4Session.export_entry']
runs=[]
for d in sorted((A/'runs').iterdir()):
 if d.is_dir():
  rows={n:json.loads((d/n).read_bytes())for n in ('command.json','exit.json','stdout.json')}
  rows.update(run=d.name,stderr=(d/'stderr.txt').read_text(),source=pin(d/'source.py'),raw_pins=[pin(d/n)for n in ('command.json','stdout.json','stderr.txt','exit.json')]);runs.append(rows)
assert [r['exit.json']['exit_code']for r in runs]==[1,0,0]
scope=json.loads((R/'.local/plan-20261014-final-c/immutable-f5989cd/immutable_scope.json').read_bytes())
req=sha(json.dumps(scope['requirements'],sort_keys=True,separators=(',',':'),ensure_ascii=False).encode());assert req=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
report=dict(assignment=pin(assignment),author_FINAL=pin(A/'FINAL.json'),author_freeze=pin(A/'freeze.json'),author_frozen_files=count,old_review_files_unchanged=old_count,changed_products=changed,ast_changed=ast_changed,source_pins=pins,control=pin(D/control.name),all_other_candidate_deps_inputs_harness_unchanged=True,exact_patch_match=True,requirements_sha256=req,runs=runs,tests_executed=False)
(D/'audit.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print(json.dumps({k:v for k,v in report.items()if k not in ('source_pins','runs')},indent=2))
print(json.dumps(runs,indent=2))
