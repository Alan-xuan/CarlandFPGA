from pathlib import Path
import json,subprocess,sys
D=Path(__file__).resolve().parent;out=D/sys.argv[1];out.mkdir(exist_ok=False)
cmd=[sys.executable,'-X','utf8','-B',str(D/sys.argv[2]),*sys.argv[3:]]
(out/'command.json').write_text(json.dumps(dict(argv=cmd,cwd=str(D),timeout_seconds=30),indent=2)+'\n')
p=subprocess.run(cmd,cwd=D,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30)
(out/'stdout.txt').write_bytes(p.stdout);(out/'stderr.txt').write_bytes(p.stderr);(out/'exit.json').write_text(json.dumps(dict(exit_code=p.returncode))+'\n')
print(p.stdout.decode('utf8'));print(p.stderr.decode('utf8'));print(json.dumps(dict(exit_code=p.returncode)));raise SystemExit(p.returncode)
