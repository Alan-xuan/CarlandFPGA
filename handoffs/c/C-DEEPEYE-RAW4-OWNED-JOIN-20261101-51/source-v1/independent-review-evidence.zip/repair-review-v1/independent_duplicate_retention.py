"""One NEW adjacent control for extracted retention and committed duplicates.
Usage: python -B independent_duplicate_retention.py REPAIR_DIR OUTPUT_DIR
Only reused synthetic graph setup executes; no existing author case/main.
No actual Root/actor/core/native/board; old Root successor is synthetic.
"""
import ast,json,sys,types,hashlib
from pathlib import Path
A=Path(sys.argv[1]).resolve();D=Path(sys.argv[2]).resolve();p=A/'test_join_new.py'
t=ast.parse(p.read_bytes());nodes=[]
for n in t.body:
 if isinstance(n,ast.FunctionDef)and n.name=='mechanical_bind':break
 nodes.append(n)
nodes.append(next(n for n in t.body if isinstance(n,ast.FunctionDef)and n.name=='route_modules'))
ctx={'__name__':'independent_repair_setup','__file__':str(p)};exec(compile(ast.Module(body=nodes,type_ignores=[]),str(p),'exec'),ctx)
j=ctx['join'];z=ctx['graph']();s=j.Raw4Session(z.channel)
for record,selection in zip(z.records,z.channel._raw4_selections):s.bind(record,selection)
entry=s._entries[-1];s.check_entry(entry)
successor=types.SimpleNamespace(boot=z.comp._boot);z.book._root=z.comp._executor._root=successor
def rejects(fn):
 try:fn()
 except ValueError as e:return str(e)
 raise AssertionError('unexpected acceptance')
active_error=rejects(lambda:s.check_entry(entry));assert active_error=='original registry refs/state changed'
# The existing policy is responsible for selecting the committed duplicate path.
# This new control checks only that helper branch, not a command publication.
s.check_entry(entry,committed_duplicate=True)
old=entry['record'].refs['preparation'];entry['record'].refs['preparation']=types.SimpleNamespace(original=old.original)
duplicate_error=rejects(lambda:s.check_entry(entry,committed_duplicate=True));assert duplicate_error=='original selected source changed'
entry['record'].refs['preparation']=old;s.check_entry(entry,committed_duplicate=True)
result=dict(case='successor_root_committed_duplicate_still_checks_retention',pass_=True,ordinary_current_hold_error=active_error,duplicate_with_intact_retention_accepted=True,changed_preparation_same_bytes_duplicate_error=duplicate_error,restored_reference_accepted=True,synthetic_root=True,author_cases_executed=0,core_native_dispatch_calls=0,source_sha256=hashlib.sha256((A/'candidate/competition/deepeye/simulation/authority/raw4_owned_join_v1.py').read_bytes()).hexdigest())
(D/'observed.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');print(json.dumps(result,indent=2))
