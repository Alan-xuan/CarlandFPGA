# C51-R1 independent closure — bounded source approval

**R1 is closed on the reviewed repaired source.** The exact original counterexample now rejects the replaced historical preparation before exporting a usable result, while its unchanged positive full proof still projects. No new blocking finding was found in this one-file repair. This is source approval for the C51 slice, not A installation, production recovery or formal task acceptance.

Reviewed module: `candidate/competition/deepeye/simulation/authority/raw4_owned_join_v1.py`, 23,828 bytes, SHA256 `109d246f826d9484e278ae919042c1ce6e86d3eece7ca4f1ecdbbada71b1fd34`. Author FINAL SHA `34bbc28d5abbd4f7f1c22e332f958033577785458f274173f05ecbacdfc0c2c8`; freeze SHA `a933efc7024d98acd46af7ae0e3ae870138cf27e59e281aadc9541e403cbc577`.

## Source review

The exact one-product-file diff was regenerated and matched `repair.patch` under normal newline reading; its original bytes are retained as `exact-repair.patch`. All seven other candidate files, dependencies, input JSON and the setup harness are byte-identical to rejected v1. AST changes are limited to `Raw4Session.check_entry`, `export_entry`, and the two new helpers `_check_retention` / `_check_export`.

`_check_retention` contains the former existing record/phase/sample identity, copied candidate/fields byte snapshot and `_selected` reference/byte comparisons. Thus the gate still checks historical preparation, token, admitted record, admission, payload, draft and phase references as well as their retained source/request/response values. It does not impose the current Root/getter on historical captures.

`export_entry` captures `tuple(self._entries)`, checks equal membership length and each ordered object identity, checks the selected current entry with its original hold, then checks every other entry's retained refs/bytes. Both exported capture/history arrays use that captured tuple. The same checks run after the fixed C50 projector returns, before a result can return to the caller. A historical native EM capture, when included in this retained set, receives the same original-retention check; held-origin construction and C50 structural/temporal checks are unchanged. Missing required origin still cannot be manufactured by this repair.

The distinction between history and current holds is explicit. `_check_retention` does not label history as a committed duplicate. `check_entry` still performs live session checks and current hold checks unless its existing committed-duplicate argument is true, then always calls `_check_retention`. The policy selecting that duplicate argument, source/dispatch/previous caps, current association checks and one-use command/slot rules are unchanged. The repair does not add callbacks or allow arbitrary projection-time code; the author's wrappers described below are fault injection only.

Prior M1–M5 static conclusions remain those recorded in the sealed v1 REVIEW. The changed helpers resolve the separate R1 omission; they do not upgrade any earlier synthetic test to a real Root run or retroactively re-label old source versions.

## Independent execution

Only two bounded pure controls ran, each under a 30-second subprocess bound:

1. `replay-run01`, exit **0**: copied original `independent_history_check.py` is byte-exact, 3,528 bytes, SHA256 `b94983cbd5ad185519b1fad63258c87f54f4f9a29c7273671b8fa887de05438a`. Positive two-entry graph returns PROJECTED/core_ran=false. Replacing only the historical preparation object, with identical underlying original bytes, now causes `export_entry` to reject with `original selected source changed`. The source/input fixture/harness hashes are recorded. The original failed directory and all its bytes remain untouched.
2. `adjacent-run01`, exit **0**: one NEW combination targeting the extracted helper's duplicate branch. After a synthetic successor Root replaces both executor/book Root, normal `check_entry` rejects the old current hold. The already-committed duplicate helper path accepts the intact retained entry; replacing its preparation with a different object containing the same original bytes then rejects; restoring the original reference accepts. This tests the helper branch only, not actual command submission/commit or the policy's authorization to select it.

Both controls AST-reuse only the frozen author's synthetic graph setup. None of the author's cases/main or older suites execute. The replay uses the real fixed C50 projector; the new duplicate check invokes no projector/core. Root allocations, clock/checkpoint and authority-type setup are synthetic. There are zero actual Root/native/actor dispatch/model/PDE/C28 inference/board calls. Original/changed proof output and observations are saved without rewriting. These are one affected replay and one new combined control, not a broad test matrix.

## Reviewed author evidence and integrity

All 67 repair freeze entries and all 29 sealed old-review entries were independently checked. The seven other candidate/dependency/input/setup copies were compared against v1. Fixed H01–H15 requirements hash was recomputed as `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804`. `audit.json` retains source pins and all three actual author commands/stdout/stderr/exits:

- Author run01: original join `2aa67962...`, original counterexample, exit1. This remains RED on the rejected source.
- Author run02: repaired join `109d246f...`, byte-identical control, exit0.
- Author run03: repaired join, exit0; distinct historical Root/getter, changed historical phase bytes, mutations after the real projector (historical preparation, member replacement/append/order), and current veto/hold. These four author groups were read and source-reviewed, not rerun by this reviewer. Their multiple internal variants are not independent production tests.

The independent integrity/audit subprocess exited0. The first read command in this review mistakenly requested `repair.diff`; the actual file is `repair.patch`. Its original exit1 is preserved in native tool evidence and was a read-path error, not a product failure. No source files were changed. There was no publication, service, network/peer, credential, SQL or board operation.

Default production preallocation refusal remains. A's real original registry branch, factory wiring, real finite joined lifecycle and formal acceptance are NOT_RUN/uncompleted here. H01–H15, both H12 obligations and A-only physical-board ownership remain unchanged. Main owns final acceptance/publication.

Ownership of this review scope is released after the successful finalizer exit and final response. No owned background jobs or subprocesses remain.
