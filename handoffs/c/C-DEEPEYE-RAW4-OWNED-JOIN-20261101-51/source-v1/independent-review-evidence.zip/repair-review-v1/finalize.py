from pathlib import Path
import hashlib,json,datetime
D=Path(__file__).resolve().parent;W=D.parent;A=W/'repair-v1';OLD=W/'independent-review-v1';B=W/'implementation-v1'
assignment=json.loads((W/'main/repair-review-assignment-v1.json').read_bytes())
def pin(p,base=None):
 b=p.read_bytes();return dict(path=p.relative_to(base).as_posix()if base else str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def write(n,obj):(D/n).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
counts={}
for root in (A,OLD,B):
 rows=json.loads((root/'freeze.json').read_bytes())['files'];counts[root.name]=len(rows)
 for r in rows:
  p=root/r['path'];b=p.read_bytes();assert len(b)==r['bytes']and hashlib.sha256(b).hexdigest()==r['sha256'],p
assert pin(A/'FINAL.json')['sha256']==assignment['candidate_FINAL_sha256']
assert pin(A/'freeze.json')['sha256']==assignment['candidate_freeze_sha256']
for run in ('audit-run','replay-run01','adjacent-run01'):assert json.loads((D/run/'exit.json').read_bytes())['exit_code']==0
assert (D/'independent_history_check.py').read_bytes()==(OLD/'independent_history_check.py').read_bytes()
assert (D/'replay-run01/positive-full.json').read_bytes()==(OLD/'history-run01/positive-full.json').read_bytes()
assert (D/'replay-run01/positive-result.json').read_bytes()==(OLD/'history-run01/positive-result.json').read_bytes()
replay=json.loads((D/'replay-run01/observed.json').read_bytes());adjacent=json.loads((D/'adjacent-run01/observed.json').read_bytes())
assert replay['pass_']and adjacent['pass_']
write('FINDINGS.json',dict(source_approved=True,approval_scope='bounded C51 source slice after one-file R1 repair; no production/runtime approval',open_findings=[],closed_findings=[dict(id='C51-R1',status='CLOSED',module_sha256='109d246f826d9484e278ae919042c1ce6e86d3eece7ca4f1ecdbbada71b1fd34',evidence=['replay-run01/observed.json','adjacent-run01/observed.json'],prior_rejected_source_sha256='2aa67962610a5b3cdda0e12c91ef2c6ca68f08a4a7d97dcea2285d0e4d758082',original_RED_preserved=True)],actual_A_installation_run=False,production_restored=False))
audit=json.loads((D/'audit.json').read_bytes())
write('source-pins.json',dict(source_pins=audit['source_pins'],author_final=audit['author_FINAL'],author_freeze=audit['author_freeze'],original_control=audit['control'],fixture=pin(A/'inputs/source-data.json'),setup=pin(A/'test_join_new.py'),prior_review_FINAL=pin(OLD/'FINAL.json'),post_execution_all_freezes_verified=counts,positive_full_and_result_byte_equal_to_original=True))
session=Path(assignment['original_session_metadata_path']);lines=session.read_bytes().splitlines();meta=json.loads(lines[0]);assert meta['type']=='session_meta'and meta['payload']['id']==assignment['actual_thread_id']
selected=[];calls={};outputs={}
for line in lines:
 r=json.loads(line)
 if r['type']=='session_meta' or r.get('timestamp','')>=assignment['created_utc']:
  selected.append(line);p=r.get('payload',{})
  if r['type']=='response_item'and p.get('type')=='function_call':calls[p['call_id']]=p
  if r['type']=='response_item'and p.get('type')=='function_call_output':outputs[p['call_id']]=p
(D/'native-session-records.jsonl').write_bytes(b'\n'.join(selected)+b'\n')
write('execution-snapshot.json',dict(actual_thread_id=meta['payload']['id'],session_metadata=meta,original_session=str(session),cutoff='current finalizer invocation; actual finalizer exit and final response are independently audited by main from original session',calls_seen=len(calls),outputs_seen=len(outputs),pending_at_cutoff=[k for k in calls if k not in outputs],independent_raw_exits={'audit':0,'original_control_replay':0,'new_duplicate_combination':0},initial_read_path_error_exit=1,owned_jobs=[],owned_subprocesses_after_finalizer_exit=[],actual_Root_native_core_model_board_runs=0))
files=[pin(p,D)for p in sorted(D.rglob('*'))if p.is_file()and p.name not in ('FINAL.json','freeze.json')];write('freeze.json',dict(files=files))
final={k:assignment[k]for k in ('task_id','task_version','work_id','operation_id','actual_agent_id','actual_thread_id','main_thread_id','contract_id','contract_revision','contract_source','requirements_sha256','fixed_design','source_A_commit')}
final.update(status='R1_CLOSED_BOUNDED_SOURCE_APPROVAL',source_approved=True,review_passed=True,R1_closed=True,open_findings=[],candidate_FINAL_sha256=assignment['candidate_FINAL_sha256'],candidate_freeze_sha256=assignment['candidate_freeze_sha256'],module_sha256='109d246f826d9484e278ae919042c1ce6e86d3eece7ca4f1ecdbbada71b1fd34',freeze=pin(D/'freeze.json',D),artifact_count=len(files),independent_replay_exit=0,independent_new_combination_exit=0,hash_audit_exit=0,author_groups_replayed=0,actual_A_installation_runtime_formal_acceptance=False,production_restored=False,actual_Root_native_core_model_board_runs=0,ownership_released=True,jobs=[],subprocesses=[],release_condition='successful finalizer exit followed by final response; main audits actual session closure',completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());write('FINAL.json',final)
print(json.dumps(dict(FINAL=pin(D/'FINAL.json',D),freeze=pin(D/'freeze.json',D),artifact_count=len(files),R1_closed=True,source_approved=True,jobs=[],subprocesses=[])))
