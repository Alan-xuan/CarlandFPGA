from pathlib import Path
import ast,difflib,hashlib,json
D=Path(__file__).resolve().parent;W=D.parent;A=W/'implementation-v1';M=W/'root-interface-map-v1';R=W.parents[2]
def sha(b):return hashlib.sha256(b).hexdigest()
def pin(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def check(root,rows):
 for row in rows:
  p=root/row.get('snapshot_path',row.get('path',''));b=p.read_bytes()
  assert len(b)==row['bytes'] and sha(b)==row['sha256'],p
 return len(rows)
assert sha((W/'main/review-assignment-v1.json').read_bytes())=='e2a78f6371fca8bbc7d6b8bdb2736ee04dda74d6a4eb39eefc32fb6d59dd7951'
assert sha((A/'FINAL.json').read_bytes())=='c3a155f2eaf0781f46cda3626441a0aab2c15ec9fe044849c7232953aaffdb5c'
assert sha((A/'freeze.json').read_bytes())=='ec6f583922aa0fd8850caf8bd7e2f17f4588d41d9ed736e52c455f3b3dafbb04'
frozen=check(A,json.loads((A/'freeze.json').read_bytes())['files'])
baseline=json.loads((A/'baseline-pins.json').read_bytes());check(A/'baseline',baseline)
for row in baseline:assert sha(Path(row['source']).read_bytes())==row['sha256']
deps=check(A,json.loads((A/'dependency-pins.json').read_bytes()))
mapping=json.loads((M/'source-pins.json').read_bytes())['files'];check(M,mapping)
diff=[];sources=[];ast_changes=[]
for p in sorted((A/'candidate').rglob('*.py')):
 rel=p.relative_to(A/'candidate');old=A/'baseline'/rel;ast.parse(p.read_bytes())
 diff.extend(difflib.unified_diff(old.read_text().splitlines(True)if old.exists()else[],p.read_text().splitlines(True),fromfile='a/'+rel.as_posix()if old.exists()else'/dev/null',tofile='b/'+rel.as_posix()))
 sources.append(pin(p))
 def symbols(text):
  t=ast.parse(text);out={}
  for n in t.body:
   if isinstance(n,ast.FunctionDef):out[n.name]=ast.dump(n,include_attributes=False)
   if isinstance(n,ast.ClassDef):
    for f in n.body:
     if isinstance(f,ast.FunctionDef):out[n.name+'.'+f.name]=ast.dump(f,include_attributes=False)
  return out
 before=symbols(old.read_bytes())if old.exists()else{};after=symbols(p.read_bytes())
 ast_changes.append(dict(path=str(rel),changed=sorted(k for k in before.keys()|after.keys()if before.get(k)!=after.get(k))))
assert ''.join(diff)==(A/'complete.patch').read_text()
(D/'exact-reviewed.patch').write_bytes((A/'complete.patch').read_bytes())
runs=[]
for d in sorted((A/'runs').iterdir()):
 if not d.is_dir():continue
 count=check(A,json.loads((d/'pins.json').read_bytes()))
 cmd=json.loads((d/'command.json').read_bytes());out=json.loads((d/'stdout.json').read_bytes());err=(d/'stderr.txt').read_text()
 versions=[pin(p)for p in sorted((d/'version').rglob('*.py'))]
 runs.append(dict(run=d.name,exit_code=json.loads((d/'exit.json').read_bytes())['exit_code'],command=cmd,stdout=out,stderr=err,verified_pins=count,versions=versions,raw_pins=[pin(d/n)for n in ('command.json','stdout.json','stderr.txt','exit.json','pins.json')]))
assert [r['exit_code']for r in runs]==[1,1,0,0,1,0,1,0,0]
scope=json.loads((R/'.local/plan-20261014-final-c/immutable-f5989cd/immutable_scope.json').read_bytes())
req=sha(json.dumps(scope['requirements'],sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())
assert req=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
report=dict(freeze_count=frozen,baseline_count=len(baseline),dependency_count=deps,mapping_count=len(mapping),exact_patch_match=True,requirements_sha256=req,source_pins=sources,ast_changes=ast_changes,runs=runs,tests_executed=False)
(D/'audit.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print(json.dumps({k:v for k,v in report.items()if k not in ('runs','source_pins','ast_changes')}))
print(json.dumps(ast_changes,indent=2))
