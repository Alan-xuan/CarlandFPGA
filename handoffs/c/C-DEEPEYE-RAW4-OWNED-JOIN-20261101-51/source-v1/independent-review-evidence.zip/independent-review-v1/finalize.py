from pathlib import Path
import hashlib,json,datetime,shutil
D=Path(__file__).resolve().parent;W=D.parent;A=W/'implementation-v1';M=W/'root-interface-map-v1'
assignment=json.loads((W/'main/review-assignment-v1.json').read_bytes())
def pin(p,base=None):
 b=p.read_bytes();return dict(path=p.relative_to(base).as_posix()if base else str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def write(name,obj):(D/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n',encoding='utf8')
assert hashlib.sha256((A/'FINAL.json').read_bytes()).hexdigest()==assignment['candidate_FINAL_sha256']
frozen=json.loads((A/'freeze.json').read_bytes())['files']
for r in frozen:
 p=A/r['path'];b=p.read_bytes();assert len(b)==r['bytes']and hashlib.sha256(b).hexdigest()==r['sha256'],p
assert json.loads((D/'audit-run/exit.json').read_bytes())['exit_code']==0
assert json.loads((D/'history-run01/exit.json').read_bytes())['exit_code']==1
observed=json.loads((D/'history-run01/observed.json').read_bytes());assert observed['pass_']is False and observed['full_bytes_unchanged']and observed['direct_history_check_error']=='original selected source changed'
inputs=D/'inputs';inputs.mkdir(exist_ok=False)
input_rows=[]
for p in (A/'inputs/source-data.json',A/'test_join_new.py',W/'main/review-assignment-v1.json',W/'main/review-queue-v1.json'):
 dest=inputs/p.name;shutil.copyfile(p,dest);input_rows.append(dict(original=pin(p),retained=pin(dest,D)))
write('input-provenance.json',dict(inputs=input_rows,mutation='replace only historical preparation object with another object holding the exact same original byte-bearing object',author_cases_invoked=0))
audit=json.loads((D/'audit.json').read_bytes())
write('source-pins.json',dict(candidate=audit['source_pins'],author_final=pin(A/'FINAL.json'),author_freeze=pin(A/'freeze.json'),baseline=json.loads((A/'baseline-pins.json').read_bytes()),dependencies=json.loads((A/'dependency-pins.json').read_bytes()),mapping=json.loads((M/'source-pins.json').read_bytes())))
write('FINDINGS.json',dict(source_approved=False,open_findings=[dict(id='C51-R1',priority=1,file='candidate/competition/deepeye/simulation/authority/raw4_owned_join_v1.py',lines=[185,215],sha256=observed['source_sha256'],title='Historical original preparation identity is not rechecked before history export',status='OPEN',evidence='history-run01/observed.json',exit_code=1,scope='synthetic original-reference gate and fixed C50 JSON projection only; no runtime authority demonstrated')],main_items={k:'STATICALLY_ADDRESSED_WITH_AUTHOR_VERSIONED_SYNTHETIC_EVIDENCE_NOT_REPLAYED'for k in ['M1','M2','M3','M4','M5']},whole_source_approved=False))
session=Path(assignment['original_session_metadata_path']);lines=session.read_bytes().splitlines();meta=json.loads(lines[0])
assert meta['type']=='session_meta'and meta['payload']['id']==assignment['actual_thread_id']
selected=[];calls={};outputs={}
for line in lines:
 row=json.loads(line)
 if row['type']=='session_meta' or row.get('timestamp','')>=assignment['created_utc']:
  selected.append(line)
  p=row.get('payload',{})
  if row['type']=='response_item'and p.get('type')=='function_call':calls[p['call_id']]=p
  if row['type']=='response_item'and p.get('type')=='function_call_output':outputs[p['call_id']]=p
(D/'native-session-records.jsonl').write_bytes(b'\n'.join(selected)+b'\n')
write('execution-snapshot.json',dict(actual_thread_id=meta['payload']['id'],session_metadata=meta,original_session=str(session),cutoff='finalizer invocation; its completion/terminal exit and final response are audited by main from original session',calls_seen=len(calls),outputs_seen=len(outputs),pending_at_cutoff=[k for k in calls if k not in outputs],audit_exit=0,new_combined_control_exit=1,product_dispatches=0,core_runs=0,actual_root_native_model_board_runs=0,owned_background_jobs=[],owned_subprocesses_after_finalizer_exit=[]))
files=[pin(p,D)for p in sorted(D.rglob('*'))if p.is_file()and p.name not in ('FINAL.json','freeze.json')]
write('freeze.json',dict(files=files))
final={k:assignment[k]for k in ('task_id','task_version','work_id','operation_id','actual_agent_id','actual_thread_id','main_thread_id','contract_id','contract_revision','contract_source','requirements_sha256','fixed_design','source_A_commit')}
final.update(status='REJECTED_C51_R1_OPEN',source_approved=False,review_passed=False,open_findings=['C51-R1'],candidate_FINAL_sha256=assignment['candidate_FINAL_sha256'],candidate_freeze_sha256=assignment['candidate_freeze_sha256'],sources_verified_before_and_after=172,freeze=pin(D/'freeze.json',D),artifact_count=len(files),source_pins=pin(D/'source-pins.json',D),audit_exit_code=0,independent_combined_control_exit_code=1,independent_new_controls=1,author_groups_replayed=0,actual_root_native_core_model_board_runs=0,production_restored=False,ownership_released=True,jobs=[],subprocesses=[],release_condition='finalizer successful exit followed by final response; main verifies actual session closure',completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
write('FINAL.json',final)
print(json.dumps(dict(FINAL=pin(D/'FINAL.json',D),freeze=pin(D/'freeze.json',D),artifacts=len(files),source_approved=False,open_findings=['C51-R1'],jobs=[],subprocesses=[])))
