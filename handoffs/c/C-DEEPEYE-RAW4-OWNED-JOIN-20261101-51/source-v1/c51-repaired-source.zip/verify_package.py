"""Offline ZIP integrity/privacy checks only. Never imports packaged source."""
import gzip,hashlib,io,json,re,stat,sys,zipfile
from pathlib import Path,PurePosixPath
MAX_TOTAL=64*1024*1024
PATTERNS={
 'user_home':rb'(?i)(?:[a-z]:[\\/]+Users[\\/]+[^\s"\r\n]+|/[h]ome/[^/\s]+/|/[U]sers/[^/\s]+/)',
 'codex_private_path':rb'(?i)(?:\.codex[\\/]+(?:sessions|memories)|rollout-20\d\d-)',
 'private_session_id':rb'01a[0-9a-f]{5}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}',
 'private_key':rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',
 'credential_assignment':rb'''(?i)(?:password|app_secret|access_token|refresh_token|authorization)\s*[=:]\s*["'][^"'\r\n]{16,}["']''',
 'board_login':rb'(?i)(?:pynq|xilinx|root)@(?:[a-z0-9.-]+)',
 'private_network':rb'\b(?:192\.168\.\d{1,3}\.\d{1,3}|10\.\d{1,3}\.\d{1,3}\.\d{1,3}|172\.(?:1[6-9]|2\d|3[01])\.\d{1,3}\.\d{1,3})\b',
}
def need(value,why):
 if not value:raise ValueError(why)
def safe(name):
 need(type(name)is str and name and '\\'not in name and ':'not in name and '\0'not in name,'unsafe path')
 p=PurePosixPath(name);need(not p.is_absolute() and all(x not in ('','.','..')for x in name.split('/')),'traversal/noncanonical path')
def object_pairs(items):
 d={}
 for k,v in items:need(k not in d,'duplicate JSON key');d[k]=v
 return d
def main(path):
 total=0;nested=0;scanned=0
 def scan(data,name,depth=0):
  nonlocal total,nested,scanned
  need(depth<=4,'archive nesting budget');total+=len(data);scanned+=1;need(total<=MAX_TOTAL,'expanded byte budget')
  for key,pattern in PATTERNS.items():need(re.search(pattern,data)is None,'privacy pattern '+key+' in '+name)
  def check_json(value,depth=0):
   need(depth<=40,'JSON nesting budget')
   if isinstance(value,str):
    for key,pattern in PATTERNS.items():need(re.search(pattern,value.encode())is None,'decoded JSON privacy '+key+' in '+name)
    if value.strip().startswith(('{','[','\"')):
     try:inner=json.loads(value,object_pairs_hook=object_pairs)
     except (ValueError,TypeError):pass
     else:
      if inner!=value:check_json(inner,depth+1)
   elif isinstance(value,dict):
    for k,v in value.items():check_json(k,depth+1);check_json(v,depth+1)
   elif isinstance(value,list):
    for v in value:check_json(v,depth+1)
  if data.lstrip().startswith((b'{',b'[')):
   try:value=json.loads(data,object_pairs_hook=object_pairs)
   except (ValueError,UnicodeError):pass
   else:check_json(value)
  if data.startswith(b'PK\x03\x04'):
   nested+=1
   with zipfile.ZipFile(io.BytesIO(data))as z:
    seen=set()
    for info in z.infolist():
     safe(info.filename);k=info.filename.casefold();need(k not in seen,'nested duplicate path');seen.add(k)
     need(not info.is_dir() and not stat.S_ISLNK(info.external_attr>>16),'nested directory/symlink')
     need(not info.flag_bits&1 and info.file_size<=MAX_TOTAL-total,'nested size/encryption')
     scan(z.read(info),name+'!'+info.filename,depth+1)
  elif data.startswith(b'\x1f\x8b'):
   nested+=1
   with gzip.GzipFile(fileobj=io.BytesIO(data))as g:expanded=g.read(MAX_TOTAL-total+1)
   need(len(expanded)<=MAX_TOTAL-total,'gzip expansion budget');scan(expanded,name+'!gzip',depth+1)
 raw=Path(path).read_bytes();need(len(raw)<=MAX_TOTAL,'ZIP budget')
 with zipfile.ZipFile(io.BytesIO(raw))as z:
  entries={};seen=set()
  for info in z.infolist():
   safe(info.filename);need(info.filename.casefold()not in seen,'duplicate/case alias');seen.add(info.filename.casefold())
   need(not info.is_dir() and not stat.S_ISLNK(info.external_attr>>16),'directory/symlink')
   need(not info.flag_bits&1 and info.file_size<=MAX_TOTAL,'encrypted/oversized')
   entries[info.filename]=info
  need('MANIFEST.json'in entries,'manifest missing')
  manifest=json.loads(z.read('MANIFEST.json'),object_pairs_hook=object_pairs)
  expected={}
  for row in manifest['files']:
   safe(row['path']);need(row['path']not in expected,'duplicate manifest path');expected[row['path']]=row
  need(set(entries)==set(expected)|{'MANIFEST.json'},'member inventory mismatch')
  for name in sorted(entries):
   data=z.read(name)
   if name!='MANIFEST.json':
    row=expected[name];need(len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'],'hash mismatch '+name)
   scan(data,name)
 print(json.dumps(dict(status='BYTE_INTEGRITY_ONLY_PASS',zip_sha256=hashlib.sha256(raw).hexdigest(),members=len(entries),manifest_files=len(expected),expanded_bytes=total,scanned_payloads=scanned,nested_archives=nested,product_imports=0,product_tests=0)))
if __name__=='__main__':main(sys.argv[1])
