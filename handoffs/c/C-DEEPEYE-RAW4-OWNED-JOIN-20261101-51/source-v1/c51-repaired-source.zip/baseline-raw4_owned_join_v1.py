"""C51 original raw4 join. Root callsites supply custody; JSON never grants it.

No resource acquisition, callbacks, actor launch or inferred receipt creation.
The original C42 session remains unchanged; raw4 capture rows live only here.
"""
import copy
import hashlib
import json
from pathlib import Path

def need(ok,why):
    if not ok:raise ValueError(why)
def raw(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def sha(b):return hashlib.sha256(b).hexdigest()

def _fixed():
    from . import raw4_proof_v1 as proof
    folder=Path(proof.__file__).parent
    pins={'projector.py':'cfa1611e4f95ca261964a71d2712d4972f7c2be5227ead83494db93c9edb38a1','transport.py':'613b10bd6b9bdc8da6c63aa9bc762df11742f86e39b4e4248f4adef8407385d6','request.schema.json':'48a78e6653b0690fa12c7f594155800b6b9ce876f145195688c8351bafb50fa1'}
    need(all(sha((folder/n).read_bytes())==h for n,h in pins.items()),'fixed C50 source changed')
    return proof,json.loads((folder/'request.schema.json').read_bytes())

def _whitelist(value,spec,schema,missing,path='request'):
    if '$ref'in spec:return _whitelist(value,schema['$defs'][spec['$ref'].split('/')[-1]],schema,missing,path)
    choices=spec.get('anyOf',spec.get('oneOf'))
    if choices:
        if value is None and any(c.get('type')=='null'for c in choices):return None
        choices=[c for c in choices if c.get('type')!='null']
        if len(choices)>1:
            def matches(c):
                s=schema['$defs'][c['$ref'].split('/')[-1]]if '$ref'in c else c
                return type(value)is dict and all(k not in value or value[k]==v['const'] if 'const'in v else k not in value or value[k]in v['enum'] for k,v in s.get('properties',{}).items()if 'const'in v or 'enum'in v)
            choices=[c for c in choices if matches(c)]
        need(len(choices)==1,'ambiguous supplied source variant')
        return _whitelist(value,choices[0],schema,missing,path)
    if value is None:
        if spec.get('type')!='null':missing.add(path)
        return None
    if spec.get('type')=='object':
        need(type(value)is dict,'original object shape');out={}
        for k,s in spec['properties'].items():
            if k in value:out[k]=_whitelist(value[k],s,schema,missing,path+'.'+k)
            elif k in spec.get('required',[]):missing.add(path+'.'+k);out[k]=None
        return out
    if spec.get('type')=='array':
        need(type(value)is list and len(value)<=spec.get('maxItems',2048),'original array budget')
        return [_whitelist(v,spec['items'],schema,missing,path+'['+str(i)+']')for i,v in enumerate(value)]
    return copy.deepcopy(value)

def _registry_state(source):
    """Read retained fields only; never call the idle Root snapshot from a tx."""
    from .actor_composition import ActorComposition
    from ..isolation.actor_owner import ActorRegistry,ActorOwner
    from .g05p_runtime_v1 import is_original_binding
    source._check_thread();source.session._check();source.book._check()
    o,l,b,c=source.owner,source.link,source.book,source.composition
    r,a,boot,rt,ex=c._registry,c._actor,c._boot,c._runtime,c._executor;custody=b._actor_custody
    need(type(c)is ActorComposition and type(r)is ActorRegistry and type(a)is ActorOwner and is_original_binding(boot),'exact original registry types')
    need(c._state=='ACTIVE' and not c._retired and not c._foreign.is_set() and not a._foreign_call.is_set()
         and r._thread==source._thread and r._clock_binding is source.clock and r._launching is None
         and any(v is a for v in r._owners) and a._registry is r and a._boot is boot
         and a._thread==source._thread and c._thread==source._thread
         and c._host_clock is source.clock and c._clock is source.clock
         and boot.run_id==a._policy.run_id and boot.ai_instance==a.instance_id
         and r._generations.get(boot.run_id)==boot.generation
         and a._runtime_owner is rt and a._executor_owner is ex
         and a._runtime_activation is boot and a._executor_activation is boot
         and c._runtime_activation is boot and c._executor_activation is boot
         and a._state=='BOUND_ACTIVE' and rt is not None and rt._boot is boot
         and not rt._latched and rt._generation==boot.generation
         and ex is l.executor and ex._root.boot is boot
         and c._world_action_link is l and l.composition is c and l.claimed
         and l.owner is o and l.book is b and l.source is source.source
         and o._actor_link is l and o._actor_links.get(id(l))is l
         and b._source is source.source and source.source._source_book is b
         and custody is not None and custody.book is b and custody.link is l
         and custody.pending is None and b._root is ex._root
         and c._channels._refs.source is source,'original live registry association changed')
    context=json.loads(boot.context_json)
    need((boot.run_id,context.get('session'))in r._used_sessions and context.get('topology_id')==2,'original registry session/topology')
    cfg=source.session._producer._config;cr,cf=(None,None)if cfg is None else cfg
    transitions=tuple(custody.transitions);links=tuple(sorted(o._actor_links.items()));owners=tuple(r._owners)
    refs=(o,l,b,c,r,a,boot,rt,ex,ex._root,custody,source.clock,source.source,source.session,source.session._producer,cr,cf,c._boot_event,l.slot,o._publication,*transitions,*(x[1]for x in links),*owners)
    state=(tuple(x[0]for x in links),len(transitions),len(owners),tuple(raw(t.record)for t in transitions),None if cf is None else raw(cf),boot.context_json,boot.generation,o._veto_generation,c._veto,rt._veto_generation,rt._generation,r._ordinal,tuple(sorted(r._generations.items())),frozenset(r._used_sessions),a._state)
    return refs,state

def _check_hold(channel,selection):
    from ...tools.run_causal_functional_chain import _RegistryView,_RegistryHold,_check_registry_interval
    source=channel._refs.source;session=channel._refs.projection
    current,view,hold=selection['current_read'],selection['registry_view'],selection['registry_hold']
    need(type(view)is _RegistryView and type(hold)is _RegistryHold and hold.view is view,'original registry view/hold required')
    need(any(c is current and v is view and h is hold for c,v,h in source._registry_observations),'original idle observation not retained')
    need(any(v is view and h is hold and at==current['at_qpc_ns']for v,h,at in session._registries),'actual C42 registry context attachment required')
    need(any(c is current for c in session._current),'original current getter required')
    _check_registry_interval(current,hold.lower_qpc_ns,hold.upper_qpc_ns)
    need(current['at_qpc_ns']==hold.getter_end_qpc_ns and raw(current)==selection['current_bytes'],'original getter changed')
    refs,state=_registry_state(source)
    need(len(refs)==len(view._refs)and all(a is b for a,b in zip(refs,view._refs))and state==view._state,'original registry refs/state changed')
    session._check()

def stage(channel,event,**values):
    """Called by original idle Root after its real getter/registry attachment."""
    channel.checkpoint();owner=channel._capability.composition
    need(owner is not None and not owner._busy,'stage only in original idle owner')
    names={'current_read','registry_view','registry_hold','source_bound_receipt','dispatch_bound_receipt','source_deadline_ns','dispatch_deadline_ns','cause_action','previous_action','previous_deadline_ns'}
    need(set(values)==names,'exact raw4 selection fields')
    rows=[(f,r)for e,f,r in channel._producer._history if e is event]
    need(len(rows)==1 and rows[0][0]['kind']=='trace_scan'and not any(e is event for e,_,_ in channel._events),'unused original TRACE event required')
    need(not any(s['event']is event for s in channel._raw4_selections),'selection cannot be restaged')
    selection=dict(values,event=event,used=False,current_bytes=raw(values['current_read']))
    _check_hold(channel,selection)
    channel._raw4_selections.append(selection)

def _pose(session,read,span,index,nominal):
    if read is None:return None
    return dict(receipt_id=session._bind(read),pose=copy.deepcopy(read.get('pose')),pose_revision=read.get('pose_revision'),source_admission_index=index,nominal_source_qpc_ns=nominal,pose_read={k:read.get(k)for k in ('begin_qpc_ns','end_qpc_ns')},valid_span=None if span is None else dict(receipt_id=session._bind(span),from_qpc_ns=span.get('from_qpc_ns'),through_qpc_ns=span.get('through_qpc_ns')))

def _selected(record):
    r=record.refs;a=r['admitted'];t=r['token'];p=r['preparation'].original
    need(t._draft is r['draft'] and a['token'] is t and a['draft'] is r['draft']
         and a['admission'] is r['admission'] and a['entry']['payload'] is r['payload'],'selected source references changed')
    need(p.request==record.request_raw and p.source==r['source_bytes']
         and tuple(p.companions)==record.companions,'selected original preparation bytes changed')
    refs=tuple(r[k]for k in ('draft','token','admitted','admission','payload','preparation','phase_receipt'))
    data=raw(dict(sample=r['draft'],payload=r['payload'],received=a['received'],build_binding=r['build_binding']))
    return refs,(data,record.raw,record.request_raw,record.companions,record.phase.request_raw,record.phase.response_raw,record.phase.lower_qpc_ns,record.phase.upper_qpc_ns)

def check_association(owner,a,*,committed_duplicate=False):
    """Exact original raw4 row and runtime admission, including completion reuse."""
    need(type(a.session)is Raw4Session and a.owner is owner and a.source is owner._channels
         and a.clock is owner._clock and a.boot is owner._boot,'same raw4 owner required')
    a.session.check_entry(a.entry,committed_duplicate=committed_duplicate)
    need(a.entry['record'] is a.record and a.observation_bytes==a.capture_bytes==a.record.raw
         and raw(a.entry['candidate'])==a.candidate_bytes,'raw4 association bytes changed')
    need(a.selected_source_deadline_ns==a.entry['selection']['source_deadline_ns']
         and a.source_deadline_ns==min(a.selected_source_deadline_ns,a.record.sample_lower_ns+100_000_000),'selected and derived raw4 source cap changed')
    stored=owner._runtime._observations.get(a.record.observed_seq)
    need(getattr(owner._runtime,'_trace_observations',{}).get(a.record.observed_seq)is a.record
         and stored is not None and stored.raw==a.record.raw
         and stored.sample_lower_ns==a.record.sample_lower_ns,'original admitted raw4 observation lost')

class Raw4Session:
    """One channel's retained raw4 rows alongside its unchanged C42 session."""
    def __init__(self,channel):
        self.channel=channel;self.original=channel._refs.projection
        self._link=self.original._link;self._book=self.original._book;self._entries=[]
    def _check(self):
        self.channel.checkpoint();self.original._check()
        need(self.channel._refs.projection is self.original and self.original._link is self._link and self.original._book is self._book,'original projection replaced')
    def bind(self,record,selection):
        self._check();_check_hold(self.channel,selection)
        need(len(self._entries)<32 and not any(e['record']is record or e['phase']is record.phase for e in self._entries),'original raw4 capture already retained')
        refs=record.refs;sample=refs['draft'];token=refs['token'];session=self.original
        need(token._book is self._book and token._draft is sample and token._ended is True and any(s is sample for s in self._book._samples),'same selected completed token required')
        request=json.loads(record.request_raw);payload=refs['payload'];origin=self.channel._refs.source.source.origin_ns;phase=record.phase
        admitted=refs['admitted'];admission=refs['admission']
        need(admitted['token']is token and admitted['draft']is sample and admitted['admission']is admission and admitted['entry']['payload']is payload,'original selection changed')
        index=sample['source_count']-1
        need(type(index)is int and index>=0 and self._book._samples[index]is sample,'original explicit source count association')
        t=dict(adc_tick_ms=payload['adc_tick_ms'],em_tick_ms=payload['em_tick_ms'],source_start_tick_ms=0,source_start_monotonic_ns=origin,admission_received_monotonic_ns=admitted['received'],adc_source_age_ns=phase.upper_qpc_ns-(origin+payload['adc_tick_ms']*1000000),em_source_age_ns=None if payload['em_tick_ms']is None else phase.upper_qpc_ns-(origin+payload['em_tick_ms']*1000000),time_basis='trusted_root_source_schedule_not_physical_sample_authentication')
        cfg=self.original._producer._config;need(cfg is not None,'original source config missing')
        context=copy.deepcopy(self.channel._refs.c42_context);generation=cfg[1]['generation']
        candidate={k:copy.deepcopy(payload[k])for k in ('channel_counts','quality','profile_id','profile_status','profile_note','source_mode')}
        # Schema metadata is fixed by the pinned ABI; it is not source evidence.
        _,schema=_fixed()
        candidate.update({k:copy.deepcopy(schema['$defs']['Candidate']['properties'][k]['const'])for k in ('schema','channel_names','quality_encoding')})
        candidate.update(kind='raw4_four_channel_observation_v1',transport_source='B113_E4_original_raw4',source_time=t,observation_identity=dict(context=context,generation=generation,source_admission_index=index,request_seq=request['lineage']['request_seq'],trigger_id=request['lineage']['trigger_id'],request_sha256=sha(record.request_raw),capture_sha256=sha(record.raw),capture_lower_qpc_ns=phase.lower_qpc_ns,receiver_upper_qpc_ns=phase.upper_qpc_ns))
        returned=json.loads(phase.response_raw)['result']['response']['results']
        packet=dict(request_hex=record.request_raw.hex(),source_hex=refs['source_bytes'].hex(),companions_hex=[b.hex()for b in record.companions],wire_hex=record.raw.hex(),result_rows=returned,build_binding=copy.deepcopy(refs['build_binding']))
        from .raw4_proof_v1 import transport
        transport.inspect(packet) # Independent original-byte decoding before retention.
        read=sample.get('pose_reads',{}).get('adc');span=sample.get('numerical_pose_span');adc=sample.get('adc')
        cause=selection['cause_action']
        if cause is not None:need(any(slot is cause for _,_,slot,_ in session._producer._actions),'original action attachment required')
        fields=dict(capture_sha256=sha(record.raw),source_record_sha256=sha(refs['source_bytes']),mapping_receipt_id=session._bind(refs['preparation']),raw4=packet,cause_action_id=session._producer._id(cause),adc_book_source_sha256=sample.get('source_sha256'),adc_root_revision=None if read is None else read.get('root_revision'),adc_call=None if adc is None else {k:adc.get(k)for k in ('begin_qpc_ns','end_qpc_ns')},adc_pose=_pose(session,read,span,index,sample.get('nominal_qpc_ns')),em_pose=None,em_root_revision=None,em_book_source_sha256=None,em_origin_capture_sha256=None,original_em_call=None,original_em_scope_closed_qpc_ns=None)
        held=sample.get('held_em_association');em=held.get('original_em')if type(held)is dict else None
        if em is not None:
            native=[s for s in self._book._samples if s.get('tick_ms')==payload['em_tick_ms']]
            need(len(native)==1,'original EM sample association missing');native=native[0]
            prior=[e for e in self._entries if e['sample']is native]
            origin_capture=sha(record.raw)if native is sample else (prior[0]['fields']['capture_sha256']if len(prior)==1 else None)
            fields.update(em_book_source_sha256=native.get('source_sha256'),em_origin_capture_sha256=origin_capture,em_root_revision=em.get('root_revision'),original_em_call=copy.deepcopy(em.get('call')),original_em_scope_closed_qpc_ns=em.get('scope_closed_qpc_ns'),em_pose=_pose(session,em.get('pose_read'),em.get('numerical_pose_span'),native['source_count']-1,em.get('nominal_qpc_ns')))
        entry=dict(record=record,phase=phase,sample=sample,selection=selection,candidate=candidate,fields=fields,bytes=raw(dict(candidate=candidate,fields=fields)),selected=_selected(record))
        self._entries.append(entry);return entry
    def check_entry(self,entry,*,committed_duplicate=False):
        self._check()
        # Only the existing policy's exact already-committed duplicate path may
        # retain its old sample after the command changed the current Root.
        # Original row membership/bytes, live channel and caps still apply.
        if not committed_duplicate:_check_hold(self.channel,entry['selection'])
        need(any(e is entry for e in self._entries)and entry['record'].phase is entry['phase']and entry['record'].refs['draft']is entry['sample']and raw(dict(candidate=entry['candidate'],fields=entry['fields']))==entry['bytes'],'retained raw4 selection changed')
        refs,values=_selected(entry['record']);oldrefs,oldvalues=entry['selected']
        need(all(x is y for x,y in zip(refs,oldrefs))and values==oldvalues,'original selected source changed')
    def export_entry(self,entry):
        self.check_entry(entry);s=self.original;p=s._producer;selection=entry['selection'];current=selection['current_read'];view=selection['registry_view']
        readings=[r for r in p._readings if r[0]is current];need(len(readings)==1,'actual getter not retained')
        cur,evidence,curraw,evraw,span=readings[0]
        need(raw(cur)==curraw and raw(evidence)==evraw and cur.get('valid_span')is span,'saved current/evidence mutated')
        registries=[r for r in p._registry if r[0]is view];need(len(registries)==1,'original registered hold missing');registry=registries[0]
        conf=copy.deepcopy(p._config[1]);conf.update(receipt_id=p._id(p._config[0]),pose_book_id=p._id(self._book),owner_binding_id=p._id(self._link.binding),transport_source='B113_E4_original_raw4')
        req=json.loads(entry['record'].request_raw);conf['trace_namespace']={k:req['lineage'][k]for k in ('operation_id','request_hash','tested_commit','boot_id','session_id','tag','generation')};conf['trace_namespace']['clock_domain_id']=req['scan']['clock_domain_id']
        admissions=[]
        for _,_,refs in self.channel._source_events:
            draft=refs['draft'];a=refs['admission'];item=refs['admitted'];payload=refs['payload']
            need(item['token']is refs['token']and item['draft']is draft and item['admission']is a and item['entry']['payload']is payload,'original admission replaced')
            admissions.append(dict(index=draft['source_count']-1,adc_tick_ms=payload['adc_tick_ms'],em_tick_ms=payload['em_tick_ms'],new_em_sample=a.new_em_sample,channel_counts=copy.deepcopy(payload['channel_counts']),quality=payload['quality'],received_qpc_ns=item['received'],source_record_sha256=sha(raw(payload))))
        current_fields=dict(receipt_id=p._id(cur),context=copy.deepcopy(registry[1]),generation=registry[2],root_revision=span['root_revision'],pose=copy.deepcopy(cur['pose']),pose_revision=cur['pose_revision'],at_qpc_ns=cur['at_qpc_ns'],pose_read=copy.deepcopy(cur['pose_read']),valid_span=dict(receipt_id=p._id(span),from_qpc_ns=span['from_qpc_ns'],through_qpc_ns=span['through_qpc_ns']))
        book=copy.deepcopy(evidence);book.update(source_commit='0469345fd1eef2884de1417f0f4eb5b67688f84c',snapshot_sha256=sha(evraw),current_read=copy.deepcopy(cur),claim='numerical_immutable_committed_root_only',native_interval_atomic=False)
        root=dict(kind='c50_raw4_root_association_v1',evidence_scope='root_supplied_diagnostic',config=conf,source_admissions=admissions,captures=[copy.deepcopy(e['fields'])for e in self._entries],current_pose=current_fields,actor_registry=dict(receipt_id=p._id(view),context=copy.deepcopy(registry[1]),generation=registry[2],as_of_qpc_ns=registry[3],associations=[p._action(a)for a in p._actions]))
        request=dict(schema_version=1,abi_id='raw4_full_proof_v1',diagnostic_only=True,evidence_scope='root_supplied_diagnostic',enabled=True,now_qpc_ns=cur['at_qpc_ns'],candidate=copy.deepcopy(entry['candidate']),history=[copy.deepcopy(e['candidate'])for e in self._entries if e is not entry],root_receipt=root,actor_book=book)
        proof,schema=_fixed();missing=set();full=_whitelist(request,schema,schema,missing)
        need(not missing,'original raw4 full proof unavailable: '+','.join(sorted(missing)))
        result=json.loads(proof.project_raw4_json(raw(full)));self.check_entry(entry)
        need(result['input_status']=='PROJECTED'and result['core_ran']is False and result['authorization']=='none','original raw4 projection unavailable')
        return full,result

def retain(owner,event,record):
    from .g05p_runtime_v1 import checked_trace
    from .owned_invocation_v1.adapter import _Association,_KEY
    from .candidate_owner import _InputTransaction
    from .actor_composition import ActorComposition
    from .owned_invocation_v1.adapter import uint
    need(type(owner)is ActorComposition and owner._busy and owner._state=='ACTIVE','active original composition entry')
    channel=owner._channels;checked_trace(record,owner._boot,now_ns=owner._progress_time())
    tx=owner._input_transaction
    need(type(tx)is _InputTransaction and tx.kind=='observation'and tx.original_event is event and tx.observation_record is record and tx.owned_association is None,'same active original raw4 transaction')
    matches=[s for s in channel._raw4_selections if s['event']is event];need(len(matches)==1 and not matches[0]['used'],'one original idle selection required')
    selection=matches[0];selection['used']=True
    need(selection['source_bound_receipt']is not None and selection['dispatch_bound_receipt']is not None,'original independent bounds missing')
    for k in ('source_deadline_ns','dispatch_deadline_ns'):uint(selection[k],1)
    need(selection['source_deadline_ns']<=record.sample_lower_ns+owner._runtime._age_cap,'selected original runtime source cap exceeded')
    effective_source_deadline=min(selection['source_deadline_ns'],record.sample_lower_ns+100_000_000)
    previous=selection['previous_deadline_ns']
    if previous is None:need(selection['previous_action'] is None,'explicit no previous same-action bound')
    else:
        uint(previous,1)
        need(selection['previous_action']is owner._progress.bound and owner._progress.bound is not None and owner._progress.bound.deadline_ns==previous,'original previous same-action bound')
    if channel._raw4_join is None:channel._raw4_join=Raw4Session(channel)
    session=channel._raw4_join;entry=session.bind(record,selection)
    tx.owned_association=_Association(_KEY,owner=owner,tx=tx,event=event,record=record,session=session,entry=entry,source=channel,clock=owner._clock,boot=owner._boot,candidate_bytes=raw(entry['candidate']),capture_bytes=record.raw,observation_bytes=record.raw,observation_key=raw(dict(context=json.loads(owner._boot.context_json),observed_seq=record.observed_seq)),selected_source_deadline_ns=selection['source_deadline_ns'],source_deadline_ns=effective_source_deadline,dispatch_deadline_ns=selection['dispatch_deadline_ns'],previous_action=selection['previous_action'],previous_deadline_ns=selection['previous_deadline_ns'],source_bound_receipt=selection['source_bound_receipt'],dispatch_bound_receipt=selection['dispatch_bound_receipt'])
