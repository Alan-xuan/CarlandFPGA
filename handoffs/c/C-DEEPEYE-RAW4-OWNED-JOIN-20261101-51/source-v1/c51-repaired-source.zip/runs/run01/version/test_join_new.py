"""NEW C51 pure controls. All owner/OS/provider allocations are SYNTHETIC.

AST selection executes unchanged method/decorator bodies; it never constructs
original Root/actor, starts processes, or calls a model/native/board operation.
The copied C50 JSON is fixture DATA only, not replay of its earlier test suite.
"""
import ast,copy,hashlib,importlib.util,json,sys,threading,types,traceback
from pathlib import Path
from types import SimpleNamespace as N
from dataclasses import dataclass
from functools import wraps
from collections import OrderedDict
D=Path(__file__).resolve().parent;A=D/'candidate/competition/deepeye/simulation/authority';I=D/'candidate/competition/deepeye/integration'
BASE='c51synthetic';AUTH=BASE+'.simulation.authority';INTEG=BASE+'.integration'
def module(name,path=None):
 m=types.ModuleType(name);m.__package__=name.rpartition('.')[0];m.__file__=str(path or D);sys.modules[name]=m;return m
for name in (BASE,BASE+'.simulation',AUTH,AUTH+'.owned_invocation_v1',INTEG,BASE+'.tools'):
 m=module(name);m.__path__=[]
def load(name,path):
 sp=importlib.util.spec_from_file_location(name,path,submodule_search_locations=[str(path.parent)]if path.name=='__init__.py'else None);m=importlib.util.module_from_spec(sp);sys.modules[name]=m;sp.loader.exec_module(m);return m
def selected(name,path,functions=(),classes=None,values=None):
 tree=ast.parse(path.read_bytes());out=[]
 for n in tree.body:
  if isinstance(n,(ast.FunctionDef,ast.ClassDef))and n.name in functions:out.append(n)
  if isinstance(n,ast.ClassDef)and classes and n.name in classes:
   names=classes[n.name];n.body=[f for f in n.body if isinstance(f,ast.FunctionDef)and f.name in names];out.append(n)
 m=module(name,path);m.__dict__.update(dict(dataclass=dataclass,wraps=wraps,json=json,threading=threading,OrderedDict=OrderedDict));m.__dict__.update(values or {})
 exec(compile(ast.Module(body=out,type_ignores=[]),str(path),'exec'),m.__dict__);return m
watch=module(INTEG+'.pc_direct_watchdog');watch.PcDirectWatchdog=object
iso=module(BASE+'.simulation.isolation');iso.__path__=[]
iso=module(BASE+'.simulation.isolation.actor_owner')
class ActorRegistry:pass
class ActorOwner:pass
iso.ActorRegistry=ActorRegistry;iso.ActorOwner=ActorOwner
g=load(AUTH+'.g05p_runtime_v1',A/'g05p_runtime_v1.py')
proof=load(AUTH+'.raw4_proof_v1',D/'deps/raw4_proof_v1/__init__.py')
join=load(AUTH+'.raw4_owned_join_v1',A/'raw4_owned_join_v1.py')
tool=module(BASE+'.tools.run_causal_functional_chain')
class RegistryView:pass
class RegistryHold:pass
tool._RegistryView=RegistryView;tool._RegistryHold=RegistryHold
def interval(c,lower,upper):
 assert lower<=c['pose_read']['begin_qpc_ns']<=c['pose_read']['end_qpc_ns']<=upper
tool._check_registry_interval=interval
fixture=json.loads((D/'inputs/source-data.json').read_bytes())

def graph(input_doc=None):
 if AUTH+'.actor_composition'not in sys.modules:route_modules()
 x=copy.deepcopy(fixture if input_doc is None else input_doc);b=x['actor_book'];cfg=x['root_receipt']['config'];now=x['now_qpc_ns']
 current=b['current_read'];span=current['valid_span'];book=N(_samples=b['samples']);root=N();book._root=root
 owner=N(_veto_generation=0,_publication=object(),_actor_links={})
 comp=N(_state='ACTIVE',_retired=False,_foreign=threading.Event(),_veto=0,_busy=False,_boot_event=object())
 binding=N(context_json=join.raw({'topology_id':2}),generation=cfg['generation'])
 rt=N(_latched=False,_veto_generation=0,_generation=1,_boot=binding)
 actor=N(_foreign_call=threading.Event(),_boot=binding,_state='RUNNING')
 registry=N(_launching=None,_owners=[actor],_ordinal=1,_generations={},_used_sessions=set())
 custody=N(pending=None,transitions=[]);book._actor_custody=custody
 link=N(owner=owner,book=book,composition=comp,slot=None,binding=object());ex=N(_root=root);link.executor=ex
 ids=[]
 def bind(ref):
  if ref is None:raise ValueError('absent synthetic reference')
  for r,label in ids:
   if r is ref:return label
  label='synthetic-ref-'+str(len(ids));ids.append((ref,label));return label
 def ident(ref):return next((label for r,label in ids if r is ref),None)if ref is not None else None
 p=N(_config=(object(),cfg),_actions=[],_registry=[],_readings=[],_id=ident)
 session=N(_link=link,_book=book,_producer=p,_registries=[],_current=[current],_bind=bind,_check=lambda:None)
 source=N(owner=owner,link=link,book=book,composition=comp,clock=object(),source=N(origin_ns=b['source_origin_qpc_ns']),session=session,_registry_observations=[])
 ch=N(_refs=N(source=source,projection=session,c42_context=cfg['context']),_source_events=[],_raw4_selections=[],_raw4_join=None,_capability=N(composition=comp),_events=[])
 ch.checkpoint=lambda **kw:now
 comp._channels=ch;comp._world_action_link=link;comp._registry=registry;comp._actor=actor;comp._boot=binding;comp._runtime=rt;comp._executor=ex
 actualch=g.G05Channels.__new__(g.G05Channels);actualch.__dict__.update(ch.__dict__);ch=actualch
 actualcomp=sys.modules[AUTH+'.actor_composition'].ActorComposition.__new__(sys.modules[AUTH+'.actor_composition'].ActorComposition);actualcomp.__dict__.update(comp.__dict__);comp=actualcomp;source.composition=comp;link.composition=comp;comp._channels=ch;ch._capability.composition=comp
 binding=g.G05SessionBinding(g._KEY,ch,'synthetic-run',1,join.raw({'topology_id':2,'session':7}),'synthetic-actor');ch._binding=binding;ch._revoked=False;comp._boot=binding;rt._boot=binding
 realreg=ActorRegistry();realreg.__dict__.update(registry.__dict__);registry=realreg;comp._registry=registry
 realactor=ActorOwner();realactor.__dict__.update(actor.__dict__);actor=realactor;comp._actor=actor;registry._owners=[actor]
 fixture_live(source)
 view=RegistryView();view._refs,view._state=join._registry_state(source)
 hold=RegistryHold();hold.view=view;hold.lower_qpc_ns=current['pose_read']['begin_qpc_ns'];hold.upper_qpc_ns=current['at_qpc_ns'];hold.getter_end_qpc_ns=current['at_qpc_ns'];hold.context_attached=False
 source._registry_observations.append((current,view,hold));session._registries.append((view,hold,current['at_qpc_ns']))
 p._registry.append((view,cfg['context'],cfg['generation'],current['at_qpc_ns']))
 p._readings.append((current,b,join.raw(current),join.raw(b),span))
 for ref in (p._config[0],book,link.binding,current,span,view):bind(ref)
 slots=[]
 for a in x['root_receipt']['actor_registry']['associations']:
  slot=object();slots.append(slot);ids.append((slot,a['action_id']));p._actions.append((object(),root,slot,a))
 def action(row):
  a=copy.deepcopy(row[3]);a['custody']['pose_book_id']=ident(book);a['custody']['owner_binding_id']=ident(link.binding);return a
 p._action=action
 records=[];payload_template=json.loads(bytes.fromhex(x['root_receipt']['captures'][-1]['raw4']['source_hex']))
 for adm in x['root_receipt']['source_admissions']:
  sample=book._samples[adm['index']];payload=copy.deepcopy(payload_template)
  payload.update(adc_tick_ms=adm['adc_tick_ms'],em_tick_ms=adm['em_tick_ms'],channel_counts=adm['channel_counts'],quality=adm['quality'])
  # Exact source data values accompany counts in the immutable fixture.
  payload['channel_values']=[None if n is None else v for n,v in zip(payload['channel_counts'],payload_template['channel_values'])]
  token=N(_book=book,_draft=sample,_ended=True);admission=N(new_em_sample=adm['new_em_sample'])
  admitted=dict(token=token,draft=sample,admission=admission,entry=dict(payload=payload),received=adm['received_qpc_ns'])
  refs=dict(token=token,draft=sample,admission=admission,admitted=admitted,payload=payload)
  ch._source_events.append((object(),{},refs))
 for cap,cand in zip(x['root_receipt']['captures'],x['history']+[x['candidate']]):
  packet=cap['raw4'];ref=ch._source_events[cand['observation_identity']['source_admission_index']][2]
  sourcebytes=bytes.fromhex(packet['source_hex']);original=N(request=bytes.fromhex(packet['request_hex']),source=sourcebytes,companions=tuple(bytes.fromhex(v)for v in packet['companions_hex']))
  exactpayload=json.loads(sourcebytes);ref['payload'].clear();ref['payload'].update(exactpayload)
  phase=N(lower_qpc_ns=cand['observation_identity']['capture_lower_qpc_ns'],upper_qpc_ns=cand['observation_identity']['receiver_upper_qpc_ns'],request_raw=join.raw({'payload':packet}),response_raw=join.raw({'result':{'response':{'results':packet['result_rows']}}}))
  refs=dict(ref,preparation=N(original=original),source_bytes=sourcebytes,build_binding=packet['build_binding'],phase_receipt=phase)
  event=object();record=g.TraceObservation(g._KEY,ch,binding,event,phase,bytes.fromhex(packet['wire_hex']),cand['observation_identity']['request_seq'],min(v for v in [b['source_origin_qpc_ns']+cand['source_time']['adc_tick_ms']*1000000,None if cand['source_time']['em_tick_ms']is None else b['source_origin_qpc_ns']+cand['source_time']['em_tick_ms']*1000000]if v is not None),tuple(cand['channel_counts']),(),refs,original.request,original.companions)
  selection=dict(current_read=current,registry_view=view,registry_hold=hold,source_bound_receipt=rt,dispatch_bound_receipt=actor,source_deadline_ns=now+1000000,dispatch_deadline_ns=now+2000000,previous_action=None,previous_deadline_ns=None,cause_action=next((s for s in slots if ident(s)==cap['cause_action_id']),None),event=event,used=False,current_bytes=join.raw(current))
  ch._raw4_selections.append(selection);records.append(record)
 return N(x=x,channel=ch,session=session,producer=p,source=source,comp=comp,book=book,current=current,view=view,hold=hold,records=records,now=now)

def fixture_live(source):
 c=source.composition;l=source.link;b=source.book;o=source.owner;r=c._registry;a=c._actor;boot=c._boot;rt=c._runtime;ex=c._executor;tid=threading.get_ident()
 source._thread=tid;source._check_thread=lambda:None;b._check=lambda:None
 c._thread=tid;c._clock=c._host_clock=source.clock;c._runtime_activation=c._executor_activation=boot
 r._thread=tid;r._clock_binding=source.clock;r._generations={boot.run_id:boot.generation};r._used_sessions={(boot.run_id,json.loads(boot.context_json).get('session'))}
 a._registry=r;a._thread=tid;a._boot=boot;a._policy=N(run_id=boot.run_id);a.instance_id=boot.ai_instance;a._runtime_owner=rt;a._executor_owner=ex;a._runtime_activation=a._executor_activation=boot;a._state='BOUND_ACTIVE'
 rt._boot=boot;rt._generation=boot.generation;ex._root.boot=boot;l.claimed=True;l.source=source.source;o._actor_link=l;o._actor_links={id(l):l};b._source=source.source;source.source._source_book=b;b._actor_custody.book=b;b._actor_custody.link=l

def mechanical_bind():
 z=graph();s=join.Raw4Session(z.channel)
 for r,selection in zip(z.records,z.channel._raw4_selections):s.bind(r,selection)
 full,result=s.export_entry(s._entries[-1])
 assert result['input_status']=='PROJECTED'and result['core_ran']is False
 assert full['candidate']['observation_identity']['context']['session_id']!=full['root_receipt']['config']['trace_namespace']['session_id']
 assert full['candidate']['channel_counts']==z.x['candidate']['channel_counts']
 return dict(status=result['input_status'],core_ran=False,synthetic=True,entries=len(s._entries))

CASES={'mechanical_bind':mechanical_bind}
def route_modules():
 env=module(INTEG+'.host_envelope');env._parse_message=json.loads
 env.validate_message=lambda *args,**kwargs:N(kind='motion_request')
 box=selected(INTEG+'.candidate_mailbox',I/'candidate_mailbox.py',functions=('_integer','_entry','_Observation','SlotGrant','Selection','PcDirectWindowSelection','ObservedIntervalBoundsV2'),classes={'LatestCompletedMailbox':('_halt','_time','_active','observe_raw4','consume_pc_direct_v2')},values=dict(MAX_TIME=(1<<63)-1,MAX_OBSERVATIONS=4,envelope=env))
 rt=selected(AUTH+'.pc_direct_runtime',A/'pc_direct_runtime.py',functions=('_integer','_runtime_entry','_Observation','VerifiedObservation','VerifiedEnvelope','BootBinding'),classes={'PcDirectRuntime':('_active','_event','observe')})
 co=selected(AUTH+'.candidate_owner',A/'candidate_owner.py',functions=('_bounded','_InputTransaction','_VerifiedSlot','_CompletedInference'),classes={'_CandidateOwner':('_active','observe','select','commit','duplicate_proof')},values=dict(BootBinding=rt.BootBinding,mailbox=box,_MAX_NS=(1<<63)-1))
 ac=selected(AUTH+'.actor_composition',A/'actor_composition.py',functions=('_entry','_Dependencies'),classes={'ActorComposition':('accept_observation','_runtime_active')},values=dict(AuthorityDependencies=object,_InputTransaction=co._InputTransaction,VerifiedObservation=rt.VerifiedObservation,CompositionRejected=type('CompositionRejected',(ValueError,),{}),StepOutcome=type('StepOutcome',(),{}),_STOPPED=object()))
 class Identity:
  def __init__(self,operation_id,request_hash,tested_commit,package_manifest_sha256,run_id,invocation_id,actor_instance_id):self.__dict__.update(locals());del self.__dict__['self']
 class Record:pass
 def uint(x,low=0):
  assert type(x)is int and low<=x<(1<<63);return x
 verifier=N(ABI='synthetic',validate_public=lambda x:None,fixed_request=lambda b:b)
 adapter=selected(AUTH+'.owned_invocation_v1.adapter',A/'owned_invocation_v1/adapter.py',functions=('_Association','_root_guard','_same_root'),classes={'_OwnedInvocationAdapter':('begin','retire')},values=dict(need=join.need,uint=uint,encode=join.raw,_KEY=object(),_InputTransaction=co._InputTransaction,_root=lambda root:root.value,verifier=verifier,InvocationIdentity=Identity,_ActorRecord=Record,MANIFEST='synthetic-fixed-manifest'))
 return N(box=box,rt=rt,co=co,ac=ac,adapter=adapter,Record=Record)

def active_graph():
 m=route_modules();z=graph();ch=g.G05Channels.__new__(g.G05Channels);ch.__dict__.update(z.channel.__dict__)
 owner=m.ac.ActorComposition.__new__(m.ac.ActorComposition);owner.__dict__.update(z.comp.__dict__)
 z.source.composition=owner;z.session._link.composition=owner;owner._channels=ch;ch._capability.composition=owner;ch._revoked=False
 bind=g.G05SessionBinding(g._KEY,ch,'synthetic-run',1,join.raw({'topology_id':2,'session':7}),'synthetic-actor');ch._binding=bind;owner._boot=bind
 owner._actor._boot=bind;owner._executor._root.value={'revision':1};owner._clock=z.source.clock;owner._host_clock=owner._clock
 owner._thread=threading.get_ident();owner._errors=[];owner._world_pending_stop=False;owner._input_transaction=None;owner._progress=N(bound=None,revoked=False)
 owner._config=N(g05p_profile=object());owner._active=lambda:None;owner._channel_health=lambda:None;owner._checkpoint=lambda *args:None;owner._progress_time=lambda:z.now
 owner._remember=lambda error:owner._errors.append(str(error));owner._retire=lambda why:setattr(owner,'_retired',True);owner._cleanup=lambda:None
 runtime=m.rt.PcDirectRuntime.__new__(m.rt.PcDirectRuntime);runtime.__dict__.update(owner._runtime.__dict__);owner._runtime=runtime
 runtime._boot=bind;runtime._g05p_profile=owner._config.g05p_profile;runtime._started_ns=z.x['actor_book']['source_origin_qpc_ns'];runtime._age_cap=100000000;runtime._busy=False;runtime._stepping=False;runtime._observations=OrderedDict();runtime._last_observed_seq=None;runtime._advance=lambda:z.now;runtime._trip=lambda why:setattr(runtime,'_latched',True);runtime._reason='synthetic';runtime._deps=m.ac._Dependencies(owner)
 mailbox=m.box.LatestCompletedMailbox.__new__(m.box.LatestCompletedMailbox);mailbox.__dict__.update(dict(_source=ch,_generation=1,_context={'topology_id':2,'session':7},_started=runtime._started_ns,_age_cap=runtime._age_cap,_time_high=0,_stopped=False,_observations=OrderedDict(),_last_observed=None))
 cand=m.co._CandidateOwner.__new__(m.co._CandidateOwner);cand._retired=False;cand._boot=bind;cand._source=ch;cand._mailbox=mailbox;owner._candidates=cand
 adapter=m.adapter._OwnedInvocationAdapter.__new__(m.adapter._OwnedInvocationAdapter);adapter.owner=owner;adapter.actor=owner._actor;adapter.source=ch;adapter.clock=owner._clock;adapter.pending=None;adapter.ready=None;adapter.records=[];adapter.associations=[];adapter._check=lambda:z.now;adapter.failed=False
 adapter.policy=N(max_invocations=2,max_reads=4,operation_id='synthetic',request_hash='1'*64,tested_commit='2'*40);owner._owned_invocations=adapter
 actor=owner._actor;actor._run_deadline=z.now+3000000;actor.instance_id='synthetic-actor';actor.dispatched=0
 def prepare(identity,**opts):
  r=m.Record();r.owner=actor;r.request=opts['request_raw'];r.identity=identity;r.deadline=opts['io_deadline_ns'];actor._invocation=r
 actor.prepare_invocation=prepare;actor.prepare_next_invocation=prepare;actor.dispatch_invocation_once=lambda:setattr(actor,'dispatched',actor.dispatched+1)
 records=[]
 for r in z.records:
  r2=g.TraceObservation(g._KEY,ch,bind,r.event,r.phase,r.raw,r.observed_seq,r.sample_lower_ns,r.counts,r.qualities,r.refs,r.request_raw,r.companions);records.append(r2);g._TRACES.append(r2)
 ch.verify_observation=lambda event,binding:next(r for r in records if r.event is event)
 fixture_live(z.source);z.view._refs,z.view._state=join._registry_state(z.source)
 z.channel=ch;z.comp=owner;z.records=records;z.runtime=runtime;z.mailbox=mailbox;z.adapter=adapter;z.modules=m
 # Earlier original capture is retained as history, not dispatched as AI input.
 ch._raw4_join=join.Raw4Session(ch);ch._raw4_join.bind(records[0],ch._raw4_selections[0])
 return z

def joined_dispatch():
 z=active_graph();r=z.records[-1];status=z.comp.accept_observation(r.event)
 assert status=='PENDING'and z.comp._actor.dispatched==1
 assert z.runtime._trace_observations[r.observed_seq]is r and z.mailbox._raw4_observations[r.observed_seq]is r
 assert z.adapter.pending['association'].entry['record']is r and z.comp._input_transaction is None and z.comp._busy is False
 try:z.comp.accept_observation(r.event)
 except ValueError:pass
 else:raise AssertionError('duplicate dispatch accepted')
 assert z.comp._actor.dispatched==1
 return dict(status=status,dispatches=1,duplicate_rejected=True,actual_method_sequence=['accept_observation','_Dependencies.verify_observation','retain','PcDirectRuntime.observe','_CandidateOwner.observe','LatestCompletedMailbox.observe_raw4','_OwnedInvocationAdapter.begin'],synthetic_boundaries=['Root/producer allocations','checkpoint clock','unchanged authority _check','child verifier','actor prepare/dispatch'])

def changed_retention():
 outcomes=[]
 for change in ('veto','config','transition','source_payload','foreign_record','copy_record','prefix_missing'):
  z=active_graph();r=z.records[-1]
  if change=='veto':z.source.owner._veto_generation+=1
  elif change=='config':z.producer._config[1]['goal_m'][0]+=0.1
  elif change=='transition':z.book._actor_custody.transitions.append(N(record={}))
  elif change=='source_payload':r.refs['payload']['quality']^=1
  elif change in ('foreign_record','copy_record'):
   v=g.TraceObservation(g._KEY,N()if change=='foreign_record'else z.channel,r.boot,r.event,r.phase,r.raw,r.observed_seq,r.sample_lower_ns,r.counts,r.qualities,dict(r.refs),r.request_raw,r.companions)
   z.channel.verify_observation=lambda event,binding:v
  elif change=='prefix_missing':z.channel._source_events.pop(1)
  try:z.comp.accept_observation(r.event)
  except ValueError:pass
  else:raise AssertionError(change+' was accepted')
  assert z.comp._actor.dispatched==0;outcomes.append(change)
 return dict(rejected_before_dispatch=outcomes)

CASES.update(joined_dispatch=joined_dispatch,changed_retention=changed_retention)
def missing_live_checks():
 results=[]
 for name in ('registry_clock','runtime_activation','link_source'):
  z=active_graph()
  if name=='registry_clock':z.comp._registry._clock_binding=object()
  elif name=='runtime_activation':z.comp._actor._runtime_activation=object()
  else:z.session._link.source=object()
  rejected=False
  try:z.comp.accept_observation(z.records[-1].event)
  except ValueError:rejected=True
  results.append(dict(mutation=name,rejected=rejected,dispatches=z.comp._actor.dispatched))
 assert all(x['rejected'] and x['dispatches']==0 for x in results),results
 return results
CASES['missing_live_checks']=missing_live_checks
def completed_graph():
 z=active_graph();z.comp.accept_observation(z.records[-1].event);a=z.adapter;o=z.comp;c=z.channel;p=a.pending;r=a.records[-1]
 policy=load(AUTH+'.g05_mailbox_policy_v1',A/'g05_mailbox_policy_v1.py')
 intervalmod=module(INTEG+'.completion_interval')
 class FiniteActionCandidate:pass
 intervalmod.FiniteActionCandidate=FiniteActionCandidate
 assoc=p['association'];doc=dict(schema_version=2,kind='model_candidate',context=json.loads(o._boot.context_json),candidate_id=1,observation=json.loads(assoc.observation_key),target=dict(action=1,duration_ms=1))
 raw=join.raw(doc);bounds=N();proofrow=z.modules.co._CompletedInference(o._boot,c,o._clock,raw,1,z.now-60,z.now-40,z.now-20,bounds)
 finite=FiniteActionCandidate();finite.candidate=N(document=doc,valid_until_ns=z.now+1000);finite.host_issue_ns=z.now-10;finite.deadline_ns=z.now+500
 event=object();a.ready=event;a._retained=(event,r,proofrow,finite,p,raw,bounds);r._close_attempted=True;r._close_error=None
 ticket=N(record=r,sealed_pair=object(),observed_qpc_ns=proofrow.completion_upper_ns);a.series=N(ledger=N(tickets=[ticket]));a.actor._invocation_check=lambda:None
 o.inspect_owned_candidate=lambda ev:finite
 c._clock=o._clock;c._config=o._config;c._session_deadline_ns=z.now+3000000;c.revoke=lambda:setattr(c,'_revoked',True)
 o._candidates._pending=proofrow;o._candidates._current=None;o._candidates._clock=o._clock
 s=dict(channel=c,binding=c._binding,attempts=[],max_commands=2,origin=z.now-100,first=100,period=1000000,width=100,policy=N(usb_upper_ns=10,packing_upper_ns=10),window=N(consume_window_ns=100),clock=o._clock)
 policy._schedule=lambda channel,binding:(s,z.now) # Existing authenticated schedule is an explicit synthetic dependency.
 box=z.mailbox;box._origin=s['origin'];box._window_first=s['first'];box._window_period=s['period'];box._pc_direct_window_v2=s['window'];box._bounds=s['policy'];box._clock_domain=o._clock;box._context_raw=o._boot.context_json;box._mode='PC_DIRECT';box._last_slot=-1
 box._pending=N(observed_seq=assoc.record.observed_seq,candidate_id=1,record=N(deadline_ns=z.now+1000,completion_upper_ns=proofrow.completion_upper_ns,invocation_id=1,candidate_raw=raw))
 o._candidates._pc_direct_window_v2=s['window']
 token=policy._retain_original_completion(c,event);command=policy._produce_original_command(c,token,command_seq=1,window_index=0)
 z.policy=policy;z.command=command;z.proof=proofrow;return z

def command_and_committed_duplicate():
 z=completed_graph();o=z.comp;c=z.channel
 o._busy=True;o._input_transaction=z.modules.co._InputTransaction('command',slot_event=z.command)
 verified=c.verify_command(z.command,o._boot);slot=c.verify_slot(z.command,o._boot)
 selected=o._candidates.select(verified.raw,slot,z.now);assert selected is z.proof
 o._candidates.commit(verified.raw,selected);assert z.mailbox._last_slot==0 and z.mailbox._pending is None
 # The real command's changed current Root is a synthetic completed-commit
 # dependency here, not a board/CAS execution or manufactured completion.
 successor=N(boot=o._boot,value={'revision':2});o._executor._root=successor;z.book._root=successor
 o._input_transaction=z.modules.co._InputTransaction('command',slot_event=z.command)
 duplicate=c.verify_command(z.command,o._boot)
 assert duplicate.raw==verified.raw and o._candidates.duplicate_proof(duplicate.raw)is selected
 assert z.mailbox._last_slot==0
 try:c.verify_slot(z.command,o._boot)
 except ValueError:pass
 else:raise AssertionError('second slot accepted')
 return dict(command=True,slot_consumed_once=True,committed_duplicate_preserved=True,actual_methods=['_retain_original_completion','_produce_original_command','G05Channels.verify_command','G05Channels.verify_slot','_CandidateOwner.select','LatestCompletedMailbox.consume_pc_direct_v2','_CandidateOwner.commit'],synthetic_completion_not_core=True)

def changed_completion_source():
 z=completed_graph();o=z.comp;o._busy=True;o._input_transaction=z.modules.co._InputTransaction('command',slot_event=z.command)
 z.records[-1].refs['draft']['source_sha256']='0'*64
 try:z.channel.verify_command(z.command,o._boot)
 except ValueError:pass
 else:raise AssertionError('mutated source accepted at command')
 assert z.mailbox._last_slot==-1
 return dict(rejected=True,slot_not_consumed=True)

def snapshot_dispatch_cap():
 z=active_graph();r=z.records[-1];selected=z.channel._raw4_selections[-1]
 z.runtime._age_cap=500000000;selected['source_deadline_ns']=r.sample_lower_ns+500000000
 z.comp.accept_observation(r.event);a=z.adapter.associations[-1]
 assert a.selected_source_deadline_ns==r.sample_lower_ns+500000000 and a.source_deadline_ns==r.sample_lower_ns+100000000
 # Direct new deadline branch at real later dispatch time; no current/getter
 # timestamp is changed to pretend that another real read occurred.
 z=active_graph();r=z.records[-1];selected=z.channel._raw4_selections[-1];z.runtime._age_cap=500000000;selected['source_deadline_ns']=r.sample_lower_ns+500000000
 old=z.current['at_qpc_ns'];z.now=r.sample_lower_ns+100000001
 try:z.comp.accept_observation(r.event)
 except ValueError:pass
 else:raise AssertionError('old snapshot extended dispatch freshness')
 assert z.current['at_qpc_ns']==old and z.comp._actor.dispatched==0
 return dict(original_selected_cap_retained=True,derived_fixed_cap_ns=100000000,late_dispatch_rejected=True)

CASES.update(command_and_committed_duplicate=command_and_committed_duplicate,changed_completion_source=changed_completion_source,snapshot_dispatch_cap=snapshot_dispatch_cap)
def stage_and_missing_attachment():
 for missing in (False,True):
  z=active_graph();c=z.channel;r=z.records[-1];selection=c._raw4_selections.pop()
  c._producer=N(_history=[(r.event,{'kind':'trace_scan'},r.refs)]);c.revoke=lambda:setattr(c,'_revoked',True)
  args={k:v for k,v in selection.items()if k not in ('event','used','current_bytes')}
  if missing:z.session._registries.clear()
  try:c.stage_raw4_invocation(r.event,**args)
  except ValueError:
   assert missing and not c._raw4_selections[-1]['event']is r.event;continue
  assert not missing
  assert c._raw4_selections[-1]['registry_hold']is z.hold and z.hold.context_attached is False
  assert z.comp.accept_observation(r.event)=='PENDING'
 return dict(original_hold_false_preserved=True,explicit_attachment_required=True)

def held_original_pose():
 z=graph(json.loads((D/'inputs/held-source-data.json').read_bytes()));s=join.Raw4Session(z.channel)
 for r,selection in zip(z.records,z.channel._raw4_selections):s.bind(r,selection)
 latest=s._entries[-1];native=s._entries[0];f=latest['fields']
 assert f['em_origin_capture_sha256']==native['fields']['capture_sha256']
 assert f['em_pose']['pose']==native['fields']['em_pose']['pose']
 assert f['em_pose']['nominal_source_qpc_ns']<f['adc_pose']['nominal_source_qpc_ns']
 assert f['em_pose']['pose_revision']!=f['adc_pose']['pose_revision']
 return dict(original_held_pose_preserved=True,original_capture_link_preserved=True,no_core=True)

CASES.update(stage_and_missing_attachment=stage_and_missing_attachment,held_original_pose=held_original_pose)
if __name__=='__main__':
 result=[]
 for name in sys.argv[1:] or CASES:
  try:detail=CASES[name]();result.append(dict(case=name,pass_=True,detail=detail))
  except BaseException as e:result.append(dict(case=name,pass_=False,error=type(e).__name__+': '+str(e)));traceback.print_exc()
 print(json.dumps(result,indent=2));raise SystemExit(0 if all(r['pass_']for r in result)else 1)
