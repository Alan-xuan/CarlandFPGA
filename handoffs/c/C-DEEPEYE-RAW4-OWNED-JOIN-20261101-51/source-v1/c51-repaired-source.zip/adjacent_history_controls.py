"""NEW narrow C51-R1 controls. Synthetic setup only; no old author case runs.

The projection-time mutator below is test-only fault injection around the exact
fixed pure projector, never a production callback or original authority source.
"""
import ast,copy,json,sys,traceback,types
from pathlib import Path
D=Path(__file__).resolve().parent;OUT=Path(sys.argv[1]);path=D/'test_join_new.py'
tree=ast.parse(path.read_bytes());nodes=[]
for n in tree.body:
 if isinstance(n,ast.FunctionDef)and n.name=='mechanical_bind':break
 nodes.append(n)
nodes.append(next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='route_modules'))
ctx={'__file__':str(path),'__name__':'new_c51_repair_setup'};exec(compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec'),ctx)
j=ctx['join']
def graph():
 z=ctx['graph']();s=j.Raw4Session(z.channel)
 for r,v in zip(z.records,z.channel._raw4_selections):s.bind(r,v)
 return z,s
def rejects(fn,contains):
 try:fn()
 except ValueError as e:
  assert contains in str(e),(contains,str(e));return str(e)
 raise AssertionError('expected rejection: '+contains)

def historical_getter_differs():
 z=ctx['graph']();s=j.Raw4Session(z.channel);prior=z.records[0];chosen=z.channel._raw4_selections[0]
 current_root=z.book._root;oldroot=types.SimpleNamespace(boot=z.comp._boot)
 z.book._root=z.comp._executor._root=oldroot
 oldread=copy.deepcopy(z.current);oldread.update(pose=copy.deepcopy(prior.refs['draft']['pose_reads']['adc']['pose']),pose_revision=0,at_qpc_ns=prior.phase.upper_qpc_ns)
 oldread['pose_read']={'begin_qpc_ns':prior.phase.upper_qpc_ns-1,'end_qpc_ns':prior.phase.upper_qpc_ns};oldread['valid_span']=dict(from_qpc_ns=prior.refs['draft']['nominal_qpc_ns'],through_qpc_ns=oldread['at_qpc_ns'],pose_revision=0,root_revision=0)
 v=ctx['RegistryView']();v._refs,v._state=j._registry_state(z.source);h=ctx['RegistryHold']();h.view=v;h.lower_qpc_ns=oldread['pose_read']['begin_qpc_ns'];h.upper_qpc_ns=h.getter_end_qpc_ns=oldread['at_qpc_ns'];h.context_attached=False
 z.source._registry_observations.append((oldread,v,h));z.session._current.append(oldread);z.session._registries.append((v,h,oldread['at_qpc_ns']))
 oldselection=dict(chosen,current_read=oldread,registry_view=v,registry_hold=h,current_bytes=j.raw(oldread))
 s.bind(prior,oldselection)
 z.book._root=z.comp._executor._root=current_root
 s.bind(z.records[-1],z.channel._raw4_selections[-1]);full,result=s.export_entry(s._entries[-1])
 assert result['input_status']=='PROJECTED'and result['core_ran']is False
 assert s._entries[0]['selection']['registry_view']is not s._entries[-1]['selection']['registry_view']
 error=rejects(lambda:s.check_entry(s._entries[0]),'registry refs/state changed')
 return dict(status=result['input_status'],old_and_current_roots_distinct=True,direct_current_hold_check_rejects_old=error)

def historical_bytes_changed():
 z,s=graph();s._entries[0]['record'].phase.response_raw+=b'\n'
 return dict(error=rejects(lambda:s.export_entry(s._entries[-1]),'original selected source changed'))

def projection_changes():
 outcomes=[]
 for mode in ('historical_reference','member_replacement','member_append','member_reorder'):
  z,s=graph();entry=s._entries[-1];proof,_=j._fixed();original=proof.project_raw4_json;count=[0]
  def injected(b):
   result=original(b);count[0]+=1
   if mode=='historical_reference':
    r=s._entries[0]['record'];r.refs['preparation']=types.SimpleNamespace(original=r.refs['preparation'].original)
   elif mode=='member_replacement':s._entries[0]=dict(s._entries[0])
   elif mode=='member_append':s._entries.append(dict(s._entries[0]))
   else:s._entries.reverse()
   return result
  proof.project_raw4_json=injected
  try:error=rejects(lambda:s.export_entry(entry),'selected source changed'if mode=='historical_reference'else'history membership changed')
  finally:proof.project_raw4_json=original
  assert count==[1];outcomes.append(dict(mode=mode,rejected_after_exact_projector=True,error=error))
 return outcomes

def current_hold_still_required():
 z,s=graph();z.source.owner._veto_generation+=1
 return dict(error=rejects(lambda:s.export_entry(s._entries[-1]),'registry refs/state changed'))

results=[]
for fn in (historical_getter_differs,historical_bytes_changed,projection_changes,current_hold_still_required):
 try:results.append(dict(case=fn.__name__,pass_=True,detail=fn()))
 except BaseException as e:traceback.print_exc();results.append(dict(case=fn.__name__,pass_=False,error=type(e).__name__+': '+str(e)))
(OUT/'observed.json').write_text(json.dumps(dict(synthetic=True,old_author_cases_executed=0,core_calls=0,results=results),indent=2)+'\n');print(json.dumps(results,indent=2));raise SystemExit(0 if all(r['pass_']for r in results)else 1)
