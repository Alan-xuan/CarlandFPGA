# C51 original raw4 join: explicit Root attachment

This is C-side source for an original trusted Root callsite. It is not a public
JSON API, an authentication mechanism, or permission to activate production.
`require_activation_ready()` remains the original preallocation refusal.

## Required installation and order

The candidate is an explicit composition of A046/C49, the reviewed C50 mailbox
policy and the final C50 raw4 projector. Apply `complete.patch` to the exact
seven files described by `baseline-pins.json` and add the new eighth file.
The C50 three channel delegates are included, byte-for-byte method bodies from
the source in `delegates-source-pin.json`. Do not separately overwrite the
result with C49 or C50's whole `g05p_runtime_v1.py` afterward. Place unchanged
`deps/raw4_proof_v1` and corrected C48 `deps/g05_csr_bridge_v1.py` beside these
authority modules; all other original C46/A modules remain their frozen versions.

A owns the actual factory, original Root, broker, source producer and lifecycle.
In particular A must add the fixed G05 binding branch to its original idle
`FunctionalSource._registry_snapshot`; the current A046 method requires a
legacy BootBinding. C51 does not modify A's method or construct its view/hold.

After genuine original source admissions and trace completion, before consuming
the trace event and while the original composition is idle:

```python
current, view, hold = functional_source.read_current_with_registry()
projection.attach_registry(
    view, actual_operation._c42, actual_config_generation,
    as_of_qpc_ns=current['at_qpc_ns'], observation_ref=hold)
channels.stage_raw4_invocation(
    original_trace_event,
    current_read=current, registry_view=view, registry_hold=hold,
    source_bound_receipt=original_runtime_record_policy_attachment,
    dispatch_bound_receipt=original_actor_policy_clock_attachment,
    source_deadline_ns=selected_original_source_deadline,
    dispatch_deadline_ns=selected_original_dispatch_deadline,
    cause_action=actual_original_action_slot_or_none,
    previous_action=actual_same_action_bound_or_none,
    previous_deadline_ns=actual_same_action_deadline_or_none)
composition.accept_observation(original_trace_event)
```

The attachment must genuinely support the named as-of time: the actual hold
brackets the getter and its retained unchanged registry. `read_current_with_registry`
does not attach C42 context automatically. Neither the old hold's
`context_attached=False` nor its old diagnostic reason is rewritten. The original
operation strongly holds both namespaces and source/projection; the explicit
`attach_registry` uses that original mapping. Numeric TRACE session is never
equated with textual C42 session.

Bounds are conservative selected policies over original objects, not new hardware
measurements. Root can retain the actual runtime/record and choose a source bound
no later than `record.sample_lower_ns + runtime._age_cap`; retain actual actor,
policy and clock and choose dispatch no later than the actor's real run deadline.
The raw4 association preserves `selected_source_deadline_ns` and derives
`source_deadline_ns = min(selected_source_deadline_ns,
record.sample_lower_ns + 100_000_000)`. The actual dispatch clock must precede
both effective caps. Original selected values and receipt references survive;
this derivation only tightens the fixed C50 path. Existing DemoAgeBudget remains
applicable to its scanner/selector scope and is not relabeled missing. A wider
downstream projection/AI budget is not qualified by this version.

The C50 `now_qpc_ns` and public view are the real getter snapshot, not a new read
at dispatch. C51 independently checks actual dispatch freshness and unchanged
original registry/Root; it never updates getter timestamps to reduce apparent age.

Original C50 broker ordering remains necessary: select/retain schedule before
factory claim; retain original seven-item C46 completion before accept_completion
consumes it; offer the exact original proof; produce the command; call the original
command/slot transaction. C51 preserves completion, finite issue/deadline, source,
clock, pending proof, command and slot gates. It does not create a completion.

## Mechanical field map

| C50 field | Actual retained source |
|---|---|
| raw request/source/companions | `refs['preparation'].original` and same original byte references |
| wire | original retained four-frame result, independently decoded by fixed C50 transport |
| result_rows | original phase response `result.response.results` |
| build_binding | original phase/preparation binding; independently checked against actual wire |
| counts/quality/profile/ADC and EM ticks | original selected `refs['payload']`; compared by C50 to wire and full source proof |
| schema/channel_names/quality_encoding | constants in the pinned C50 ABI, explicitly schema metadata |
| capture lower/receiver upper | actual original phase QPC lower/upper |
| source admission index | original completed draft `source_count - 1`, checked against that exact book object |
| received time/new EM flag | exact original admitted item and Admission object |
| source grid | original source `origin_ns` plus original tick; derived schedule, not physical sampling proof |
| ADC pose/call/revision/span | original draft read and numerical span, unchanged bounds |
| held EM pose/call/revision/span | `held_em_association.original_em`; original native sample and prior raw4 capture link, never newest pose |
| config | actual C42 producer retained config, original IDs/book/binding |
| current/read/span | actual `session._producer._readings` row, including original saved bytes and span object |
| registry/actions | original registered view/hold/context plus original producer action records |
| book | exact saved evidence accompanying the getter, projected through C50's fixed field whitelist |

Opaque labels use the unchanged original session/producer ID registry for
consistency only. Neither labels nor JSON hashes establish provenance. Raw4 rows
are held separately by `Raw4Session`; original C42 `_captures` remains untouched.
No fabricated C42 `capture_raw`, native counters, ACK, TELEM means, or BOOT exists.

## Retention and failure behavior

One staged event is consumed in its exact active `_InputTransaction`. Typed
observations retain their original record identity through runtime and mailbox;
same bytes in another object or foreign channel fail. Original ordering, four-row
caches, half-range mailbox check, age and expiry rules remain. The adapter uses
the fixed C50 projector with no core call, then original C46 prepare/dispatch.
Failures retire through original entry handling; there is no retry or lock reset.

Current registry checks match all original A `_registry_snapshot` live relations,
including thread/clock, actor activation, session and link/custody/source relations.
Only its legacy binding type is replaced with the existing exact G05 binding and
its idle-only condition is omitted inside the already-owned active transaction.
The retained idle view and every unchanged state/ref are still required.

At first command, the same full retained association and pre-command Root apply.
The existing policy's already-committed exact bytes/proof duplicate may bypass
only the old getter/Root snapshot after the actual command changes Root; original
channel liveness, source bytes, association, finite/cap and current-command gates
remain. It cannot consume another slot or renew a deadline.
