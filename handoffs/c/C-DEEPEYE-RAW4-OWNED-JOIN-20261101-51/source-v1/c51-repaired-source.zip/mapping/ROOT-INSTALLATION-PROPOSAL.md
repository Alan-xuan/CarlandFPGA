# A-owned installation proposal — documentation only

No code in this document has been installed or executed. The registry fragment is an exact minimal proposal against pinned A046. The integration sketch is call order, not an executable runner; names for local retention rows are descriptive and must not be exported as authority constructors.

## Registry compatibility patch

Apply only after the fixed C51/C49 G05 module has been reviewed and installed by A. Preserve the legacy exact type path and every remaining original check. This is not permission to accept an arbitrary object with matching fields.

```diff
--- a/competition/deepeye/tools/run_causal_functional_chain.py
+++ b/competition/deepeye/tools/run_causal_functional_chain.py
@@
         registry, actor, boot, runtime, executor = (comp._registry, comp._actor, comp._boot,
                                                     comp._runtime, comp._executor)
+        original_boot = type(boot) is BootBinding
+        if not original_boot:
+            from ..simulation.authority.g05p_runtime_v1 import is_original_binding
+            original_boot = is_original_binding(boot, executor=executor)
         if (type(registry) is not ActorRegistry or type(actor) is not ActorOwner
-                or type(boot) is not BootBinding or comp._state != 'ACTIVE' or comp._retired
+                or not original_boot or comp._state != 'ACTIVE' or comp._retired
                 or comp._busy or comp._foreign.is_set() or actor._foreign_call.is_set()
```

`is_original_binding` at sealed C50 `g05p_runtime_v1.py:78–85` checks exact G05 binding type, retained membership, exact channel/binding, revocation and original capability executor. This patch leaves `comp._busy` rejection intact. No G05 shape check, context JSON or caller boolean replaces it. Native/provider qualification remains outside this static patch.

## Original Root call order

1. Validate original plan and prepare exactly once with `prepare_pre_source_cycle`. After actual init/operation binding, before original factory claim or later board phase, attach original operation and `_retain_original_schedule`. Select finite `TransferPolicy(basis='selected_policy', ...)` in original Root; do not require nonexistent empirical timing fields or label policy as measurement. Do not initialize a live session just to wait for code review; its fixed deadline already runs.
2. Use the existing source-start/config binding path and actual original authority factory once the complete integration is approved. Preserve original same config/link/book/executor/clock refs, one-use claim and all cleanup. Accept the actual original init event for BOOT; this creates mailbox activation before any observation dispatch. No child completion is required to choose schedule policy.
3. Use actual `OriginalChainReceiptProducer.admit_source/scan_actual`, holding exact selected payload/token/draft/admission/preparation and complete source history, including samples produced during preparation. Obtain the original returned event; do not consume it yet. Do not replace the selected item by whichever sample is now latest.
4. While the composition is idle, call actual `FunctionalSource.read_current_with_registry`. Retain its exact `(current, view, hold)` triple, actual session/current/registry attachment and original source event. A's existing registry attachment must retain both genuine C42 context and generation, not copy TRACE numeric session. The C51 stage branch subsequently rechecks actual retained refs/state without invoking the idle-only snapshot while busy.
5. Select immutable conservative source/dispatch bounds from actual source request/companions and runtime profile/actor run policy. Store source event/preparation/token/phase/runtime/clock references and selected value in Root's own retention row; store actual actor/policy/run deadline/clock and selected dispatch value in another. These are the `source_bound_receipt` / `dispatch_bound_receipt` references, not new authenticated serialized types. Never create a fake record merely to obtain `sample_lower_ns`.
6. Call the confirmed `channels.stage_raw4_invocation(event, current_read=current, registry_view=view, registry_hold=hold, source_bound_receipt=..., dispatch_bound_receipt=..., source_deadline_ns=..., dispatch_deadline_ns=..., cause_action=actual_or_None, previous_action=actual_or_None, previous_deadline_ns=actual_or_None)` once. Then call `owner.accept_observation(event)` once. Only inside that entry may C allocate the exact TRACE record and bind the exact active `_InputTransaction`, compare source cap against the new record's real minimum source time, validate the retained current/registry state, build full raw4 proof and dispatch the fixed wire. Failure consumes the attempt; it does not permit staging a replacement for the same event.
7. Drive only the original finite owned-invocation poll contract. Pending is not completion; no resend on timeout/error. After actual pair sealing yields a completion event, call `_retain_original_completion(channel,event)` first. Then `owner.accept_completion(event)`; require its success. The original adapter's ready tuple is consumed by verification, so reversing these calls is invalid.
8. Only with the exact offered `_candidates._pending` proof, call `_produce_original_command(channel, token, command_seq=chosen_finite_sequence, window_index=chosen_existing_window)`. Use the returned exact event in `owner.accept_command(command_event, slot_event=command_event)`. All original issue/full duration/target/observation/caps and fixed schedule are retained; no new clock sample renews them. Full duration must fit; no partial lease substitution. Command acceptance and actual motion/second-H12 board producer remain original authority responsibilities.

## Finite review cases for the implementation owner (not run here)

Static proposal acceptance should be followed by narrowly scoped tests under its own assignment: original G05 binding with same executor succeeds where wrong executor/revoked/copied binding fails; idle retained getter is accepted but replaced Root/registry/config/slot/custody fails during active join; stage does not consume TRACE and consumed/replayed event refuses; held source cap uses original old EM time; failed stage/dispatch never retries; retain-before-offer works but reversed order fails; command preserves full finite candidate and duplicate does not create a new slot. Demo token application must state exactly which gate consumes it; absent downstream support must remain explicit rather than being silently simulated.
