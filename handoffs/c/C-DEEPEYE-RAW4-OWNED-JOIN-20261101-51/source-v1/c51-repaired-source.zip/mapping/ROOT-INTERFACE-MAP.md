# C51 static Root interface map — uninstalled proposal

This is source inspection, not a product candidate, runtime qualification, or authority grant. A source is fixed at `0469345fd1eef2884de1417f0f4eb5b67688f84c`. The 30 exact source snapshots, SHA256, original Git blobs where applicable, and line/symbol index are in `source-pins.json` and `symbols.json`. Original A paths below start at `competition/deepeye/`. C49/C50 line references identify the separately named sealed snapshots, not a claim that those patches are already installed at A046. No product source was imported or executed.

The original producer, phase receipt, source token, selected sample, operation binding, current getter and registry hold already exist. Remaining work is a concrete join and installation at the right callsites. It is incorrect to request a new generic producer or to reconstruct original authority from serialized proof. It is also incorrect to require a child completion before mailbox activation: activation happens in BOOT before an observation can dispatch a child request.

## Existing objects and exact order

| Stage | Actual source and lines | Retained facts / consequence |
|---|---|---|
| Pre-source prepare | `tools/diagnostic/demo30h_pre_source_coordinator_a.py:234`, especially 282–315 | `prepare_pre_source_cycle(plan, chain)` creates `OriginalChainReceiptProducer`, performs exactly one original init, retains `init_event` and `OriginalPhaseReceipt`, optionally chooses demo age, creates `OriginalG05OperationBinding`, then deferred scanner and disabled source pump. It returns the actual `PreparedCycle`; its snapshot is not a resumable capability. |
| Original binding | `tools/diagnostic/original_g05_operation_binding_a.py:81` and 87 | `claim_for_factory` is one-use. `attach_source_config(original_config_ref)` retains the actual projection producer configuration and validates original source origin/context. Keep legacy/TRACE numeric session and C42 string session as separate namespaces. |
| Policy before claim | C50 `g05p_runtime_v1.py:177`; `g05_mailbox_policy_v1.py:70–117` | Root calls `attach_original_operation(config, cycle.binding)` and `_retain_original_schedule(cycle.binding, config, transfer_policy=..., enabled=True)` after successful prepare and before factory claim or later phases. The schedule uses exact `init.upper_qpc_ns` as a selected software anchor, not measured BOOT time. First/period are fast 210/500 ms or stress 2050/8000 ms; window, transfer policy and session cap do not renew. No child object is needed. |
| Factory/BOOT | C49 `actor_composition.py:184`, 514–574 | Factory still calls the deliberate preallocation refusal before acquisition. Once independently reviewed and installed by A, original BOOT activates runtime/executor/actor/mailbox and installs the owned adapter. Do not remove the refusal merely to run this proposal. |
| Original selected TRACE | `tools/diagnostic/original_chain_receipt_producer_a.py:163–210` | `scan_actual` retains actual result/phase, payload, admitted item, admission, token, draft, ADC/EM handles, preparation, request/source/companions, root facts and build binding. In owner-work mode it fixes selected item/entry/token/draft/admission before pumping; it requires their membership in the complete history after pumping. The selected sample need not still be latest. |
| Original current/registry | `tools/run_causal_functional_chain.py:399–485` | `read_current_with_registry` takes before/after original registry snapshots around `session.read_current`, checks stability and interval, returns `(current, view, hold)` and strongly appends that exact triple to `_registry_observations`. It is idle-only; `_registry_snapshot` rejects `comp._busy`. |
| Stage, then active admission | Confirmed C51 author API below; C49 `actor_composition.py:582–593`; original `candidate_owner.py:57–65` | Stage while event is original and unconsumed. No `TraceObservation` exists yet. `accept_observation` creates the exact `_InputTransaction`, runtime verifies/allocates the record, candidate owner observes it, and adapter begins within the same active transaction. The wrapper clears `_input_transaction` in `finally` at C49 line264. Root must not call the old retain hook after this returns. |
| Completion retention | C50 `g05_mailbox_policy_v1.py:184–218`; C46 adapter 219–241 | `poll_owned_invocation` yields the opaque event only after actual serial pair sealing. Root must call `_retain_original_completion(channel, event)` BEFORE `owner.accept_completion(event)`. Inspection retains exact event/record/proof/finite/pending/raw/bounds. Original verification consumes adapter `ready/_retained`; later retention would be too late. |
| Offer then command | C49 `actor_composition.py:596–606`; original `candidate_owner.py:129–164`; C50 policy 280 onward | Successful offer retains exact proof in `_candidates._pending`. Only then `_produce_original_command(channel, token, command_seq=..., window_index=...)` may create the original command/slot event. The same event enters `accept_command(event, slot_event=event)`. It binds exact issue, full duration, target, observation, caps and window. It never rebases issue to arrival time, silently shortens duration, or grants a fresh slot for a duplicate. |

## Confirmed join API and stage/admission split

The author-reported C51 interface is a proposed candidate under independent implementation/review, not an API verified in the frozen sources:

```python
channels.stage_raw4_invocation(
    event, *, current_read, registry_view, registry_hold,
    source_bound_receipt, dispatch_bound_receipt,
    source_deadline_ns, dispatch_deadline_ns,
    cause_action=None, previous_action=None, previous_deadline_ns=None,
)
```

The session is fixed to `operation.projection`. `event` must be a still-unconsumed original producer-history event. Root obtains `(current_read, registry_view, registry_hold)` from the actual idle getter, with the exact retained triple and associated session/current/registry records. C then holds these inputs until active admission, where it rechecks original references and state: Root, source, config, clock, executor, slot, publication, custody/transitions, veto/epoch, registry ordinal/generations/used sessions, and event membership. Calling the idle-only `_registry_snapshot` inside the busy transaction is not an acceptable implementation.

Do not pre-call `retain_trace` to obtain a record before staging. That consumes the event and creates a circular requirement. The actual record is allocated during admission; only then can the adapter bind exact `tx.observation_record`, admitted runtime row and immutable request bytes. Staging is neither consumption nor a successful dispatch.

## Finite source and dispatch policies already have real sources

Original C46 `owned_invocation_v1/adapter.py:62–104` accepts non-null source/dispatch receipt references; it does not define a new external receipt class. Its line160 independently enforces:

```text
now < source_deadline_ns <= admitted_record.sample_lower_ns + runtime._age_cap
now < dispatch_deadline_ns <= original_actor._run_deadline
```

The original runtime `_age_cap` is profile policy: 1.5 s for profile1, 12 s for profile2 (`pc_direct_runtime.py:367–368`; C49 successor400–401). Actor `_run_deadline = start + policy.lifetime_timeout_ns` is fixed in original `isolation/actor_owner.py:385`. Adapter line168 passes the chosen dispatch bound to original serial `io_deadline_ns`; it does not derive a new deadline from response arrival. Previous same-action limit, when present, must refer to the exact `owner._progress.bound` and its unchanged `deadline_ns`; explicit None means no prior cap, not an unlimited override.

Before staging there is no admitted record, but Root already retains actual preparation/request/source/token/phase and the selected valid lane times. `original_source_trace_scan_a.py:52–74` encodes `scan.lanes[*].source_qpc_ns` from the original nominal source grid, with valid flags; C50 `retain_trace:482–501` later uses the minimum valid lane source time for `sample_lower_ns`. Root can choose a conservative bound using those same original facts and the runtime profile, retaining them by identity. Active admission must recompute/recheck against the actual record, not trust the proposed value. Held EM retains its older source time; neither current ADC nor phase arrival replaces it.

A minimal Root-owned retention row can hold `(event, original preparation, original request/source/companions, token, phase, runtime, runtime policy, clock, chosen source bound)` and a second row `(same event, original actor, actor policy, clock, original run deadline, chosen dispatch bound)`. These are callsite records for already available facts, not new serialized authority tokens. Their exact accepted container/type is for the C51 author to freeze; this mapping does not invent a type requirement. Private Python objects alone are not a security boundary. Installation and membership checks at A's trusted original callsite remain necessary. Policy values need not pretend to be empirical transfer measurements.

## Concrete mismatches requiring the explicit typed route

1. C50 `g05p_runtime_v1.py:465–471` compares TRACE lineage session directly with C42 context. TRACE session is numeric; C42 session is a string namespace. A73 confirms ABI3/type7/rev1 TRACE, not legacy TELEM1/EVENT2/STATE8. Preserve both actual contexts and compare only genuinely shared fields under the raw4 schema.
2. `retain_trace:428–503` returns `TraceObservation`, explicitly not `VerifiedObservation`. C49 `_Dependencies.verify_observation`, runtime observation, candidate owner and mailbox still have legacy exact-type/TELEM/EVENT assumptions. Renaming the type or fabricating mean-distance JSON is invalid. Parent's `author-scope-addendum-v1.json` assigns these four minimal typed gates to the other C51 author. This mapper does not edit them.
3. C50 mailbox `_check_completion:252–263` expects the C46 association's original C42 `_captures` row, `candidate_bytes/capture_bytes`, observation bytes/key and runtime sample row. C51's raw4 association branch must explicitly support these checks; a detached raw4 projection alone cannot satisfy them. Keep full command/finite consistency, original Root guard, pair seal and caps. Main has additionally assigned the corresponding `g05_mailbox_policy_v1` typed branch to the C51 author; it must accompany that candidate while preserving the seven-element retained tuple and finite/slot/cap checks. No old C50 source is changed here.
4. A `FunctionalSource._registry_snapshot:411–412` accepts only exact legacy `BootBinding`, so a legitimate C49 G05 binding cannot reach `read_current_with_registry`. The accompanying minimal textual patch proposes using the fixed `is_original_binding(boot, executor=executor)` branch while retaining every existing live-registry/clock/custody/state check. A must review/install it; no product file is modified here.
5. Actual A046 `_production_channels` still raises unconditionally; C49/C50 preserve a more specific preallocation refusal. No Root preparation call, policy attachment, proof JSON, or successful static mapping authorizes removing that gate. The complete joined candidate and A's original installation are separate responsibilities.

## What raw4 evidence exists, and what it proves

Original phase receipts and `RootBinding` are supplied APIs, not missing concepts. The original producer preserves byte-for-byte request/source/companions and actual returned wire/phase/correlation. `original_source_trace_scan_a.py:29–115` explicitly labels nominal grid times, carries original Book draft with read/call/custody evidence, and preserves separate host clock domain. Board cycle/tick fields are not host QPC. Full source history, selected sample and held EM original references must remain intact; no current-pose reconstruction of old samples.

C50 repaired `raw4_proof_v1/projector.py` SHA `cfa1611e4f95ca261964a71d2712d4972f7c2be5227ead83494db93c9edb38a1` is a detached pure structural path, core0/authority none. Its `project_raw4_json` output is not the original C36 full-proof packet and does not authenticate capture/getter/owner/BOOT. C51 must use the exact original retained facts to join this path to the active transaction; actual host owned invocation remains the only completion route. This static task did not inspect or qualify the other author's unfinished implementation.

## A65 / A69 / A71 / A73 and timing applicability

`A-instruction-pins.json` independently pins the four cached original messages and author ID328016885. A65 says use published original host APIs and preserve the fixed contract. A69 permits explicit phase2 demo compromises in quality/speed/100ms/1% reporting, but not fake CRC/layout/source or replacement of physical provenance; the final contract remains. A71 publishes an actual `DemoAgeBudget`; A73 reiterates the original factory refusal and distinct TRACE ABI, and treats A343 fallback as a separate branch rather than C takeover.

The actual token is chosen once after successful init, before scanner binding/source start (`demo30h_age_budget_a.py:24–37`), with `100ms < maximum <= 5s` and maximum <= original chain duration. It strongly retains world/source/producer/chain/session/clock/origin and later scanner/ledger, and refuses serialization. `_verify` and `_ledger_limit` check original membership and clock; arbitrary JSON is not equivalent. Source admission/selection can therefore honor this existing demo policy without inventing another token.

The token does not automatically change every downstream gate. TRACE request association still records `freshness_limit_ns=100000000` (scanner line101), repaired raw4 projector has `AGE_NS=100000000` (line19), C46 has its own progress max-age, and runtime/actor/session/full-action caps remain separate. Report ADC/EM actual ages and whether 100ms was met; do not label the original token absent, pretend it extends all caps, or silently tighten the human demo request into a new authorization policy. An explicit reviewed downstream demo-policy choice, if desired, is separate work. Physical H01–H15, both H12 paths and final acceptance are not established by this mapping.

## Remaining responsibility

- C51 author: exact typed raw4 stage→active transaction→single owned invocation join; four observation gates; C50 mailbox retained-association compatibility; no fake legacy encodings, no dispatch before proof, no action duplication.
- A original Root installer: fixed G05 registry branch, preclaim policy attachments, actual source/config and original scan caller, idle current/registry staging, exact completion-before-offer and command/slot order, original provider installation and physical execution. Existing facts are available; the trusted callsite must retain and pass them.
- Main/independent review: freeze candidate API and dependencies, review all branches before opening the acquisition refusal. This proposal is uninstalled and cannot by itself unblock native acquisition.

Validation: static SHA256/Git blob checks and AST parsing only. No test controls or product execution were authorized or run. The first collection helper exited1 due solely to a misspelled standard-library encoding name (`utf8-sig`); exact helper/stdout/stderr retained. Corrected helper exited0 and checked30 source files, four messages, and all15 requirement entries. A read-only exploratory tree display was unnecessarily large; the tree was not copied into this package or executed.
