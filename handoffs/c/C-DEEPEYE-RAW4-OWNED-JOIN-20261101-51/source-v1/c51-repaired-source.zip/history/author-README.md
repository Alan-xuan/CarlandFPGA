# C51 bounded C-side raw4 join

This candidate connects original typed raw4 observations through the original
composition, runtime, candidate owner, mailbox, C46 owned invocation adapter and
C50 command policy. It implements useful assembly and call paths, while retaining
the existing preallocation refusal. It is source-ready for independent review;
it is not production restoration, native execution, board evidence, H12 completion
or formal acceptance. A alone operates the board. H01–H15 and fixed contract hashes
are unchanged (`contract-check.json`).

`API.md` gives the required actual Root attachments and installation sequence.
The current A046 idle registry getter still requires its A-owned typed G05 branch.
The Root must provide real source, current, custody, actor and schedule/completion
attachments; merely applying this patch cannot supply them. The original fixed
100ms downstream proof and finite-action limits remain a local constraint on this
path even when a real scanner DemoAgeBudget permits older source selection.

## Changes

* New `raw4_owned_join_v1.py` mechanically assembles the fixed C50 full proof from
  original retained records, checks original wire bytes independently, and keeps
  a separate raw4 association alongside unchanged C42.
* Four original observation gates now accept only the existing exact typed TRACE
  record and preserve it through one active original transaction.
* C46's raw4 branch calls the fixed projector, keeps no inference/core in the host,
  and preserves the original serial invocation and complete/final fences.
* The reviewed three C50 channel delegates and typed completion association check
  make the original command and slot path reachable without fake legacy capture.
* Registry live relations and retained source bytes are rechecked. The original
  selected source policy is retained separately from the tighter C50 dispatch cap.

## Evidence and limits

All controls are NEW C51 behavioral controls. Two copied JSON files are immutable
fixture DATA; no old suite was run. `test_join_new.py` AST-selects unchanged actual
method and decorator bodies to avoid importing/starting native Root dependencies.
The original typed classes/producer allocations, unchanged authority `_check`,
clock/schedule, actor prepare/dispatch and child response are explicit synthetic
dependencies. No authenticated original Root, real child/core, native, model, PDE,
SSH or board operation was executed. Results verify software plumbing and rejection
behavior only. Original snapshot/raw command outputs and exits are in `runs/`.

| Run | Actual exit | Scope |
|---|---:|---|
| run01 | 1 | Product RED: original payload lacks target schema metadata. Fixed by pinned ABI constants. |
| run02 | 1 | Fixture defect: synthetic action custody labels differed from its own book/binding labels. |
| run03 | 0 | Complete mechanical assembly reaches actual fixed C50 PROJECTED, core false. |
| run04 | 0 | Actual seven-method front path reaches one synthetic dispatch; duplicate and seven changed-retention variants reject. |
| run05 | 1 | Product RED: three omitted live registry relations permitted dispatch. |
| run06 | 0 | Exact three live-relation repairs plus affected positive front path. |
| run07 | 1 | Fixture loader omitted dataclass base Selection; no product case executed. |
| run08 | 0 | Actual command/slot/select/consume path, mutated-source rejection, selected/derived cap and late dispatch rejection. |
| run09 | 0 | Actual committed Root change duplicate; real stage method and explicit registry attachment; original held EM pose/link preservation. |

After the relevant controls passed, no broad group was repeated. `complete.patch`
is a plain source diff, not a Git operation. `freeze.json` pins all candidate,
dependency, fixture, source version, raw output and documentation files. Exact
reviewer replay and actual A installation remain separate gates.
