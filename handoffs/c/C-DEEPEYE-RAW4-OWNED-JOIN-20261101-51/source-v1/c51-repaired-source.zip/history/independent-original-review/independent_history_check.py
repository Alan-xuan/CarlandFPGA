"""NEW historical-custody counterexample, no author cases executed.

CLI: python -B independent_history_check.py IMPLEMENTATION_DIR OUTPUT_DIR
Reuses ONLY the frozen author's synthetic graph setup, selected by AST; input
data and fixed C50 projector are real frozen files. All Root/checkpoint/type
allocations in that setup are synthetic. No actor/native/core/board operation.
This checks the original-reference gate, not production authentication.
"""
import ast,hashlib,json,sys,types
from pathlib import Path
A=Path(sys.argv[1]).resolve();D=Path(sys.argv[2]).resolve()
path=A/'test_join_new.py';tree=ast.parse(path.read_bytes())
# Stop before the first author case; append the one setup definition needed by
# graph(). Never execute mechanical_bind/CASES/main or any other author case.
nodes=[]
for n in tree.body:
 if isinstance(n,ast.FunctionDef) and n.name=='mechanical_bind':break
 nodes.append(n)
nodes.append(next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='route_modules'))
ctx={'__file__':str(path),'__name__':'c51_independent_fixture_setup'}
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec'),ctx)
join=ctx['join'];z=ctx['graph']();s=join.Raw4Session(z.channel)
for record,selection in zip(z.records,z.channel._raw4_selections):s.bind(record,selection)
assert len(s._entries)>1
prior=s._entries[0];current=s._entries[-1]
full_before,result_before=s.export_entry(current)
(D/'positive-full.json').write_bytes(join.raw(full_before))
(D/'positive-result.json').write_bytes(join.raw(result_before))
assert result_before['input_status']=='PROJECTED' and result_before['core_ran']is False
original=prior['record'].refs['preparation']
# Same exact original request/source/companions, different preparation object.
# Thus all encoded evidence is unchanged; only original custody is lost.
replacement=types.SimpleNamespace(original=original.original)
prior['record'].refs['preparation']=replacement
direct_error=None
try:s.check_entry(prior,committed_duplicate=True)
except ValueError as e:direct_error=str(e)
assert direct_error=='original selected source changed',direct_error
export_error=None;full_after=result_after=None
try:full_after,result_after=s.export_entry(current)
except ValueError as e:export_error=str(e)
if full_after is not None:
 (D/'changed-full.json').write_bytes(join.raw(full_after))
 (D/'changed-result.json').write_bytes(join.raw(result_after))
report=dict(case='historical_preparation_identity_replacement',synthetic_graph_reused_from=str(path),author_cases_executed=0,positive_status=result_before['input_status'],history_entries=len(s._entries)-1,mutation=dict(path="entries[0].record.refs['preparation']",same_original_bytes=True,same_reference=False),direct_history_check_error=direct_error,current_export_error=export_error,current_export_status=None if result_after is None else result_after['input_status'],full_bytes_unchanged=full_after is not None and join.raw(full_before)==join.raw(full_after),result_bytes_unchanged=result_after is not None and join.raw(result_before)==join.raw(result_after),expected='reject changed original historical preparation before exporting dependent history',pass_=export_error is not None,core_ran=False,dispatch_calls=0,source_sha256=hashlib.sha256((A/'candidate/competition/deepeye/simulation/authority/raw4_owned_join_v1.py').read_bytes()).hexdigest())
(D/'observed.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print(json.dumps(report,indent=2));raise SystemExit(0 if report['pass_']else 1)
