# REPAIRED_SOURCE_DRAFT_PENDING_MAIN_REVIEW

This package contains the repaired source and exact historical evidence. It is
not approved for production, actual Root/native/actor/core/model/PDE/board use,
H12 completion or H01–H15 acceptance. Independent repair results are pending and
will be added separately by main. No product import or test was run to make this
package. A alone operates physical hardware.

Only `candidate/competition/deepeye/simulation/authority/raw4_owned_join_v1.py`
changes from rejected C51 v1. Its SHA256 is
`109d246f826d9484e278ae919042c1ce6e86d3eece7ca4f1ecdbbada71b1fd34`.
Seven other candidate modules, dependencies, fixtures and author synthetic setup
are byte-identical. `repair.patch` is the exact narrow original patch.
`complete-final.DERIVED.patch` is a newly generated complete patch against the
seven original `baseline/` files plus the eighth new module. Its hunks were
reconstructed as bytes and checked against all eight final sources. It is clearly
DERIVED and must not be confused with the rejected author's `complete.patch`.
`final-source-pins.DERIVED.json` records those exact final/baseline/patch hashes.

`README.md` is the exact repair author's document. `API.md` is the exact unchanged
original API, and `history/author-README.md` is the earlier exact source-ready
document. Where the old API mentions `complete.patch`, use the current explicitly
DERIVED complete patch or apply the exact narrow repair to the exact rejected
candidate. The earlier patch remains history inside the rejected archive; it is
not silently relabeled current. Original baseline provenance and delegates pins
are preserved in that archive's explicitly DERIVED metadata; local private source
path originals are disclosed rather than rewritten.

The fix separates historical original-retention checks from the current getter/
Root hold. History may legitimately refer to a different older Root/getter; it
must still retain its original record/phase/sample, selected source, preparation,
token/admission and bytes. A captured identity-ordered collection is checked before
and after projection. Replacing historical references or collection membership
cannot pass merely because serialized proof is unchanged. Current hold/veto checks
remain necessary; history is not reclassified as a committed-command duplicate.
See exact README.md and narrow repair.patch for the actual change.

The original registry attachment order remains explicit: idle original getter,
`projection.attach_registry(view, actual_operation._c42, actual_generation,
as_of_qpc_ns=current['at_qpc_ns'], observation_ref=hold)`, then stage an unconsumed
original event, then active `accept_observation`. No record is fabricated or
pre-consumed to stage. The original mapping documents and separate clarification
are retained under `mapping/` and `ATTACHMENT-CLARIFICATION.md`; they do not replace
the final API or install the A-owned registry/factory branch.

Repair history has three original runs: run01 exit1 reproduces R1 against rejected
source; run02 exit0 uses the same exact reviewer control against repaired source;
run03 exit0 covers only new adjacent cases. No old author cases or suite were run.
The source.py/control.py and raw clean stdout/stderr/exit plus original outputs
are retained. Each run/version has exact supporting candidate/deps/inputs and
controls so relative paths remain portable; these added support copies are marked
separately, not claimed original run members. `REPLAY.DERIVED.json` is an unexecuted
plan requiring separate authorization and a new output directory. Do not run the
historical RED control against the final root candidate and call it the old run.

`history/C51-rejected-history-v1.zip` is byte-exact, SHA256
`6a3e8517dc2b6e4c4cdbc16664d6b824d6215c49d90cb35062a2b9cfed700a49`.
It retains all nine original author versions and their failures. Clean original
independent RED source/outcomes are also retained; private reviewer fields and
observed/stdout paths are WITHHELD by exact length/hash. DERIVED diagnostic files
are explicitly labelled and are never represented as raw originals.

`DISCLOSURE.json` covers exact or withheld originals, derived metadata and added
exact support copies. The standard-library `verify_package.py` validates member
paths, duplicate/symlink rejection, manifest bytes/hashes, and recursively scans
ZIP/gzip contents for private paths/session IDs/credentials/network identifiers.
It imports no product source. `python -I verify_package.py ARCHIVE.zip` checks
packaging integrity only; it does not grant correctness, deployment or approval.
