# C51-R1 historical original-association repair

Only `candidate/.../raw4_owned_join_v1.py` changes from rejected C51 v1.
All other candidate files, fixed C50/C48 dependencies, original fixture data and
the author setup file are exact copied bytes and are pinned by the final check.
The original implementation and independent review are untouched.

The bug was an asymmetric gate: `export_entry(current)` checked current custody,
but copied every historical candidate/capture without rechecking its original
references. Replacing a historical preparation with a different object containing
the same bytes passed detached projection, even though a direct historical check
correctly rejected it.

The repair extracts `_check_retention`, containing the existing original
record/phase/sample, candidate/fields bytes, preparation/token/admission and
selected source identity/byte checks. `check_entry` still checks current liveness
and its original hold except for the pre-existing exact committed-duplicate path.
History uses `_check_retention` directly; it is not mislabeled a committed duplicate
and is not required to have the current Root/getter hold.

`export_entry` captures an identity-ordered tuple of the actual entries. Before
assembly and after the fixed projector returns it checks that membership/order
has not changed, checks the selected current hold, and checks every historical
original retention. Both exported arrays use that captured tuple. Thus changing
references, bytes, or collection members during projection cannot return a usable
result. No C50 source/schema/core or production callback API changes.

## Exact bounded evidence

* `runs/run01`: exact reviewer control, original source, exit **1**; reproduces
  unchanged output after historical preparation identity replacement.
* `runs/run02`: byte-identical reviewer control, repaired source, exit **0**;
  positive complete proof projects, replacement now rejects before returning.
* `runs/run03`: NEW adjacent controls only, exit **0**: distinct historical
  Root/getter remains valid history; historical raw phase bytes mutation rejects;
  test-only mutations around the actual pure projector (ref replacement,
  collection member replacement, append, reorder) reject; current hold/veto
  checking remains required.

The reviewer control SHA256 is
`b94983cbd5ad185519b1fad63258c87f54f4f9a29c7273671b8fa887de05438a`.
It AST-reuses setup only; no old author case or suite executes. These are synthetic
Root allocations and pure software controls. No Root/native/model/PDE/core/board
or service operation ran. The test-only projection wrapper restores the original
function and never edits the frozen dependency files.

The initial intake-copy command exited 1 after copying, because its read-only
immutable-scope path had one excess parent. `finish_intake.py` reads the corrected
path and recomputes the same H01–H15 requirements hash without repeating the copy.
The original failed command remains in the native session audit; the script is
preserved unchanged. This was not a product failure or a side-effect retry.

Production preallocation remains disabled. Actual A-owned registry/factory
installation, independent repair acceptance and formal task acceptance remain
separate and incomplete. Physical board operations remain A-only.
