# Separate clarification to the unchanged historical mapping

The final candidate API requires this original idle sequence explicitly:

```python
current, view, hold = functional_source.read_current_with_registry()
projection.attach_registry(
    view, actual_operation._c42, actual_config_generation,
    as_of_qpc_ns=current['at_qpc_ns'], observation_ref=hold)
channels.stage_raw4_invocation(original_trace_event, ...)
composition.accept_observation(original_trace_event)
```

The getter does not automatically attach C42 context. Root must use the actual
operation's retained mapping and generation and a real hold supporting the named
as-of time; it must not rewrite the old hold's diagnostic fields. Numeric TRACE
session and textual C42 session remain distinct. The static A-owned G05 registry
patch remains a proposal requiring A installation and independent review.

Staging happens before the original TRACE event is consumed. Do not obtain a
TraceObservation by consuming the event before stage. Root already holds the
original preparation/request/token/phase and runtime/actor policies, from which
it can select conservative bounds and retain real references. The exact admitted
record is allocated inside accept_observation; the active join then checks those
bounds against that record. The reference to runtime/record in API.md's policy
description is an ultimate admission check, not a requirement to fabricate or
pre-consume a record before stage.

The final candidate retains selected_source_deadline_ns separately and tightens
the effective source bound with the unchanged 100ms raw4 path. Existing actual
DemoAgeBudget supports its scanner/selection scope; it is neither missing nor a
JSON grant that widens all downstream gates. Completion retention must precede
accept_completion, successful offer must precede command construction, and the
original full-duration/slot/finite bounds do not renew. These are source-level
integration instructions, not authorization to acquire a native actor or board.
