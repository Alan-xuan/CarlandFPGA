# C48 public draft — approval pending

This draft is for independent review. It grants no source, ownership or motion
authority and claims no board/native/runtime/full-task acceptance. Main alone
adds the independent conclusion and canonical delivery manifest after approval.

The logical module, API, product patch, source pins and implementation README are
exact frozen copies. Evidence ZIP contains all six executed source versions,
synthetic fixtures, exact raw stdout/stderr and selected original source bytes
with their original read-only GET records. No test or source was executed during
packaging. Earlier passing versions are historical, not final regression runs.
Run05 final factory-order change had only its new targeted boundary control.

execution-index.json is explicitly derived: exit/time/source hashes and trailing
test arguments are preserved; portable argv replaces private machine paths.
Original command-record SHA identifies each sealed private record. Raw logs were
not edited. Native session/tool logs, private IDs, original command files, full
Git tree, recovery messages, environment/configuration and credentials are
excluded. The README's reference to retained native fetch-error evidence refers
to the sealed private audit; that private record is not in this public archive.

verify_delivery.py reads and hashes bytes/ZIP members only, without importing
the validator, A sources or tests. pins.json is a draft file index, not the main
canonical approval manifest. All H01–H15 and both H12 remain unchanged.
