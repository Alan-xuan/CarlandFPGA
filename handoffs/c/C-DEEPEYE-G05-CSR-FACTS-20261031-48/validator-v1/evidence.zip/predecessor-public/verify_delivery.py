from pathlib import Path
import hashlib,json,zipfile
P=Path(__file__).resolve().parent
pins=json.loads((P/'pins.json').read_bytes())
for r in pins:
 b=(P/r['path']).read_bytes();assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256'],r['path']
rows=json.loads((P/'evidence-index.json').read_bytes())['files']
with zipfile.ZipFile(P/'evidence.zip') as z:
 assert len(z.namelist())==len(rows) and set(z.namelist())=={r['path'] for r in rows}
 for r in rows:
  b=z.read(r['path']);assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256'],r['path']
print(json.dumps({'draft_pins':len(pins),'archive_members':len(rows),'source_execution':False,'approval':'PENDING'}))
