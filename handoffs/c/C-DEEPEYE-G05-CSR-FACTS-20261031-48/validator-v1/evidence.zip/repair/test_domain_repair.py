"""NEW domain-only synthetic controls; no old suite or A source execution."""
from pathlib import Path
import copy,hashlib,importlib.util,json,sys
D=Path(__file__).resolve().parent
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m
V=load('repair_candidate',D/'g05_csr_bridge_v1.py');F=load('synthetic_builder',D/'independent_fixture.py')
raw=F.raw;out=D/'inputs';out.mkdir();results=[]
def rewrite(doc,w):
 if doc.get('capture') is not None:doc['capture']['words32']=w.copy()
 if 'captures' in doc:doc['captures'][0]['words32']=w.copy()
 for r in doc['receipts']:
  s=json.loads(bytes.fromhex(r['started_raw_hex']))
  if s['kind']=='read' and 0x300<=s['offset']<0x380:
   t=json.loads(bytes.fromhex(r['returned_raw_hex']));t['value']=w[(s['offset']-0x300)//4];r['returned_raw_hex']=raw(t).hex()
def words(start=20):
 b=F.Ledger();b.phase('init');w=b.phase('apply',F.CMD)['capture']['words32']
 for j in range(3):w[18+2*j:20+2*j]=[start+j%2,0];w[24+2*j:26+2*j]=[start+127+j%2,0]
 return w
def session(w):
 b=F.Ledger();docs=[b.phase('init'),b.phase('apply',F.CMD),b.phase('status'),b.phase('close')]
 for d in docs[1:]:rewrite(d,w)
 return docs
def run(label,w,reject=False):
 docs=session(w);original=raw(docs);(out/(label+'.json')).write_bytes(original);state=None;err=None
 try:
  for i,d in enumerate(docs):
   f=V.validate_session_v2(raw(d),policy_raw=raw(F.POLICY),expected_identity=F.IDENTITY,expected_command=F.CMD if i==1 else None,previous=state,host_qpc_interval=((1<<61)+i*1000,(1<<61)+i*1000+999),host_clock_domain='independent-host-qpc');state=f.next_state
  assert f.state=='CLOSED' and f.captures[-1].words32==tuple(w) and f.authority=='not_evaluated'
 except V.Rejected as e:err=str(e)
 assert original==raw(docs);ok=(err is not None)==reject
 r=dict(case=label,passed=ok,expected='Rejected' if reject else 'CLOSED',error=err,input_sha256=hashlib.sha256(original).hexdigest());results.append(r);print(json.dumps(r));assert ok
run('01-local20-global-above63-close-history',words())
run('02-first-local-witness1',words(1))
w=words(0);run('03-local-start0',w,True)
w=words();w[19]=1;run('04-start-high32',w,True)
w=words();w[25]=1;run('05-end-high32',w,True)
w=words();w[24]=19;run('06-reversed-local',w,True)
w=words();w[10:12]=w[6:8];run('07-global-result-not-after-applied',w,True)
w=words();w[8:10]=w[10:12];run('08-global-deadline-not-after-result',w,True)
w=words();w[12]+=1;run('09-period-disagrees-with-local-span',w,True)
w=words();w[20]+=2;w[26]+=2;run('10-local-join-gap',w,True)
w=words();w[15]=w[12];run('11-high-equals-period',w,True)
run('12-local-end-max-u32',words(0xffffffff-128))
# Shared _capture also covers original transaction v1: use retained synthetic
# original shape, then change both submitted capture and raw read values.
doc=json.loads((D/'v1-original.input.json').read_bytes());policy=(D/'v1-policy.json').read_bytes();cmd=(20,10,1,4,20,1,700)
w=words();w[:6]=[1,cmd[5],cmd[6],cmd[3]*256+cmd[2],cmd[1]*65536+cmd[0],cmd[4]];w[30]=13;rewrite(doc,w)
wire=raw(doc);(out/'13-v1-local.input.json').write_bytes(wire)
f=V.validate_transaction_v1(wire,policy_raw=policy,expected_identity=tuple(range(1,14)),expected_commands=(cmd,),stop_requested=False,host_qpc_interval=(500,900),host_clock_domain='synthetic-host-QPC-domain')
assert f.facts_raw==wire and f.captures[0].cycles.starts==(20,21,20)
results.append(dict(case='13-transaction-shared-domain',passed=True,input_sha256=hashlib.sha256(wire).hexdigest()))
(out/'results.json').write_bytes(raw(results));print(json.dumps({'controls':len(results),'passed':True,'core_calls':0,'A_imports':0}))
