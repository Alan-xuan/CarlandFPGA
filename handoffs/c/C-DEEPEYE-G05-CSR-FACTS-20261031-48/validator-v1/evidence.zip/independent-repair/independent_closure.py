"""Two focused affected controls; CLI MODULE_FILE ORIGINAL_INPUT OUTPUT_DIR."""
import copy,dataclasses,hashlib,importlib.util,json,sys
from pathlib import Path
raw=lambda x:json.dumps(x,sort_keys=True,separators=(',',':')).encode()
def main():
 path=Path(sys.argv[1]);original=Path(sys.argv[2]).read_bytes();out=Path(sys.argv[3]);out.mkdir(parents=True,exist_ok=True)
 assert hashlib.sha256(original).hexdigest()=='00cbe99b27927b3081c8db9f9cd079c725f6ce3b74a36f6020d6fb190b4b5ed2'
 s=importlib.util.spec_from_file_location('closure_candidate',path);v=importlib.util.module_from_spec(s);sys.modules[s.name]=v;s.loader.exec_module(v)
 base=json.loads(original);negative=copy.deepcopy(base);doc=json.loads(negative['apply_raw_utf8']);w=doc['capture']['words32']
 # Raise all witnesses by exactly2^32, preserving local periods and joins.
 for i in (19,21,23,25,27,29):w[i]=1
 for r in doc['receipts']:
  start=json.loads(bytes.fromhex(r['started_raw_hex']))
  if start['kind']=='read' and 0x300<=start['offset']<0x380:
   returned=json.loads(bytes.fromhex(r['returned_raw_hex']));returned['value']=w[(start['offset']-0x300)//4];r['returned_raw_hex']=raw(returned).hex()
 negative['apply_raw_utf8']=raw(doc).decode();results=[]
 for name,payload,wire,reject in [('01-exact-original-RED-replay',base,original,False),('02-all-local-high32-set',negative,raw(negative),True)]:
  (out/(name+'.input.json')).write_bytes(wire);snapshot=raw(payload);error=None;result=None
  try:
   kwargs=dict(policy_raw=payload['policy_raw_utf8'].encode(),expected_identity=tuple(payload['identity']),host_clock_domain='independent-host-qpc')
   init=v.validate_session_v2(payload['init_raw_utf8'].encode(),expected_command=None,previous=None,host_qpc_interval=tuple(payload['host_intervals'][0]),**kwargs)
   f=v.validate_session_v2(payload['apply_raw_utf8'].encode(),expected_command=tuple(payload['command']),previous=init.next_state,host_qpc_interval=tuple(payload['host_intervals'][1]),**kwargs)
   cycles=f.captures[0].cycles;result=dataclasses.asdict(cycles)
   assert cycles.applied_tick==9223372036855775808 and cycles.result_tick==9223372036855776108 and cycles.deadline_tick==9223372036865775808
   assert cycles.starts==(20,21,20) and cycles.ends==(147,148,147)
   assert f.captures[0].words32==tuple(json.loads(payload['apply_raw_utf8'])['capture']['words32'])
   assert f.facts_raw==payload['apply_raw_utf8'].encode() and f.authority=='not_evaluated'
   try:cycles.starts=(0,0,0)
   except dataclasses.FrozenInstanceError:pass
   else:raise AssertionError('mutable cycles')
  except v.Rejected as e:error=str(e)
  assert snapshot==raw(payload)
  passed=(error=='local witness must be zero-extended uint32') if reject else error is None
  record=dict(case=name,passed=passed,expected='Rejected' if reject else 'ACCEPT_APPLY',error=error,retained_cycles=result,input_sha256=hashlib.sha256(wire).hexdigest());results.append(record);print(json.dumps(record),flush=True)
 summary=dict(module_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),controls=results,passed=all(r['passed'] for r in results),old_suites_run=False,A_imports=0,native_calls=0)
 (out/'results.json').write_bytes(raw(summary));return 0 if summary['passed'] else 1
if __name__=='__main__':raise SystemExit(main())
