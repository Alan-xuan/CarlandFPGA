# C48 final independent source review

**Not approved: C48-R1 is open.** Final module SHA256
`814783f3770e1b63706a8e597244dbc30ad0ad0f606747aca6a490979b2f6454`
mixes two different cycle origins in `_capture`. This review does not modify the
candidate. Only this review directory was written.

## Blocking finding C48-R1 — local capture witnesses compared with global cycles

At `g05_csr_bridge_v1.py:236`, `applied<start<end<=result` compares global
application/result ticks with rearm-local capture witnesses. Both use 50 MHz
cycles, but equal units do not imply equal origins.

The actual pinned engine
`dd52028af809-deepeye_g05_capture_engine_50mhz.sv`, SHA256
`fcdb04d1e307506328c205154730e1cf8c5bff2efe72727a46a2f3f4b856ed8a`,
states at lines98–101 that rearm resets the local witness; lines102–110 actually
zero-extend `cap_start_raw`/`cap_end_raw` from32 bits and instantiate the primitive
with WITNESS_W=32. Lines196–197 retain these raw local values in joined payloads;
lines386–387 publish them without adding any global origin. In contrast,
lines385 and407 assign global `edge_tick` to result_tick and global cycle_tick
to applied_tick. Lines242–246/408 derive the global deadline. The wrapper
`dd52028af809-deepeye_g05_axi_50mhz_candidate.sv`, SHA256
`99cdb09399466966458343351d0d941191f34cc9af6f9808c5fb3cc58086ea5a`,
lines224–234 copies those separate fields into words6–29 unchanged.

One NEW source-domain counterexample produced the actual first RED, run02 exit1:
init passes; apply with global applied9223372036855775808,
result9223372036855776108, deadline9223372036865775808 and local
starts[20,21,20], ends[147,148,147], periods[127,127,127] is rejected with
`coherent measured cycle fields`. The raw capture words and matching raw CSR
return records were changed together. Its exact input SHA256 is
`00cbe99b27927b3081c8db9f9cd079c725f6ce3b74a36f6020d6fb190b4b5ed2`.
This is a synthetic isolated consistency control, not an A-issued receipt or a
physical PWM/mapper qualification. It exposes the clock-origin mistake directly.

There is also an over-acceptance aspect of the same finding: the initial NEW
positive fixtures used global-sized start/end values above2^63. They passed,
although the actual source always zero-extends32-bit local witnesses. Those
passing controls therefore establish parser behavior, not valid actual RTL
capture provenance. They remain preserved unchanged; they are not relabeled as
correct source-domain positives or hidden by the subsequent RED.

Minimal repair conditions:

* Keep `applied<result<deadline` in the global64 domain. Engine publication is
  disabled on TTL expiry, application and faults (lines256–292); a capture is
  published only after the application/rearm sequence (lines306–324,428–447).
* Validate start/end in their original zero-extended32-bit local domain:
  `0<start<end`, `end-start==period`, `0<high<period`; upper32 words must be zero.
  Do not add an invented epoch/offset or equate them to global application time.
* Keep the three-channel start/end difference<=1 checks. These compare the same
  local rearm domain, and the original engine explicitly checks all unordered
  pairs (lines168–185,221–223). They are not the cross-domain problem.
* Correct CaptureCycles/README origin descriptions and add a local-witness
  positive plus high-word rejection. Shared `_capture` affects both transaction
  v1 and session v2. Do not broaden this repair into B132 PWM-to-motion decoding.

## Source and evidence audit

Independently rehashed all146 frozen files and the exact author FINAL
`3d21032f597d985413bc786cdb67fd7a80401fe34ec62032ade588d763355015`.
All12 source pins match byte lengths, SHA256 and Git blob SHA1. Source audit and
command/log/version matches are in `input-audit.json`; no network fetch or
source execution was needed. Read the full final validator, resume.diff, actual
A216 session, underlying G05 port/transaction and A218 encoding/limits, plus the
relevant actual layout and engine publication/witness paths.

The six original author command exits are [0,0,0,0,0,0], each independently
matched to retained script/source versions and raw stdout/stderr hashes:
run01 five methods on a76ec2f..., run02 one on89651fa..., run03 six and run04 one
onf69eced..., run05 one on final814783f..., run06 static source checks only.
Earlier versions are not final-version coverage. The author's earlier long-path
fetch failure remains in its immutable evidence; no original failure was edited.

Our `audit` is hash/log verification, not a product test. Our NEW run01 comprises
six focused controls, exit0: two-apply/status/explicit-STOP parser sequence;
cumulative original-byte change; closed-with-unresolved refusal; factory return
one ns after selection; exactly64 status reads followed by null close; and the
same exhausted budget followed by STOP's65th read. They import only the pure
final C48 module and this review's independent fixture, never author tests or
A source. Raw input/output, commands, script/source hashes and exits are retained.
The separate run02 is the single new clock-origin counterexample, exit1. No
passing group was rerun. Every subprocess had a30-second timeout and has exited.

## Other source observations and boundaries

Exact init first5..39, identity re-reads before apply/status, poll-before-latch
status facts, command/result order, complete cumulative receipt bytes, original
factory completion before selected lower, and all hidden status reads counted
excluding factory match the inspected A216 grammar. The byte parser rejects
unknown effect evidence rather than manufacturing completion. Final per-MMIO
return after a deadline remains an observation, not proof of an in-call timeout.
Host QPC, board monotonic ns, global cycle ticks and local witness counts remain
distinct; JSON labels/hashes establish none of their actual provenance.

`close` has no expected_stop argument. Null close and explicit STOP close are
mechanically distinguishable, but original request.stop authorization/correlation
is intentionally external to this API. C49/Root must enforce it. Similarly,
the caller must bind selected request caps and A218 transport's status-count cap;
this detached function checks the documented maximum64 reads,2 commands,
450 encoded receipts and exact retained history, not original request ownership.

Detached state is constructible, not a one-use token. Actual Root/issuer/session/
process/clock/source provenance, selected operation/lifetime, motion transfer,
B132 decoding, board electrical behavior and performance remain outside this
review. No C28/core/model/PDE/native/board/old suite ran. H01–H15 and both H12
remain unchanged and formally unaccepted. A's phase2 demonstration relaxations
are not revoked by this source-consistency finding.

Public excerpt: private task/session footer omitted; exact original remains retained privately. Original full review SHA256: 5b5e7ee4326753f7a131ee1c0f345319c4dd469c146e09811ac1e6ec68b36699
