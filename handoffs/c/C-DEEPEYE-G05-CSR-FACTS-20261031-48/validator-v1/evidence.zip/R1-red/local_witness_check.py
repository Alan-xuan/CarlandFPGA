"""One new source-domain counterexample; only own fixture + pure C48 import.
CLI: MODULE_FILE OUTPUT_DIRECTORY. Exit1 means the positive control is rejected.
"""
import hashlib,importlib.util,json,sys
from pathlib import Path
D=Path(__file__).resolve().parent
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m
def main():
 f=load('independent_fixture',D/'independent_checks.py');v=load('local_witness_candidate',Path(sys.argv[1]));out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
 b=f.Ledger();initial=b.phase('init');apply=b.phase('apply',f.CMD,1)
 w=apply['capture']['words32']
 # Exact engine cap_start/end are ZERO EXTENDED rearm-local32 witnesses.
 # Keep global applied/result/deadline untouched; do not invent an epoch sum.
 for j in range(3):
  w[18+2*j:20+2*j]=[20+(j%2),0];w[24+2*j:26+2*j]=[147+(j%2),0]
 for receipt in apply['receipts']:
  s=json.loads(bytes.fromhex(receipt['started_raw_hex']))
  if s['kind']=='read' and 0x300<=s['offset']<0x380:
   r=json.loads(bytes.fromhex(receipt['returned_raw_hex']));r['value']=w[(s['offset']-0x300)//4];receipt['returned_raw_hex']=f.raw(r).hex()
 payload=dict(policy_raw_utf8=f.raw(f.POLICY).decode(),identity=f.IDENTITY,init_raw_utf8=f.raw(initial).decode(),apply_raw_utf8=f.raw(apply).decode(),command=f.CMD,host_intervals=[[(1<<61),(1<<61)+999],[(1<<61)+1000,(1<<61)+1999]])
 original=f.raw(payload);(out/'original.input.json').write_bytes(original)
 common=dict(policy_raw=f.raw(f.POLICY),expected_identity=f.IDENTITY,host_clock_domain='independent-host-qpc')
 first=v.validate_session_v2(f.raw(initial),expected_command=None,previous=None,host_qpc_interval=tuple(payload['host_intervals'][0]),**common)
 error=None;accepted=False
 try:
  result=v.validate_session_v2(f.raw(apply),expected_command=f.CMD,previous=first.next_state,host_qpc_interval=tuple(payload['host_intervals'][1]),**common)
  accepted=result.kind=='apply'
 except v.Rejected as exc:error=str(exc)
 assert original==f.raw(payload)
 observed=dict(case='rearm-local-witness-is-not-global-cycle',expected='ACCEPT_APPLY',accepted=accepted,error=error,source_sha256=hashlib.sha256(Path(sys.argv[1]).read_bytes()).hexdigest(),input_sha256=hashlib.sha256(original).hexdigest(),global_applied=w[6]|w[7]<<32,global_result=w[10]|w[11]<<32,global_deadline=w[8]|w[9]<<32,local_starts=[w[i] for i in (18,20,22)],local_ends=[w[i] for i in (24,26,28)],periods=w[12:15],A_imports=0,native_calls=0)
 (out/'observed.json').write_bytes(f.raw(observed));print(json.dumps(observed),flush=True)
 return 0 if accepted else 1
if __name__=='__main__':raise SystemExit(main())
