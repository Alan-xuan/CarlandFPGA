"""New independent synthetic controls. CLI: MODULE_FILE OUTPUT_DIRECTORY.
Only imports the supplied pure C48 validator; no author tests or A source.
"""
import copy,hashlib,importlib.util,json,sys
from pathlib import Path
raw=lambda x:json.dumps(x,sort_keys=True,separators=(',',':')).encode()
IDENTITY=tuple(range(101,114)); CMD=(7,65529,1,3,200,41,920)
BIND=dict(operation_id='independent-c48',request_sha256='ab'*32,boot_id='2397c113-6820-424b-a551-909efcbb33d2',source_commit='0469345fd1eef2884de1417f0f4eb5b67688f84c',build_id='34'*16)
POLICY=dict(binding=BIND,limits=dict(begin=1,commit=2,stop=1,latch=2,release=2,total_io=450))
POLICY['policy_sha256']=hashlib.sha256(raw(POLICY)).hexdigest()
LOW=(1<<55)+500; DEADLINE=LOW+20000000
class Ledger:
 def __init__(self):self.rows=[];self.group_index=0;self.clock=LOW-100
 def group(self,ops,name=None):
  self.group_index+=1;rid=name or 'independent-'+str(self.group_index)
  for kind,offset,value in ops:
   index=len(self.rows)+1;self.clock+=2
   s=dict(request_id=rid,io=index,kind=kind,offset=offset,value=None if kind=='read' else value,pid=193,monotonic_ns=self.clock)
   t=dict(request_id=rid,io=index,kind=kind,value=value if kind=='read' else None,monotonic_ns=self.clock+1)
   self.rows.append(dict(index=index,started_raw_hex=raw(s).hex(),returned_raw_hex=raw(t).hex()))
 def read(self,o,v):self.group([('read',o,v)])
 def identity(self):
  for i,v in enumerate(IDENTITY):self.read(0x100+4*i,v)
 def phase(self,kind,cmd=None,result=1,extra_polls=0,stop=False):
  before=len(self.rows);cap=None;status=1;fault=0
  if kind=='init':
   self.group([('read',0,0x47303550)],'factory-magic');self.group([('read',4,2)],'factory-layout');self.group([('read',8,0),('read',16,0)],'factory-status');before=4;self.clock=LOW
   self.group([('read',8,0),('read',16,0)]+[('write',0x100+4*i,v) for i,v in enumerate(IDENTITY)])
   self.group([('read',8,0),('read',16,0),('write',12,1),('read',8,1),('read',16,0)])
   self.identity();self.read(8,1);self.read(16,0)
  elif kind=='apply':
   self.identity()
   self.group([('read',8,1),('read',16,0)]+[('write',0x200+4*i,v) for i,v in enumerate(cmd)])
   self.group([('read',8,1),('read',16,0),('write',12,2),('read',20,cmd[5]),('read',8,1),('read',16,0)])
   for _ in range(extra_polls):self.read(8,1);self.read(16,0)
   self.read(8,17);self.read(16,0)
   self.group([('read',8,17),('read',16,0),('write',12,4),('read',8,49),('read',16,0)])
   w=[0]*32;w[:6]=[result,cmd[5],cmd[6],cmd[3]*256+cmd[2],cmd[1]*65536+cmd[0],cmd[4]]
   a=(1<<63)+result*1000000
   def u64(i,v):w[i:i+2]=[v&0xffffffff,v>>32]
   u64(6,a);u64(8,a+cmd[4]*50000);u64(10,a+300)
   for j in range(3):
    w[12+j]=127;w[15+j]=60+j;u64(18+j*2,a+20+(j%2));u64(24+j*2,a+147+(j%2))
   w[30:]=[IDENTITY[12],0x47303550]
   self.group([('read',8,49),('read',16,0),('read',28,result)]+[('read',0x300+4*i,v) for i,v in enumerate(w)]+[('read',28,result),('read',8,49),('read',16,0)])
   self.group([('read',8,49),('read',16,0),('write',12,5),('read',8,17),('read',16,0)])
   cap=dict(status_before_latch=17,fault_before_latch=0,words32=w,status_before_snapshot=49,status_after_snapshot=49,result_seq=result,tick_unit='50MHz_cycles');status=17
  elif kind=='status':self.identity();self.read(8,1);self.read(16,0)
  else:
   status=fault=None
   if stop:self.group([('write',12,3)]);self.read(8,3);self.read(16,0);status=3;fault=0
  return dict(schema='g05_csr_session_v2',kind=kind,operation_id=BIND['operation_id'],policy_sha256=POLICY['policy_sha256'],identity_words=list(IDENTITY),capture=cap,deadline_selected_lower_board_monotonic_ns=LOW,deadline_board_monotonic_ns=DEADLINE,phase_io_first=before+1 if len(self.rows)>before else None,phase_io_last=len(self.rows) if len(self.rows)>before else None,status=status,fault=fault,receipts=copy.deepcopy(self.rows),unresolved_receipts=[],state='CLOSED' if kind=='close' else 'ACTIVE',authority='not_evaluated')
def main():
 module=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();out.mkdir(parents=True,exist_ok=True)
 spec=importlib.util.spec_from_file_location('independent_c48_candidate',module);v=importlib.util.module_from_spec(spec);sys.modules[spec.name]=v;spec.loader.exec_module(v)
 results=[]
 def execute(label,docs,commands,reject=False,fragment=None):
  inputs=dict(policy_raw_utf8=raw(POLICY).decode(),identity=IDENTITY,phases=[dict(raw_utf8=raw(d).decode(),command=c,host_interval=((1<<61)+i*1000,(1<<61)+i*1000+999)) for i,(d,c) in enumerate(zip(docs,commands))])
  wire=raw(inputs);(out/(label+'.input.json')).write_bytes(wire);previous=None;accepted=[];err=None
  try:
   for item in inputs['phases']:
    f=v.validate_session_v2(item['raw_utf8'].encode(),policy_raw=raw(POLICY),expected_identity=IDENTITY,expected_command=item['command'],previous=previous,host_qpc_interval=item['host_interval'],host_clock_domain='independent-host-qpc')
    assert f.facts_raw==item['raw_utf8'].encode() and f.authority=='not_evaluated'
    previous=f.next_state;accepted.append(dict(kind=f.kind,state=f.state,receipts=len(f.receipts),commands=len(f.accepted_commands),status=f.status))
   if not reject:
    assert f.state=='CLOSED' and f.captures[-1].cycles.applied_tick>1<<63
  except v.Rejected as e:err=str(e)
  assert raw(inputs)==wire
  passed=(err is not None and (fragment is None or fragment in err)) if reject else err is None
  result=dict(label=label,passed=passed,expected='Rejected' if reject else 'CLOSED',error=err,accepted=accepted,input_sha256=hashlib.sha256(wire).hexdigest())
  results.append(result);print(json.dumps(result),flush=True)
 b=Ledger();d0=b.phase('init');d1=b.phase('apply',CMD,1);d2=b.phase('status');cmd2=(0,0,1,3,200,43,922);d3=b.phase('apply',cmd2,2);d4=b.phase('close',stop=True)
 docs=[d0,d1,d2,d3,d4];commands=[None,CMD,None,cmd2,None]
 execute('01-complete-two-apply-status-stop',docs,commands)
 bad=copy.deepcopy(docs);bad[2]['receipts'][0]['returned_raw_hex']+='20';execute('02-cumulative-original-byte-change',bad,commands,True,'prefix')
 bad=copy.deepcopy(docs);bad[4]['unresolved_receipts']=[dict(index=451,started_raw_hex=None,returned_raw_hex=None,not_attempted_raw_hex=None)];execute('03-closed-with-unresolved',bad,commands,True,'unresolved')
 bad=copy.deepcopy(docs);r=bad[0]['receipts'][3];x=json.loads(bytes.fromhex(r['returned_raw_hex']));x['monotonic_ns']=LOW+1;r['returned_raw_hex']=raw(x).hex();execute('04-factory-return-late',bad,commands,True,'factory')
 b=Ledger();i=b.phase('init');a=b.phase('apply',CMD,1,extra_polls=50);close=b.phase('close');execute('05-exact64-null-close',[i,a,close],[None,CMD,None])
 b=Ledger();i=b.phase('init');a=b.phase('apply',CMD,1,extra_polls=50);close=b.phase('close',stop=True);execute('06-exact64-followed-stop65',[i,a,close],[None,CMD,None],True,'status-read budget')
 summary=dict(source_sha256=hashlib.sha256(module.read_bytes()).hexdigest(),controls=results,passed=all(r['passed'] for r in results),A_imports=0,native_calls=0,core_calls=0)
 (out/'results.json').write_bytes(raw(summary));print(json.dumps(dict(passed=summary['passed'],controls=len(results))))
 return 0 if summary['passed'] else 1
if __name__=='__main__':raise SystemExit(main())
