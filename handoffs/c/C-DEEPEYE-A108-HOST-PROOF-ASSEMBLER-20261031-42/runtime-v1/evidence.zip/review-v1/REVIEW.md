# C42 independent review v1

**Source approval withheld: C42-R1 is open (P2).** The adapter can produce a non-null `proof` and `ASSEMBLED_UNVALIDATED` with no missing paths despite explicitly missing required original binding IDs or raw capture/request bytes. Main was informed with exact retained evidence. No source repair was made in this scope.

Reviewed FINAL: `42557d0a2e1d6d2acb20bc5e8053021b64fa69dd29dec22d16f5c16c14450e2c`. Runtime: `1190bae774ce5caa6e84342a539f065c983385fc1aae4bc07110bd20d856def4`. Schema remains the exact frozen C36 v2 `ab1b432e9f337523fd75057fec4647f5eda2569de308e7c777507e05907bdd70`. All 12 declared artifacts plus four retained A source files were pinned. No C36/C28 or original A module was imported or executed.

## C42-R1: required nullable originals are not counted as missing

`proof_assembler.py:47` returns null immediately for a nullable schema alternative, without recording a missing path. The explicit completeness scan at lines 142–156 covers top-level attachment groups, selected receipt-name suffixes and a few original fields, but omits required original `config.pose_book_id`, `config.owner_binding_id`, and capture `request_raw`/`capture_raw`. Consequently line 158 treats these incomplete assemblies as complete. The live producer can naturally create the missing-ID form: `_id` at line 177 returns None for an unbound original reference, and export line 244 puts those values into config. The pure diagnostic path has the same completeness defect.

A NEW independently constructed schema-complete synthetic fixture was used, with fresh identifiers, one source sample/admission/capture, explicit current read, no transitions and no history. It was constructed only from the frozen schema, not an old sample70/96, C36 fixture or author test function. Its illustrative raw JSON is explicitly synthetic; it is **not** a claim of downstream C36 semantic validation or native wire authenticity. Its purpose is to exercise the assembler's own availability contract under populated and selectively absent original fields.

One bounded process ran five NEW cases, exit **1**:

| Case | Expected | Actual |
|---|---|---|
| New fully populated assembly | ASSEMBLED_UNVALIDATED | Same; proof present, missing_paths empty |
| Only config.pose_book_id=null | INPUT_UNAVAILABLE/proof=None | ASSEMBLED_UNVALIDATED; proof present, missing_paths empty |
| Only config.owner_binding_id=null | INPUT_UNAVAILABLE/proof=None | Same incorrect completion |
| Only captures[0].request_raw=null | INPUT_UNAVAILABLE/proof=None | Same incorrect completion |
| Only captures[0].capture_raw=null | INPUT_UNAVAILABLE/proof=None | Same incorrect completion |

The complete case establishes that this is a usable mechanical assembler rather than an always-unavailable stub. Four one-field changes demonstrate incorrect completeness reporting. All output authority flags remain false. This is **not** a demonstrated downstream C36 acceptance or authentication bypass; C36 remains mandatory. It still violates C42's documented promise that missing original fields/bindings leave proof=None and useful missing paths.

Minimum repair: make completeness requirements explicit for required original bindings and selected capture request/raw data, retaining null in the partial result and recording precise paths. Do not synthesize an ID, wire document, clock, config or receipt. Preserve legitimately absent optional values, such as BOOT command receipt fields, no cause action, unavailable EM under fault semantics, and source-start prior-ADC absence. A generic ban on every nullable field would be incorrect. Adjacent nullable ADC/source-association fields belong to the same static completeness boundary; they were not executed as extra RED cases here.

Raw fixture/input/output bytes, per-case SHA-256, actual stdout/stderr/command/exit and the portable `independent_missing_checks.py` are retained in this directory. Positive input SHA is `4ec1891a6c9ec922218b9c9821c4ee1710460920a048be69805511fde7a3e2d2`. The four original RED inputs are retained unchanged in `new-evidence`; their exact hashes are in results.json. No rerun or additional test expansion followed the RED.

## Other source findings and limits

The production factory checks four exact already-loaded A108 modules, exact owner/link/book types, production-owner flag, thread and retained relationships. It does not import/start A. `_registered` and custody `_context` are invoked through the original modules. These are trusted-process reference conventions, not an OS security boundary or authentication by file hash. A must still install the actual callsite attachment hooks and supply genuine opaque references; this adapter adds none to A's source.

Identity binding rejects reference rebinding and label collision. Config/registry/admission/capture/transition references are retained with finite limits. Registry selection, candidate and full history are explicit references; there is no latest-index or hash-derived identity. Capture samples must be original objects in book._samples, and transition/slot attachment checks the original retained custody/owner relationships. Successor Roots are retained at the genuine completion point rather than replaced by a later current Root.

The original `RootSourceBook.current_pose_interval` at lines 318–335 returns actual numerical pose/read/span data. C42 calls that getter once and then evidence, retaining both returned objects/bytes and the original current span pointer. This is ordered and non-atomic, with no time sampling, max/offset/remainder conversion or renewed registry timestamp. Export checks original read/evidence bytes and span identity before using them. Interval-only evidence is not promoted into a current read. Exceptions during read/export latch the producer; no retry or original-resource reset is implemented.

Mechanical capture mapping keeps ADC bracket/read/span and held original EM pose/read/call/scope fields separate. It hashes supplied original UTF-8 capture bytes rather than substituting the canonical book source hash. OriginalEM origin-capture linkage, wire-source hash, receipt IDs and native admission remain external facts. STEP mapping uses retained witness/candidate/returned receipt/command/publication data and invokes A108's exact admitted readback checker before publication export. The retained original source fields and APIs match the mappings under review. No real producer call was exercised.

The schema projector uses explicit union constants/enums, finite shapes and limits; it retains the full source prefix/history and discards non-schema private fields without copying their values into the proof. Dropped paths are diagnostic names, not a public authentication claim. Source evidence has a separate 16 MiB input bound and projected proof a 1 MiB bound; it does not silently trim to fit. Snapshot hash is over detached original evidence before projection. Whole original integer QPC values remain integers.

Getter bounds are converted from Fraction only if integral or exactly representable as a float by round-trip equality. Otherwise None is retained and nonnullable numeric projection marks the value missing. No rounded smaller bound is manufactured. Nonrepresentable real bounds and immutable per-read registry timestamp association remain genuine integration dependencies, not permission to alter frozen C36. This review did not execute those old author controls again.

Author evidence was read by version: six runs exited `[1,0,0,0,0,0]`; run01's original nested-merge failure is retained, followed by targeted repair/new controls. The author's final runtime was exercised only by run06's source-private-budget test. Twenty distinct author controls across source versions are not a final full-suite pass. This review's five cases are the only new adapter execution. There were no old fixtures/groups, C36/core/A runtime, model/PDE/native/board runs or public writes.

H01–H15, original 29 requirements, both H12 obligations, fixed design and 100 MHz/timing/1%/100 ms requirements remain unchanged and unaccepted. Board authority remains A alone. Main owns repair and publication. Current review is frozen and released with empty jobs/subprocesses.
