"""NEW assembly/required-null controls; only new adapter is imported.
Usage: python -I -S -B independent_missing_checks.py ADAPTER_DIR FIXTURE_JSON OUTPUT_DIR
"""
import copy,hashlib,importlib.util,json,pathlib,sys
S,F,O=map(pathlib.Path,sys.argv[1:]);O.mkdir(exist_ok=False)
assert hashlib.sha256((S/'proof_assembler.py').read_bytes()).hexdigest()=='1190bae774ce5caa6e84342a539f065c983385fc1aae4bc07110bd20d856def4'
spec=importlib.util.spec_from_file_location('new_c42_only',S/'proof_assembler.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
base=json.loads(F.read_bytes());cases=[]
cases.append(('new-schema-complete-assembly',copy.deepcopy(base),'ASSEMBLED_UNVALIDATED'))
for name,group,key in [('missing-original-book-binding','config','pose_book_id'),('missing-original-owner-binding','config','owner_binding_id'),('missing-original-request-wire','capture','request_raw'),('missing-original-capture-wire','capture','capture_raw')]:
 x=copy.deepcopy(base);target=x['attachments'][group]if group=='config'else x['attachments']['captures'][0];target[key]=None;cases.append((name,x,'INPUT_UNAVAILABLE'))
rows=[]
for name,x,expected in cases:
 raw=json.dumps(x,sort_keys=True,separators=(',',':')).encode();(O/(name+'.input.json')).write_bytes(raw)
 try:
  result=m.assemble_snapshot(x['evidence'],x['current'],x['attachments'],candidate=x['candidate'],history=x['history'],enabled=x['enabled']);observed=result['status'];assert result['source_authenticated']is False and result['dispatch_authorized']is False and result['core_ran']is False
 except Exception as exc:result=dict(exception=type(exc).__name__,reason=str(exc));observed=type(exc).__name__
 output=json.dumps(result,sort_keys=True,separators=(',',':')).encode();(O/(name+'.output.json')).write_bytes(output)
 row=dict(case=name,expected=expected,observed=observed,passed=observed==expected,proof_present=result.get('proof')is not None,missing_paths=result.get('missing_paths'),input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(output).hexdigest());rows.append(row);print(json.dumps(row),flush=True)
(O/'results.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf8')
assert not any(n.startswith('competition.')or n.startswith('_c37')or 'frozen_c28'in n for n in sys.modules)
raise SystemExit(0 if all(x['passed']for x in rows)else 1)
