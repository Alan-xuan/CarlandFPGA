"""Only C42 assembler. CLI: ADAPTER_DIR ORIGINAL_FIVE_BUNDLE OUTPUT_DIR."""
import copy,hashlib,importlib.util,json,pathlib,sys
S,B,O=map(pathlib.Path,sys.argv[1:]);O.mkdir(exist_ok=False)
H='b49169ac2ab87073e31406d8448d69c7958d5e5775310f94990fe89eee8d3722'
assert hashlib.sha256((S/'proof_assembler.py').read_bytes()).hexdigest()==H
spec=importlib.util.spec_from_file_location('c42_repair_only',S/'proof_assembler.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
enc=lambda x:json.dumps(x,sort_keys=True,separators=(',',':')).encode()
rows=[];cases=[]
paths={'missing-original-book-binding':'request.root_receipt.config.pose_book_id','missing-original-owner-binding':'request.root_receipt.config.owner_binding_id','missing-original-request-wire':'request.root_receipt.captures[0].request_raw','missing-original-capture-wire':'request.root_receipt.captures[0].capture_raw'}
for r in json.loads(B.read_bytes()):
 raw=r['utf8'].encode();assert len(raw)==r['bytes'] and hashlib.sha256(raw).hexdigest()==r['sha256'];x=json.loads(raw)
 cases.append((r['name'],raw,'INPUT_UNAVAILABLE'if r['name']in paths else 'ASSEMBLED_UNVALIDATED',{paths[r['name']]}if r['name']in paths else set(),'exact-replay'))
 if r['name']=='new-schema-complete-assembly':base=x

def add(name,x,expected,paths):cases.append((name,enc(x),expected,set(paths),'new-adjacent'))
x=copy.deepcopy(base);r=x['attachments']['captures'][0];r['adc_call']=None;r['adc_root_revision']=None;r['adc_pose']['pose_read']=None
add('adc-independent-null-paths',x,'INPUT_UNAVAILABLE',['request.root_receipt.captures[0].adc_call','request.root_receipt.captures[0].adc_root_revision','request.root_receipt.captures[0].adc_pose.pose_read'])
x=copy.deepcopy(base);x['attachments']['source_admissions']=[];x['attachments']['captures']=[]
add('empty-prefix-and-selected-capture',x,'INPUT_UNAVAILABLE',['request.root_receipt.source_admissions','request.candidate.observation_identity.capture_sha256'])
x=copy.deepcopy(base);x['evidence']['samples'][0]['held_em_association']['original_em']['call']=None
add('missing-original-em-nested-call',x,'INPUT_UNAVAILABLE',['request.actor_book.samples[0].held_em_association.original_em.call'])
x=copy.deepcopy(base);x['history']=[copy.deepcopy(x['candidate'])];x['candidate']['source_time']['em_tick_ms']=None;x['attachments']['captures'][0]['original_em_call']=None
add('history-em-needs-original-despite-candidate-null',x,'INPUT_UNAVAILABLE',['request.root_receipt.captures[0].original_em_call'])
x=copy.deepcopy(base);c=x['candidate'];c['source_time'].update(em_tick_ms=None,em_source_age_ns=None);c.update(quality=0,channel_counts=[None]*4);x['attachments']['source_admissions'][0].update(em_tick_ms=None,new_em_sample=False,quality=0,channel_counts=[None]*4)
r=x['attachments']['captures'][0]
for key in ('em_pose','em_root_revision','em_book_source_sha256','em_origin_capture_sha256','original_em_call','original_em_scope_closed_qpc_ns'):r[key]=None
sample=x['evidence']['samples'][0];sample['held_em_association']=None;sample['pose_reads']['em']=None
wire=json.loads(r['capture_raw']);wire.update(quality=0,channel_counts=[None]*4);r['capture_raw']=enc(wire).decode();r['capture_sha256']=hashlib.sha256(r['capture_raw'].encode()).hexdigest();c['observation_identity']['capture_sha256']=r['capture_sha256']
add('no-em-null-preserved',x,'ASSEMBLED_UNVALIDATED',[])
for name,raw,expected,required,group in cases:
 (O/(name+'.input.json')).write_bytes(raw);x=json.loads(raw);before=copy.deepcopy(x)
 try:
  result=m.assemble_snapshot(**x);status=result['status'];missing=set(result['missing_paths']);passed=status==expected and required<=missing
  passed &= x==before and all(result[k]is False for k in ('core_ran','source_authenticated','dispatch_authorized'))
  passed &= (result['proof']is None)if expected=='INPUT_UNAVAILABLE'else(result['proof']is not None and not missing)
  passed &= result['partial']['actor_book']['source_origin_qpc_ns']==base['evidence']['source_origin_qpc_ns']
 except Exception as exc:result=dict(exception=type(exc).__name__,reason=str(exc));status=type(exc).__name__;missing=set();passed=False
 output=enc(result);(O/(name+'.output.json')).write_bytes(output)
 row=dict(case=name,group=group,expected=expected,observed=status,passed=bool(passed),missing_paths=sorted(missing),input_sha256=hashlib.sha256(raw).hexdigest(),output_sha256=hashlib.sha256(output).hexdigest(),source_sha256=H);rows.append(row);print(json.dumps(row),flush=True)
(O/'results.json').write_text(json.dumps(rows,indent=2),encoding='utf8')
assert not any(n.startswith('competition.')or n.startswith('_c37')or 'frozen_c28'in n or n=='host_projection'for n in sys.modules)
raise SystemExit(0 if all(r['passed']for r in rows)else 1)
