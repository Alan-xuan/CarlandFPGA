"""NEW C41 handcrafted pair controls. No C40 import or core/native execution."""
import copy,dataclasses,hashlib,importlib.util,json,sys,unittest
from pathlib import Path
from unittest.mock import patch
D=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('c41_verifier',D/'c40_pair_verifier_v1.py')
v=importlib.util.module_from_spec(spec);sys.modules[spec.name]=v;spec.loader.exec_module(v)
BASE=(1<<62)+123456789

def pose():return dict(position_m=[0,0,0],orientation_xyzw=[0,0,0,1])
def public(enabled=True):
    o=dict(sample_id='a'*64,counts=[1740,2048,2048,0],quality=15,adc_qpc_ns=BASE,em_qpc_ns=BASE,adc_pose=pose(),em_pose=pose())
    return dict(schema_version=1,projection_id='c36_c28_public_view_v1',enabled=enabled,now_qpc_ns=BASE,pose=pose(),goal_m=[0,0,10],observation=o,history=[],executed_actions=[])
def ids():return dict(operation_id='C41-synthetic',run_id='not-original-provider',actor_instance_id='not-owned-process',invocation_id=(1<<63)-1,tested_commit='a'*40,package_manifest_sha256=v.PACKAGE_MANIFEST_SHA256)
def request(p=None,enabled=True):return dict(abi=v.ABI,kind='recommend',echo_ids=ids(),enabled=enabled,input=public(enabled) if p is None else p)
def request_wire(r):return v.fixed_request(v._dump(r))
def advice(p):
    return dict(schema_version=1,planner_id='candidate_four_channel_planner_v1',candidate_only=True,authorization='none',status='ADVISE',reason='bounded_observation_goal_search',risk=0.1,uncertainty=0.5,direction_world=[0,0,1],speed_limit_m_s=0.1,observation=copy.deepcopy(p['observation']),map_cells=[dict(sample_id=p['observation']['sample_id'],em_qpc_ns=p['observation']['em_qpc_ns'],pose=pose(),risk=0.1)],independent_em_count=1)
def pair(r,status='RESULT',core=True,reason=None,result='AUTO'):
    w=request_wire(r);a=dict(abi=v.ABI,kind='READY',echo_ids=ids(),request_wire_sha256=hashlib.sha256(w).hexdigest(),core_sha256=v.CORE_SHA256,authority='none')
    result=advice(r['input']) if result=='AUTO' else result
    reason=result['reason'] if reason is None else reason
    b=dict(abi=v.ABI,kind='RESULT',echo_ids=ids(),request_wire_sha256=a['request_wire_sha256'],status=status,core_ran=core,authority='none',completion_grant=False,result=result,reason=reason)
    return a,b
def output(a,b):return v.frame(v._dump(a),2048)+v.frame(v._dump(b))
def check(r,a,b):return v.verify_pair(request_wire(r),output(a,b),expected_ids=ids())
class Controls(unittest.TestCase):
    def test01_valid_advice_exact_high_time_immutable_and_pure(self):
        r=request();a,b=pair(r)
        with patch('builtins.open',side_effect=AssertionError('I/O forbidden')):
            parsed=check(r,a,b)
        self.assertEqual(parsed.result['result']['observation']['adc_qpc_ns'],BASE)
        with self.assertRaises(TypeError):parsed.result['result']['observation']['counts'][0]=1
        with self.assertRaises(TypeError):parsed.ready['kind']='RESULT'
        with self.assertRaises(dataclasses.FrozenInstanceError):parsed.request_wire_sha256='x'
        b['result']['risk']=0.2;self.assertEqual(parsed.result['result']['risk'],0.1)
        self.assertFalse(any(n.startswith('_c37') for n in sys.modules))
        (D/'synthetic-request.bin').write_bytes(request_wire(r));(D/'synthetic-pair.bin').write_bytes(output(a,pair(r)[1]))
    def test02_exact_two_frames_size_and_order(self):
        r=request();a,b=pair(r);good=output(a,b);w=request_wire(r)
        for raw in (good[:-1],good+b' ',good+good,v.frame(v._dump(a)),output(b,a),b'\0'*10,(2049).to_bytes(4,'little')+b' '*2049+v.frame(v._dump(b)),b'x'*18441):
            with self.subTest(length=len(raw)):
                with self.assertRaises(ValueError):v.verify_pair(w,raw,expected_ids=ids())
    def test03_schema_exact_duplicate_nonfinite_and_types(self):
        r=request();a,b=pair(r)
        for field in a:
            x=copy.deepcopy(a);del x[field]
            with self.subTest(missing=field):
                with self.assertRaises(ValueError):check(r,x,b)
        for field in b:
            x=copy.deepcopy(b);del x[field]
            with self.subTest(missing=field):
                with self.assertRaises(ValueError):check(r,a,x)
        for key,val in [('unknown',0),('core_ran',1),('completion_grant',0)]:
            x=copy.deepcopy(b);x[key]=val
            with self.assertRaises(ValueError):check(r,a,x)
        raw=v._dump(b)
        for bad in (b'{"kind":"RESULT",'+raw[1:],raw.replace(b'"risk":0.1',b'"risk":NaN')):
            with self.assertRaises(ValueError):v.verify_pair(request_wire(r),v.frame(v._dump(a))+v.frame(bad),expected_ids=ids())
    def test04_correlation_pins_and_padding_hash(self):
        r=request();a,b=pair(r)
        for target,field,val in [('ready','core_sha256','0'*64),('ready','request_wire_sha256','0'*64),('result','request_wire_sha256','0'*64),('result','authority','move'),('result','completion_grant',True)]:
            aa,bb=copy.deepcopy((a,b));(aa if target=='ready' else bb)[field]=val
            with self.assertRaises(ValueError):check(r,aa,bb)
        for key in ids():
            aa=copy.deepcopy(a);aa['echo_ids'][key]=('b'*40 if key=='tested_commit' else '0'*64 if key=='package_manifest_sha256' else 1 if key=='invocation_id' else 'changed')
            with self.subTest(key=key):
                with self.assertRaises(ValueError):check(r,aa,b)
        wrong=ids();wrong['package_manifest_sha256']='0'*64
        with self.assertRaises(ValueError):v.verify_pair(request_wire(r),output(a,b),expected_ids=wrong)
        changed=request_wire(r)[:-1]+b'\n'
        with self.assertRaises(ValueError):v.verify_pair(changed,output(a,b),expected_ids=ids())
        digest=hashlib.sha256(changed).hexdigest();a['request_wire_sha256']=digest;b['request_wire_sha256']=digest
        v.verify_pair(changed,output(a,b),expected_ids=ids())
    def test05_disabled_and_known_invalid_request(self):
        r=request(enabled=False);del r['enabled'];a,b=pair(r,'DISABLED',False,'disabled',None);check(r,a,b)
        for change in [('core_ran',True),('reason','INTERNAL_ERROR'),('status','RESULT'),('result',{})]:
            x=copy.deepcopy(b);x[change[0]]=change[1]
            with self.assertRaises(ValueError):check(r,a,x)
        r['input']['truth']=0;a,b=pair(r,'REJECTED',False,'INVALID_SHAPE',None);check(r,a,b)
        for code in ('disabled','OUTPUT_TOO_LARGE','INTERNAL_ERROR'):
            x=copy.deepcopy(b);x['reason']=code
            with self.assertRaises(ValueError):check(r,a,x)
    def test06_rejected_semantics_including_postcore_oversize(self):
        r=request()
        for core in (False,True):
            a,b=pair(r,'REJECTED',core,'INTERNAL_ERROR',None);check(r,a,b)
        a,b=pair(r,'REJECTED',True,'OUTPUT_TOO_LARGE',None);check(r,a,b)
        b['core_ran']=False
        with self.assertRaises(ValueError):check(r,a,b)
        b['core_ran']=True;b['result']={}
        with self.assertRaises(ValueError):check(r,a,b)
        b['result']=None;b['reason']='made_up'
        with self.assertRaises(ValueError):check(r,a,b)
        a,b=pair(r);b['core_ran']=False
        with self.assertRaises(ValueError):check(r,a,b)
        b['core_ran']=True;b['status']='INPUT_UNAVAILABLE'
        with self.assertRaises(ValueError):check(r,a,b)
    def test07_stop_quality_and_exact_100ms_boundary(self):
        r=request();r['input']['now_qpc_ns']+=100_000_000;a,b=pair(r);check(r,a,b)
        r['input']['now_qpc_ns']+=1;a,b=pair(r)
        with self.assertRaises(ValueError):check(r,a,b)
        x=b['result'];x.update(status='STOP',reason='original_sample_expired',risk=1,uncertainty=1,direction_world=[0,0,0],speed_limit_m_s=0,map_cells=[],independent_em_count=0);b['reason']=x['reason'];check(r,a,b)
        x['speed_limit_m_s']=0.01
        with self.assertRaises(ValueError):check(r,a,b)
        r=request();r['input']['observation'].update(quality=4104,counts=[None,None,None,0],em_qpc_ns=None,em_pose=None)
        a,b=pair(r);x=b['result'];x.update(status='STOP',reason='invalid_faulted_or_saturated',risk=1,uncertainty=1,direction_world=[0,0,0],speed_limit_m_s=0,map_cells=[],independent_em_count=0);b['reason']=x['reason'];check(r,a,b)
    def test08_nested_output_bounds_unknown_fields_and_map_provenance(self):
        r=request();a,b=pair(r)
        mutations=[lambda x:x.update(risk=-0.1),lambda x:x.update(uncertainty=1.1),lambda x:x.update(speed_limit_m_s=0.2),lambda x:x.update(direction_world=[0,0,0.9]),lambda x:x.update(candidate_only=1),lambda x:x.update(schema_version=True),lambda x:x.update(completed_monotonic_ns=BASE),lambda x:x.update(independent_em_count=0),lambda x:x['map_cells'][0].update(em_qpc_ns=BASE+1),lambda x:x['map_cells'][0].update(em_tick_ms=1),lambda x:x['map_cells'][0].update(em_qpc_ns=float(BASE)),lambda x:x['observation'].update(adc_qpc_ns=float(BASE)),lambda x:x.update(map_cells=x['map_cells']*33)]
        for i,change in enumerate(mutations):
            bb=copy.deepcopy(b);change(bb['result'])
            with self.subTest(i=i):
                with self.assertRaises(ValueError):check(r,a,bb)
    def test09_all_stop_reason_shapes_and_result_reason_equality(self):
        r=request()
        for reason in v._STOP-{'invalid_faulted_or_saturated','original_sample_expired'}:
            a,b=pair(r);b['result'].update(status='STOP',reason=reason,direction_world=[0,0,0],speed_limit_m_s=0,risk=0.9 if reason=='candidate_risk_limit' else 1,uncertainty=1 if reason=='original_observation_pose_inapplicable' else 0.5);b['reason']=reason;check(r,a,b)
            b['reason']='disabled'
            with self.assertRaises(ValueError):check(r,a,b)
    def test10_observed_interval_exact_not_freshness_or_completion(self):
        x=v.validate_observed_interval(dispatch_lower_ns=BASE,all_result_observed_upper_ns=BASE+100_000_001,now_ns=BASE+100_000_001)
        self.assertEqual(x.lower_ns,BASE);self.assertEqual(x.upper_ns,BASE+100_000_001)
        self.assertFalse(hasattr(x,'completed_monotonic_ns'));self.assertFalse(hasattr(x,'deadline'))
        for lower,upper,now in ((True,BASE,BASE),(float(BASE),BASE,BASE),(BASE,BASE-1,BASE),(BASE,BASE+1,BASE),(BASE,1<<63,1<<63)):
            with self.assertRaises(ValueError):v.validate_observed_interval(dispatch_lower_ns=lower,all_result_observed_upper_ns=upper,now_ns=now)
    def test11_request_caps_strict_ids_and_missing_fields(self):
        r=request();a,b=pair(r);raw=request_wire(r)
        for bad in (raw[:-1],raw+b' ',b'\0\0\0\0'+raw[4:]):
            with self.assertRaises(ValueError):v.verify_pair(bad,output(a,b),expected_ids=ids())
        aa=copy.deepcopy(a);aa['echo_ids']=None
        with self.assertRaises(ValueError):check(r,aa,b)
        rr=copy.deepcopy(r);rr['echo_ids']['invocation_id']=True
        with self.assertRaises(ValueError):v.verify_pair(request_wire(rr),output(a,b),expected_ids=ids())
    def test12_held_preserves_native_map_identity(self):
        r=request();native=copy.deepcopy(r['input']['observation']);held=r['input']['observation'];held.update(sample_id='b'*64,adc_qpc_ns=BASE+10_000_000,quality=0x70f)
        r['input']['history']=[native];r['input']['now_qpc_ns']=held['adc_qpc_ns'];a,b=pair(r)
        b['result']['map_cells']=[dict(sample_id=native['sample_id'],em_qpc_ns=BASE,pose=pose(),risk=0.1)];check(r,a,b)
        b['result']['map_cells'][0]['sample_id']=held['sample_id']
        with self.assertRaises(ValueError):check(r,a,b)
if __name__=='__main__':unittest.main(verbosity=2)
