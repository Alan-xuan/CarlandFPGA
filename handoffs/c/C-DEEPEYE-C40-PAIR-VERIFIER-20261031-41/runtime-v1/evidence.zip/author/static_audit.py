from pathlib import Path
import ast,json,hashlib,difflib
D=Path(__file__).resolve().parent;W=D.parents[1]
sha=lambda b:hashlib.sha256(b).hexdigest()
a=json.loads((D.parent/'main/assignment-v1.json').read_bytes());source=Path(a['source_package'])/'c37_package.py'
s=source.read_text();t=(D/'c40_pair_verifier_v1.py').read_text();st=ast.parse(s);tt=ast.parse(t)
record=json.loads((D/'source-extraction.json').read_bytes());record['A39_body_raw_text_sha256']=record.pop('A39_body_sha256');record['A39_original_JSON_body_sha256']=a['source_A_body_sha256']
record['copied_definitions_AST_identical']=True
for row in record['copied_definitions']:
 name=row['name']
 def find(tree):
  return next(n for n in tree.body if (getattr(n,'name',None)==name or isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id==name for x in n.targets)))
 assert ast.dump(find(st),include_attributes=False)==ast.dump(find(tt),include_attributes=False),name
imports=[n.module if isinstance(n,ast.ImportFrom) else n.names[0].name for n in tt.body if isinstance(n,(ast.Import,ast.ImportFrom))]
assert imports==['hashlib','json','math','re','dataclasses','types']
for n in ast.walk(tt):
 if isinstance(n,ast.Call) and isinstance(n.func,ast.Name):assert n.func.id not in ('open','exec','eval','compile','__import__')
record['imports']=imports;record['final_source_sha256']=sha(t.encode());record['fixed_package_pins']={x.name:sha(x.read_bytes()) for x in Path(a['source_package']).iterdir() if x.is_file()}
(D/'source-extraction.json').write_text(json.dumps(record,indent=2)+'\n')
(D/'post-run01.diff').write_text(''.join(difflib.unified_diff((D/'c40_pair_verifier_v1.run01.py').read_text().splitlines(True),t.splitlines(True),fromfile='run01/verifier.py',tofile='final/verifier.py')))
abi={'abi_id':'c41_c40_pair_consistency_v1','entry':'verify_pair(request_wire: bytes, response_wire: bytes, *, expected_ids: dict) -> PairConsistency','secondary':'validate_observed_interval(*, dispatch_lower_ns, all_result_observed_upper_ns, now_ns) -> HostObservedInterval','C40_abi':'c37-owned-cpu-package/v2','fixed_manifest_sha256':'d63dc5d32c7b9d8bb32035edc1d78483a51c6d88e680b7fbd4ef9f304cf005f0','fixed_core_sha256':'70b317681fee8c9182c342fe8d2f94eaecc957c62231a74a080d213bb5e0eab4','request_bytes':16384,'request_payload_bytes':16380,'response_frame_count':2,'ordered_kinds':['READY','RESULT'],'payload_limits':[2048,16384],'total_response_limit':18440,'uint63_ns_max':(1<<63)-1,'JSON_depth_limit':24,'JSON_node_limit':4096,'JSON_collection_limit':32,'unexpected_fields':'reject','return_mutability':'recursively immutable detached mappingproxy/tuple in frozen dataclass','source_imports':0,'core_calls':0,'authority':'none','completion_grant':False,'null_ID_early_diagnostics':'outside admission, rejected','completion_interval_proposal':'README; no old completed_monotonic_ns synthesis','current_A_envelope_semantics':'unverified, A decision required'}
(D/'ABI.json').write_text(json.dumps(abi,indent=2)+'\n')
print(json.dumps({'AST_checks':len(record['copied_definitions']),'imports':imports,'core_calls':0,'source_sha256':record['final_source_sha256']}))
