"""Four NEW handcrafted consistency controls; never imports C40/C28 or tests.
Usage: python -I -S -B independent_checks.py VERIFIER_FILE OUTPUT_DIR
"""
import copy,hashlib,importlib.util,json,pathlib,sys
path,O=map(pathlib.Path,sys.argv[1:]);O.mkdir(exist_ok=False)
assert hashlib.sha256(path.read_bytes()).hexdigest()=='fc00cd1441e0dc15a092e601bb2864419e19ca688ba508c0b5a52faee429dd9b'
spec=importlib.util.spec_from_file_location('independent_c41',path);v=importlib.util.module_from_spec(spec);sys.modules[spec.name]=v;spec.loader.exec_module(v)
BASE=(1<<61)+3571
def pose(x=0):return dict(position_m=[x,0,0],orientation_xyzw=[0,0,0,1])
def observation(letter,ns,x,count=1800):return dict(sample_id=letter*64,counts=[count,2048,2048,0],quality=15,adc_qpc_ns=ns,em_qpc_ns=ns,adc_pose=pose(x),em_pose=pose(x))
def public():
 one=observation('a',BASE,0,1700);two=observation('b',BASE+10_000_000,0.05);held=copy.deepcopy(two);held.update(sample_id='c'*64,adc_qpc_ns=BASE+20_000_000,quality=0x70f,adc_pose=pose(0.1))
 return dict(schema_version=1,projection_id='c36_c28_public_view_v1',enabled=True,now_qpc_ns=BASE+20_000_000,pose=pose(0.1),goal_m=[0,0,8],observation=held,history=[one,two],executed_actions=[])
def advice(p):return dict(schema_version=1,planner_id='candidate_four_channel_planner_v1',candidate_only=True,authorization='none',status='ADVISE',reason='bounded_observation_goal_search',risk=0.2,uncertainty=0.6,direction_world=[0,0,1],speed_limit_m_s=0.05,observation=copy.deepcopy(p['observation']),map_cells=[dict(sample_id=o['sample_id'],em_qpc_ns=o['em_qpc_ns'],pose=copy.deepcopy(o['em_pose']),risk=0.2)for o in p['history']],independent_em_count=2)
ids=dict(operation_id='C41-independent',run_id='handcrafted-not-inference',actor_instance_id='no-process',invocation_id=7,tested_commit='f'*40,package_manifest_sha256=v.PACKAGE_MANIFEST_SHA256)
def encode(obj):return json.dumps(obj,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def frame(b):return len(b).to_bytes(4,'little')+b
rows=[]
def run(name,p,result,expected):
 request=dict(abi=v.ABI,kind='recommend',echo_ids=copy.deepcopy(ids),enabled=True,input=p);payload=encode(request);wire=frame(payload+b' '*(16380-len(payload)))
 digest=hashlib.sha256(wire).hexdigest();ready=dict(abi=v.ABI,kind='READY',echo_ids=copy.deepcopy(ids),request_wire_sha256=digest,core_sha256=v.CORE_SHA256,authority='none')
 response=dict(abi=v.ABI,kind='RESULT',echo_ids=copy.deepcopy(ids),request_wire_sha256=digest,status='RESULT',core_ran=True,authority='none',completion_grant=False,result=result,reason=result['reason'])
 pair=frame(encode(ready))+frame(encode(response));(O/(name+'.request.bin')).write_bytes(wire);(O/(name+'.pair.bin')).write_bytes(pair)
 caller_ids=copy.deepcopy(ids);status='ACCEPTED';detail=None
 try:
  parsed=v.verify_pair(wire,pair,expected_ids=caller_ids)
  caller_ids['run_id']='mutated-after-return';assert parsed.ready['echo_ids']['run_id']==ids['run_id']
  try:parsed.result['result']['map_cells']+=({},)
  except TypeError:pass
  else:raise AssertionError('nested mapping remained writable')
 except v.Rejected as e:status='REJECTED';detail=str(e)
 row=dict(case=name,expected=expected,observed=status,reason=detail,passed=status==expected,request_sha256=digest,pair_sha256=hashlib.sha256(pair).hexdigest(),C40_core_imports=0)
 rows.append(row);print(json.dumps(row),flush=True)
p=public();r=advice(p);run('held-two-original-native-origins',p,r,'ACCEPTED')
wrong=copy.deepcopy(r);wrong['map_cells'].reverse();run('reordered-original-native-map',p,wrong,'REJECTED')
p=public();p['history']=[];p['observation']=observation('d',BASE,0,0);p['observation']['quality']=31;p['now_qpc_ns']=BASE+100_000_001
r=advice(p);r.update(status='STOP',reason='invalid_faulted_or_saturated',risk=1,uncertainty=1,direction_world=[0,0,0],speed_limit_m_s=0,map_cells=[],independent_em_count=0)
run('saturated-and-expired-quality-takes-priority',p,r,'ACCEPTED')
r=copy.deepcopy(r);r['reason']='original_sample_expired';run('expired-reason-cannot-hide-saturation',p,r,'REJECTED')
assert not any('c37' in n or 'frozen_c28' in n for n in sys.modules)
(O/'results.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf8')
raise SystemExit(0 if all(r['passed']for r in rows) else 1)
