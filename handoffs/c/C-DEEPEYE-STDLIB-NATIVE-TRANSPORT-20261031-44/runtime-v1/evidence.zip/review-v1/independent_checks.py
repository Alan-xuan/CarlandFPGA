"""Two NEW combined fault controls. CLI PACKAGE_DIR OUTPUT_DIR; no native calls."""
import contextlib,hashlib,importlib.util,io,json,pathlib,sys
P,O=map(pathlib.Path,sys.argv[1:]);O.mkdir(exist_ok=False)
assert hashlib.sha256((P/'c37_entry.py').read_bytes()).hexdigest()=='899b843111a1b9278e4c5ee16b11d4493c35c1cb0bca328a57f164c3f0c11c74'
def entry():
 sp=importlib.util.spec_from_file_location('independent_c44_entry',P/'c37_entry.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);return m
args=['--actor-stdio-v2','--max-invocations','2','--request-bytes','16384','41','42','43'];rows=[]
def check(name,setup_fail):
 E=entry();calls=[];instances=[];setup_errors=[];fake_process_calls=0;write_count=0
 class API:
  def ReadFile(self,h,n,*,overlapped):calls.append(['read',h,n,overlapped]);return(b'x'*n,0)
  def WriteFile(self,h,b,*,overlapped):
   nonlocal write_count
   write_count+=1;calls.append(['write',h,len(b),overlapped]);return(len(b)if write_count==1 else len(b)-1,0)
  def CloseHandle(self,h):
   calls.append(['close',h])
   if setup_fail:
    if h==41:return False
    if h==42:raise OSError('secret-close-42')
   else:
    if h==41:raise OSError('secret-close-41')
    if h==43:return False
   return None
 class Event:
  def wait(self,*a,**k):calls.append(['wait',list(a),k]);raise AssertionError('unreachable after short write')
 class Package:
  def request_identity(self,wire):calls.append(['identity',len(wire)]);return dict(invocation_id=1,run_id='fixed-fake')
  def process_wire(self,wire):
   nonlocal fake_process_calls
   fake_process_calls+=1;calls.append(['fake_process',len(wire)]);return b'y'*9001
 api=API();E._get_winapi=lambda:api
 def signal(h):calls.append(['signal',h]);return None
 E._get_set_event=lambda:signal
 def event():
  calls.append(['event_init'])
  if setup_fail:raise RuntimeError('secret-event-init')
  return Event()
 E._new_wait_event=event;E.load_package=lambda:Package();T=E.NativeTransport
 def transport(*a):
  try:t=T(*a);instances.append(t);return t
  except E.NativeSetupFailure as e:setup_errors.append(dict(close_available=e.close_available,attempted=list(e.close_attempted),failed=list(e.close_failed)));raise
 E.NativeTransport=transport
 params=dict(argv=args,synthetic_api=True,scenario=name,setup_failure=setup_fail,read_chunk=8192,output_bytes=9001,second_write='short-by-one',close_fault_slots=[0,1]if setup_fail else[0,2])
 (O/(name+'.input.json')).write_text(json.dumps(params,indent=2),encoding='utf8')
 stdout,stderr=io.StringIO(),io.StringIO()
 with contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr):code=E.main(args)
 expected=75 if setup_fail else 73
 checks=dict(fixed_exit=code==expected,no_pipe_diagnostics=stdout.getvalue()==stderr.getvalue()=='',all_slots_attempted=[c for c in calls if c[0]=='close']==[['close',41],['close',42],['close',43]])
 if setup_fail:
  checks.update(no_ready_or_IO_or_callback=not any(c[0]in('signal','read','write','fake_process')for c in calls),setup_state=setup_errors==[dict(close_available=True,attempted=[0,1,2],failed=[0,1])])
 else:
  t=instances[0];checks.update(one_callback_only=fake_process_calls==1,no_next_request=sum(c[0]=='read'for c in calls)==2,no_write_retry=sum(c[0]=='write'for c in calls)==2,no_wait=not any(c[0]=='wait'for c in calls),close_state=t.close_attempted==[0,1,2]and t.close_failed==[0,2])
  before=list(calls);t.close();refused=[]
  for op in(t.signal_ready,lambda:t.read(1),lambda:t.write(b'z'),t.wait_for_owner_teardown):
   try:op();refused.append(False)
   except RuntimeError:refused.append(True)
  checks.update(no_closed_reuse=all(refused),no_repeated_API=calls==before)
 observed=dict(code=code,expected=expected,checks=checks,calls=calls,fake_process_calls=fake_process_calls,setup_errors=setup_errors,stdout=stdout.getvalue(),stderr=stderr.getvalue(),real_handle_calls=0,core_calls=0)
 (O/(name+'.output.json')).write_text(json.dumps(observed,indent=2),encoding='utf8');row=dict(case=name,passed=all(checks.values()),observed_exit=code,expected_exit=expected);rows.append(row);print(json.dumps(row),flush=True)
check('partial-response-short-write-plus-close-failures',False)
check('pre-ready-event-init-failure-plus-close-failures',True)
assert '_c37_fixed_package'not in sys.modules and '_ctypes'not in sys.modules and 'ctypes'not in sys.modules
(O/'results.json').write_text(json.dumps(rows,indent=2),encoding='utf8');raise SystemExit(0 if all(r['passed']for r in rows)else 1)
