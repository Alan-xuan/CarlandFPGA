"""NEW main/transport exception integration; fake API and fake package only."""
import importlib.util,sys,unittest
from pathlib import Path
from unittest.mock import patch
D=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('c44_controls',D/'test_transport_c44.py');m=importlib.util.module_from_spec(s);sys.modules[s.name]=m;s.loader.exec_module(m)
E=m.E
class Controls(unittest.TestCase):
 def test12_api_exception_cleanup_main(self):
  args=['--actor-stdio-v2','--max-invocations','1','--request-bytes','16384','11','12','13']
  class Package:
   calls=0
   def request_identity(self,raw):return {'invocation_id':1}
   def process_wire(self,raw):self.calls+=1;return b'x'
  for fault in ('read','write','signal','close','event_init'):
   with self.subTest(fault=fault):
    api=m.FakeAPI();api.read_result=(b'x'*8192,0);event=m.FakeEvent();package=Package()
    def fail(*a,**k):raise OSError('synthetic API error must not be printed')
    if fault=='read':api.ReadFile=fail
    if fault=='write':api.WriteFile=fail
    if fault=='signal':api.SetEvent=fail
    if fault=='close':api.bad_close={12}
    with patch.object(E,'load_package',return_value=package),patch.object(E,'_get_winapi',return_value=api),patch.object(E,'_get_set_event',return_value=api.SetEvent),patch.object(E,'_new_wait_event',side_effect=fail if fault=='event_init' else None,return_value=event):code=E.main(args)
    self.assertEqual(code,73 if fault=='close' else 71 if fault=='event_init' else 72)
    self.assertEqual([c for c in api.calls if c[0]=='close'],[('close',11),('close',12),('close',13)])
    self.assertEqual(package.calls,1 if fault in ('write','close') else 0)
if __name__=='__main__':unittest.main(verbosity=2)
