import sys,json,hashlib,struct
from pathlib import Path
import _winapi,_overlapped
D=Path(__file__).resolve().parent;root=Path(sys.base_prefix)
def pe(path):
 raw=path.read_bytes();u16=lambda o:struct.unpack_from('<H',raw,o)[0];u32=lambda o:struct.unpack_from('<I',raw,o)[0]
 assert raw[:2]==b'MZ';p=u32(60);assert raw[p:p+4]==b'PE\0\0';count=u16(p+6);opt=p+24;magic=u16(opt);dirs=opt+(112 if magic==0x20b else 96);sections=[];start=opt+u16(p+20)
 for i in range(count):
  q=start+40*i;sections.append((u32(q+12),max(u32(q+8),u32(q+16)),u32(q+20)))
 def offset(rva):
  for va,size,ptr in sections:
   if va<=rva<va+size:return ptr+rva-va
  if rva<u32(opt+60):return rva
  raise ValueError('RVA outside sections')
 def name(rva):
  q=offset(rva);return raw[q:raw.index(b'\0',q)].decode('ascii')
 imports=[];rva=u32(dirs+8)
 if rva:
  q=offset(rva)
  while any(raw[q:q+20]):imports.append(name(u32(q+12)));q+=20
 delay=[];rva=u32(dirs+13*8)
 if rva:
  q=offset(rva)
  while any(raw[q:q+32]):
   assert u32(q)&1;delay.append(name(u32(q+4)));q+=32
 return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),machine=hex(u16(p+4)),imports=imports,delay_imports=delay)
modules={}
for module,names in ((_winapi,('ReadFile','WriteFile','CloseHandle')),(_overlapped,('SetEvent',))):
 modules[module.__name__]=dict(origin=module.__spec__.origin,file=getattr(module,'__file__',None),functions={n:dict(text_signature=getattr(getattr(module,n),'__text_signature__',None),doc=getattr(module,n).__doc__) for n in names})
paths=[Path(sys.executable),root/'python312.dll',Path(_overlapped.__file__),root/'vcruntime140.dll',root/'vcruntime140_1.dll']
result=dict(python_version=sys.version,executable=sys.executable,base_prefix=sys.base_prefix,modules=modules,winapi_has_SetEvent=hasattr(_winapi,'SetEvent'),ctypes_imported=('ctypes' in sys.modules or '_ctypes' in sys.modules),PE=[pe(p) for p in paths if p.exists()],actual_handle_API_calls=0,core_calls=0,original_actor_runs=0)
(D/'local-api-pe.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
