from pathlib import Path
import subprocess,sys,datetime,json,hashlib
D=Path(__file__).resolve().parent;R=D.parents[3]
a=json.loads((D.parent/'main/assignment-v1.json').read_bytes());c=json.loads(Path(a['source_A_body_path']).read_bytes());sha=lambda b:hashlib.sha256(b).hexdigest()
assert c['id']==a['source_A_comment'] and c['user']['id']==a['source_A_author'] and sha(c['body'].encode())==a['source_A_body_sha256']
lock=json.loads((R/'.local/plan-20261014-final-c/immutable-f5989cd/immutable_scope.json').read_bytes());assert sha(json.dumps(lock['requirements'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())==a['requirements_sha256']
(D/'primary-source').mkdir()
for path in ('Modules/_winapi.c','Modules/overlapped.c'):
 argv=['gh','api','--method','GET','-H','Accept: application/vnd.github.raw+json','repos/python/cpython/contents/'+path+'?ref=v3.12.14']
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();p=subprocess.run(argv,capture_output=True,timeout=20)
 name=Path(path).name;(D/'primary-source'/name).write_bytes(p.stdout);(D/'primary-source'/(name+'.stderr')).write_bytes(p.stderr)
 rec=dict(argv=argv,start_utc=start,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=p.returncode,timeout_seconds=20,bytes=len(p.stdout),sha256=sha(p.stdout),stderr_sha256=sha(p.stderr),git_blob=hashlib.sha1(b'blob '+str(len(p.stdout)).encode()+b'\0'+p.stdout).hexdigest())
 (D/'primary-source'/(name+'.command.json')).write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps(rec),flush=True);assert p.returncode==0
