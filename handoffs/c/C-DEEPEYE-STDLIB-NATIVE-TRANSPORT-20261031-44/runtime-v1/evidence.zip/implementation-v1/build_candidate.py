from pathlib import Path
import hashlib,json,difflib,ast
D=Path(__file__).resolve().parent
B=D.parent.parent
old=B/'C40-20261031/implementation-v2'
pkg=D/'c44-owned-cpu-package';pkg.mkdir(exist_ok=False)
entry=(old/'c37-owned-cpu-package-v2/c37_entry.py').read_text()
new_native='''class NativeSetupFailure(Exception):
    """Fixed local diagnostic only; no handle values or arbitrary error text."""
    def __init__(self, close_available, attempted, failed):
        super().__init__('native setup failed')
        self.close_available = close_available
        self.close_attempted = tuple(attempted)
        self.close_failed = tuple(failed)


class HandleCloseFailure(Exception):
    pass


def _get_winapi():
    import _winapi
    return _winapi


def _get_set_event():
    from _overlapped import SetEvent
    return SetEvent


def _new_wait_event():
    from threading import Event
    return Event()


class NativeTransport:
    """One-use inherited handles. Original owner retains custody and lifetime."""
    def __init__(self, ready, input_handle, output_handle):
        self._handles = (ready, input_handle, output_handle)
        self._closed = False
        self._ready_attempted = False
        self._ready = False
        self._wait_started = False
        self._close_handle = None
        self.close_attempted = []
        self.close_failed = []
        try:
            if sys.platform != 'win32' or any(type(h) is not int or not 0 < h < (1 << 64) - 1 for h in self._handles) or len(set(self._handles)) != 3:
                raise ValueError('three distinct Windows handles required')
            self._api = _get_winapi()
            self._close_handle = self._api.CloseHandle
            self._set_event = _get_set_event()
            # Initialized before readiness/inference; never set or timed here.
            self._owner_wait = _new_wait_event()
        except Exception:
            available = self._close_handle is not None
            if available:
                try:
                    self.close()
                except HandleCloseFailure:
                    pass
            else:
                self._closed = True
            raise NativeSetupFailure(available, self.close_attempted, self.close_failed) from None

    def _live(self):
        if self._closed or self._wait_started:
            raise RuntimeError('transport already retired')

    def signal_ready(self):
        self._live()
        if self._ready_attempted:
            raise RuntimeError('readiness already attempted')
        self._ready_attempted = True
        if self._set_event(self._handles[0]) is not None:
            raise OSError('invalid readiness result')
        self._ready = True

    def read(self, size):
        self._live()
        if not self._ready or type(size) is not int or not 1 <= size <= 8192:
            raise ValueError('read state/chunk budget')
        result = self._api.ReadFile(self._handles[1], size, overlapped=False)
        if (type(result) is not tuple or len(result) != 2
            or type(result[0]) is not bytes or not 0 < len(result[0]) <= size
            or type(result[1]) is not int or result[1] != 0):
            raise OSError('invalid synchronous read result')
        # Positive partial byte-stream reads remain legal, as in C40.
        return result[0]

    def write(self, raw):
        self._live()
        if not self._ready or type(raw) is not bytes or not 1 <= len(raw) <= 8192:
            raise ValueError('write state/chunk budget')
        result = self._api.WriteFile(self._handles[2], raw, overlapped=False)
        if (type(result) is not tuple or len(result) != 2
            or type(result[0]) is not int or result[0] != len(raw)
            or type(result[1]) is not int or result[1] != 0):
            raise OSError('short/invalid synchronous write result; no retry')
        return result[0]

    def wait_for_owner_teardown(self):
        self._live()
        if not self._ready:
            raise RuntimeError('readiness required')
        self._wait_started = True
        self._owner_wait.wait()
        raise RuntimeError('owner teardown wait returned unexpectedly')

    def close(self):
        if self._closed:
            return
        self._closed = True
        for slot, handle in enumerate(self._handles):
            self.close_attempted.append(slot)
            try:
                if self._close_handle(handle) is not None:
                    raise OSError('invalid close result')
            except Exception:
                self.close_failed.append(slot)
        if self.close_failed:
            raise HandleCloseFailure('inherited handle close failed; no retry')
'''
new_main='''def main(argv):
    # Original ActorOwner appends the final three native handle strings.
    if len(argv) != 8 or argv[0:2] != ['--actor-stdio-v2', '--max-invocations'] or argv[3] != '--request-bytes':
        return 64
    try:
        values = [int(argv[i]) for i in (2, 4, 5, 6, 7)]
        if any(str(value) != argv[index] for value, index in zip(values, (2, 4, 5, 6, 7))):
            return 64
        count, size, ready, inp, out = values
        if not 1 <= count <= 16 or size != 16384 or len({ready, inp, out}) != 3:
            return 64
        if not all(0 < handle < (1 << 64) - 1 for handle in (ready, inp, out)):
            return 64
    except Exception:
        return 64
    try:
        package = load_package()
    except Exception:
        return 70
    try:
        transport = NativeTransport(ready, inp, out)
    except NativeSetupFailure as error:
        # 71: all three closes attempted and succeeded; 74: no close API;
        # 75: all attempted, at least one failed. OS exit is final cleanup.
        return (71 if not error.close_failed else 75) if error.close_available else 74
    except Exception:
        return 74
    try:
        serve(transport, size, count, package)
        return 72  # A returning serve is not a successful live child.
    except HandleCloseFailure:
        return 73
    except Exception:
        return 72
'''
start=entry.index('class NativeTransport:');end=entry.index("if __name__ == '__main__':")
new=entry[:start]+new_native+'\n\n'+new_main+'\n\n'+entry[end:]
(pkg/'c37_entry.py').write_text(new,encoding='utf-8',newline='\n')
for name in ['c37_package.py','frozen_c28.py']:
 (pkg/name).write_bytes((old/'c37-owned-cpu-package-v2'/name).read_bytes())
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest={'schema_version':1,'files':{p.name:sha(p.read_bytes()) for p in sorted(pkg.iterdir())}}
(pkg/'package-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
pin=sha((pkg/'package-manifest.json').read_bytes())
source=B/'C41-20261031/implementation-v1/c40_pair_verifier_v1.py'
raw=source.read_bytes();oldpin=b'd63dc5d32c7b9d8bb32035edc1d78483a51c6d88e680b7fbd4ef9f304cf005f0';assert raw.count(oldpin)==1
out=raw.replace(oldpin,pin.encode());(D/'c44_pair_verifier_v1.py').write_bytes(out)
for label,a,b in [('entry',entry,new),('verifier',raw.decode(),out.decode())]:
 (D/(label+'.diff')).write_text(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='frozen/'+label,tofile='C44/'+label)),encoding='utf-8',newline='\n')
(D/'stage_package.py').write_bytes((old/'stage_package.py').read_bytes())
inv_path=old/'runtime-inventory-v2.json';inv=json.loads(inv_path.read_text())
inv['package_files']=[{'path':p.name,'bytes':len(p.read_bytes()),'sha256':sha(p.read_bytes())} for p in sorted(pkg.iterdir())]
inv['created_utc']='2026-10-30T20:40:00+00:00'
inv['provenance']={'runtime_rows':'inherited C40 frozen inventory; not all rehashed in C44','inherited_inventory_path':str(inv_path),'inherited_inventory_sha256':sha(inv_path.read_bytes()),'current_checks':'local-api-pe.json only; actual C CPython 3.12.14 API/selected PE bytes','not_A_runtime':True,'A632_adaptation':'A responsibility; not staged or qualified here','unused_ctypes_files':'present in inherited closure; not imported by new transport or required by observed _overlapped PE imports'}
# Preserve original inventory field names while updating aggregate package bytes.
for key in list(inv):
 if key in ('package_bytes','stage_bytes','total_bytes'): del inv[key]
inv['package_bytes']=sum(r['bytes'] for r in inv['package_files']);inv['stage_bytes']=sum(r['bytes'] for r in inv['files'])+inv['package_bytes']
(D/'runtime-inventory-c44.json').write_text(json.dumps(inv,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'manifest_sha256':pin,'package':manifest,'runtime_files':len(inv['files']),'package_bytes':inv['package_bytes'],'stage_bytes':inv['stage_bytes']}))
