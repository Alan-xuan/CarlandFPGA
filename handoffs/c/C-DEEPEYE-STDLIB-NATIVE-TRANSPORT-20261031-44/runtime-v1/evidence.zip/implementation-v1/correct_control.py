from pathlib import Path
import json,datetime,hashlib
D=Path(__file__).resolve().parent
p=D/'test_transport_c44.py';raw=p.read_bytes();(D/'test_transport_c44.run02-original.py').write_bytes(raw)
s=raw.decode('utf-8-sig').replace("req=v.fixed_request({'abi':v.ABI,'kind':'recommend','echo_ids':ids,'input':{}})","req=v.fixed_request(v._dump({'abi':v.ABI,'kind':'recommend','echo_ids':ids,'input':{}}))").replace("pair=v.frame(ready,2048)+v.frame(result)","pair=v.frame(v._dump(ready),2048)+v.frame(v._dump(result))")
p.write_text(s,encoding='utf-8',newline='\n')
i=D/'runtime-inventory-c44.json';old=i.read_bytes();(D/'runtime-inventory-c44.run01-original.json').write_bytes(old)
x=json.loads(old);x['created_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();x['status']='C44_INHERITED_C633_ROWS_SELECTED_API_PE_RECHECK_ONLY_NOT_STAGED';x['prior_C40_inherited_inventory_sha256']=x.pop('inherited_inventory_sha256');i.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'test_fix':'Use original byte-oriented framing API with explicitly serialized synthetic JSON; production unchanged','production_changed':False,'inventory_metadata_fix':'Use actual creation time; name upstream inheritance separately','original_test_sha256':hashlib.sha256(raw).hexdigest()}))
