from pathlib import Path
import json,hashlib,datetime,importlib.util,inspect,threading,_thread
D=Path(__file__).resolve().parent;B=D.parent.parent
sha=lambda b:hashlib.sha256(b).hexdigest()
inv=json.loads((D/'runtime-inventory-c44.json').read_text());root=Path(inv['runtime_original_root'])
selected=[]
for name in ('python.exe','Lib/threading.py','LICENSE.txt'):
 p=root/name;raw=p.read_bytes();row=next(r for r in inv['files'] if r['path']=='runtime/'+name)
 assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
 selected.append({'path':str(p),'bytes':len(raw),'sha256':sha(raw),'matches_inherited_row':True})
r={'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':selected,'thread_module_origin':importlib.util.find_spec('_thread').origin,'Event_wait_signature':str(inspect.signature(threading.Event.wait)),'Event_instances_created':0,'native_handle_API_calls':0,'core_calls':0,'actor_launches':0}
(D/'selected-runtime-current.json').write_text(json.dumps(r,indent=2)+'\n')
primary=[]
for p in sorted((D/'primary-source').glob('*.c')):
 primary.append({'path':str(p.relative_to(D)),'bytes':len(p.read_bytes()),'sha256':sha(p.read_bytes()),'upstream':'https://github.com/python/cpython/blob/v3.12.14/Modules/'+p.name})
source=[]
paths=[B/'C40-20261031/implementation-v2/c37-owned-cpu-package-v2'/n for n in ['c37_entry.py','c37_package.py','frozen_c28.py','package-manifest.json']]
paths += [B/'C40-20261031/implementation-v2/runtime-inventory-v2.json',B/'C40-20261031/implementation-v2/stage_package.py',B/'C41-20261031/implementation-v1/c40_pair_verifier_v1.py',D.parent/'main/assignment-v1.json',D.parent/'main/A42-original.json']
for p in paths:source.append({'path':str(p),'bytes':len(p.read_bytes()),'sha256':sha(p.read_bytes())})
(D/'source-pins.json').write_text(json.dumps({'source':source,'official_CPython':primary},indent=2)+'\n')
print(json.dumps(r))
