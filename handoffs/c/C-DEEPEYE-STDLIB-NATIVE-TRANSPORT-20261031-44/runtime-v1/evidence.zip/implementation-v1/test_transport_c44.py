"""NEW C44 fake API boundary controls; never load adapter/frozen core."""
import ast,hashlib,importlib.util,json,sys,unittest
from pathlib import Path
from unittest.mock import patch
D=Path(__file__).resolve().parent;B=D.parent.parent

def module(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m
E=module('c44_entry_test',D/'c44-owned-cpu-package/c37_entry.py')
class Halt(Exception):pass
class FakeEvent:
 def __init__(self):self.calls=[];self.returns=False
 def wait(self,*args,**kw):
  self.calls.append((args,kw))
  if not self.returns:raise Halt('synthetic teardown')
class FakeAPI:
 def __init__(self):self.calls=[];self.read_result=(b'x',0);self.write_result=None;self.bad_close=set();self.event_result=None
 def ReadFile(self,h,n,*,overlapped):self.calls.append(('read',h,n,overlapped));return self.read_result
 def WriteFile(self,h,b,*,overlapped):self.calls.append(('write',h,len(b),overlapped));return self.write_result if self.write_result is not None else (len(b),0)
 def CloseHandle(self,h):
  self.calls.append(('close',h))
  if h in self.bad_close:raise OSError('synthetic close failure')
 def SetEvent(self,h):self.calls.append(('signal',h));return self.event_result
class Controls(unittest.TestCase):
 def make(self):
  api,event=FakeAPI(),FakeEvent()
  with patch.object(E,'_get_winapi',return_value=api),patch.object(E,'_get_set_event',return_value=api.SetEvent),patch.object(E,'_new_wait_event',return_value=event):t=E.NativeTransport(11,12,13)
  return t,api,event
 def test01_static_frozen_scope_and_no_ctypes(self):
  old=B/'C40-20261031/implementation-v2/c37-owned-cpu-package-v2'
  new=D/'c44-owned-cpu-package'
  for name in ('c37_package.py','frozen_c28.py'):self.assertEqual((old/name).read_bytes(),(new/name).read_bytes())
  a,b=(old/'c37_entry.py').read_text(),(new/'c37_entry.py').read_text()
  for name in ('load_package','serve'):
   x=next(n for n in ast.parse(a).body if isinstance(n,ast.FunctionDef) and n.name==name)
   y=next(n for n in ast.parse(b).body if isinstance(n,ast.FunctionDef) and n.name==name)
   self.assertEqual(ast.get_source_segment(a,x),ast.get_source_segment(b,y))
  imports=[n for n in ast.walk(ast.parse(b)) if isinstance(n,(ast.Import,ast.ImportFrom))]
  self.assertFalse(any('ctypes' in ast.unparse(n) for n in imports))
  self.assertEqual((D/'stage_package.py').read_bytes(),(old.parent/'stage_package.py').read_bytes())
  for p in new.glob('*.py'):compile(p.read_bytes(),str(p),'exec') # syntax only, no execution
  self.assertNotIn('_c37_fixed_package',sys.modules)
  self.assertNotIn('_ctypes',sys.modules)
 def test02_partial_reads_exact_sync_and_full_writes(self):
  t,a,e=self.make();t.signal_ready();a.read_result=(b'ab',0)
  self.assertEqual(t.read(8192),b'ab');self.assertEqual(t.write(b'abc'),3)
  self.assertIn(('read',12,8192,False),a.calls);self.assertIn(('write',13,3,False),a.calls)
  t.close();self.assertEqual(t.close_attempted,[0,1,2]);self.assertEqual(t.close_failed,[])
 def test03_read_tuple_errors_and_bounds(self):
  t,a,e=self.make();t.signal_ready()
  for result in [(b'',0),(b'xx',0),(b'x',234),(b'x',True),[b'x',0],(bytearray(b'x'),0),(b'x',0,1)]:
   with self.subTest(result=repr(result)):
    a.read_result=result
    with self.assertRaises(OSError):t.read(1)
  count=len(a.calls)
  for size in (0,8193,True,1.5):
   with self.assertRaises(ValueError):t.read(size)
  self.assertEqual(len(a.calls),count);t.close()
 def test04_write_short_errors_no_retries(self):
  t,a,e=self.make();t.signal_ready()
  for result in [(0,0),(1,0),(3,0),(2,5),(2,False),(True,0),[2,0]]:
   before=len(a.calls);a.write_result=result
   with self.assertRaises(OSError):t.write(b'ab')
   self.assertEqual(len(a.calls),before+1)
  for raw in (b'',b'x'*8193,bytearray(b'a')):
   with self.assertRaises(ValueError):t.write(raw)
  t.close()
 def test05_ready_close_and_one_use(self):
  t,a,e=self.make()
  with self.assertRaises(ValueError):t.read(1)
  a.event_result=False
  with self.assertRaises(OSError):t.signal_ready()
  with self.assertRaises(RuntimeError):t.signal_ready()
  a.bad_close={12}
  with self.assertRaises(E.HandleCloseFailure):t.close()
  self.assertEqual(t.close_attempted,[0,1,2]);self.assertEqual(t.close_failed,[1])
  before=len(a.calls);t.close()
  for f in (t.signal_ready,lambda:t.read(1),lambda:t.write(b'x'),t.wait_for_owner_teardown):
   with self.assertRaises(RuntimeError):f()
  self.assertEqual(len(a.calls),before)
 def test06_init_cleanup_all_slots_and_no_api(self):
  for phase in ('set_event','event'):
   api=FakeAPI();api.bad_close={11,13}
   with patch.object(E,'_get_winapi',return_value=api),patch.object(E,'_get_set_event',side_effect=ImportError('fake') if phase=='set_event' else None,return_value=api.SetEvent),patch.object(E,'_new_wait_event',side_effect=RuntimeError('fake')):
    with self.assertRaises(E.NativeSetupFailure) as got:E.NativeTransport(11,12,13)
   self.assertTrue(got.exception.close_available);self.assertEqual(got.exception.close_attempted,(0,1,2));self.assertEqual(got.exception.close_failed,(0,2))
  with patch.object(E,'_get_winapi',side_effect=ImportError('fake')):
   with self.assertRaises(E.NativeSetupFailure) as got:E.NativeTransport(11,12,13)
  self.assertFalse(got.exception.close_available);self.assertEqual(got.exception.close_attempted,())
 def test07_preinitialized_wait_no_timeout_no_return(self):
  t,a,e=self.make();t.signal_ready();e.returns=True
  with self.assertRaises(RuntimeError):t.wait_for_owner_teardown()
  self.assertEqual(e.calls,[((),{})])
  with self.assertRaises(RuntimeError):t.wait_for_owner_teardown()
  with self.assertRaises(RuntimeError):t.read(1)
  t.close()
 def test08_serve_fake_package_finite_partial_stream(self):
  t,a,e=self.make();a.read_result=(b'x'*4096,0)
  class Package:
   calls=0
   def request_identity(self,raw):self_test.assertEqual(len(raw),16384);return {'invocation_id':self.calls+1,'other':'fixed'}
   def process_wire(self,raw):self.calls+=1;return b'y'*9000
  self_test=self;p=Package()
  with self.assertRaises(Halt):E.serve(t,16384,2,p)
  self.assertEqual(p.calls,2);self.assertEqual(sum(c[0]=='read' for c in a.calls),8)
  self.assertEqual(sum(c[0]=='write' for c in a.calls),4);self.assertEqual(sum(c[0]=='signal' for c in a.calls),1)
  self.assertEqual(e.calls,[((),{})]);self.assertEqual(t.close_attempted,[0,1,2])
 def test09_fixed_main_exit_phases(self):
  args=['--actor-stdio-v2','--max-invocations','1','--request-bytes','16384','11','12','13']
  self.assertEqual(E.main([]),64)
  with patch.object(E,'load_package',side_effect=ValueError('secret must not print')):self.assertEqual(E.main(args),70)
  for failure,code in [(E.NativeSetupFailure(False,[],[]),74),(E.NativeSetupFailure(True,[0,1,2],[]),71),(E.NativeSetupFailure(True,[0,1,2],[1]),75)]:
   with patch.object(E,'load_package',return_value=object()),patch.object(E,'NativeTransport',side_effect=failure):self.assertEqual(E.main(args),code)
  for failure,code in [(ValueError('fake'),72),(E.HandleCloseFailure('fake'),73)]:
   with patch.object(E,'load_package',return_value=object()),patch.object(E,'NativeTransport',return_value=object()),patch.object(E,'serve',side_effect=failure):self.assertEqual(E.main(args),code)
 def test10_new_verifier_only_manifest_delta(self):
  new=(D/'c44_pair_verifier_v1.py').read_bytes();old=(B/'C41-20261031/implementation-v1/c40_pair_verifier_v1.py').read_bytes()
  pin=hashlib.sha256((D/'c44-owned-cpu-package/package-manifest.json').read_bytes()).hexdigest()
  oldpin='d63dc5d32c7b9d8bb32035edc1d78483a51c6d88e680b7fbd4ef9f304cf005f0'
  self.assertEqual(new,old.replace(oldpin.encode(),pin.encode()))
  v=module('c44_verify_test',D/'c44_pair_verifier_v1.py')
  ids={'operation_id':'synthetic','run_id':'r','actor_instance_id':'a','invocation_id':1,'tested_commit':'0'*40,'package_manifest_sha256':pin}
  req=v.fixed_request(v._dump({'abi':v.ABI,'kind':'recommend','echo_ids':ids,'input':{}}))
  common={'abi':v.ABI,'echo_ids':ids,'request_wire_sha256':hashlib.sha256(req).hexdigest(),'authority':'none'}
  ready=dict(common,kind='READY',core_sha256=v.CORE_SHA256)
  result=dict(common,kind='RESULT',status='REJECTED',reason='INVALID_SHAPE',core_ran=False,completion_grant=False,result=None)
  pair=v.frame(v._dump(ready),2048)+v.frame(v._dump(result));got=v.verify_pair(req,pair,expected_ids=ids)
  with self.assertRaises(TypeError):got.result['status']='RESULT'
  ids['package_manifest_sha256']=oldpin
  with self.assertRaisesRegex(v.Rejected,'PACKAGE_PIN'):v.verify_pair(req,pair,expected_ids=ids)
 def test11_manifest_inventory_scope(self):
  pkg=D/'c44-owned-cpu-package';m=json.loads((pkg/'package-manifest.json').read_text())
  for name,pin in m['files'].items():self.assertEqual(hashlib.sha256((pkg/name).read_bytes()).hexdigest(),pin)
  inv=json.loads((D/'runtime-inventory-c44.json').read_text());old=json.loads((B/'C40-20261031/implementation-v2/runtime-inventory-v2.json').read_text())
  self.assertEqual(inv['files'],old['files']);self.assertEqual(len(inv['files']),633)
  self.assertEqual(inv['stage_bytes'],sum(r['bytes'] for r in inv['files']+inv['package_files']))
  for row in inv['package_files']:
   raw=(pkg/row['path']).read_bytes();self.assertEqual(len(raw),row['bytes']);self.assertEqual(hashlib.sha256(raw).hexdigest(),row['sha256'])
if __name__=='__main__':unittest.main(verbosity=2)
