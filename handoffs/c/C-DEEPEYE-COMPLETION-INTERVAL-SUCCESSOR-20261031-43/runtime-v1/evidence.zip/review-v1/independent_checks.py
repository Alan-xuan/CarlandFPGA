"""NEW bounded C43 controls only. CLI: IMPLEMENTATION_DIR OUTPUT_DIR.
Reads pinned private vendor; imports host validator/adapter only, never author tests.
"""
import copy,hashlib,importlib.util,json,pathlib,sys
from collections.abc import Mapping
S,O=map(pathlib.Path,sys.argv[1:]);O.mkdir(exist_ok=False)
assert hashlib.sha256((S/'completion_interval.py').read_bytes()).hexdigest()=='05da98393d47f3eaf4690d8979d2e37d2e4f1e0b00c801177a3fb6a3f84bbe96'
sys.path.insert(0,str(S/'dependencies/attempt02/vendor'))
def load(name,path):
 sp=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(sp);sys.modules[name]=m;sp.loader.exec_module(m);return m
old=load('independent_c43_old_host',S/'baseline/integration/host_envelope.py');host=load('independent_c43_new_host',S/'patched/integration/host_envelope.py')
U=(1<<63)-1;N=(1<<60)+918273645
ctx=dict(session=93,config_epoch=17,boot_sha256='7'*64,transport_profile_id=1,source_id=1,topology_id=2,acquisition_profile_id=1)
def doc(lower=N,upper=N+10_000_000,duration=1):return dict(schema_version=2,context=copy.deepcopy(ctx),kind='model_candidate',candidate_id=29,model_sha256='8'*64,observation=dict(context=copy.deepcopy(ctx),observed_seq=419),target=dict(action=1,yaw_q=0,pitch_q=0,speed_code=1,duration_ms=duration),completion_observed_interval_ns=dict(lower_ns=lower,upper_ns=upper),basis='host_dispatch_to_complete_result_observed_v1')
def bounds(age=100_000_000,source=N+80_000_000,dispatch=N+70_000_000,previous=None):return dict(max_age_ns=age,source_deadline_ns=source,dispatch_deadline_ns=dispatch,previous_deadline_ns=previous)
def raw(x):return json.dumps(x,sort_keys=True,separators=(',',':')).encode()
def thaw(x):
 if isinstance(x,Mapping):return {k:thaw(v)for k,v in x.items()}
 if isinstance(x,tuple):return [thaw(v)for v in x]
 if hasattr(x,'__dataclass_fields__'):return {k:thaw(getattr(x,k))for k in x.__dataclass_fields__}
 return x
results=[]
def run(name,inputs,fn):
 (O/(name+'.input.json')).write_bytes(raw(inputs))
 try:r=fn();passed=True;output=thaw(r)
 except Exception as e:passed=False;output=dict(exception=type(e).__name__,message=str(e))
 (O/(name+'.output.json')).write_bytes(raw(output));row=dict(case=name,passed=passed,input_sha256=hashlib.sha256(raw(inputs)).hexdigest(),output_sha256=hashlib.sha256(raw(output)).hexdigest());results.append(row);print(json.dumps(row),flush=True)
def validate(d,b,now):return host.validate_message(raw(d),producer='ai_controller',context=ctx,now_ns=now,consumer='world_authority',enable_completion_interval=True,completion_bounds=b)
def unavailable(fn):
 try:fn()
 except ValueError as e:return dict(exception=type(e).__name__,message=str(e))
 raise AssertionError('expected ValueError, accepted')
def default():
 d=doc();d['schema_version']=1;d['completed_monotonic_ns']=N;del d['basis'];del d['completion_observed_interval_ns'];args=dict(producer='ai_controller',context=ctx,now_ns=U+1,consumer='world_authority')
 a=old.validate_message(raw(d),**args);b=host.validate_message(raw(d),**args);assert a.__dict__==b.__dict__;assert 'deepeye_completion_interval'not in sys.modules;return dict(default_equal=True,document=b.document)
run('v1-retains-unbounded-caller-now-default',dict(now_ns=U+1),default)
def nearmax():
 d=doc(U-2_000_000,U-1_000_000);b=bounds(2_000_000,U,U);c=validate(d,b,U-1_000_000);assert c.valid_until_ns==U
 f=sys.modules['deepeye_completion_interval'].adapt_action_candidate(c,host_issue_ns=U-1_000_000,now_ns=U-1_000_000,previous_deadline_ns=None);assert f.deadline_ns==U and f.authority=='none';return f
run('uint63-exact-cap-and-duration-equality',dict(document=doc(U-2_000_000,U-1_000_000),bounds=bounds(2_000_000,U,U),now=U-1_000_000),nearmax)
def previous():
 c=validate(doc(U-2_000_000,U-1_000_000),bounds(2_000_000,U,U),U-1_000_000)
 return unavailable(lambda:sys.modules['deepeye_completion_interval'].adapt_action_candidate(c,host_issue_ns=U-1_000_000,now_ns=U-1_000_000,previous_deadline_ns=U-1))
run('previous-action-cap-one-ns-short',dict(previous_deadline_ns=U-1,now=U-1_000_000),previous)
def nonrenewal():
 b=bounds(previous=N+60_000_000);a=validate(doc(upper=N+40_000_000),b,N+40_000_000);z=validate(doc(upper=N+50_000_000),b,N+50_000_000);assert a.valid_until_ns==z.valid_until_ns==N+60_000_000
 return dict(first=thaw(a),later=thaw(z))
run('later-observation-cannot-extend-minimum',dict(lower=N,uppers=[N+40_000_000,N+50_000_000],bounds=bounds(previous=N+60_000_000)),nonrenewal)
run('previous-cap-exact-expiry',dict(document=doc(upper=N+60_000_000),bounds=bounds(previous=N+60_000_000),now=N+60_000_000),lambda:unavailable(lambda:validate(doc(upper=N+60_000_000),bounds(previous=N+60_000_000),N+60_000_000)))
def detached():
 d=doc(duration=10);b=bounds(source=N+30_000_000);c=validate(d,b,N+10_000_000);b['source_deadline_ns']=U;d['target']['duration_ms']=1;assert c.valid_until_ns==N+30_000_000 and c.document['target']['duration_ms']==10 and c.bounds['source_deadline_ns']==N+30_000_000
 try:c.document['target']['duration_ms']=1
 except TypeError:pass
 else:raise AssertionError('mutable validated target')
 result=unavailable(lambda:sys.modules['deepeye_completion_interval'].adapt_action_candidate(c,host_issue_ns=N+25_000_000,now_ns=N+25_000_000,previous_deadline_ns=None));result['retained']=thaw(c);return result
run('detached-inputs-and-delayed-duration',dict(document=doc(duration=10),bounds=bounds(source=N+30_000_000),validation_now=N+10_000_000,issue_now=N+25_000_000),detached)
def one_ns():
 c=validate(doc(N,N),bounds(1,N+1,N+1),N);assert c.valid_until_ns==N+1
 return dict(candidate=thaw(c),action=unavailable(lambda:sys.modules['deepeye_completion_interval'].adapt_action_candidate(c,host_issue_ns=N,now_ns=N,previous_deadline_ns=None)))
run('zero-width-observed-interval-one-ns-validity',dict(document=doc(N,N),bounds=bounds(1,N+1,N+1),now=N),one_ns)
run('checked-addition-at-uint63-max',dict(document=doc(U,U),bounds=bounds(1,U,U),now=U),lambda:unavailable(lambda:validate(doc(U,U),bounds(1,U,U),U)))
assert not any(n.startswith('competition.')or 'frozen_c28'in n or n.startswith('_c37')for n in sys.modules)
(O/'results.json').write_text(json.dumps(results,indent=2),encoding='utf8');raise SystemExit(0 if all(r['passed']for r in results)else 1)
