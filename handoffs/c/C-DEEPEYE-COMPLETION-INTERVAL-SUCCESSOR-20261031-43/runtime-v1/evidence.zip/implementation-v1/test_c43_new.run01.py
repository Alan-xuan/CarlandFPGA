"""NEW C43 interval/default compatibility controls; no old suites or core."""
import copy,dataclasses,hashlib,importlib.util,json,sys,unittest
from pathlib import Path
D=Path(__file__).resolve().parent

def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
baseline=load('c43_baseline',D/'baseline/integration/host_envelope.py')
patched=load('c43_patched',D/'patched/integration/host_envelope.py')
BASE=(1<<62)+123456789
CTX=dict(session=7,config_epoch=2,boot_sha256='a'*64,transport_profile_id=1,source_id=1,topology_id=2,acquisition_profile_id=1)

def candidate():return dict(schema_version=2,context=copy.deepcopy(CTX),kind='model_candidate',candidate_id=5,model_sha256='b'*64,observation=dict(context=copy.deepcopy(CTX),observed_seq=7),target=dict(action=1,yaw_q=0,pitch_q=0,speed_code=1,duration_ms=10),completion_observed_interval_ns=dict(lower_ns=BASE,upper_ns=BASE+20_000_000),basis='host_dispatch_to_complete_result_observed_v1')
def bounds():return dict(max_age_ns=100_000_000,source_deadline_ns=BASE+80_000_000,dispatch_deadline_ns=BASE+70_000_000,previous_deadline_ns=None)
def raw(x):return json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def call(doc=None,policy='DEFAULT',now=BASE+25_000_000,**kwargs):
 return patched.validate_message(raw(candidate() if doc is None else doc),producer='ai_controller',context=CTX,now_ns=now,consumer='world_authority',enable_completion_interval=True,completion_bounds=bounds() if policy=='DEFAULT' else policy,**kwargs)
class NewC43(unittest.TestCase):
 def test01_default_scalar_compatibility_and_no_new_module_load(self):
  self.assertNotIn('deepeye_completion_interval',sys.modules)
  c=candidate();c['schema_version']=1;c['completed_monotonic_ns']=BASE;del c['completion_observed_interval_ns'];del c['basis']
  args=dict(producer='ai_controller',context=CTX,now_ns=BASE+25_000_000,consumer='world_authority')
  a=baseline.validate_message(raw(c),**args);b=patched.validate_message(raw(c),**args)
  self.assertEqual(a.__dict__,b.__dict__);self.assertNotIn('deepeye_completion_interval',sys.modules)
  c['completed_monotonic_ns']=BASE+30_000_000
  for m in (baseline,patched):
   with self.assertRaises(ValueError):m.validate_message(raw(c),**args)
  with self.assertRaises(ValueError):patched.validate_message(raw(candidate()),**args)
 def test02_opt_in_strict_schema_and_same_original_defs(self):
  checked=call();self.assertEqual(checked.valid_until_ns,BASE+70_000_000)
  m=sys.modules['deepeye_completion_interval'];schema=m._schema(patched)
  self.assertEqual(schema,json.loads((D/'completion_interval.schema.json').read_bytes()))
  original=baseline._sealed_schema()
  for key,value in original['$defs'].items():self.assertEqual(schema['$defs'][key],value)
  self.assertNotIn('completed_monotonic_ns',checked.document)
  with self.assertRaises(TypeError):checked.document['target']['action']=0
  with self.assertRaises(dataclasses.FrozenInstanceError):checked.valid_until_ns=0
 def test03_missing_unknown_mixed_and_fixed_basis(self):
  base=candidate()
  for name in base:
   c=copy.deepcopy(base);del c[name]
   with self.subTest(missing=name):
    with self.assertRaises(ValueError):call(c)
  for key,value in [('completed_monotonic_ns',BASE),('unknown',0),('basis','cpu_finished'),('schema_version',1),('schema_version',True)]:
   c=copy.deepcopy(base);c[key]=value
   with self.assertRaises(ValueError):call(c)
  c=candidate();c['completion_observed_interval_ns']['extra']=1
  with self.assertRaises(ValueError):call(c)
 def test04_original_gates_not_bypassed(self):
  mutations=[lambda c:c['context'].update(session=8),lambda c:c['observation']['context'].update(config_epoch=3),lambda c:c.update(observation=None),lambda c:c['target'].update(speed_code=21),lambda c:c['target'].update(yaw_q=15000),lambda c:c['target'].update(duration_ms=3001),lambda c:c['target'].update(action=True),lambda c:c.update(truth=1)]
  for change in mutations:
   c=candidate();change(c)
   with self.assertRaises(ValueError):call(c)
  with self.assertRaises(ValueError):patched.validate_message(raw(candidate()),producer='hardware_bridge',context=CTX,now_ns=BASE+25_000_000,enable_completion_interval=True,completion_bounds=bounds())
  with self.assertRaises(ValueError):patched.validate_message(raw(candidate()),producer='ai_controller',consumer='unknown',context=CTX,now_ns=BASE+25_000_000,enable_completion_interval=True,completion_bounds=bounds())
 def test05_uint63_order_future_and_overflow(self):
  for lower,upper in [(True,BASE),(float(BASE),BASE),(BASE+2,BASE+1),(-1,BASE),(BASE,1<<63),(BASE,BASE+25_000_001)]:
   c=candidate();c['completion_observed_interval_ns']=dict(lower_ns=lower,upper_ns=upper)
   with self.assertRaises(ValueError):call(c)
  c=candidate();c['completion_observed_interval_ns']=dict(lower_ns=(1<<63)-50_000_000,upper_ns=(1<<63)-49_999_999)
  b=bounds();b.update(source_deadline_ns=(1<<63)-1,dispatch_deadline_ns=(1<<63)-1)
  with self.assertRaises(ValueError):call(c,b,now=(1<<63)-49_999_999)
 def test06_expiry_lower_boundary_and_no_upper_renewal(self):
  b=bounds();b.update(source_deadline_ns=BASE+200_000_000,dispatch_deadline_ns=BASE+200_000_000)
  c=candidate();c['completion_observed_interval_ns']['upper_ns']=BASE+99_999_999
  self.assertEqual(call(c,b,now=BASE+99_999_999).valid_until_ns,BASE+100_000_000)
  for now in (BASE+100_000_000,BASE+100_000_001):
   c['completion_observed_interval_ns']['upper_ns']=now
   with self.assertRaises(ValueError):call(c,b,now=now)
  c=candidate();x=call(c);c['completion_observed_interval_ns']['upper_ns']=BASE+25_000_000
  self.assertEqual(call(c).valid_until_ns,x.valid_until_ns)
 def test07_each_original_cap_and_missing_previous_distinction(self):
  for name in ('source_deadline_ns','dispatch_deadline_ns','previous_deadline_ns'):
   b=bounds();b[name]=BASE+30_000_000;self.assertEqual(call(policy=b).valid_until_ns,BASE+30_000_000)
   b[name]=BASE+25_000_000
   with self.assertRaises(ValueError):call(policy=b)
  for name in bounds():
   b=bounds();del b[name]
   with self.assertRaises(ValueError):call(policy=b)
  self.assertIsNone(call().bounds['previous_deadline_ns'])
  for b in (None,dict(bounds(),source_deadline_ns=None),dict(bounds(),dispatch_deadline_ns=None)):
   with self.assertRaises(ValueError):call(policy=b)
  for age in (0,100_000_001,True,1.0):
   with self.assertRaises(ValueError):call(policy=dict(bounds(),max_age_ns=age))
 def test08_concrete_finite_action_candidate_and_no_duration_extension(self):
  c=call();m=sys.modules['deepeye_completion_interval']
  x=m.adapt_action_candidate(c,host_issue_ns=BASE+25_000_000,now_ns=BASE+25_000_000,previous_deadline_ns=None)
  self.assertEqual(x.deadline_ns,BASE+35_000_000);self.assertEqual(x.authority,'none');self.assertEqual(x.candidate.document['target'],c.document['target'])
  self.assertFalse(hasattr(x,'motion_grant'));self.assertFalse(hasattr(x,'completed_monotonic_ns'))
  for issue,now,previous in ((BASE+65_000_000,BASE+65_000_000,None),(BASE+25_000_000,BASE+25_000_000,BASE+34_999_999),(BASE+30_000_000,BASE+29_999_999,None),(BASE+24_999_999,BASE+25_000_000,None),(BASE+60_000_000,BASE+70_000_000,None)):
   with self.assertRaises(ValueError):m.adapt_action_candidate(c,host_issue_ns=issue,now_ns=now,previous_deadline_ns=previous)
  with self.assertRaises(TypeError):m.adapt_action_candidate(c,host_issue_ns=BASE+25_000_000,now_ns=BASE+25_000_000)
 def test09_stop_keeps_original_null_observation_without_positive_lease(self):
  c=candidate();c['target']=dict(action=0,yaw_q=0,pitch_q=0,speed_code=0,duration_ms=0);c['observation']=None
  checked=call(c);m=sys.modules['deepeye_completion_interval']
  x=m.adapt_action_candidate(checked,host_issue_ns=BASE+200_000_000,now_ns=BASE+200_000_000,previous_deadline_ns=None)
  self.assertIsNone(x.deadline_ns);self.assertEqual(x.candidate.document['target']['action'],0)
  c['target']['speed_code']=1
  with self.assertRaises(ValueError):call(c)
 def test10_runtime_default_forwarding_and_explicit_switch_types(self):
  m=sys.modules['deepeye_completion_interval'];c=candidate();c['schema_version']=1;c['completed_monotonic_ns']=BASE;del c['completion_observed_interval_ns'];del c['basis']
  args=dict(legacy=baseline,producer='ai_controller',context=CTX,now_ns=BASE+25_000_000)
  result=m.validate_message(raw(c),**args);self.assertEqual(result.document,c)
  with self.assertRaises(ValueError):m.validate_message(raw(c),bounds=bounds(),**args)
  for flag in (1,None,'yes'):
   with self.assertRaises(ValueError):m.validate_message(raw(candidate()),enable_interval=flag,bounds=bounds(),**args)
 def test11_duplicate_bytes_and_high_exact_ns_retained(self):
  c=candidate();r=raw(c)
  for bad in (b'{"basis":"x",'+r[1:],r+b' x',b'x'*16385):
   with self.assertRaises(ValueError):patched.validate_message(bad,producer='ai_controller',context=CTX,now_ns=BASE+25_000_000,enable_completion_interval=True,completion_bounds=bounds())
  checked=call();self.assertEqual(checked.document['completion_observed_interval_ns']['lower_ns'],BASE)
  self.assertEqual(checked.valid_until_ns-BASE,70_000_000)
  (D/'synthetic-candidate.json').write_bytes(r)
if __name__=='__main__':unittest.main(verbosity=2)
