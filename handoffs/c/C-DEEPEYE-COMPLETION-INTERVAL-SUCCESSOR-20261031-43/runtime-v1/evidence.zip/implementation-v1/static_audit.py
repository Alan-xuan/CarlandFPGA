from pathlib import Path
import ast,hashlib,json,difflib
D=Path(__file__).resolve().parent;S=D.parent/'main/inputs';sha=lambda b:hashlib.sha256(b).hexdigest()
old=(S/'host_envelope.py').read_text();new=(D/'patched/integration/host_envelope.py').read_text();a=ast.parse(old);b=ast.parse(new)
defs=lambda t:{n.name:n for n in t.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
af,bf=defs(a),defs(b);assert set(af)==set(bf)
changed=[]
for name in af:
 if ast.dump(af[name],include_attributes=False)!=ast.dump(bf[name],include_attributes=False):changed.append(name)
assert changed==['validate_message']
x,y=af['validate_message'],bf['validate_message'];index=next(i for i,n in enumerate(y.body) if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='schema')
assert [ast.dump(n,include_attributes=False) for n in x.body[1:]]==[ast.dump(n,include_attributes=False) for n in y.body[index:]]
assert (D/'completion_interval.py').read_bytes()==(D/'patched/integration/completion_interval.py').read_bytes()
for root in ('baseline','patched'):
 for name in ('host_contract.json','host_timing_contract.md'):assert (D/root/'docs'/name).read_bytes()==(S/name).read_bytes()
 for name in ('wire.py','motion.py'):assert (D/root/'integration'/name).read_bytes()==(D/'dependencies'/name).read_bytes()
# Standalone timing successor specification is separate from old v1 docs.
readme=(D/'README.md').read_text(encoding='utf-8-sig');spec=readme[:readme.index('## Evidence and integration limits')]
(D/'host_completion_interval_v2.md').write_text(spec,encoding='utf-8',newline='\n')
patch=(D/'host_envelope.py.patch').read_text()
for source,target in [('completion_interval.py','competition/deepeye/integration/completion_interval.py'),('completion_interval.schema.json','competition/deepeye/docs/completion_interval.schema.json'),('host_completion_interval_v2.md','competition/deepeye/docs/host_completion_interval_v2.md')]:
 patch+=''.join(difflib.unified_diff([], (D/source).read_text().splitlines(True),fromfile='/dev/null',tofile='b/'+target))
(D/'completion-interval-successor.patch').write_text(patch,encoding='utf-8',newline='\n')
api=dict(abi_id='host_completion_interval_successor_v2',runtime='completion_interval.py',host_patch='completion-interval-successor.patch',schema='completion_interval.schema.json',base_A_commit='42f3de654aef3d52300ae1cfb16e3ac512ea2cea',base_host_sha256=sha((S/'host_envelope.py').read_bytes()),runtime_sha256=sha((D/'completion_interval.py').read_bytes()),default='original scalar/v1 behavior, no successor import',opt_in_host_keywords={'enable_completion_interval':True,'completion_bounds':'exactdict max_age_ns/source_deadline_ns/dispatch_deadline_ns/previous_deadline_ns'},standalone_entry='validate_message(raw_bytes, *, legacy, producer, context, now_ns, consumer=None, enable_interval=False, bounds=None)',downstream_entry='adapt_action_candidate(candidate, *, host_issue_ns, now_ns, previous_deadline_ns)',version=2,kind='model_candidate',basis='host_dispatch_to_complete_result_observed_v1',time='exact uint63, ordered closed observation interval, upper<=now',validity='exclusive min(lower+max_age, source_deadline, dispatch_deadline, explicit previous if present)>now',max_age_ns_limit=100000000,overflow='reject checked additions, no wrapping or saturation',downstream_duration='full exact target duration must fit; refuse rather than truncate or renew',STOP='original zero target and null observation allowed; downstream deadline None, no positive lease',completion_scalar_synthesized=False,authority='none')
(D/'API.json').write_text(json.dumps(api,indent=2)+'\n')
record=dict(original_functions=len(af),changed_functions=changed,old_validate_body_AST_identical_after_optin_branch=True,original_schema_and_timing_bytes_unchanged=True,wire_motion_bytes_unchanged=True,runtime_sha256=api['runtime_sha256'],host_patch_sha256=sha((D/'host_envelope.py.patch').read_bytes()),complete_patch_sha256=sha((D/'completion-interval-successor.patch').read_bytes()),schema_sha256=sha((D/'completion_interval.schema.json').read_bytes()),public_deployment_modified=False)
(D/'static-audit.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
