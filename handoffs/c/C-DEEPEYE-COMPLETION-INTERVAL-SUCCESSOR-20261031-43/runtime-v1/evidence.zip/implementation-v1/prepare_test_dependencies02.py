from pathlib import Path
import os,sys,subprocess,json,hashlib,datetime,zipfile,email,re
D=Path(__file__).resolve().parent;old=D/'dependencies';assert not list((old/'wheels').iterdir())
D=old/'attempt02';D.mkdir();wheels=D/'wheels';vendor=D/'vendor';wheels.mkdir();vendor.mkdir()
(D/'authorization.json').write_text(json.dumps({'main_authorized_corrected_isolated_attempt':True,'prior_pip_subprocess_terminated':True,'prior_wheels_empty':True,'reason':'Confirmed inherited extra-index leakage in old command, not blind repeat','env_policy':'Remove PIP_* in child copy; PIP_CONFIG_FILE=os.devnull; never write global config'},indent=2))
env=dict(os.environ)
for key in list(env):
 if key.upper().startswith('PIP_'):del env[key]
env['PIP_CONFIG_FILE']=os.devnull
pins=['jsonschema==4.23.0','attrs==24.2.0','jsonschema-specifications==2024.10.1','referencing==0.35.1','rpds-py==0.20.0']
commands=[('download',25,[sys.executable,'-m','pip','--disable-pip-version-check','download',*pins,'--no-deps','--index-url','https://pypi.org/simple','--dest',str(wheels),'--only-binary=:all:','--no-cache-dir','--retries','0','--timeout','5','--verbose','--log',str(D/'pip-download.log')]),('install',15,[sys.executable,'-m','pip','--disable-pip-version-check','install',*pins,'--no-index','--find-links',str(wheels),'--target',str(vendor),'--no-compile','--ignore-installed','--no-cache-dir','--retries','0'])]
for name,timeout,argv in commands:
 rec=dict(argv=argv,start_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),timeout_seconds=timeout,child_PIP_CONFIG_FILE=env['PIP_CONFIG_FILE'],other_child_PIP_variables=[])
 try:
  p=subprocess.run(argv,capture_output=True,timeout=timeout,cwd=D,env=env);out,err=p.stdout,p.stderr;rec.update(exit_code=p.returncode,timed_out=False)
 except subprocess.TimeoutExpired as exc:out,err=exc.stdout or b'',exc.stderr or b'';rec.update(exit_code=None,timed_out=True)
 (D/(name+'.stdout')).write_bytes(out);(D/(name+'.stderr')).write_bytes(err);rec.update(end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest());(D/(name+'.command.json')).write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps(rec),flush=True)
 if rec['exit_code']!=0:raise SystemExit(1)
 if name=='download':
  log=(D/'pip-download.log').read_text();assert 'aliyun' not in log and 'ustc' not in log
rows=[]
log=(D/'pip-download.log').read_text()
for p in sorted(wheels.iterdir()):
 with zipfile.ZipFile(p) as z:info=email.message_from_bytes(z.read(next(n for n in z.namelist() if n.endswith('.dist-info/METADATA'))))
 urls=sorted(set(re.findall(r'https://files\.pythonhosted\.org/[^\s\)\"\']*'+re.escape(p.name),log)))
 assert urls,p.name
 rows.append(dict(filename=p.name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),name=info['Name'],version=info['Version'],original_download_urls=urls))
(D/'resolved-wheels.json').write_text(json.dumps({'wheels':rows,'index':'https://pypi.org/simple','installed_only_to':str(vendor),'original_environment_modified':False},indent=2)+'\n');print(json.dumps({'wheels':rows}),flush=True)
