from pathlib import Path
import json,hashlib,subprocess,datetime
D=Path(__file__).resolve().parent;R=D.parents[3]
a=json.loads((D.parent/'main/assignment-v1.json').read_bytes());comment=json.loads(Path(a['source_A_body_path']).read_bytes())
sha=lambda b:hashlib.sha256(b).hexdigest()
assert comment['id']==a['source_A_comment'] and comment['user']['id']==a['source_A_author'] and sha(comment['body'].encode())==a['source_A_body_sha256']
lock=json.loads((R/'.local/plan-20261014-final-c/immutable-f5989cd/immutable_scope.json').read_bytes());assert sha(json.dumps(lock['requirements'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())==a['requirements_sha256']
pins=json.loads(Path(a['source_inventory']).read_bytes())
for row in pins:assert sha(Path(row['local']).read_bytes())==row['sha256']
(D/'dependencies').mkdir();records=[]
for name in ('wire.py','motion.py'):
 argv=['gh','api','--method','GET','-H','Accept: application/vnd.github.raw+json','repos/carolwjade/CarlandFPGA/contents/competition/deepeye/integration/'+name+'?ref='+a['A_source_commit']]
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();p=subprocess.run(argv,capture_output=True,timeout=20)
 (D/'dependencies'/name).write_bytes(p.stdout);(D/'dependencies'/(name+'.stderr')).write_bytes(p.stderr)
 rec=dict(argv=argv,start_utc=start,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=p.returncode,timeout_seconds=20,bytes=len(p.stdout),sha256=sha(p.stdout),stderr_sha256=sha(p.stderr),git_blob=hashlib.sha1(b'blob '+str(len(p.stdout)).encode()+b'\0'+p.stdout).hexdigest())
 (D/'dependencies'/(name+'.command.json')).write_text(json.dumps(rec,indent=2)+'\n');records.append(rec)
 assert p.returncode==0
(D/'input-pins.json').write_text(json.dumps({'main_pins':pins,'dependency_GETs':records,'contract_verified':True,'A41_verified':True},indent=2)+'\n');print(json.dumps(records))
