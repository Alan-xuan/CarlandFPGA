from pathlib import Path
import subprocess,sys,hashlib,json,datetime,zipfile,email
D=Path(__file__).resolve().parent;deps=D/'dependencies';wheels=deps/'wheels';vendor=deps/'vendor';wheels.mkdir();vendor.mkdir()
commands=[('download',15,[sys.executable,'-m','pip','download','jsonschema==4.23.0','--index-url','https://pypi.org/simple','--dest',str(wheels),'--only-binary=:all:','--no-cache-dir','--retries','0','--timeout','5','--verbose','--log',str(deps/'pip-download.log')]),('install',10,[sys.executable,'-m','pip','install','jsonschema==4.23.0','--no-index','--find-links',str(wheels),'--target',str(vendor),'--no-compile','--no-cache-dir','--retries','0'])]
for name,timeout,argv in commands:
 r=dict(argv=argv,start_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),timeout_seconds=timeout)
 try:
  p=subprocess.run(argv,capture_output=True,timeout=timeout,cwd=D);out,err=p.stdout,p.stderr;r.update(exit_code=p.returncode,timed_out=False)
 except subprocess.TimeoutExpired as exc:out,err=exc.stdout or b'',exc.stderr or b'';r.update(exit_code=None,timed_out=True)
 (deps/(name+'.stdout')).write_bytes(out);(deps/(name+'.stderr')).write_bytes(err);r.update(end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest());(deps/(name+'.command.json')).write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
 if r['exit_code']!=0:raise SystemExit(1)
rows=[]
for p in sorted(wheels.iterdir()):
 with zipfile.ZipFile(p) as z:info=email.message_from_bytes(z.read(next(n for n in z.namelist() if n.endswith('.dist-info/METADATA'))))
 rows.append(dict(filename=p.name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),name=info['Name'],version=info['Version']))
log=(deps/'pip-download.log').read_text();import re
urls=sorted(set(re.findall(r'https://files\.pythonhosted\.org/[^\s\)]+\.whl(?:\?[^\s\)]*)?',log)))
(deps/'resolved-wheels.json').write_text(json.dumps({'wheels':rows,'download_urls':urls,'index':'https://pypi.org/simple','installed_only_to':str(vendor),'runtime_or_global_environment_modified':False},indent=2)+'\n');print(json.dumps({'wheels':rows,'download_URL_count':len(urls)}))
