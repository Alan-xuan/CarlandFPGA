from pathlib import Path
import json,hashlib,shutil,difflib
D=Path(__file__).resolve().parent;S=D.parent/'main/inputs'
sha=lambda b:hashlib.sha256(b).hexdigest()
schema=json.loads((S/'host_contract.json').read_bytes());digest=sha(json.dumps(schema,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())
p=D/'completion_interval.py';p.write_text(p.read_text(encoding='utf-8-sig').replace('SCHEMA_PIN_REPLACED_BY_GENERATOR',digest),encoding='utf-8',newline='\n')
# Reviewable integration tree is private; original inputs remain untouched.
for root in ('baseline','patched'):
 (D/root/'integration').mkdir(parents=True);(D/root/'docs').mkdir()
 for name in ('host_envelope.py',):shutil.copyfile(S/name,D/root/'integration'/name)
 for name in ('wire.py','motion.py'):shutil.copyfile(D/'dependencies'/name,D/root/'integration'/name)
 for name in ('host_contract.json','host_timing_contract.md'):shutil.copyfile(S/name,D/root/'docs'/name)
old=(S/'host_envelope.py').read_text()
needle='def validate_message(raw_bytes, *, producer, context, now_ns, consumer=None):'
replacement='def validate_message(raw_bytes, *, producer, context, now_ns, consumer=None,\n                     enable_completion_interval=False, completion_bounds=None):'
text=old.replace(needle,replacement);assert text!=old
anchor='    schema = _sealed_schema()\n    message_validator, context_validator = _validators()'
branch='''    if type(enable_completion_interval) is not bool:
        raise ValueError('enable_completion_interval must be bool')
    if enable_completion_interval:
        adapter = sys.modules.get('deepeye_completion_interval')
        if adapter is None:
            adapter = _load_sibling('deepeye_completion_interval', 'completion_interval.py')
        return adapter.validate_message(raw_bytes, legacy=sys.modules[__name__],
            producer=producer, context=context, now_ns=now_ns, consumer=consumer,
            enable_interval=True, bounds=completion_bounds)
    if completion_bounds is not None:
        raise ValueError('completion_bounds require explicit interval opt-in')
'''
assert text.count(anchor)==1;text=text.replace(anchor,branch+anchor)
(D/'patched/integration/host_envelope.py').write_text(text,encoding='utf-8',newline='\n')
shutil.copyfile(p,D/'patched/integration/completion_interval.py')
(D/'host_envelope.py.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),text.splitlines(True),fromfile='a/competition/deepeye/integration/host_envelope.py',tofile='b/competition/deepeye/integration/host_envelope.py')),encoding='utf-8')
# Schema successor generated directly from original defs, old v1 file unchanged.
schema['$id']='urn:carlandfpga:deepeye:host-model-candidate-completion-interval:v2';schema['title']='Explicit opt-in model candidate completion interval revision 2';schema['oneOf']=[{'$ref':'#/$defs/model_candidate_interval'}]
import copy
c=copy.deepcopy(schema['$defs']['model_candidate']);c['properties']['schema_version']={'const':2};del c['properties']['completed_monotonic_ns'];c['required'].remove('completed_monotonic_ns');c['properties']['completion_observed_interval_ns']={'$ref':'#/$defs/interval_ns'};c['properties']['basis']={'const':'host_dispatch_to_complete_result_observed_v1'};c['required']+=['completion_observed_interval_ns','basis'];schema['$defs']['model_candidate_interval']=c
(D/'completion_interval.schema.json').write_text(json.dumps(schema,indent=2)+'\n')
print(json.dumps({'runtime_sha256':sha(p.read_bytes()),'base_schema_canonical_sha256':digest,'patch_sha256':sha((D/'host_envelope.py.patch').read_bytes())}))
