from pathlib import Path
import sys,subprocess,json,hashlib,datetime
D=Path(__file__).resolve().parent;label=sys.argv[1];script=sys.argv[2]
sha=lambda b:hashlib.sha256(b).hexdigest();argv=[sys.executable,'-I','-B',str(D/script)]+sys.argv[3:]
r=dict(argv=argv,cwd=str(D),start_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),timeout_seconds=25,source_sha256=sha((D/'completion_interval.py').read_bytes()),patched_host_sha256=sha((D/'patched/integration/host_envelope.py').read_bytes()),test_sha256=sha((D/script).read_bytes()))
try:
 p=subprocess.run(argv,capture_output=True,timeout=25,cwd=D);out,err=p.stdout,p.stderr;r.update(exit_code=p.returncode,timed_out=False)
except subprocess.TimeoutExpired as exc:out,err=exc.stdout or b'',exc.stderr or b'';r.update(exit_code=None,timed_out=True)
(D/(label+'.stdout')).write_bytes(out);(D/(label+'.stderr')).write_bytes(err);r.update(end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),stdout_sha256=sha(out),stderr_sha256=sha(err));(D/(label+'.command-exit.json')).write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r));print(out.decode(errors='replace'));print(err.decode(errors='replace'));raise SystemExit(r['exit_code'] if r['exit_code'] is not None else 124)
