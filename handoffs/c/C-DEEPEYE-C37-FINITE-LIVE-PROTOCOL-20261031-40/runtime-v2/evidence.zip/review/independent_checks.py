"""Three NEW adjacent controls, fake byte transport only.
Usage: python -I -S -B independent_checks.py PACKAGE_DIR OUTPUT_DIR
No native transport construction, actor process, A import or author test import.
"""
import hashlib,importlib.util,json,pathlib,sys
P,O=map(pathlib.Path,sys.argv[1:]);O.mkdir(exist_ok=False)
assert hashlib.sha256((P/'c37_entry.py').read_bytes()).hexdigest()=='03446c7ae78605a90fe134d961700d377cadfbc8af629a879a317ddb5ca79930'
assert hashlib.sha256((P/'c37_package.py').read_bytes()).hexdigest()=='60e26bc8ae9ee0ba1fba8bcea358b4bfad8be2f3a58ccb360e767b6886d62f16'
spec=importlib.util.spec_from_file_location('independent_entry',P/'c37_entry.py');entry=importlib.util.module_from_spec(spec);spec.loader.exec_module(entry);package=entry.load_package()
original_globals=package._FROZEN.recommend.__globals__.copy();local_globals=package._CORE.__globals__.copy()
assert package._CORE.__code__ is package._FROZEN.recommend.__code__
def dump(name,data):(O/name).write_text(json.dumps(data,indent=2)+'\n',encoding='utf8')
def view(enabled=True):
 pose={'position_m':[0,0,0],'orientation_xyzw':[0,0,0,1]};ns=(1<<61)+971
 obs=dict(sample_id='c'*64,counts=[1700,2030,2070,0],quality=15,adc_qpc_ns=ns,em_qpc_ns=ns,adc_pose=pose,em_pose=pose)
 return dict(schema_version=1,projection_id='c36_c28_public_view_v1',enabled=enabled,now_qpc_ns=ns,pose=pose,goal_m=[0,0,8],observation=obs,history=[],executed_actions=[])
def envelope(n,enabled=True):return dict(abi=package.ABI,kind='recommend',echo_ids=dict(operation_id='C40-independent-adjacent',run_id='synthetic-only',actor_instance_id='no-native-process',invocation_id=n,tested_commit='d'*40,package_manifest_sha256='e'*64),enabled=enabled,input=view(enabled))
def raw(n,enabled=True):
 # Direct canonical encoding intentionally permits the UINT63+1 negative input.
 b=json.dumps(envelope(n,enabled),sort_keys=True,separators=(',',':')).encode();return (16380).to_bytes(4,'little')+b+b' '*(16380-len(b))
def frames(b):
 result=[];i=0
 while i<len(b):
  size=int.from_bytes(b[i:i+4],'little');assert size>0 and i+4+size<=len(b);result.append(json.loads(b[i+4:i+4+size]));i+=4+size
 return result
class BytesOnly:
 def __init__(self,stream):self.stream=stream;self.pos=0;self.output=bytearray();self.events=[];self.waits=0;self.closes=0
 def signal_ready(self):self.events.append(['ready'])
 def read(self,n):
  # Fragment request input differently from the author's full-chunk fixture.
  b=self.stream[self.pos:self.pos+min(n,4093)];self.pos+=len(b);self.events.append(['read',len(b),self.pos]);return b
 def write(self,b):self.output.extend(b);self.events.append(['write',len(b)]);return len(b)
 def wait_for_owner_teardown(self):self.waits+=1;self.events.append(['unexpected-wait-return'])
 def close(self):self.closes+=1;self.events.append(['close'])
rows=[]
def run(name,stream,k,core_expected,error_expected,wait_expected):
 (O/(name+'.input.wire')).write_bytes(stream);transport=BytesOnly(stream);calls=[];error=None
 def profile(frame,event,arg):
  if event=='call' and frame.f_code is package._CORE.__code__:calls.append(frame.f_globals is package._CORE.__globals__)
 sys.setprofile(profile)
 try:entry.serve(transport,16384,k,package)
 except Exception as exc:error=dict(type=type(exc).__name__,reason=str(exc))
 finally:sys.setprofile(None)
 output=bytes(transport.output);(O/(name+'.output.wire')).write_bytes(output);parsed=frames(output);dump(name+'.frames.json',parsed);dump(name+'.events.json',transport.events)
 assert error is not None and error['type']==error_expected,error
 assert len(calls)==core_expected and all(calls)
 assert transport.closes==1 and transport.waits==wait_expected
 assert len(parsed)==2 and [x['kind']for x in parsed]==['READY','RESULT']
 first=stream[:16384];identity=json.loads(first[4:])['echo_ids']
 assert all(x['echo_ids']==identity and x['request_wire_sha256']==hashlib.sha256(first).hexdigest() for x in parsed)
 assert parsed[1]['completion_grant'] is False and parsed[1]['authority']=='none'
 assert package._FROZEN.recommend.__globals__==original_globals and package._CORE.__globals__==local_globals
 row=dict(case=name,passed=True,core_calls=len(calls),ready_result_pairs=1,wait_calls=transport.waits,close_calls=transport.closes,consumed_input_bytes=transport.pos,input_bytes=len(stream),output_bytes=len(output),error=error,first_result_preserved=True,original_globals_stable=True,input_sha256=hashlib.sha256(stream).hexdigest(),output_sha256=hashlib.sha256(output).hexdigest(),native_runs=0)
 rows.append(row);print(json.dumps(row),flush=True)
run('uint63-exhaustion-after-first-result',raw((1<<63)-1)+raw(1<<63),2,1,'Rejected',0)
run('truncated-second-after-first-result',raw(9)+raw(10)[:-1],2,1,'ValueError',0)
run('owner-wait-return-is-terminal',raw(41,False),1,0,'RuntimeError',1)
dump('results.json',rows)
