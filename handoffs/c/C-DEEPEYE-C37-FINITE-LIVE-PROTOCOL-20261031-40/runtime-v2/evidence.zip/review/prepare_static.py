import ast,difflib,hashlib,json,pathlib
D=pathlib.Path(__file__).resolve().parent;A=json.loads((D.parent/'main/review-assignment-v1.json').read_bytes());S=pathlib.Path(A['source_directory']);W=D.parent.parent
def h(b):return hashlib.sha256(b).hexdigest()
def dump(n,x):(D/n).write_text(json.dumps(x,indent=2)+'\n',encoding='utf8')
assert h((S/'FINAL.json').read_bytes())==A['source_FINAL_sha256'];final=json.loads((S/'FINAL.json').read_bytes());assert h((S/'freeze.json').read_bytes())==final['freeze_sha256']
pins=[]
for name,pin in json.loads((S/'freeze.json').read_bytes())['files'].items():
 p=S/name;b=p.read_bytes();assert len(b)==pin['bytes'] and h(b)==pin['sha256'];pins.append(dict(path=str(p),**pin))
original=json.loads((S/'input-pins-and-dependencies.json').read_bytes());old=pathlib.Path(original['original_package']);new=S/'c37-owned-cpu-package-v2'
for name,sha in original['original_package_pins'].items():
 p=old/name;b=p.read_bytes();assert h(b)==sha;pins.append(dict(path=str(p),bytes=len(b),sha256=sha))
assert (old/'frozen_c28.py').read_bytes()==(new/'frozen_c28.py').read_bytes()
manifest=json.loads((new/'package-manifest.json').read_bytes())
for name,sha in manifest['files'].items():assert h((new/name).read_bytes())==sha
changes=[]
for name in ('c37_package.py','c37_entry.py'):
 aa=(old/name).read_text(encoding='utf8');bb=(new/name).read_text(encoding='utf8')
 (D/(name+'.diff')).write_text(''.join(difflib.unified_diff(aa.splitlines(True),bb.splitlines(True),fromfile='sealed-v1/'+name,tofile='final-v2/'+name)),encoding='utf8')
 def fs(s):return {n.name:ast.dump(n,include_attributes=False) for n in ast.walk(ast.parse(s))if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
 a,b=fs(aa),fs(bb);changes.append(dict(file=name,changed=[k for k in sorted(a.keys()&b.keys())if a[k]!=b[k]],added=sorted(b.keys()-a.keys()),removed=sorted(a.keys()-b.keys())))
assert changes[0]['changed']==['decode_request','make_request'] and changes[0]['added']==['fixed_request','request_identity']
oldinv=json.loads(pathlib.Path(original['runtime_inventory_reference']).read_bytes());inv=json.loads((S/'runtime-inventory-v2.json').read_bytes())
assert inv['files']==oldinv['files'] and len(inv['files'])==633
for row in inv['package_files']:
 p=new/row['path'];assert p.stat().st_size==row['bytes'] and h(p.read_bytes())==row['sha256']
helper=pathlib.Path(original['repaired_stager_reference']);assert h(helper.read_bytes())==original['repaired_stager_sha256']
expected=helper.read_text().replace("'--actor-stdio-v1','--max-invocations','1','--request-bytes','N'","'--actor-stdio-v2','--max-invocations','K','--request-bytes','16384'")
assert expected==(S/'stage_package.py').read_text()
a35=json.loads((S/'A35-original-comment.json').read_bytes());originalcomments=pathlib.Path(a35['source_file']).read_bytes();assert h(originalcomments)==a35['source_file_sha256']
pages=json.loads(originalcomments);comments=[comment for page in pages for comment in page];assert a35['comment'] in comments
assert a35['comment']['id']==6530717609 and a35['comment']['user']['id']==328016885 and h(a35['comment']['body'].encode())==a35['body_sha256']
scope=W.parent/'plan-20261014-final-c/immutable-f5989cd/immutable_scope.json';requirements=json.loads(scope.read_bytes())['requirements'];assert h(json.dumps(requirements,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())==A['requirements_sha256']
dump('source-pins-before.json',pins);dump('ast-deltas.json',changes)
logs=[]
for i in (1,2,3):
 base='run%02d'%i;command=json.loads((S/(base+'.command-exit.json')).read_bytes());logs.append(dict(run=base,command=command,stdout=(S/(base+'.stdout')).read_text(),stderr=(S/(base+'.stderr')).read_text()))
dump('author-raw-evidence.json',logs)
result=dict(source_pins_verified=len(pins),A35_original_verified=True,unchanged_core=True,runtime_rows_identical=633,runtime_rehashed=False,stage_executed=False,stage_bytes=sum(r['bytes']for r in inv['files']+inv['package_files']),helper_only_argument_template_changed=True,author_exits=[r['command']['exit_code']for r in logs],candidate_imports=0)
dump('static-verification.json',result);print(json.dumps(result))
