from pathlib import Path
import ast,hashlib,json,difflib
D=Path(__file__).resolve().parent;W=D.parents[1];S=W/'C37-20261031/implementation-v1';P=D/'c37-owned-cpu-package-v2'
sha=lambda b:hashlib.sha256(b).hexdigest()
inv=json.loads((S/'runtime-inventory.json').read_bytes());inv['status']='INHERITED_RUNTIME_PINS_NEW_V2_PACKAGE_NOT_STAGED_OR_REHASHED'
inv['package_files']=[dict(path=x.name,bytes=x.stat().st_size,sha256=sha(x.read_bytes())) for x in P.iterdir() if x.is_file()]
inv['inherited_inventory_sha256']=sha((S/'runtime-inventory.json').read_bytes())
(D/'runtime-inventory-v2.json').write_text(json.dumps(inv,indent=2)+'\n')
old=W/'C37-20261031/repair-stage-v1/stage_package.py'
s=old.read_text().replace("'--actor-stdio-v1','--max-invocations','1','--request-bytes','N'","'--actor-stdio-v2','--max-invocations','K','--request-bytes','16384'")
assert s!=old.read_text()
(D/'stage_package.py').write_text(s,encoding='utf-8',newline='\n')
(D/'stage_package.py.diff').write_text(''.join(difflib.unified_diff(old.read_text().splitlines(True),s.splitlines(True),fromfile='sealed-repaired-c37/stage_package.py',tofile='candidate-v2/stage_package.py')))
a=ast.parse((S/'c37-owned-cpu-package/c37_package.py').read_text());b=ast.parse((P/'c37_package.py').read_text())
f=lambda t:{n.name:ast.dump(n,include_attributes=False) for n in t.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
af,bf=f(a),f(b);changed=sorted(n for n in af if af[n]!=bf[n]);assert changed==['decode_request','make_request']
assert (S/'c37-owned-cpu-package/frozen_c28.py').read_bytes()==(P/'frozen_c28.py').read_bytes()
for n,h in json.loads((D/'input-pins-and-dependencies.json').read_bytes())['original_package_pins'].items():assert sha((S/'c37-owned-cpu-package'/n).read_bytes())==h
r=dict(kind='STATIC_CLOSURE_AND_UNCHANGED_CORE_CHECK',adapter_changed_original_functions=changed,adapter_added_functions=sorted(set(bf)-set(af)),other_original_functions_identical=True,frozen_core_identical=True,sealed_package_unchanged=True,runtime_files=len(inv['files']),runtime_bytes=sum(x['bytes'] for x in inv['files']),package_files=len(inv['package_files']),stage_bytes=sum(x['bytes'] for x in inv['files']+inv['package_files']),runtime_rehash=False,stage_executed=False,native_calls=0)
assert r['stage_bytes']<inv['actor_stage_max_bytes']
(D/'static-closure-check.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
