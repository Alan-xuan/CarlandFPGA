"""NEW C40 affected controls; synthetic fake transport, never native/old suites."""
import copy, hashlib, importlib.util, json, sys, threading, unittest
from pathlib import Path
D=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('c40_entry',D/'c37-owned-cpu-package-v2/c37_entry.py')
e=importlib.util.module_from_spec(spec);spec.loader.exec_module(e)
p=e.load_package()
BASE=(1<<62)+123456789

def pose():return {'position_m':[0,0,0],'orientation_xyzw':[0,0,0,1]}
def view(enabled=True):
    obs=dict(sample_id='a'*64,counts=[1740,2048,2048,0],quality=15,adc_qpc_ns=BASE,em_qpc_ns=BASE,adc_pose=pose(),em_pose=pose())
    return dict(schema_version=1,projection_id='c36_c28_public_view_v1',enabled=enabled,now_qpc_ns=BASE,pose=pose(),goal_m=[0,0,10],observation=obs,history=[],executed_actions=[])
def ids(n):return dict(operation_id='C40-synthetic',run_id='synthetic-not-proof',actor_instance_id='synthetic-no-owner',invocation_id=n,tested_commit='a'*40,package_manifest_sha256='b'*64)
def wire(n=1,v=None):
    v=view() if v is None else v
    return p.make_request(ids(n),v,enabled=v['enabled'])
def frames(raw):
    out=[];i=0
    while i<len(raw):
        n=int.from_bytes(raw[i:i+4],'little');out.append(json.loads(raw[i+4:i+4+n]));i+=4+n
    assert i==len(raw)
    return out
class Retired(BaseException):pass
class Fake:
    def __init__(self,requests,short=False,block=False):
        self.requests=requests;self.index=0;self.offset=0;self.outputs=[];self.buffer=bytearray();self.events=[]
        self.short=short;self.block=block;self.waiting=threading.Event();self.retire=threading.Event()
    def signal_ready(self):self.events.append('initialize')
    def read(self,n):
        assert 1<=n<=8192
        assert self.index==len(self.outputs),'read before prior pair complete'
        if self.index>=len(self.requests):raise AssertionError('extra read')
        raw=self.requests[self.index];chunk=raw[self.offset:self.offset+n];self.offset+=len(chunk)
        self.events.append(('read',self.index,len(chunk)))
        return chunk
    def write(self,raw):
        assert self.offset==16384,'unsolicited output'
        assert 1<=len(raw)<=8192
        self.events.append(('write',self.index,len(raw)));self.buffer.extend(raw)
        if self.short:return len(raw)-1
        # Do not parse incomplete frames.
        pos=0;count=0
        while pos+4<=len(self.buffer):
            size=int.from_bytes(self.buffer[pos:pos+4],'little')
            if pos+4+size>len(self.buffer):break
            count+=1;pos+=4+size
        if count==2:
            assert pos==len(self.buffer)
            self.outputs.append(bytes(self.buffer));self.buffer.clear();self.index+=1;self.offset=0
        return len(raw)
    def wait_for_owner_teardown(self):
        self.events.append('wait');self.waiting.set()
        if self.block:
            if not self.retire.wait(3):raise AssertionError('fake retirement timeout')
        raise Retired()
    def close(self):self.events.append('close')
def run(t,k):
    calls=[]
    def profile(frame,event,arg):
        if event=='call' and frame.f_code is p._FROZEN.recommend.__code__:calls.append(frame.f_globals)
    prior=sys.getprofile();sys.setprofile(profile)
    try:
        try:e.serve(t,16384,k,p)
        except Retired:pass
    finally:sys.setprofile(prior)
    return calls
class NewC40(unittest.TestCase):
    def test01_padding_exact_wire_hash_and_ascii_whitespace(self):
        w=wire();self.assertEqual(len(w),16384);self.assertEqual(w[:4],(16380).to_bytes(4,'little'))
        value=p.decode_request(w);c=p._dump(value)
        self.assertEqual(w[4:4+len(c)],c);self.assertEqual(w[4+len(c):],b' '*(16380-len(c)))
        alternate=w[:-4]+b'\t\r\n '
        self.assertEqual(p.decode_request(alternate),value)
        result=frames(p.process_wire(alternate))
        self.assertEqual([x['kind'] for x in result],['READY','RESULT'])
        self.assertTrue(all(x['request_wire_sha256']==hashlib.sha256(alternate).hexdigest() for x in result))
        self.assertNotEqual(hashlib.sha256(w).digest(),hashlib.sha256(alternate).digest())
    def test02_padding_boundary_and_bad_encoding(self):
        self.assertEqual(len(p.fixed_request(b'x'*16380)),16384)
        with self.assertRaises(p.Rejected):p.fixed_request(b'x'*16381)
        w=wire()
        for bad in (w[:-1],w+b' ',b'\x01\x00\x00\x00'+w[4:],w[:-1]+b'X',w[:-2]+b'\xc2\xa0'):
            with self.assertRaises(p.Rejected):p.decode_request(bad)
        value=p.decode_request(w);raw=json.dumps(value,sort_keys=True).encode()
        with self.assertRaises(p.Rejected):p.decode_request(p.fixed_request(raw))
    def test03_sixteen_serial_one_core_each_no_extra_read(self):
        t=Fake([wire(n) for n in range(1,18)])
        calls=run(t,16)
        self.assertEqual(len(calls),16);self.assertEqual(t.index,16);self.assertEqual(t.events[-2:],['wait','close'])
        self.assertEqual(t.events.count('initialize'),1)
        self.assertIs(p._CORE.__code__,p._FROZEN.recommend.__code__)
        self.assertEqual(set(p._CORE.__globals__),set(p._FROZEN.recommend.__globals__))
        self.assertEqual([k for k in p._CORE.__globals__ if p._CORE.__globals__[k] is not p._FROZEN.recommend.__globals__[k]],['_validate'])
        for n,output in enumerate(t.outputs,1):
            a,b=frames(output);self.assertEqual(a['echo_ids'],ids(n));self.assertEqual(b['echo_ids'],ids(n))
            self.assertTrue(b['core_ran']);self.assertFalse(b['completion_grant']);self.assertEqual(b['authority'],'none')
            self.assertEqual(b['result']['observation']['adc_qpc_ns'],BASE)
            self.assertNotIn('completed_monotonic_ns',b)
            self.assertLessEqual(len(output),18440)
    def test04_alive_after_final_until_fake_owner_retires(self):
        t=Fake([wire()],block=True);errors=[]
        def worker():
            try:run(t,1)
            except BaseException as exc:errors.append(type(exc).__name__)
        th=threading.Thread(target=worker)
        th.start()
        try:
            self.assertTrue(t.waiting.wait(2));self.assertTrue(th.is_alive())
            self.assertEqual(len(t.outputs),1);self.assertNotIn('close',t.events)
        finally:t.retire.set();th.join(3)
        self.assertFalse(th.is_alive());self.assertEqual(errors,[]);self.assertEqual(t.events[-1],'close')
    def test05_default_off_and_stale_stop_no_timestamp(self):
        off=view(False);env=dict(abi=p.ABI,kind='recommend',echo_ids=ids(1),input=off)
        a=p.fixed_request(p._dump(env));stale=view();stale['now_qpc_ns']+=100_000_001
        t=Fake([a,wire(2,stale)]);calls=run(t,2)
        self.assertEqual(len(calls),1)
        self.assertEqual(frames(t.outputs[0])[1]['status'],'DISABLED')
        b=frames(t.outputs[1])[1];self.assertEqual(b['result']['status'],'STOP')
        self.assertNotIn('completed_monotonic_ns',b)
    def test06_invalid_count_size_and_old_mode_before_transport(self):
        for k in (0,17,True):
            t=Fake([])
            with self.assertRaises(ValueError):e.serve(t,16384,k,p)
            self.assertEqual(t.events,[])
        t=Fake([])
        with self.assertRaises(ValueError):e.serve(t,100,1,p)
        self.assertEqual(t.events,[])
        self.assertEqual(e.main(['--actor-stdio-v1','--max-invocations','1','--request-bytes','16384','1','2','3']),64)
    def test07_serial_replay_or_context_change_terminal(self):
        for second in (wire(1),wire(3)):
            t=Fake([wire(1),second])
            with self.assertRaises(ValueError):run(t,2)
            self.assertEqual(len(t.outputs),1);self.assertNotIn('wait',t.events);self.assertEqual(t.events[-1],'close')
        value=p.decode_request(wire(2));value['echo_ids']['run_id']='different'
        t=Fake([wire(),p.fixed_request(p._dump(value))])
        with self.assertRaises(ValueError):run(t,2)
        self.assertEqual(len(t.outputs),1)
    def test08_partial_read_and_write_terminal_without_replay(self):
        t=Fake([wire()[:-1]])
        with self.assertRaises(ValueError):run(t,1)
        self.assertEqual(t.outputs,[]);self.assertEqual(t.events[-1],'close')
        t=Fake([wire()],short=True)
        with self.assertRaises(ValueError):run(t,1)
        self.assertEqual(sum(isinstance(x,tuple) and x[0]=='write' for x in t.events),1)
        self.assertNotIn('wait',t.events);self.assertEqual(t.events[-1],'close')
    def test09_malformed_public_rejects_core_zero_and_retains_lifetime(self):
        value=p.decode_request(wire());value['input']['truth']=1
        t=Fake([p.fixed_request(p._dump(value))]);self.assertEqual(run(t,1),[])
        self.assertEqual(frames(t.outputs[0])[1]['status'],'REJECTED');self.assertIn('wait',t.events)
    def test10_uint63_high_exact_age_and_fixed_wire_inputs(self):
        v=view();v['now_qpc_ns']=BASE+100_000_000
        internal=p._to_internal(v);self.assertEqual(p._from_internal(internal),v)
        self.assertEqual(internal['now_tick_ms']-internal['observation']['adc_tick_ms'],100)
        w=wire(v=v);(D/'synthetic-request.sha256').write_text(hashlib.sha256(w).hexdigest()+'\n')
        self.assertEqual(len(w),16384)
if __name__=='__main__':unittest.main(verbosity=2)
