"""NEW raw4 association behavior at the original-producer boundary.

Synthetic correlation objects stand in for B131's already checked decoder;
these tests prove custody/order/byte retention only, never CRC/physical origin.
"""
import types,hashlib,unittest
from test_c48_path_v2 import actual_parser_fixture,F

def trace_fixture():
    m,c,op,t,r,prod,b,init=actual_parser_fixture()
    op.check_source_config=lambda:object()
    origin=F.BASE-10000;r.source.source.origin_ns=origin
    context=r.c42_context
    context.update(operation_id='synthetic-g05',request_hash='a'*64,tested_commit='b'*40,
        boot_id='synthetic-boot',session_id='synthetic-session',tag=7)
    payload={'source':'synthetic'};draft={};r.book._samples.append(draft)
    token=types.SimpleNamespace(_book=r.book,_draft=draft,_ended=True);admission=object()
    refs=init.refs.copy();refs.pop('phase_receipt');refs.pop('client_result')
    refs.update(payload=payload,draft=draft,token=token,admission=admission)
    sf=dict(kind='source_admission',operation_id='synthetic-g05')
    se=types.SimpleNamespace(owner=prod,sequence=2,facts=sf,refs=refs)
    prod._history.append((se,sf,refs));prod.pending=[se]
    request=m._raw(dict(lineage={k:context[k] for k in ('operation_id','request_hash','tested_commit','boot_id','session_id','tag')}|dict(request_seq=1),
        scan=dict(origin_qpc_ns=origin,clock_domain_id=F.DOMAIN)))
    original=types.SimpleNamespace(request=request,source=m._raw(payload),companions=(b'a',b'b',b'c',b'd'))
    frame_rows=[];wire=b''
    for i in range(4):
        part=bytes([i+1])*35;wire+=part
        flags=dict(valid=i!=1,held=i==0,saturated=False,source_fault=False)
        point=dict(value=0 if i<2 else i,**flags)
        frame_rows.append(dict(channel=i,frame_bytes=35,frame_sha256=hashlib.sha256(part).hexdigest(),point=point,
            original_lane=dict(raw_sample_uint16=point['value'],mapped_flags=flags,source_qpc_ns=origin+100)))
    correlation=dict(status='FOUR_FRAME_CORRELATION_CONSISTENT',frames=frame_rows,
        retained=dict(original=original,companions=original.companions,wire=wire))
    Phase=type(r.init_receipt);p=Phase();p.__dict__.update(r.init_receipt.__dict__)
    p.kind='trace_scan';p.phase_index=2;p.request_id='trace';p.lower_qpc_ns=F.BASE+1000;p.upper_qpc_ns=F.BASE+1100;t[0]=F.BASE+1101
    p.request_raw=m._raw(dict(id='trace',kind='trace_scan',operation_id='synthetic-g05',payload={}))
    response=dict(id='trace',kind='trace_scan',operation_id='synthetic-g05',result={})
    p.response_raw=m._raw(response)
    tref=refs.copy();tref.update(phase_receipt=p,client_result=dict(raw_response=p.response_raw,correlation=correlation),
        preparation=types.SimpleNamespace(original=original),request=original.request,source_bytes=original.source,companions=original.companions)
    facts=dict(kind='trace_scan',operation_id='synthetic-g05',raw_response=p.response_raw,response=response,
        lower_qpc_ns=p.lower_qpc_ns,upper_qpc_ns=p.upper_qpc_ns,correlation=correlation)
    ev=types.SimpleNamespace(owner=prod,sequence=3,facts=facts,refs=tref)
    prod._history.append((ev,facts,tref));r.chain.phase_receipts+=(p,)
    return m,c,prod,ev,wire,original

class Raw4New(unittest.TestCase):
    def test_raw4_keeps_original_bytes_null_valid_zero_and_order(self):
        m,c,prod,event,wire,original=trace_fixture()
        record=c.retain_trace(event)
        self.assertIs(record.raw,wire);self.assertIs(record.request_raw,original.request)
        self.assertEqual(record.counts,(0,None,2,3));self.assertTrue(record.qualities[0][1])
        self.assertEqual(prod.next,4);self.assertEqual(len(c._source_events),1)
        self.assertEqual(c._phase_index,2);self.assertEqual(len(c._previous.phase_raws),1)
        self.assertIsNone(record.boot);self.assertEqual(c._health,[])
        with self.assertRaises(ValueError):m.checked_trace(record,None,now_ns=F.BASE+1200)
    def test_changed_returned_frame_fails_without_retry(self):
        m,c,prod,event,wire,original=trace_fixture()
        event.refs['client_result']['correlation']['retained']['wire']=b'x'+wire[1:]
        with self.assertRaises(ValueError):c.retain_trace(event)
        self.assertTrue(c._revoked);self.assertEqual(prod.next,4)
        with self.assertRaises(ValueError):c.retain_trace(event)

if __name__=='__main__':unittest.main(verbosity=2)
