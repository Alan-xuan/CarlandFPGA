"""NEW offline source-boundary mechanics, not original-source authentication.

No native imports, network, board, original suites, model or PDE execution.
The production source is AST loaded with dependency module doubles; no deployed
authentication registry/type is changed. This exercises new paths only.
"""
from pathlib import Path
import ast,types,sys,json,threading,hashlib,unittest
from dataclasses import dataclass
P=Path(__file__).resolve().parent
SOURCE=P.parent/'patched/competition/deepeye/simulation/authority/g05p_runtime_v1.py'

def load():
    name='c49test.simulation.authority.g05p_runtime_v1'
    for package in ('c49test','c49test.simulation','c49test.simulation.authority','c49test.integration',
                    'c49test.tools','c49test.tools.diagnostic'):
        m=types.ModuleType(package);m.__path__=[];sys.modules[package]=m
    w=types.ModuleType('c49test.integration.pc_direct_watchdog')
    w.PcDirectWatchdog=type('PcDirectWatchdog',(),{})
    sys.modules[w.__name__]=w
    m=types.ModuleType(name);sys.modules[name]=m
    exec(compile(SOURCE.read_bytes(),str(SOURCE),'exec'),m.__dict__)
    class Chain:pass
    class Phase:pass
    class Operation:
        def _check(self):self.checked+=1
        def claim_for_factory(self,config,capability,chain):
            if self.claimed:raise ValueError('claim twice')
            self.claimed=True
            if self.fail_claim:raise ValueError('original claim fails')
            assert config is self.config and capability is self.link and chain is self.chain
            return self.refs
    class Refs:pass
    class Producer:
        def _check(self):
            if self._failed or self._closed:raise ValueError('producer terminal')
        def take_pending_events(self):
            r=tuple(self.pending);self.pending=[];return r
        def pump_once(self):return self.take_pending_events()
    class Config:pass
    chainmod=types.ModuleType('c49test.tools.diagnostic.functional50_chain_v2_client_a')
    chainmod.ChainSessionV2=Chain;chainmod.OriginalPhaseReceipt=Phase;sys.modules[chainmod.__name__]=chainmod
    opmod=types.ModuleType('c49test.tools.diagnostic.original_g05_operation_binding_a')
    opmod.OriginalG05OperationBinding=Operation;opmod.OriginalG05FactoryRefs=Refs;sys.modules[opmod.__name__]=opmod
    prodmod=types.ModuleType('c49test.tools.diagnostic.original_chain_receipt_producer_a')
    prodmod.OriginalChainReceiptProducer=Producer
    def consume(event):
        p=event.owner
        if p.next!=event.sequence:raise ValueError('original event order')
        p.next+=1
        return event.facts,event.refs.copy()
    prodmod.consume_original_receipt=consume;sys.modules[prodmod.__name__]=prodmod
    configmod=types.ModuleType('c49test.simulation.authority.actor_composition')
    configmod.AuthorityConfig=Config;sys.modules[configmod.__name__]=configmod
    # C48 is not reimplemented: this narrow double isolates orchestration only.
    # An independent NEW real-C48 integration control must cover its actual IO.
    b=types.ModuleType('c49test.simulation.authority.g05_csr_bridge_v1')
    class DetachedFacts:pass
    b.DetachedFacts=DetachedFacts
    def validate(raw,**kwargs):
        d=json.loads(raw);r=DetachedFacts();r.authority='not_evaluated';r.kind=d['kind'];r.operation_id='op'
        r.deadline_selected_lower_board_monotonic_ns=20;r.deadline_board_monotonic_ns=120
        r.state='ACTIVE';r.fault=0;r.next_state=object();b.calls.append((raw,kwargs));return r
    b.calls=[];b.validate_session_v2=validate;sys.modules[b.__name__]=b
    return m,Chain,Phase,Operation,Refs,Producer,Config,b

def fixture():
    m,Chain,Phase,Operation,Refs,Producer,Config,b=load()
    t=[12];clock=lambda:t[0]
    cfg=Config();cfg.g05p_profile=m.G05Profile(b'{}',True)
    cap=types.SimpleNamespace();op=Operation();op.checked=0;op.claimed=False;op.fail_claim=False
    chain=Chain();chain.sequence=types.SimpleNamespace(closed=False);chain.duration=100;chain.identity=(1,)*13
    session=types.SimpleNamespace(_unknown=False,_closed=False)
    book=types.SimpleNamespace(_samples=[])
    source=types.SimpleNamespace(source=types.SimpleNamespace(state='NEW'))
    world=types.SimpleNamespace(source=source,operation_id='op')
    prod=Producer();prod._history=[];prod._failed=False;prod._closed=False;prod.next=1;prod.pending=[]
    op.config=cfg;op.chain=chain;op.link=cap;op.clock=clock
    op.origin=(None,None,clock,None,dict(policy_file_sha256=hashlib.sha256(b'{}').hexdigest()))
    r=Refs();r.world=world;r.source=source;r.chain=chain;r.session=session;r.producer=prod;r.link=cap;r.clock=clock;r.book=book
    r.c42_context=dict(clock_domain_id='d');r.legacy_context={};op.refs=r
    phase=Phase();phase.owner=chain;phase.phase_index=1;phase.kind='init';phase.request_id='init';phase.operation_id='op'
    phase.status='COMPLETE';phase.unknown=False;phase.lower_qpc_ns=10;phase.upper_qpc_ns=11
    phase.clock=clock;phase.session=session;phase.session_origin=op.origin
    phase.request_raw=m._raw(dict(id='init',kind='init',operation_id='op',payload=dict(duration_ns=100,max_commands=2,max_polls=64)))
    response=dict(id='init',kind='init',operation_id='op',result=dict(kind='init'))
    phase.response_raw=m._raw(response);r.init_receipt=phase;chain.phase_receipts=(phase,)
    refs=dict(world=world,functional_source=source,chain=chain,session=session,clock=clock,book=book,
              phase_receipt=phase,client_result=dict(raw_response=phase.response_raw))
    facts=dict(kind='init',operation_id='op',raw_response=phase.response_raw,response=response,lower_qpc_ns=10,upper_qpc_ns=11)
    event=types.SimpleNamespace(owner=prod,sequence=1,facts=facts,refs=refs);prod._history.append((event,facts,refs))
    m.attach_original_operation(cfg,op)
    return m,cfg,cap,op,clock,t,prod,r,event,b

class NewSlice(unittest.TestCase):
    def test_default_disabled_before_claim(self):
        m,cfg,cap,op,clock,*_=fixture();cfg.g05p_profile=m.G05Profile(b'{}')
        with self.assertRaises(ValueError):m.production_channels(cfg,cap,clock)
        self.assertFalse(op.claimed)
    def test_exact_claim_consumes_once_and_init_lower_caps(self):
        m,cfg,cap,op,clock,t,prod,r,event,b=fixture();c=m.production_channels(cfg,cap,clock)
        self.assertIs(c._init_event,event);self.assertEqual(prod.next,2);self.assertEqual(c._session_deadline_ns,110)
        self.assertEqual(len(b.calls),1)
        with self.assertRaises(ValueError):m.production_channels(cfg,cap,clock)
        t[0]=109;self.assertEqual(c.checkpoint(),109)
        t[0]=110
        with self.assertRaises(ValueError):c.checkpoint()
        t[0]=111
        with self.assertRaises(ValueError):c.checkpoint()
    def test_failed_claim_never_retries(self):
        m,cfg,cap,op,clock,*_=fixture();op.fail_claim=True
        with self.assertRaises(ValueError):m.production_channels(cfg,cap,clock)
        op.fail_claim=False
        with self.assertRaises(ValueError):m.production_channels(cfg,cap,clock)
    def test_pump_return_tuple_not_lost_no_phase_alias(self):
        m,cfg,cap,op,clock,t,prod,r,event,b=fixture();c=m.production_channels(cfg,cap,clock)
        for seq in (2,3):
            sample={};r.book._samples.append(sample);token=types.SimpleNamespace(_book=r.book,_draft=sample,_ended=True)
            refs=event.refs.copy();refs.update(token=token,draft=sample);refs.pop('phase_receipt');refs.pop('client_result')
            facts=dict(kind='source_admission',operation_id='op');e=types.SimpleNamespace(owner=prod,sequence=seq,facts=facts,refs=refs)
            prod._history.append((e,facts,refs));prod.pending.append(e)
        c.pump_pending();self.assertEqual(len(c._source_events),2);self.assertEqual(prod.next,4)
        self.assertEqual(c._phase_index,1);self.assertEqual(len(b.calls),1)
    def test_unknown_closed_or_producer_failure_latches(self):
        for target,field in (('session','_unknown'),('session','_closed'),('producer','_failed'),('producer','_closed')):
            with self.subTest(target=target,field=field):
                m,cfg,cap,op,clock,t,prod,r,event,b=fixture();c=m.production_channels(cfg,cap,clock)
                obj=r.session if target=='session' else prod;setattr(obj,field,True)
                with self.assertRaises(ValueError):c.checkpoint()
                setattr(obj,field,False)
                with self.assertRaises(ValueError):c.checkpoint()
    def test_event_replay_refused(self):
        m,cfg,cap,op,clock,t,prod,r,event,b=fixture();c=m.production_channels(cfg,cap,clock)
        with self.assertRaises(ValueError):c._consume(event)
        self.assertEqual(prod.next,2)

if __name__=='__main__':unittest.main(verbosity=2)
