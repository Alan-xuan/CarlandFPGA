"""NEW known partial integration must refuse before channel claim/acquisition."""
from pathlib import Path
import ast,types,sys,unittest
P=Path(__file__).resolve().parent
class Preflight(unittest.TestCase):
    def test_missing_full_path_refuses_before_claim(self):
        path=P.parent/'patched/competition/deepeye/simulation/authority/actor_composition.py'
        node=next(n for n in ast.parse(path.read_bytes()).body if isinstance(n,ast.FunctionDef) and n.name=='_production_channels')
        package='c49preflight.authority'
        for name in ('c49preflight',package):
            mod=types.ModuleType(name);mod.__path__=[];sys.modules[name]=mod
        gate=types.ModuleType(package+'.g05p_runtime_v1');calls=[]
        gate.production_channels=lambda *args:calls.append('claim')
        def unavailable():raise ValueError('raw4/C36 and mailbox full path missing')
        gate.require_activation_ready=unavailable;sys.modules[gate.__name__]=gate
        g=dict(__name__=package+'.actor_composition',__package__=package,ActivationUnavailable=ValueError)
        exec(compile(ast.Module(body=[node],type_ignores=[]),str(path),'exec'),g)
        with self.assertRaises(ValueError):g['_production_channels'](types.SimpleNamespace(g05p_profile=object()))
        self.assertEqual(calls,[])
if __name__=='__main__':unittest.main(verbosity=2)
