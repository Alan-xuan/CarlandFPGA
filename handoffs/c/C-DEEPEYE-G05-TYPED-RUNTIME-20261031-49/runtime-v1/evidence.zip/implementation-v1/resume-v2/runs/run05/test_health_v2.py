"""NEW selected health behavior using original watchdog class code, no wire IO."""
import ast,copy,json,types,unittest
from dataclasses import dataclass
from test_c48_path_v2 import actual_parser_fixture,next_phase,F,P

def health_fixture():
    m,c,op,t,r,prod,builder,event=actual_parser_fixture()
    original=P/'inputs/competition/deepeye/integration/pc_direct_watchdog.py'
    tree=ast.parse(original.read_bytes())
    nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in ('_integer','StopGateDecision','PcDirectWatchdog')]
    g=dict(dataclass=dataclass,copy=copy,_context_copy=lambda x:copy.deepcopy(x))
    exec(compile(ast.Module(body=nodes,type_ignores=[]),str(original),'exec'),g)
    watchdog=types.SimpleNamespace(PcDirectWatchdog=g['PcDirectWatchdog'],_envelope=types.SimpleNamespace(_parse_message=json.loads))
    m.watchdog=watchdog
    code=ast.parse((P.parent/'patched/competition/deepeye/simulation/authority/g05p_runtime_v1.py').read_bytes())
    cls=next(n for n in code.body if isinstance(n,ast.ClassDef) and n.name=='G05HealthGate')
    exec(compile(ast.Module(body=[cls],type_ignores=[]),'actual-selected-G05HealthGate','exec'),m.__dict__)
    c._binding=m.G05SessionBinding(m._KEY,c,'synthetic',1,b'{"session":1}','synthetic-actor')
    p=c._init_receipt;c._initial_health=m.G05Health(m._KEY,c._binding,p,p.lower_qpc_ns,p.upper_qpc_ns,p.phase_index)
    c._health.append(c._initial_health)
    gate=m.G05HealthGate(binding=c._binding,heartbeat_timeout_ns=2000,now_ns=t[0])
    return m,c,op,t,r,prod,builder,gate

class HealthNew(unittest.TestCase):
    def test_status_only_health_never_command_or_session(self):
        m,c,op,t,r,prod,b,gate=health_fixture()
        gate.track_authority_command(command_seq=1,deadline_ns=F.BASE+1500,now_ns=t[0])
        event=next_phase(m,c,op,t,r,prod,b,'status');health=c.verify_board(event,c._binding)
        before=c._session_deadline_ns;gate.ingest_g05(health,now_ns=t[0])
        self.assertEqual(gate._command_deadline_ns,F.BASE+1500)
        self.assertEqual(gate._heartbeat_deadline_ns,F.BASE+3000)
        self.assertEqual(c._session_deadline_ns,before)
        self.assertIsNone(gate._heartbeat_tick_ms)
        with self.assertRaises(ValueError):gate.ingest_g05(health,now_ns=t[0])
        self.assertTrue(gate._latched)
    def test_late_status_cannot_revive_unpolled_health_expiry(self):
        m,c,op,t,r,prod,b,gate=health_fixture()
        event=next_phase(m,c,op,t,r,prod,b,'status');health=c.verify_board(event,c._binding)
        t[0]=F.BASE+2000
        with self.assertRaises(ValueError):gate.ingest_g05(health,now_ns=t[0])
        self.assertTrue(gate._latched)
        with self.assertRaises(ValueError):gate.reset()
        with self.assertRaises(ValueError):m.G05HealthGate(binding=c._binding,heartbeat_timeout_ns=2000,now_ns=t[0])

if __name__=='__main__':unittest.main(verbosity=2)
