"""NEW C49 -> released C48 integration; synthetic Root doubles, actual parser.

Imports fixture builders only; never executes C48's old test methods or A/native.
"""
from pathlib import Path
import importlib.util,sys,types,json,hashlib,unittest
from test_slice_v2 import fixture
P=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('c49_released_fixture',P/'c48-released/test_session_new.py')
F=importlib.util.module_from_spec(spec);sys.modules[spec.name]=F;spec.loader.exec_module(F)

def actual_parser_fixture():
    m,cfg,cap,op,clock,t,prod,r,event,_=fixture()
    sys.modules['c49test.simulation.authority.g05_csr_bridge_v1']=F.V
    cfg.g05p_profile=m.G05Profile(F.POLICY,True)
    op.origin[4]['policy_file_sha256']=hashlib.sha256(F.POLICY).hexdigest()
    r.session._check=lambda:None
    r.world.operation_id='synthetic-g05';r.c42_context['clock_domain_id']=F.DOMAIN
    builder=F.Builder();doc=F.phase(builder,'init')
    phase=r.init_receipt;phase.operation_id=r.world.operation_id
    phase.lower_qpc_ns=F.BASE;phase.upper_qpc_ns=F.BASE+100;t[0]=F.BASE+101
    r.chain.duration=10_000_000;r.chain.identity=F.IDENTITY
    phase.request_raw=m._raw(dict(id='init',kind='init',operation_id=r.world.operation_id,
        payload=dict(duration_ns=r.chain.duration,max_commands=2,max_polls=64)))
    response=dict(id='init',kind='init',operation_id=r.world.operation_id,result=doc)
    phase.response_raw=m._raw(response)
    event.refs['client_result']['raw_response']=phase.response_raw
    event.facts.update(operation_id=r.world.operation_id,response=response,raw_response=phase.response_raw,
        lower_qpc_ns=phase.lower_qpc_ns,upper_qpc_ns=phase.upper_qpc_ns)
    channel=m.production_channels(cfg,cap,clock)
    return m,channel,op,t,r,prod,builder,event

def next_phase(m,c,op,t,r,prod,builder,kind):
    Phase=type(r.init_receipt);p=Phase();p.__dict__.update(r.init_receipt.__dict__)
    p.kind=kind;p.phase_index=2;p.request_id=kind;p.lower_qpc_ns=F.BASE+1000;p.upper_qpc_ns=F.BASE+1100;t[0]=F.BASE+1101
    p.request_raw=m._raw(dict(id=kind,kind=kind,operation_id=r.world.operation_id,payload={}))
    doc=F.phase(builder,kind);response=dict(id=kind,kind=kind,operation_id=r.world.operation_id,result=doc)
    p.response_raw=m._raw(response)
    refs=prod._history[0][2].copy();refs.update(phase_receipt=p,client_result=dict(raw_response=p.response_raw))
    facts=dict(kind=kind,operation_id=r.world.operation_id,response=response,raw_response=p.response_raw,
        lower_qpc_ns=p.lower_qpc_ns,upper_qpc_ns=p.upper_qpc_ns)
    e=types.SimpleNamespace(owner=prod,sequence=prod.next,facts=facts,refs=refs)
    prod._history.append((e,facts,refs));r.chain.phase_receipts+=(p,)
    return e

class RealC48(unittest.TestCase):
    def test_original_c49_init_status_lower_deadline_real_c48(self):
        m,c,op,t,r,prod,builder,event=actual_parser_fixture()
        self.assertIs(type(c._init_facts),F.V.DetachedFacts)
        self.assertEqual((c._init_facts.phase_io_first,c._init_facts.phase_io_last),(5,39))
        self.assertEqual(c._session_deadline_ns,F.BASE+10_000_000)
        # Only this synthetic Root boundary fixture allocates the private result;
        # no production original source is authenticated by this software test.
        c._binding=m.G05SessionBinding(m._KEY,c,'test-run',1,b'{}','test-actor')
        ev=next_phase(m,c,op,t,r,prod,builder,'status');record=c.verify_board(ev,c._binding)
        self.assertEqual(record.lower_qpc_ns,F.BASE+1000)
        self.assertEqual(c._session_deadline_ns,F.BASE+10_000_000)
        self.assertEqual(len(c._previous.phase_raws),2)
    def test_actual_c48_rejection_retires_consumed_phase(self):
        m,c,op,t,r,prod,builder,event=actual_parser_fixture()
        c._binding=m.G05SessionBinding(m._KEY,c,'test-run',1,b'{}','test-actor')
        ev=next_phase(m,c,op,t,r,prod,builder,'status')
        ev.facts['response']['result']['phase_io_first']=1
        raw=m._raw(ev.facts['response']);ev.facts['raw_response']=raw
        ev.refs['phase_receipt'].response_raw=raw;ev.refs['client_result']['raw_response']=raw
        with self.assertRaises(F.V.Rejected):c.verify_board(ev,c._binding)
        self.assertTrue(c._revoked);self.assertEqual(prod.next,3)
        with self.assertRaises(ValueError):c.verify_board(ev,c._binding)

if __name__=='__main__':unittest.main(verbosity=2)
