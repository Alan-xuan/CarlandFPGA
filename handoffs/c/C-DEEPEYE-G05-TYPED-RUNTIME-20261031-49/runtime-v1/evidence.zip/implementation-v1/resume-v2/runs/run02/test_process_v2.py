"""NEW lost original transport containment; no original process is started."""
import unittest
from test_slice_v2 import fixture

class LostTransport(unittest.TestCase):
    def test_actual_session_liveness_gate_must_run(self):
        m,cfg,cap,op,clock,t,prod,refs,event,bridge=fixture()
        refs.session._check=lambda:None
        channel=m.production_channels(cfg,cap,clock)
        def exited():raise ValueError('original SSH already exited')
        refs.session._check=exited
        with self.assertRaises(ValueError):channel.checkpoint()
        self.assertTrue(channel._revoked)

if __name__=='__main__':unittest.main(verbosity=2)
