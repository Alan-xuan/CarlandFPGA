"""NEW usable pre-actor receipt-only status, with real C48 pure validator."""
import unittest
from test_c48_path_v2 import actual_parser_fixture,next_phase,F
class ReceiptOnly(unittest.TestCase):
    def test_status_before_actor_is_detached_not_health(self):
        m,c,op,t,r,prod,b,event=actual_parser_fixture()
        status=next_phase(m,c,op,t,r,prod,b,'status')
        facts,phase=c.retain_status(status)
        self.assertIs(type(facts),F.V.DetachedFacts)
        self.assertEqual(facts.authority,'not_evaluated')
        self.assertIs(phase,status.refs['phase_receipt'])
        self.assertIsNone(c._binding);self.assertEqual(c._health,[])
        self.assertEqual(c._session_deadline_ns,F.BASE+10_000_000)
if __name__=='__main__':unittest.main(verbosity=2)
