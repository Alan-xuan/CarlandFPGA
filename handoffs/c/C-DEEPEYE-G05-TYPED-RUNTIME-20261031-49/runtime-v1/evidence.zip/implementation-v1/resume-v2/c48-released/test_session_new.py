"""NEW exact A216 grammar controls with synthetic IO; no A/native execution."""
import copy,dataclasses,importlib.util,json,sys,unittest
from pathlib import Path
D=Path(__file__).resolve().parent
# Reuse only C48's unexecuted fixture helpers. Do not collect/run its old methods.
s=importlib.util.spec_from_file_location('c48_fixture',D/'test_g05_new.py');F=importlib.util.module_from_spec(s);sys.modules[s.name]=F;s.loader.exec_module(F)
V=F.V;raw=F.raw;IDENTITY=F.IDENTITY;CMD=F.COMMAND;POLICY=F.POLICY_RAW;DOMAIN=F.DOMAIN
BASE=(1<<62)+10000000

class Builder(F.Builder):
 def apply(self,cmd,seq):
  begin=len(self.receipts);cap=super().apply(cmd,seq);w=cap['words32']
  w[3]=(cmd[3]<<8)|cmd[2];w[4]=(cmd[1]<<16)|cmd[0];w[5]=cmd[4]
  applied=(1<<63)+seq*10000
  def put(i,n):w[i]=n&0xffffffff;w[i+1]=n>>32
  put(6,applied);put(8,applied+cmd[4]*50000);put(10,applied+120)
  for i in range(3):w[12+i]=100;w[15+i]=50;put(18+2*i,applied+10);put(24+2*i,applied+110)
  for r in self.receipts[begin:]:
   started=json.loads(bytes.fromhex(r['started_raw_hex']))
   if started['kind']=='read' and 0x300<=started['offset']<0x380:
    returned=json.loads(bytes.fromhex(r['returned_raw_hex']));returned['value']=w[(started['offset']-0x300)//4];r['returned_raw_hex']=raw(returned).hex()
  return cap
 def identity(self):
  for i,w in enumerate(IDENTITY):self.read(0x100+4*i,w)
 def status(self,status=1):self.read(8,status);self.read(16,0)

def phase(b,kind,*,cmd=None,seq=1,stop=False):
 before=len(b.receipts)
 if kind=='init':b.factory();before=4;b.init();b.status();status=1;cap=None
 elif kind=='apply':b.identity();cap=b.apply(cmd,seq);status=17
 elif kind=='status':b.identity();b.status();status=1;cap=None
 else:
  cap=None;status=None
  if stop:b.group([('write',12,3)]);b.read(8,3);b.read(16,0);status=3
 return dict(schema='g05_csr_session_v2',kind=kind,operation_id='synthetic-g05',policy_sha256=F.POLICY['policy_sha256'],identity_words=list(IDENTITY),deadline_selected_lower_board_monotonic_ns=10000,deadline_board_monotonic_ns=10010000,phase_io_first=before+1 if len(b.receipts)>before else None,phase_io_last=len(b.receipts) if len(b.receipts)>before else None,status=status,fault=0 if status is not None else None,capture=cap,receipts=copy.deepcopy(b.receipts),unresolved_receipts=[],state='CLOSED' if kind=='close' else 'ACTIVE',authority='not_evaluated')

def call(doc,previous=None,cmd=None,n=0,domain=DOMAIN):
 return V.validate_session_v2(raw(doc),policy_raw=POLICY,expected_identity=IDENTITY,expected_command=cmd,previous=previous,host_qpc_interval=(BASE+n*1000,BASE+n*1000+500),host_clock_domain=domain)

def save(name,doc):
 folder=D/'inputs-v2';folder.mkdir(exist_ok=True);(folder/(name+'.json')).write_bytes(raw(doc))

class SessionNew(unittest.TestCase):
 def test07_init_before_command_status_apply_close(self):
  b=Builder();init=phase(b,'init');save('valid-init',init);a=call(init)
  self.assertEqual(len(a.receipts),39);self.assertEqual(a.accepted_commands,());self.assertEqual((a.phase_io_first,a.phase_io_last),(5,39))
  status=phase(b,'status');a=call(status,a.next_state,n=1)
  apply=phase(b,'apply',cmd=CMD);save('valid-apply',apply);a=call(apply,a.next_state,CMD,2)
  self.assertEqual(a.status,17);self.assertEqual(a.captures[-1].cycles.tick_unit,'50MHz_cycles');self.assertGreater(a.captures[-1].cycles.applied_tick,1<<63)
  close=phase(b,'close');save('valid-close',close);a=call(close,a.next_state,n=3)
  self.assertEqual(a.state,'CLOSED');self.assertIsNone(a.status);self.assertIsNone(a.phase_io_first)
  with self.assertRaises(V.Rejected):call(close,a.next_state,n=4)
 def test08_exact_prefix_phase_identity_and_clock_domain(self):
  for label,change in (
   ('prefix-byte',lambda x:x['receipts'][0].update(started_raw_hex=(bytes.fromhex(x['receipts'][0]['started_raw_hex'])+b' ').hex())),
   ('phase-first',lambda x:x.update(phase_io_first=1)),
   ('phase-last',lambda x:x.update(phase_io_last=True)),
   ('renew-deadline',lambda x:x.update(deadline_board_monotonic_ns=x['deadline_board_monotonic_ns']+1)),
   ('identity',lambda x:x['identity_words'].__setitem__(12,14)),
   ('missing-status-identity',lambda x:x['receipts'].pop(40))):
   b=Builder();a=call(phase(b,'init'));doc=phase(b,'status');change(doc);save(label,doc)
   with self.assertRaises(V.Rejected):call(doc,a.next_state,n=1)
  b=Builder();a=call(phase(b,'init'));doc=phase(b,'status')
  with self.assertRaises(V.Rejected):call(doc,a.next_state,n=1,domain='other-qpc')
  with self.assertRaises(V.Rejected):call(doc,a.next_state,n=0)
 def test09_two_commands_explicit_stop_and_no_init_replay(self):
  b=Builder();initial=phase(b,'init');a=call(initial)
  with self.assertRaises(V.Rejected):call(initial,a.next_state,n=1)
  for n in (1,2):
   cmd=(0,0,1,4,20,n,700+n);a=call(phase(b,'apply',cmd=cmd,seq=n),a.next_state,cmd,n)
  self.assertEqual(len(a.captures),2);self.assertGreater(a.captures[1].cycles.applied_tick,a.captures[0].cycles.result_tick)
  before=a.next_state;close=phase(b,'close',stop=True);a=call(close,before,n=3);self.assertEqual((a.status,a.fault),(3,0));self.assertEqual(len(a.receipts)-len(json.loads(before.phase_raws[-1])['receipts']),3)
  cmd=(0,0,1,4,20,3,703);doc=phase(b,'apply',cmd=cmd,seq=3)
  with self.assertRaises(V.Rejected):call(doc,before,cmd,3)
 def test10_global_hidden_status_budget_boundary(self):
  # Init costs4. Use a compressed synthetic history with real cumulative IO:
  # 26 status phases reach430IO; next exceeds exact A218450 before64 reads.
  b=Builder();a=call(phase(b,'init'))
  for n in range(1,28):
   doc=phase(b,'status')
   if len(doc['receipts'])<=450:a=call(doc,a.next_state,n=n)
   else:
    with self.assertRaises(V.Rejected):call(doc,a.next_state,n=n)
  # Tight global budget with repeated polls in an apply (all original groups).
  b=Builder();a=call(phase(b,'init'));b.identity()
  start=len(b.receipts);cap=b.apply(CMD,1)
  rows=b.receipts;pollstart=start+15
  # Existing apply's status/fault poll is copied as new chronological groups.
  prefix=rows[:pollstart];tail=rows[pollstart:];b.receipts=prefix
  for _ in range(51):b.status(status=1)
  # Re-number original remaining rows and times, keeping each method's ID.
  for r in tail:
   s=json.loads(bytes.fromhex(r['started_raw_hex']));t=json.loads(bytes.fromhex(r['returned_raw_hex']));i=len(b.receipts)+1;s['io']=t['io']=i;b.time+=1;s['monotonic_ns']=b.time;b.time+=1;t['monotonic_ns']=b.time;b.receipts.append(dict(index=i,started_raw_hex=raw(s).hex(),returned_raw_hex=raw(t).hex()))
  doc=dict(json.loads(a.facts_raw),kind='apply',phase_io_first=40,phase_io_last=len(b.receipts),receipts=b.receipts,capture=cap,status=17)
  save('global65-status-reads',doc)
  with self.assertRaises(V.Rejected):call(doc,a.next_state,CMD,1)
 def test11_unresolved_failure_and_nullable_close_are_not_health(self):
  b=Builder();a=call(phase(b,'init'));doc=phase(b,'close');doc['state']='CLOSED_AFTER_FAILURE'
  doc['unresolved_receipts']=[dict(index=40,started_raw_hex=None,returned_raw_hex=None,not_attempted_raw_hex=None)];save('unresolved-close',doc)
  with self.assertRaises(V.Rejected):call(doc,a.next_state,n=1)
  doc['state']='CLOSED'
  with self.assertRaises(V.Rejected):call(doc,a.next_state,n=1)
  doc['unresolved_receipts']=[];doc['status']=1
  with self.assertRaises(V.Rejected):call(doc,a.next_state,n=1)
 def test12_layout32_cycle_consistency_and_transaction_successor(self):
  for label,idx,value in (('cycle-order',10,0),('measured-period',12,101),('zero-high',15,0),('incoherent-join',20,123),('submitted-metadata',3,0),('session-word',30,99)):
   b=Builder();a=call(phase(b,'init'));doc=phase(b,'apply',cmd=CMD);doc['capture']['words32'][idx]=value
   # Change the exact corresponding raw read too: catches semantic contradictions,
   # rather than merely comparing the two copies of a word.
   for r in doc['receipts']:
    s=json.loads(bytes.fromhex(r['started_raw_hex']))
    if s['kind']=='read' and s['offset']==0x300+4*idx:
     returned=json.loads(bytes.fromhex(r['returned_raw_hex']));returned['value']=value;r['returned_raw_hex']=raw(returned).hex()
   save(label,doc)
   with self.assertRaises(V.Rejected):call(doc,a.next_state,CMD,1)
  b=Builder();b.factory();b.init();cap=b.apply(CMD,1);doc=F.transaction();doc['captures']=[cap];doc['receipts']=b.receipts;save('valid-v1-layout32',doc)
  facts=V.validate_transaction_v1(raw(doc),policy_raw=POLICY,expected_identity=IDENTITY,expected_commands=(CMD,),stop_requested=False,host_qpc_interval=F.HOST,host_clock_domain=DOMAIN)
  self.assertGreater(facts.captures[0].cycles.applied_tick,1<<63);self.assertEqual(facts.authority,'not_evaluated')
if __name__=='__main__':unittest.main(verbosity=2)
