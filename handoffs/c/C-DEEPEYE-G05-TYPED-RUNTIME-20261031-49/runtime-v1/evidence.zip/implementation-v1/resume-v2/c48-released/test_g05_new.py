"""NEW synthetic receipt controls only; never import or call A's producer."""
import copy,hashlib,importlib.util,json,sys,unittest
from pathlib import Path
D=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('c48_bridge',D/'g05_csr_bridge_v1.py');V=importlib.util.module_from_spec(s);sys.modules[s.name]=V;s.loader.exec_module(V)
def raw(x):return json.dumps(x,sort_keys=True,separators=(',',':')).encode()
IDENTITY=(1,2,3,4,5,6,7,8,9,10,11,12,13)
COMMAND=(20,10,1,4,20,1,700)
HOST=((1<<62)+500,(1<<62)+900)
DOMAIN='synthetic-host-QPC-domain'
POLICY=dict(binding=dict(operation_id='synthetic-g05',request_sha256='a'*64,boot_id='11111111-1111-4111-8111-111111111111',source_commit='b'*40,build_id='c'*32),limits=dict(begin=1,commit=2,stop=1,latch=2,release=2,total_io=2048))
POLICY['policy_sha256']=hashlib.sha256(V._raw(POLICY)).hexdigest()
POLICY_RAW=raw(POLICY)

class Builder:
 def __init__(self):self.receipts=[];self.time=100;self.group_index=0
 def group(self,ops,rid=None):
  self.group_index+=1;rid=rid or ('tx-'+format(self.group_index,'032x'))
  for kind,offset,value in ops:
   index=len(self.receipts)+1;self.time+=1
   a=dict(request_id=rid,io=index,kind=kind,offset=offset,value=value if kind=='write' else None,pid=55,monotonic_ns=self.time);self.time+=1
   b=dict(request_id=rid,io=index,kind=kind,value=value if kind=='read' else None,monotonic_ns=self.time)
   self.receipts.append(dict(index=index,started_raw_hex=raw(a).hex(),returned_raw_hex=raw(b).hex()))
 def read(self,offset,value):self.group([('read',offset,value)])
 def factory(self):
  self.group([('read',0,V.MAGIC)],'factory-magic');self.group([('read',4,2)],'factory-layout');self.group([('read',8,0),('read',16,0)],'factory-status');self.time=10000
 def init(self):
  self.group([('read',8,0),('read',16,0)]+[('write',0x100+4*i,x) for i,x in enumerate(IDENTITY)])
  self.group([('read',8,0),('read',16,0),('write',12,1),('read',8,1),('read',16,0)])
  for i,x in enumerate(IDENTITY):self.read(0x100+4*i,x)
 def apply(self,cmd,seq):
  self.group([('read',8,1),('read',16,0)]+[('write',0x200+4*i,x) for i,x in enumerate(cmd)])
  self.group([('read',8,1),('read',16,0),('write',12,2),('read',20,cmd[5]),('read',8,1),('read',16,0)])
  self.read(8,17);self.read(16,0)
  self.group([('read',8,17),('read',16,0),('write',12,4),('read',8,49),('read',16,0)])
  words=[seq,cmd[5],cmd[6]]+list(range(3,30))+[IDENTITY[12],V.MAGIC]
  self.group([('read',8,49),('read',16,0),('read',28,seq)]+[('read',0x300+4*i,x) for i,x in enumerate(words)]+[('read',28,seq),('read',8,49),('read',16,0)])
  self.group([('read',8,49),('read',16,0),('write',12,5),('read',8,17),('read',16,0)])
  return dict(status_before_latch=17,fault_before_latch=0,words32=words,status_before_snapshot=49,status_after_snapshot=49,result_seq=seq,tick_unit='50MHz_cycles')

def transaction(commands=(COMMAND,),stop=False):
 b=Builder();b.factory();b.init();caps=[b.apply(c,i) for i,c in enumerate(commands,1)]
 if stop:b.group([('write',12,3)]);b.read(8,3);b.read(16,0)
 return dict(schema='g05_csr_transaction_v1',operation_id='synthetic-g05',policy_sha256=POLICY['policy_sha256'],identity_words=list(IDENTITY),captures=caps,deadline_selected_lower_board_monotonic_ns=10000,deadline_board_monotonic_ns=10010000,stop_status=3 if stop else None,stop_fault=0 if stop else None,receipts=b.receipts,authority='not_evaluated')

def mutate_receipt(doc,index,side,key,value):
 entry=doc['receipts'][index];name=side+'_raw_hex';d=json.loads(bytes.fromhex(entry[name]));d[key]=value;entry[name]=raw(d).hex()

class New(unittest.TestCase):
 def call(self,doc,commands=(COMMAND,),stop=False):
  return V.validate_transaction_v1(raw(doc),policy_raw=POLICY_RAW,expected_identity=IDENTITY,expected_commands=commands,stop_requested=stop,host_qpc_interval=HOST,host_clock_domain=DOMAIN)
 def bad(self,label,doc,**kw):
  p=D/'inputs';p.mkdir(exist_ok=True);(p/(label+'.json')).write_bytes(raw(doc))
  with self.assertRaises(V.Rejected):self.call(doc,**kw)
 def test01_exact_original_shapes_and_separate_clocks(self):
  doc=transaction();(D/'inputs').mkdir(exist_ok=True);(D/'inputs/valid-transaction.json').write_bytes(raw(doc));(D/'inputs/policy.json').write_bytes(POLICY_RAW)
  facts=self.call(doc);self.assertEqual(len(facts.receipts),102);self.assertEqual(facts.accepted_commands,(COMMAND,));self.assertEqual(facts.captures[0].words32,tuple(doc['captures'][0]['words32']))
  self.assertLess(json.loads(facts.receipts[0].started_raw)['monotonic_ns'],facts.deadline_selected_lower_board_monotonic_ns)
  self.assertEqual(facts.host_qpc_interval,HOST);self.assertEqual(facts.host_clock_domain,DOMAIN);self.assertEqual(facts.authority,'not_evaluated');self.assertEqual(facts.sensor_origin,'not_established_by_csr')
  self.assertEqual(facts.receipts[0].started_raw,bytes.fromhex(doc['receipts'][0]['started_raw_hex']))
 def test02_two_commands_and_explicit_stop(self):
  cmd2=(0,0,1,4,10,2,701);doc=transaction((COMMAND,cmd2),True);facts=self.call(doc,(COMMAND,cmd2),True)
  self.assertEqual(len(facts.captures),2);self.assertEqual(facts.status,3);self.assertEqual(facts.fault,0)
  self.bad('unrequested-stop',doc,commands=(COMMAND,cmd2),stop=False)
 def test03_missing_unknown_replay_and_torn(self):
  for name,change in (
    ('missing-return',lambda x:x['receipts'][-1].pop('returned_raw_hex')),
    ('missing-prefix',lambda x:x['receipts'].pop(0)),
    ('unknown-field',lambda x:x.update(verified=True)),
    ('wrong-order',lambda x:mutate_receipt(x,4,'started','offset',16)),
    ('identity-mismatch',lambda x:x['identity_words'].__setitem__(7,999)),
    ('word-mismatch',lambda x:x['captures'][0]['words32'].__setitem__(8,999)),
    ('torn-seq',lambda x:x['captures'][0].__setitem__('result_seq',99)),
    ('replayed-request',lambda x:mutate_receipt(x,-1,'started','request_id','factory-magic')),
    ('unknown-operation',lambda x:mutate_receipt(x,4,'started','kind','reset')),
    ('wrong-operation-id',lambda x:x.update(operation_id='other'))):
   doc=transaction();change(doc);self.bad(name,doc)
 def test04_clock_and_strict_integer_boundaries(self):
  for name,change in (
    ('reverse-return',lambda x:mutate_receipt(x,5,'returned','monotonic_ns',1)),
    ('phase-before-selected',lambda x:x.update(deadline_selected_lower_board_monotonic_ns=20000)),
    ('intent-at-deadline',lambda x:x.update(deadline_board_monotonic_ns=10001)),
    ('bool-index',lambda x:x['receipts'][0].update(index=True)),
    ('pid-change',lambda x:mutate_receipt(x,5,'started','pid',99))):
   doc=transaction();change(doc);self.bad(name,doc)
  doc=transaction();last=json.loads(bytes.fromhex(doc['receipts'][-1]['returned_raw_hex']));doc['deadline_board_monotonic_ns']=last['monotonic_ns'];self.call(doc)
  # A returned final MMIO exactly at deadline is evidence, not an in-call timeout.
 def test05_command_rom_policy_fullidentity_and_rawjson(self):
  for n in (0,8,12):
   doc=transaction();doc['identity_words'][n]+=1;self.bad('identity-word-'+str(n),doc)
  doc=transaction();doc['policy_sha256']='0'*64;self.bad('policy-mismatch',doc)
  with self.assertRaises(V.Rejected):V.validate_transaction_v1(raw(transaction())[:-1]+b',"authority":"not_evaluated"}',policy_raw=POLICY_RAW,expected_identity=IDENTITY,expected_commands=(COMMAND,),stop_requested=False,host_qpc_interval=HOST,host_clock_domain=DOMAIN)
  with self.assertRaises(V.Rejected):self.call(transaction(),((15000,15000,1,1,20,1,700),))
  self.assertNotIn('pynq',sys.modules)
 def test06_exact_policy_binding_and_preserved_raw(self):
  doc=transaction();wire=raw(doc);facts=self.call(doc)
  self.assertEqual(facts.facts_raw,wire);self.assertEqual(facts.policy_raw,POLICY_RAW)
  self.assertEqual((facts.phase_io_first,facts.phase_io_last),(1,102));self.assertEqual(facts.state,'TRANSACTION_COMPLETE')
  for field,value in (('operation_id','bad operation'),('boot_id','not-a-boot'),('build_id','0'*32)):
   policy=copy.deepcopy(POLICY);policy['binding'][field]=value;body={k:v for k,v in policy.items() if k!='policy_sha256'};policy['policy_sha256']=hashlib.sha256(V._raw(body)).hexdigest()
   changed=copy.deepcopy(doc);changed['policy_sha256']=policy['policy_sha256'];changed['operation_id']=policy['binding']['operation_id']
   with self.assertRaises(V.Rejected):V.validate_transaction_v1(raw(changed),policy_raw=raw(policy),expected_identity=IDENTITY,expected_commands=(COMMAND,),stop_requested=False,host_qpc_interval=HOST,host_clock_domain=DOMAIN)
if __name__=='__main__':unittest.main(verbosity=2)
