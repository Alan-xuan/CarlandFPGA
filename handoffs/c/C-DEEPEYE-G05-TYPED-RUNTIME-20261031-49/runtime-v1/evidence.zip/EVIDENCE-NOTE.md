# Evidence reading rules

No tests were executed while creating this archive. Run result.json files are exact original records, including original hashes of private command/stderr files. They are evidence records, not a public file manifest. Only evidence-manifest.json lists actual public members. Consult evidence-index.json for every omitted original and derived replacement.

All test boundaries are synthetic, not original credential or physical authentication. The C48 module under c48-released is the HISTORICALLY EXECUTED 814 version, NOT an installation dependency. Shared fixture builders were imported; their old tests were not executed. Source snapshots preserve the two REDs and subsequent targeted fixes. Final runtime ran run09 only; no full final suite replay is claimed. WIP sources are historical, not installable.
