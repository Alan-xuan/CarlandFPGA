"""Narrow literal changes against retained exact f65 source; no imports/tests."""
from pathlib import Path
P=Path(__file__).resolve().parent
def edit(name, changes):
    path='competition/deepeye/'+name
    text=(P/'inputs'/path).read_text(encoding='utf-8')
    for old,new,count in changes:
        assert text.count(old)==count,(name,old,text.count(old),count)
        text=text.replace(old,new)
    (P/'patched'/path).write_text(text,encoding='utf-8',newline='\n')

edit('simulation/authority/pc_direct_runtime.py',[
('class _NoActiveCommand(ValueError):', '''def _is_binding(value, *, executor=None):
    if type(value) is BootBinding:
        return True
    from .g05p_runtime_v1 import is_original_binding
    return is_original_binding(value, executor=executor)


class _NoActiveCommand(ValueError):''',1),
('def __init__(self, *, run_id, dependencies, clock, heartbeat_timeout_ns):',
 'def __init__(self, *, run_id, dependencies, clock, heartbeat_timeout_ns, g05p_profile=None):',1),
('        self._run_id, self._deps, self._clock = run_id, dependencies, clock',
 '''        self._g05p_profile = g05p_profile
        if g05p_profile is not None:
            from .g05p_runtime_v1 import G05Profile
            if type(g05p_profile) is not G05Profile:
                raise ValueError('exact explicit G05 profile required')
            g05p_profile.check()
        self._run_id, self._deps, self._clock = run_id, dependencies, clock''',1),
('    def _same_boot(self, value):\n        return (type(value) is BootBinding',
 '''    def _allowed_binding(self, value):
        if self._g05p_profile is None:
            return type(value) is BootBinding
        from .g05p_runtime_v1 import is_original_binding
        return (is_original_binding(value) and
                value._channel._config.g05p_profile is self._g05p_profile)

    def _same_boot(self, value):
        return (self._allowed_binding(value)''',1),
('if (type(proposed) is not BootBinding or type(proposed.run_id)',
 'if (not self._allowed_binding(proposed) or type(proposed.run_id)',1),
('            guard = watchdog.PcDirectWatchdog(context=context, heartbeat_timeout_ns=self._timeout, now_ns=now)',
 '''            if self._g05p_profile is None:
                guard = watchdog.PcDirectWatchdog(context=context, heartbeat_timeout_ns=self._timeout, now_ns=now)
            else:
                from .g05p_runtime_v1 import G05HealthGate
                guard = G05HealthGate(binding=proposed, heartbeat_timeout_ns=self._timeout, now_ns=now)''',1),
('''        def receive():
            record = self._record(self._deps.verify_board(event, self._boot), VerifiedEnvelope)''',
 '''        def receive():
            if self._g05p_profile is not None:
                from .g05p_runtime_v1 import G05Health, G05HealthGate
                record = self._deps.verify_board(event, self._boot)
                if (type(record) is not G05Health or record.binding is not self._boot
                        or type(self._guard) is not G05HealthGate):
                    raise ValueError('original typed G05 health required')
                now = self._advance(); self._active()
                self._guard.ingest_g05(record, now_ns=now)
                return 'g05_typed_health'
            record = self._record(self._deps.verify_board(event, self._boot), VerifiedEnvelope)''',1),
])

edit('simulation/authority/actor_composition.py',[
('                                VerifiedEnvelope, VerifiedObservation)',
 '                                VerifiedEnvelope, VerifiedObservation, _is_binding)',1),
('    owned_invocation_v1: object = None','    owned_invocation_v1: object = None\n    g05p_profile: object = None',1),
('''def _production_channels(config, *, host_clock=None):
    # No callable/provider supplied by a caller can bypass this gate.''',
 '''def _production_channels(config, *, host_clock=None, capability=None):
    if config.g05p_profile is not None:
        from .g05p_runtime_v1 import production_channels
        return production_channels(config, capability, host_clock)
    # No callable/provider supplied by a caller can bypass this gate.''',1),
('''    def verify_board(self, event, boot):
        return self._verify('verify_board', event, boot, VerifiedEnvelope)''',
 '''    def verify_board(self, event, boot):
        if self._owner._config.g05p_profile is not None:
            from .g05p_runtime_v1 import G05Health
            owner = self._owner
            owner._active()
            if boot is not owner._boot:
                raise ValueError('original G05 binding required')
            epoch = owner._veto
            record = owner._channels.verify_board(event, boot)
            owner._checkpoint(epoch); owner._progress_time(); owner._checkpoint(epoch)
            if type(record) is not G05Health or record.binding is not boot:
                raise ValueError('original typed G05 health required')
            return record
        return self._verify('verify_board', event, boot, VerifiedEnvelope)''',1),
('''        self._retired = True  # Gate first, before callbacks or cleanup.
        if self._owned_invocations''',
 '''        self._retired = True  # Gate first, before callbacks or cleanup.
        if self._config.g05p_profile is not None:
            self._channels.revoke()  # Local irreversible latch only, no transport IO.
        if self._owned_invocations''',1),
('            heartbeat_timeout_ns=config.heartbeat_timeout_ns)',
 '            heartbeat_timeout_ns=config.heartbeat_timeout_ns, g05p_profile=config.g05p_profile)',1),
('if (type(proposed) is not BootBinding or proposed.run_id',
 'if (not _is_binding(proposed) or proposed.run_id',1),
('    channels = _production_channels(config, host_clock=binding)\n    from .original_world_actor_link',
 '    channels = _production_channels(config, host_clock=binding, capability=capability)\n    from .original_world_actor_link',1),
])

edit('simulation/isolation/actor_owner.py',[
('from ..authority.pc_direct_runtime import BootBinding, PcDirectRuntime',
 'from ..authority.pc_direct_runtime import BootBinding, PcDirectRuntime, _is_binding',1),
('if (type(boot) is not BootBinding or boot.run_id',
 'if (not _is_binding(boot, executor=executor) or boot.run_id',1),
])

edit('simulation/authority/motion_executor.py',[
('from .pc_direct_runtime import BootBinding, StepFence, CommitReceipt',
 'from .pc_direct_runtime import BootBinding, StepFence, CommitReceipt, _is_binding',1),
('type(boot) is not BootBinding','not _is_binding(boot, executor=self)',3),
('type(self._root.boot) is not BootBinding','not _is_binding(self._root.boot, executor=self)',1),
])

edit('tools/run_causal_functional_chain.py',[
('from ..simulation.authority.pc_direct_runtime import BootBinding',
 'from ..simulation.authority.pc_direct_runtime import BootBinding, _is_binding',1),
('type(boot) is not BootBinding','not _is_binding(boot, executor=executor)',1),
])
print('Narrow baseline patches produced; no source imported or executed.')
