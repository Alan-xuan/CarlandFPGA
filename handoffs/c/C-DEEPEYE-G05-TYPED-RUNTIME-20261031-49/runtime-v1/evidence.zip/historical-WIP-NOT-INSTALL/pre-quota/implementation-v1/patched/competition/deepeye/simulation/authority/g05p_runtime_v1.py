"""Explicit G05P/layout2/50MHz original-root profile, never legacy BOOT/STATE8.

Private records below are retained verifier results, not credentials. Production
entry must consume the fixed A-owned original chain/phase/operation allocation;
the detached C48 parser never authenticates it. Python privacy is not a sandbox.
"""
from dataclasses import dataclass
import json
import threading

from ...integration import pc_direct_watchdog as watchdog

PROFILE = 'g05p_layout2_50mhz_session_v2'
UINT63 = (1 << 63) - 1
MAX_SESSION_NS = 10_000_000_000
_BINDINGS = []
_HEALTH = []
_KEY = object()


def need(value, reason):
    if not value:
        raise ValueError(reason)


def uint(value, label):
    need(type(value) is int and 0 <= value <= UINT63, label + ': uint63 required')
    return value


@dataclass(frozen=True)
class G05Profile:
    """Trusted-root selection only; an original chain is independently checked."""
    chain: object
    enabled: bool = False

    def check(self):
        need(type(self) is G05Profile and type(self.enabled) is bool and self.enabled,
             'explicit default-disabled G05 profile required')


class G05SessionBinding:
    """Genuine private init binding; never a BootBinding or board BOOT_ACK."""
    __slots__ = ('run_id', 'generation', 'context_json', 'ai_instance', '_channel')

    def __init__(self, key, channel, run_id, generation, context_json, ai_instance):
        need(key is _KEY, 'original G05 channel allocation required')
        for name, value in (('run_id', run_id), ('generation', generation),
                            ('context_json', context_json), ('ai_instance', ai_instance),
                            ('_channel', channel)):
            object.__setattr__(self, name, value)
        _BINDINGS.append(self)

    def __setattr__(self, name, value):
        raise AttributeError('original G05 binding is immutable')


class G05Health:
    __slots__ = ('binding', 'receipt', 'lower_qpc_ns', 'upper_qpc_ns', 'sequence')

    def __init__(self, key, binding, receipt, lower, upper, sequence):
        need(key is _KEY, 'original G05 health allocation required')
        for name, value in (('binding', binding), ('receipt', receipt),
                            ('lower_qpc_ns', lower), ('upper_qpc_ns', upper),
                            ('sequence', sequence)):
            object.__setattr__(self, name, value)
        _HEALTH.append(self)

    def __setattr__(self, name, value):
        raise AttributeError('original G05 health is immutable')


def is_original_binding(value, *, executor=None):
    if type(value) is not G05SessionBinding or not any(item is value for item in _BINDINGS):
        return False
    channel = value._channel
    return (type(channel) is G05Channels and channel._binding is value
            and not channel._revoked
            and (executor is None or channel._capability.executor is executor))


class G05HealthGate(watchdog.PcDirectWatchdog):
    """Selected typed status veto; inherits only original command/clock fences.

    The legacy-named decision slots are runtime compatibility fields. No STATE8
    bytes, heartbeat tick or board/host clock equality is fabricated.
    """
    def __init__(self, *, binding, heartbeat_timeout_ns, now_ns):
        need(is_original_binding(binding), 'original retained G05 session required')
        need(not binding._channel._health_gate_taken, 'G05 initial health already consumed')
        binding._channel._health_gate_taken = True
        self._g05_binding = binding
        self._g05_last_phase = -1
        self._g05_command_count = 0
        context = watchdog._envelope._parse_message(binding.context_json)
        super().__init__(context=context, heartbeat_timeout_ns=heartbeat_timeout_ns,
                         now_ns=now_ns)
        self.ingest_g05(binding._channel._initial_health, now_ns=now_ns)

    def _advance(self, now_ns):
        super()._advance(now_ns)
        if not self._latched:
            try:
                self._g05_binding._channel.checkpoint(now_ns=now_ns)
            except BaseException:
                self._trip('g05_original_session_retired')
                raise

    def ingest_g05(self, record, *, now_ns):
        self._advance(now_ns)  # Expired status cannot revive a prior latch.
        try:
            need(not self._latched, 'G05 health is irreversibly latched')
            need(type(record) is G05Health and any(item is record for item in _HEALTH)
                 and record.binding is self._g05_binding,
                 'original same-session G05 health required')
            uint(record.lower_qpc_ns, 'health lower'); uint(record.upper_qpc_ns, 'health upper')
            uint(record.sequence, 'original phase index')
            need(record.lower_qpc_ns <= record.upper_qpc_ns <= now_ns,
                 'actual original enclosing QPC interval required')
            need(record.sequence > self._g05_last_phase, 'health phase replay forbidden')
            channel = self._g05_binding._channel
            need(any(item is record for item in channel._health), 'foreign health allocation')
            deadline = min(uint(record.lower_qpc_ns + self._heartbeat_timeout_ns,
                                'typed health deadline'), channel._session_deadline_ns)
            need(now_ns < deadline, 'typed health already stale')
            self._g05_last_phase = record.sequence
            self._heartbeat_deadline_ns = deadline
            self._heartbeat_sequence = record.sequence
            self._heartbeat_tick_ms = None
            self._receipt_lower_ns, self._receipt_upper_ns = record.lower_qpc_ns, record.upper_qpc_ns
            # No source/AI/command/action deadline changes occur here.
            return self._decision()
        except BaseException:
            self._trip('invalid_g05_health')
            raise

    def ingest_heartbeat(self, *args, **kwargs):
        self._trip('legacy_STATE8_not_selected')
        raise ValueError('typed G05 profile does not consume legacy STATE8')

    def track_authority_command(self, *, command_seq, deadline_ns, now_ns):
        new = self._last_command_seq is None or command_seq > self._last_command_seq
        if new and self._g05_command_count >= 2:
            self._trip('g05_two_command_limit')
            raise ValueError('finite G05 session command budget exhausted')
        result = super().track_authority_command(command_seq=command_seq,
                                               deadline_ns=deadline_ns, now_ns=now_ns)
        if new:
            self._g05_command_count += 1
        return result

    def reset(self, **kwargs):
        self._trip('g05_session_is_nonrenewing')
        raise ValueError('G05 session cannot reset or renew')


def _original_types():
    # Fixed package path, no registration hook or caller-selected class. A216/
    # A218 allocating source must be published/pinned before this opt-in deploys.
    from ...tools.diagnostic.functional50_chain_v2_client_a import (
        ChainSessionV2, PhaseReceipt, RootOperationBinding)
    return ChainSessionV2, PhaseReceipt, RootOperationBinding


class G05Channels:
    """Original Root producer adapter; it never performs transport I/O itself.

    Required A-owned type/field API is explicit. There is no dict-to-provenance
    conversion, generic callback, private type-registration or verified flag.
    Original Root still owns init/apply/status/close(stop=False) and all effects.
    """
    def __init__(self, key, config, capability, chain, operation_binding, clock):
        need(key is _KEY, 'fixed G05 production gate required')
        Chain, Phase, Operation = _original_types()
        need(type(chain) is Chain and type(operation_binding) is Operation,
             'exact original Root producer types required')
        need(any(item is operation_binding for item in chain._operation_bindings),
             'operation binding not retained by original chain')
        need(operation_binding.chain is chain and operation_binding.config is config
             and operation_binding.capability is capability
             and operation_binding.clock is clock and chain._clock is clock,
             'original operation/config/capability/QPC association required')
        need(operation_binding.source_book is capability.book
             and operation_binding.root_owner is capability.owner
             and operation_binding.projection_session._book is capability.book
             and operation_binding.projection_session._link is capability,
             'original Root/SourceBook/C42 session association required')
        self._config, self._capability = config, capability
        self._chain, self._operation, self._clock = chain, operation_binding, clock
        self._thread = threading.get_ident()
        self._revoked = False
        self._binding = self._initial_health = None
        self._health_gate_taken = False
        self._health = []
        self._phase_index = 0
        self._previous = None
        self._session_deadline_ns = None
        self._init_receipt = operation_binding.init_receipt
        need(type(self._init_receipt) is Phase, 'actual original init receipt required')
        # init exists BEFORE original actor allocation; no ai_instance is required.
        self._init_facts = self._consume_phase(self._init_receipt, expected_kind='init')
        duration = (self._init_facts.deadline_board_monotonic_ns
                    - self._init_facts.deadline_selected_lower_board_monotonic_ns)
        need(type(duration) is int and 0 < duration <= MAX_SESSION_NS,
             'fixed nonrenewing original board duration required')
        # An enclosing host lower plus the original duration is conservative.
        # Board monotonic and 50MHz cycles are never converted into host QPC.
        self._session_deadline_ns = uint(self._init_receipt.lower_qpc_ns + duration,
                                         'host session horizon')
        self.checkpoint()

    def _consume_phase(self, receipt, *, expected_kind=None):
        from . import g05_csr_bridge_v1 as bridge
        Chain, Phase, Operation = _original_types()
        need(type(receipt) is Phase and receipt.owner is self._chain,
             'original same-chain phase receipt required')
        ledger = self._chain._phase_receipts
        need(type(ledger) in (tuple, list) and self._phase_index < len(ledger)
             and ledger[self._phase_index] is receipt,
             'phase must be next actual retained allocation, without gaps/replay')
        need(receipt.index == self._phase_index + 1
             and receipt.operation_id == self._operation.operation_id,
             'original phase index/operation mismatch')
        need(expected_kind is None or receipt.kind == expected_kind, 'wrong original phase kind')
        need(type(receipt.facts_raw) is bytes and type(self._operation.policy_raw) is bytes,
             'original retained phase and policy bytes required')
        need(receipt.clock is self._clock, 'original phase QPC binding mismatch')
        need(type(receipt.request_raw) is bytes and type(receipt.response_raw) is bytes,
             'original request/response bytes required')
        facts = bridge.validate_session_v2(receipt.facts_raw,
            policy_raw=self._operation.policy_raw,
            expected_identity=self._operation.identity_words,
            expected_command=receipt.expected_command, previous=self._previous,
            host_qpc_interval=(receipt.lower_qpc_ns, receipt.upper_qpc_ns),
            host_clock_domain=self._operation.host_clock_domain)
        need(type(facts) is bridge.DetachedFacts and facts.authority == 'not_evaluated'
             and facts.kind == receipt.kind and facts.operation_id == receipt.operation_id,
             'detached result and original phase disagree')
        need(facts.state == 'ACTIVE' and facts.fault == 0,
             'original G05 phase not active/healthy')
        self._phase_index += 1
        self._previous = facts.next_state
        return facts

    def checkpoint(self, *, now_ns=None):
        need(threading.get_ident() == self._thread, 'original G05 owner thread required')
        now = self._clock() if now_ns is None else uint(now_ns, 'host now')
        if (self._revoked or self._chain._unknown or self._chain._closed
                or (self._session_deadline_ns is not None and now >= self._session_deadline_ns)):
            self._revoked = True
            raise ValueError('original G05 session expired/unknown/closed/revoked')
        need(self._operation.capability is self._capability
             and self._operation.config is self._config,
             'original retained operation association changed')
        return now

    def revoke(self):
        self._revoked = True  # No transport close/STOP/retry from this adapter.

    def verify_boot(self, event, *, run_id, instance_id):
        self.checkpoint()
        need(self._binding is None and event is self._init_receipt,
             'original init is single-use; no replacement phase')
        op = self._operation
        need(run_id == op.run_id and type(instance_id) is str and bool(instance_id),
             'original actor run/instance required')
        composition = self._capability.composition
        need(composition is not None and composition._channels is self
             and composition._actor.instance_id == instance_id,
             'actual new original actor instance required')
        need(type(op.legacy_context_json) is bytes and type(op.c42_context_json) is bytes,
             'separate original context mapping required')
        need(type(op.generation) is int and op.generation > 0, 'original generation required')
        self._binding = G05SessionBinding(_KEY, self, run_id, op.generation,
                                         op.legacy_context_json, instance_id)
        self._initial_health = G05Health(_KEY, self._binding, event,
            event.lower_qpc_ns, event.upper_qpc_ns, event.index)
        self._health.append(self._initial_health)
        return self._binding

    def verify_board(self, event, binding):
        try:
            self.checkpoint()
            need(binding is self._binding, 'original G05 binding required')
            need(event.kind in ('status', 'apply'), 'typed status/apply phase required')
            self._consume_phase(event)
            record = G05Health(_KEY, binding, event, event.lower_qpc_ns,
                               event.upper_qpc_ns, event.index)
            self._health.append(record)
            return record
        except BaseException:
            self.revoke()
            raise

    def _original_event(self, kind, event, binding):
        self.checkpoint()
        need(binding is self._binding, 'same original G05 binding required')
        # Fixed method on the exact original Root type; not a supplied callback.
        # It independently validates and retains the actual source/config/action
        # records, including C46 association at the observation callsite.
        record = self._operation.verify_original_event(kind, event, binding)
        need(any(original_event is event and retained is record and retained_kind == kind
                 for retained_kind, original_event, retained in self._operation._verified_events),
             'original event result not retained by Root')
        self.checkpoint()
        return record

    def verify_observation(self, event, binding):
        return self._original_event('observation', event, binding)

    def verify_command(self, event, binding):
        return self._original_event('command', event, binding)

    def verify_slot(self, event, binding):
        return self._original_event('slot', event, binding)

    def mailbox_activation_for_boot(self, binding):
        return self._original_event('mailbox_activation', self._init_receipt, binding)


def _attach_original_g05(config, capability, chain, operation_binding, *, clock):
    profile = config.g05p_profile
    need(type(profile) is G05Profile, 'explicit typed G05 selection required')
    profile.check()
    need(profile.chain is chain and capability is not None,
         'original world capability and selected chain required')
    return G05Channels(_KEY, config, capability, chain, operation_binding, clock)


def production_channels(config, capability, clock):
    profile = config.g05p_profile
    need(type(profile) is G05Profile, 'explicit typed G05 selection required')
    profile.check()
    Chain, Phase, Operation = _original_types()
    need(type(profile.chain) is Chain, 'fixed original ChainSessionV2 required')
    matches = [item for item in profile.chain._operation_bindings
               if type(item) is Operation and item.config is config and item.capability is capability]
    need(len(matches) == 1, 'one original per-operation Root binding required')
    return _attach_original_g05(config, capability, profile.chain, matches[0], clock=clock)
