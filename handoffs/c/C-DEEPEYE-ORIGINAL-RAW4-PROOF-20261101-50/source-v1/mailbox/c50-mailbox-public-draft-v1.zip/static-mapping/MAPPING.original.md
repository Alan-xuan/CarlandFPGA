# C50 original mailbox mapping — static source findings

The mailbox types and consumer APIs already exist. The remaining G05 gap is the
installation of a retained original schedule/transfer-policy association and a
current command-slot event producer. It is not absence of Root phase receipts,
QPC brackets, contexts or C42 objects. No product source was changed or executed.

All A references below are at0469345fd1eef2884de1417f0f4eb5b67688f84c, under
competition/deepeye/. `source-pins.json` contains full SHA256, Git blob, length
and local snapshot for every cited source. Seventeen A files were checked against
that exact commit tree; two missing profile files were read with immutable GET.
The five historical C snapshots are separately identified. C45 mailbox and C46
adapter are byte-identical to these A046 files. Other equivalence is not assumed.

## Existing fields, creation and consumption

| Original symbol / fields | Original callsite and availability | Meaning and limit |
|---|---|---|
| `candidate_owner._MailboxActivation`: boot, source, clock_domain, slot_origin_ns, usb_upper_ns, packing_upper_ns | authority/candidate_owner.py38–45 defines container. ActorComposition.accept_boot522 asks `channels.mailbox_activation_for_boot(proposed)`;526 constructs _CandidateOwner, which checks exact boot/source/clock identities at79–85. | Origin is an established host-domain schedule anchor <= activation now. USB/packing are explicit nonnegative finite upper-bound values. No inferred zero/default. Container construction is not authentication. |
| `TransferBounds(usb_upper_ns, packing_upper_ns)` | integration/candidate_mailbox.py45–49; candidate_owner84–85 constructs it from activation. Mailbox activate214–218 checks exact type and strict bounded integers. | Trusted verifier/provider-supplied cost bounds. These checks do **not** require a measurement-record type; Root may explicitly select conservative software policy bounds with honest basis/scope. This does not make them measured or physically qualified. |
| `PcDirectWindowV2.consume_window_ns` | candidate_mailbox52–54; AuthorityConfig carries it; demo30h_pre_source_coordinator_a111–113 validates prospective selection before real init. Mailbox220–231 requires topology2 and 0<width<period. | Explicit policy, not scheduler observation or motion deadline. Legacy path remains exact-slot-only. |
| Fixed first slot and period | docs/boot_profiles.json profiles; boot_profile.slot_start_ms1165 and mailbox224–227/378–380. | fast_9600 first210ms, period500ms; stress_300 first2050ms, period8000ms. These are legacy profile policy. They do not demonstrate G05 transport timing or prove BOOT. Existing retained legacy context selects profile. |
| `_VerifiedSlot`: boot, source, clock_domain, window_index | candidate_owner48–54. actor_composition.verify_command327 calls `channels.verify_slot(transaction.slot_event, boot)` only for a new positive command; candidate_owner154–161 checks exact associations and creates local SlotGrant. | Original provider must own event/retention/one-use association. Merely calculating an index or constructing dataclass grants no authority. Duplicate committed command uses retained proof rather than allocating another slot. |
| `_InputTransaction` kind/slot_event/observation_record/selected_proof/request_raw/original_event/owned_association | candidate_owner57–66. accept_observation565 creates it; verifier304–310 attaches exact runtime-admitted VerifiedObservation; begin574 runs while active. accept_command605 creates command transaction. Entry finally259 clears it. | Synchronous scope, not persistent credential. Source attachment belongs inside original observation verification/admission; cannot revive transaction after return. |
| `BootBinding(run_id,generation,context_json,ai_instance)`; `VerifiedEnvelope(boot,raw)`; `VerifiedObservation(boot,raw,sample_lower_ns)` | pc_direct_runtime57–74. Boot comes from original channels.verify_boot before activation; command/observation are retained runtime records. | Existing exact typed boundaries. A raw4 record is not legacy TELEM and must not be converted by inventing means or identity. C50 raw4 successor is the other author's scope. |
| `OriginalPhaseReceipt` original request/response, owner/index/id/kind/operation, lower/upper QPC, session/process/streams/clock, session_origin/spec/ready bytes and ready QPC, source_pump/status/unknown | functional50_chain_v2_client_a21–33. _send paths retain actual raw requests/replies and bracket original call;183–188 expose init/apply/status/close. | Genuine original retained phase facts already exist. Init is available before source start. Phase elapsed includes combined transport/board/processing; it is not a reusable USB-only/packing upper bound or CPU completion time. |
| `OriginalG05FactoryRefs` and `OriginalG05OperationBinding` | original_g05_operation_binding_a39–52/55–85. Constructor requires actual complete first init retained in original producer ledger77–78. `claim_for_factory` one-use81–85; source NEW or RUNNING accepted67. | Original world/source/link/book/projection/producer/chain/session/init/clock/two contexts already exist. Source config attachment87–106 is a later real RUNNING-source association, not required to invent a mailbox measurement. |
| C42/native getter/current-read/registry evidence | source_projection_v1/provider.py88 retains admitted readback;103 real registry observation explicitly forbids inferring as_of from getter;116–119 export requires retained original current_read. original_world_actor_link.py retains exact admitted readback identity/digest around375–386. | Pose/publication/sample custody exists. It does not contain a command schedule grant or USB/packing timing measurement. Do not label it missing, and do not repurpose it as scheduling authority. |

## Required order: no child-completion prerequisite for activation

1. A's existing pre-source coordinator validates selected configuration/profile
   before effects (demo30h_pre_source_coordinator_a106–153), then uses the actual
   ready session and init (277–294), creates OriginalG05OperationBinding299–301,
   deferred scanner303–304 and disabled pump308–314. This returns PREPARED, not
   authority. Init already starts the non-renewable board deadline.
2. ActorComposition.accept_boot498 obtains the actual BootBinding, boots runtime
   and executor513–515, binds ActorOwner517, obtains mailbox activation522 and
   constructs candidate owner526–530, then changes ACTIVE535. The owned invocation
   adapter is installed536–538. This sequence does not need a completed child.
3. Only later accept_observation563–574 creates an active transaction and starts
   the owned invocation. C46 adapter136–173 validates original observation/full
   projection and fixed bounds, then dispatches once. `source_deadline_ns` and
   `dispatch_deadline_ns` must already be retained selections; they cannot be
   filled from the future completion read upper time.
4. The original native read/pair seal then yields actual dispatch/read brackets
   and ticket observation time (adapter195–210). C44 verify_pair only checks
   wire consistency; its validate_observed_interval280–288 only checks ordered
   integers. These do not provide schedule/transfer measurement provenance.
5. Completion is offered, then the original broker submits an exact finite
   motion_request plus original slot_event (accept_command603–605). The mailbox
   consumes once. Executor/runtime/progress remain separate gates.

Actual A `_production_channels`183–185 is deliberately unavailable. The released
C49 G05Channels420–424/502–506 explicitly refuses activation/command/slot; its
preflight526–527 refuses before actor acquisition. The quoted missing interface
is therefore a real installation gap in this inspected route, not evidence that
the existing underlying types are missing or that native receipt types must be
reimplemented. This mapping does not claim any alternative provider is installed.

## Policy, observations and finite deadlines

`boot_profiles.json`502–550 leaves measurement identities (including USB upper)
null/unverified_not_measured. It has no measured packing_upper_ns field. This is
evidence that those profile measurements are unavailable, **not** an extra API
rule requiring all software policy bounds to become measured before any explicit
nonfinal path can be defined. Root must distinguish (a) prospectively selected
finite policy, (b) actual same-clock observations, and (c) qualified measurement
evidence. A type, hash, phase elapsed, configured timeout, ready event or returned
sample cannot silently substitute for another category.

For PC_DIRECT v2 the exact implementation computes:
`start=origin+first+index*period`, `close=start+consume_window`, and
`ready=completion_upper+usb_upper+packing_upper`; it requires `ready<=start` and
`start<=now<min(close, candidate_deadline, sample_deadline)` (mailbox422–440).
The later consume window does not move origin or let a result arriving after
start enter that slot. Legacy consume397–405 additionally requires now==start.
Therefore selecting a future viable window must preserve the original schedule,
and a result may expire before one exists. No success is asserted from this map.

C46 keeps original source/dispatch/previous same-action caps160–161,202–210,
including the finite C43 candidate's fixed host issue/duration. It must not use
mailbox waiting to reissue/extend that candidate. Runtime command396–403 further
takes min(issue+duration, sample+age, previous deadline for identical sequence).
Actor run/readiness deadlines and IO deadline are bounded limits, not elapsed
measurements. A phase upper QPC is observed receipt time; board-monotonic G05
deadline and 50MHz cycles remain separate clocks. No conversion is inferred.

## Minimum original A attachment proposal (new, not claimed implemented)

Retain one prospective schedule selection alongside the existing
OriginalG05OperationBinding/config on the original Root thread, before factory
claim. It needs exact operation/config/clock references, canonical profile/context
identity, the original host-QPC anchor event/reference and chosen slot origin,
USB/packing bound values with explicit basis (`selected_policy` versus verified
measurement evidence and its scope), and existing PcDirectWindowV2 selection.
Keep strong references and immutable selected bytes; no JSON flag/callback grants
ownership. The attachment may be completed with actual BootBinding/source-channel
identity inside `mailbox_activation_for_boot(binding)`; neither child RESULT nor
new raw4 sample is a prerequisite. Source-config and capture proof still arrive
through their original later C50 admission paths.

Implement the already named provider methods, rather than another planner:

* `mailbox_activation_for_boot(binding)` checks retained original selection,
  exact binding/channel/clock and established origin, returns existing
  `_MailboxActivation`. An explicitly selected software policy remains labeled
  policy; missing selection is unavailable, never filled with zero or now.
* `verify_slot(event,binding)` consumes a Root-owned event ledger entry containing
  exact operation/binding/channel/clock, fixed selected window index and current
  original QPC observation. Check window against retained origin/profile, exact
  broker candidate/command association and one-use state. Return `_VerifiedSlot`.
  Do not choose/rebase a window merely to make late completion fit.
* `verify_command(event,binding)` retains the actual original broker-issued bytes
  and complete finite candidate association, returns `VerifiedEnvelope` for the
  appropriate versioned command path. `accept_command(...,slot_event=...)` already
  provides the attachment site. Do not reinterpret a G05 status/health or an
  applied hardware capture as this command-slot event. B132's board motion
  decoding and the second H12 path remain separately owned and unaccepted here.

These are narrow provenance/selection attachments. They do not change C44/C45,
invent measured bounds, waive raw4 full-proof validation, grant motion, or change
the default100ms/final contract. H01–H15 and both H12 remain fixed under requirements
SHA256 c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804.

### Concrete C50 implementation boundary for the next assignment

Use a new default-off private version module, proposed
`simulation/authority/g05_mailbox_policy_v1.py`; this name is a proposal, not an
existing installed module. It should retain the original operation/config/clock
and immutable schedule-policy record in a bounded one-use registry. Proposed
private installation is `_retain_original_schedule(operation, config, *,
origin_receipt, slot_origin_ns, transfer_policy, pc_direct_window_policy)` called
only at the original Root preparation site with real retained references. This
is a trusted-process convention, not Python security isolation or a public grant
constructor. Root selects basis/values before activation; no mid-session update.

After existing G05Channels factory claim, bind that exact channel and later the
exact original BootBinding to the retained record. Implement C49's currently
refusing methods at420,502,505 by delegating to the new private retained module.
At command production, retain an opaque event with exact boot/channel/clock,
original host-QPC observation, immutable window index, exact command bytes,
candidate/finite-action reference and original observation association. Consume
that entry in verify_slot once, marking consumed before downstream selection;
reject reused/foreign/replaced events and changed policy or source binding.
Preserve an identical committed command's existing duplicate-proof path rather
than minting another event. Missing evidence returns unavailable; failed
verification or consumption permanently invalidates the entry, with no retry,
slot rebasing, deadline renewal, reassignment or automatic second dispatch.

This module need not wait for child completion to install schedule policy. Only
the later command-slot event depends on a specific original completed candidate.
No frozen C49 file is changed by this mapping task; its successor patch and any
default-off preflight change need the next explicit implementation assignment.
