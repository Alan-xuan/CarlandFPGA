from pathlib import Path
import sys,subprocess,json,hashlib,time,shutil
D=Path(__file__).resolve().parent
run=sys.argv[1];testargs=sys.argv[2:]
V=D/'versions'/run;V.mkdir(parents=True,exist_ok=False)
for name in ('g05_mailbox_policy_v1.py','g05p_runtime_v1.py','g05p_runtime_v1.patch','test_mailbox_policy_v1.py'):
 shutil.copyfile(D/name,V/name)
pins=[dict(path=p.name,size=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in V.iterdir()]
(V/'source-pins.json').write_text(json.dumps(pins,indent=2),encoding='utf-8')
argv=[sys.executable,'-I','-B',str(V/'test_mailbox_policy_v1.py'),*testargs]
(V/'command.json').write_text(json.dumps(dict(argv=argv,cwd=str(V),timeout_seconds=30,classification='NEW synthetic fake dependencies only; no A source/native/core execution'),indent=2),encoding='utf-8')
t=time.monotonic()
try:
 r=subprocess.run(argv,cwd=V,capture_output=True,timeout=30);out,err,exitcode=r.stdout,r.stderr,r.returncode
except subprocess.TimeoutExpired as e:
 out,err,exitcode=e.stdout or b'',e.stderr or b'',None
(V/'stdout.raw').write_bytes(out);(V/'stderr.raw').write_bytes(err)
(V/'exit.json').write_text(json.dumps(dict(exit_code=exitcode,elapsed_seconds=time.monotonic()-t,timeout=exitcode is None,active_jobs=[],subprocesses=[])),encoding='utf-8')
print(json.dumps(dict(run=run,exit_code=exitcode,stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest())))
print(err.decode(errors='replace')[-10000:])
sys.exit(exitcode if exitcode is not None else 124)
