from pathlib import Path
import hashlib,json,difflib
D=Path(__file__).resolve().parent
M=D.parent/'mailbox-mapping-v1'
p=M/'sources/C49-g05p_runtime_v1.py'
b=p.read_bytes(); assert hashlib.sha256(b).hexdigest()=='17e156a6f4297eb56bf0c3221ef2abb6ada7232907685cf70988db270a5ff508'
s=b.decode(); n=s.replace("        # Explicit remaining boundary: original A046 provides both contexts,\n        # but no original mailbox transfer/schedule observation receipt. Zero\n        # would fabricate a bound. This partial slice cannot activate motion.\n        raise ValueError('original mailbox schedule and transfer evidence unavailable')", "        from .g05_mailbox_policy_v1 import _activation\n        return _activation(self, binding)")
n=n.replace("        raise ValueError('original G05 command/slot producer not installed')", "        from .g05_mailbox_policy_v1 import _consume\n        return _consume(self, event, binding, slot=False)",1)
n=n.replace("        raise ValueError('original G05 command/slot producer not installed')", "        from .g05_mailbox_policy_v1 import _consume\n        return _consume(self, event, binding, slot=True)",1)
assert n!=s and 'from .g05_mailbox_policy_v1 import _activation' in n
(D/'g05p_runtime_v1.py').write_bytes(n.encode())
(D/'g05p_runtime_v1.patch').write_text(''.join(difflib.unified_diff(s.splitlines(True),n.splitlines(True),fromfile='a/competition/deepeye/simulation/authority/g05p_runtime_v1.py',tofile='b/competition/deepeye/simulation/authority/g05p_runtime_v1.py')),encoding='utf-8',newline='')
assert s[s.index('def require_activation_ready'):]==n[n.index('def require_activation_ready'):]
pins=[]
for rel in ['sources/C49-g05p_runtime_v1.py','sources/C46-adapter.py','sources/integration/candidate_mailbox.py','sources/simulation/authority/candidate_owner.py','sources/simulation/authority/actor_composition.py','sources/tools/diagnostic/original_g05_operation_binding_a.py','sources/integration/host_envelope.py','sources/docs/boot_profiles.json']:
 p=M/rel;v=p.read_bytes();pins.append(dict(path=str(p),size=len(v),sha256=hashlib.sha256(v).hexdigest()))
(D/'dependency-pins.json').write_text(json.dumps(pins,indent=2),encoding='utf-8')
print('exact C49 baseline; three delegation methods only; preallocation refusal unchanged')

