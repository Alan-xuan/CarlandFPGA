"""NEW synthetic module-state controls. No A source or native/core is executed."""
import sys, types, json, importlib.util, unittest
from pathlib import Path
from dataclasses import dataclass
S=types.SimpleNamespace
PK='competition.deepeye.simulation.authority'
def mod(name, **attrs):
 m=types.ModuleType(name); m.__path__=[]; m.__dict__.update(attrs);sys.modules[name]=m;return m
for p in ['competition','competition.deepeye','competition.deepeye.simulation',PK,'competition.deepeye.integration',PK+'.owned_invocation_v1']:mod(p)
class Profile:
 def check(self): assert self.enabled
class Config:pass
class Operation:
 def _check(self): assert not self.failed
 def check_source_config(self):
  if getattr(self,"source_changed",False):raise ValueError("original source config replaced")
class Phase:pass
@dataclass(frozen=True)
class Window:consume_window_ns:int
@dataclass(frozen=True)
class Activation:
 boot:object;source:object;clock_domain:object;slot_origin_ns:int;usb_upper_ns:int;packing_upper_ns:int
@dataclass(frozen=True)
class Slot:
 boot:object;source:object;clock_domain:object;window_index:int
@dataclass(frozen=True)
class Proof:
 boot:object;source:object;clock_domain:object;candidate_raw:bytes;invocation_id:int;dispatch_lower_ns:int;completion_lower_ns:int;completion_upper_ns:int;observed_interval_v2:object
@dataclass
class Tx:
 kind:str;slot_event:object
@dataclass(frozen=True)
class Envelope:boot:object;raw:bytes
@dataclass(frozen=True)
class Finite:
 candidate:object;host_issue_ns:int;deadline_ns:object
class Owner:
 def _active(self): assert self._state=='ACTIVE'
 def inspect_owned_candidate(self,event):
  a=self._owned_invocations
  assert a.ready is event and a._retained[0] is event and not a.failed
  return a._retained[3]
class Adapter:pass
class Channel:
 def checkpoint(self):
  now=self._clock()
  if self._revoked or now<self.last or now>=self._session_deadline_ns:raise ValueError('checkpoint')
  self.last=now;self._operation._check();return now
 def revoke(self):self._revoked=True
class Clock:
 metadata={'domain_id':'a'*32}
 def __init__(self):self.now=10_000_000
 def __call__(self):return self.now
mod(PK+'.g05p_runtime_v1',G05Profile=Profile,G05Channels=Channel,
    _original_types=lambda:(object,Phase,Operation,object,object),
    is_original_binding=lambda b:isinstance(b,S) and b._channel._binding is b and not b._channel._revoked)
mod(PK+'.actor_composition',AuthorityConfig=Config,ActorComposition=Owner)
mod('competition.deepeye.integration.candidate_mailbox',PcDirectWindowV2=Window)
mod(PK+'.candidate_owner',_MailboxActivation=Activation,_VerifiedSlot=Slot,_InputTransaction=Tx,_CompletedInference=Proof)
mod(PK+'.pc_direct_runtime',VerifiedEnvelope=Envelope)
mod('competition.deepeye.integration.completion_interval',FiniteActionCandidate=Finite)
def same_root(o,a,g):
 if o.root is not g[0]:raise ValueError('Root replaced')
mod(PK+'.owned_invocation_v1.adapter',_OwnedInvocationAdapter=Adapter,_same_root=same_root)
def validate(raw,**kw):
 d=json.loads(raw)
 assert set(d)=={'schema_version','kind','context','candidate_id','command_seq','observation','target','host_issue_monotonic_ns'}
 assert d['schema_version']==1 and d['context']==kw['context'] and d['host_issue_monotonic_ns']<=kw['now_ns']
 return S(kind=d['kind'],document=d)
mod('competition.deepeye.integration.host_envelope',validate_message=validate)
spec=importlib.util.spec_from_file_location(PK+'.g05_mailbox_policy_v1',Path(__file__).with_name('g05_mailbox_policy_v1.py'))
m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
def raw(d):return json.dumps(d,sort_keys=True,separators=(',',':')).encode()
class Fixture:
 def __init__(self):
  self.clock=Clock();self.config=Config();p=Profile();p.enabled=True;p.policy_raw=b'synthetic';self.config.g05p_profile=p;self.config.pc_direct_window_v2=Window(20_000_000)
  self.op=Operation();self.op.failed=False;self.op._claim_attempted=False;self.op.config=self.config;self.op.clock=self.clock
  self.phase=Phase();self.phase.request_raw=b'original synthetic init request';self.phase.response_raw=b'original synthetic init response';self.phase.lower_qpc_ns=0;self.phase.upper_qpc_ns=10_000_000
  self.op.receipt=self.phase;self.op.chain=S(phase_receipts=[self.phase]);self.op._legacy={'topology_id':2,'transport_profile_id':1};self.op._c42={'operation_id':'synthetic','clock_domain_id':'a'*32}
  self.policy=m.TransferPolicy(1_000_000,1_000_000,'selected_policy','synthetic offline bounds')
  self.c=Channel();self.c._config=self.config;self.c._clock=self.clock;self.c._operation=self.op;self.c._init_receipt=self.phase;self.c._session_deadline_ns=1_000_000_000;self.c.last=0;self.c._revoked=False
  self.boot=S(_channel=self.c,context_json=raw(self.op._legacy));self.c._binding=self.boot
 def attach(self):m._retain_original_schedule(self.op,self.config,transfer_policy=self.policy,enabled=True)
 def activate(self):self.attach();return m._activation(self.c,self.boot)
 def candidate(self,action=1):
  self.clock.now=219_000_000
  o=Owner();o._channels=self.c;o._clock=o._host_clock=self.clock;o._config=self.config;o._boot=self.boot;o._state='ACTIVE';o._busy=False;o.root=object()
  self.c._capability=S(composition=o);self.o=o
  ob={'context':self.op._legacy,'observed_seq':7};obs=S(raw=raw(ob),sample_lower_ns=190_000_000);o._runtime=S(_observations={7:obs})
  assoc=S(owner=o,source=self.c,clock=self.clock,boot=self.boot,record=obs,observation_bytes=obs.raw,observation_key=raw(ob),source_deadline_ns=290_000_000,dispatch_deadline_ns=300_000_000,previous_deadline_ns=None)
  assoc.capture_ref=object();assoc.sample_ref=object();assoc.candidate_bytes=b'{}';assoc.capture_bytes=b'original synthetic capture'
  assoc.session=S(_check=lambda:None,_producer=S(_captures=[(assoc.capture_ref,assoc.sample_ref,{},dict(capture_raw='original synthetic capture'))]))
  rec=S(request=b'exact synthetic request',_close_attempted=True,_close_error=None)
  actor=S(_invocation=rec,_invocation_check=lambda:None);rec.owner=actor;o._actor=actor
  a=Adapter();a.owner=o;a.actor=actor;a.source=self.c;a.clock=self.clock;a.failed=False;a.records=[rec];a.associations=[assoc];o._owned_invocations=a
  a.series=S(ledger=S(tickets=[S(record=rec,sealed_pair=('ready','result'),observed_qpc_ns=218_000_000)]))
  doc=dict(schema_version=2,kind='model_candidate',context=self.op._legacy,candidate_id=1,model_sha256='f'*64,observation=ob,target={'action':action,'duration_ms':10,'speed':1},basis='synthetic',completion_observed_interval_ns={'lower_ns':200_000_000,'upper_ns':218_000_000})
  finite=Finite(S(document=doc,valid_until_ns=290_000_000),219_000_000,None if action==0 else 229_000_000)
  bounds=object();proof=Proof(self.boot,self.c,self.clock,raw(doc),1,200_000_000,201_000_000,218_000_000,bounds)
  p=dict(association=assoc,record=rec,wire=rec.request,caps=(290_000_000,300_000_000,None),guard=(o.root,))
  event=object();a.ready=event;a._retained=(event,rec,proof,finite,p,proof.candidate_raw,bounds)
  o._candidates=S(_pending=None,_current=None,_mailbox=S(_origin=10_000_000,_window_first=210_000_000,_window_period=500_000_000,_pc_direct_window_v2=self.config.pc_direct_window_v2))
  self.a=a;self.proof=proof;self.finite=finite;self.event=event
  return m._retain_original_completion(self.c,event)
 def offer(self):self.a.ready=None;self.a._retained=None;self.o._candidates._pending=self.proof;self.clock.now=220_000_000
 def command(self,action=1):self.activate();t=self.candidate(action);self.offer();return m._produce_original_command(self.c,t,command_seq=2,window_index=0)
 def tx(self,event):self.o._busy=True;self.o._input_transaction=Tx('command',event)
class Controls(unittest.TestCase):
 def setUp(self):m._SCHEDULES.clear();m._COMPLETIONS.clear();m._COMMANDS.clear()
 def test01_policy_before_child_and_defaultoff(self):
  f=Fixture()
  with self.assertRaises(ValueError):m._retain_original_schedule(f.op,f.config,transfer_policy=f.policy)
  f.attach();a=m._activation(f.c,f.boot);self.assertEqual(a.slot_origin_ns,10_000_000);self.assertFalse(hasattr(f.c,'_capability'))
 def test02_missing_policy_and_failed_attach(self):
  f=Fixture()
  with self.assertRaises(ValueError):m._retain_original_schedule(f.op,f.config,transfer_policy=None,enabled=True)
  with self.assertRaises(ValueError):f.attach()
 def test03_foreign_config_claimed_or_mutation(self):
  for what in ('foreign','claimed','mutated'):
   with self.subTest(what=what):
    self.setUp();f=Fixture()
    if what=='foreign':f.op.config=Config()
    if what=='claimed':f.op._claim_attempted=True
    if what!='mutated':
     with self.assertRaises(ValueError):f.attach()
    else:
     f.attach();object.__setattr__(f.policy,'usb_upper_ns',2)
     with self.assertRaises(ValueError):m._activation(f.c,f.boot)
 def test04_clock_binding_and_session_cap_replacement(self):
  for what in ('clock','binding','deadline'):
   with self.subTest(what=what):
    self.setUp();f=Fixture();f.activate()
    if what=='clock':f.c._clock=Clock()
    if what=='binding':f.c._binding=S(_channel=f.c,context_json=f.boot.context_json)
    if what=='deadline':f.c._session_deadline_ns+=1
    with self.assertRaises(ValueError):f.candidate()
 def test05_offer_then_original_fields_and_slot_once(self):
  f=Fixture();e=f.command();f.tx(e);out=m._consume(f.c,e,f.boot,slot=False);d=json.loads(out.raw)
  self.assertEqual(d['host_issue_monotonic_ns'],f.finite.host_issue_ns);self.assertEqual(d['target'],f.finite.candidate.document['target']);self.assertEqual(d['observation'],f.finite.candidate.document['observation'])
  grant=m._consume(f.c,e,f.boot,slot=True);self.assertEqual(grant.window_index,0)
  with self.assertRaises(ValueError):m._consume(f.c,e,f.boot,slot=True)
  self.assertTrue(f.c._revoked)
 def test06_offer_missing_replaced_and_no_retry(self):
  f=Fixture();f.activate();t=f.candidate();f.clock.now=220_000_000
  with self.assertRaises(ValueError):m._produce_original_command(f.c,t,command_seq=1,window_index=0)
  f.offer()
  with self.assertRaises(ValueError):m._produce_original_command(f.c,t,command_seq=1,window_index=0)
 def test07_finite_deadline_exact(self):
  f=Fixture();e=f.command();f.clock.now=f.finite.deadline_ns;f.tx(e)
  with self.assertRaises(ValueError):m._consume(f.c,e,f.boot,slot=False)
 def test08_window_before_open_and_close(self):
  for now in (219_999_999,240_000_000):
   with self.subTest(now=now):
    self.setUp();f=Fixture();f.activate();t=f.candidate(action=1);f.offer();f.clock.now=now
    with self.assertRaises(ValueError):m._produce_original_command(f.c,t,command_seq=1,window_index=0)
 def test09_transfer_bound_must_fit_fixed_start(self):
  f=Fixture();f.policy=m.TransferPolicy(2_000_000,1_000_000,'selected_policy','synthetic');f.activate();t=f.candidate();f.offer()
  with self.assertRaises(ValueError):m._produce_original_command(f.c,t,command_seq=1,window_index=0)
 def test10_root_observation_and_candidate_mutation(self):
  for what in ('root','observation','candidate'):
   with self.subTest(what=what):
    self.setUp();f=Fixture();e=f.command();f.tx(e)
    if what=='root':f.o.root=object()
    if what=='observation':f.o._runtime._observations[7]=S(raw=b'wrong',sample_lower_ns=190_000_000)
    if what=='candidate':f.finite.candidate.document['target']['speed']=9
    with self.assertRaises(ValueError):m._consume(f.c,e,f.boot,slot=False)
 def test11_active_tx_slot_order_and_clock_regression(self):
  for what in ('absent','slotfirst','clock'):
   with self.subTest(what=what):
    self.setUp();f=Fixture();e=f.command();f.tx(e)
    if what=='absent':f.o._busy=False
    if what=='clock':f.clock.now-=1
    with self.assertRaises(ValueError):m._consume(f.c,e,f.boot,slot=what=='slotfirst')
 def test12_exact_committed_duplicate_no_new_slot_or_issue(self):
  f=Fixture();e=f.command();f.tx(e);r=m._consume(f.c,e,f.boot,slot=False);m._consume(f.c,e,f.boot,slot=True)
  f.o._candidates._pending=None;f.o._candidates._current=(r.raw,f.proof);f.o.root=object();f.tx(e)
  duplicate=m._consume(f.c,e,f.boot,slot=False);self.assertEqual(duplicate.raw,r.raw)
  with self.assertRaises(ValueError):m._consume(f.c,e,f.boot,slot=True)
 def test13_uncommitted_replay_and_foreign_token(self):
  f=Fixture();e=f.command();f.tx(e);m._consume(f.c,e,f.boot,slot=False);f.tx(e)
  with self.assertRaises(ValueError):m._consume(f.c,e,f.boot,slot=False)
 def test14_stop_has_no_positive_slot(self):
  f=Fixture();e=f.command(action=0);f.tx(e);d=json.loads(m._consume(f.c,e,f.boot,slot=False).raw);self.assertEqual(d['target']['action'],0)
  with self.assertRaises(ValueError):m._consume(f.c,e,f.boot,slot=True)
 def test15_exact_baseline_fence(self):
  import ast
  p=Path(__file__).with_name('g05p_runtime_v1.py');tree=ast.parse(p.read_text())
  gate=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='require_activation_ready')
  self.assertTrue(any(isinstance(n,ast.Raise) for n in ast.walk(gate)))
 def test16_source_and_capture_retention_change(self):
  for what in ('source','capture'):
   with self.subTest(what=what):
    self.setUp();f=Fixture();e=f.command();f.tx(e)
    if what=='source':f.op.source_changed=True
    else:f.a.associations[0].session._producer._captures.clear()
    with self.assertRaises(ValueError):m._consume(f.c,e,f.boot,slot=False)
 def test17_exact_window_close_before_finite_deadline(self):
  f=Fixture();f.config.pc_direct_window_v2=Window(8_000_000);e=f.command();f.clock.now=228_000_000;f.tx(e)
  self.assertLess(f.clock.now,f.finite.deadline_ns)
  with self.assertRaises(ValueError):m._consume(f.c,e,f.boot,slot=False)
 def test18_final_valid_original_chain_and_foreign_event(self):
  f=Fixture();e=f.command();f.tx(e);r=m._consume(f.c,e,f.boot,slot=False);g=m._consume(f.c,e,f.boot,slot=True)
  self.assertEqual(g.window_index,0);self.assertEqual(json.loads(r.raw)['target'],f.finite.candidate.document['target'])
  f.o._candidates._pending=None;f.o._candidates._current=(r.raw,f.proof);f.tx(e)
  self.assertEqual(m._consume(f.c,e,f.boot,slot=False).raw,r.raw)
  with self.assertRaises(ValueError):m._consume(f.c,object(),f.boot,slot=False)
 def test19_original_clock_metadata_mapping_proxy(self):
  from types import MappingProxyType
  f=Fixture();f.clock.metadata=MappingProxyType(dict(kind='qpc_raw_v1',domain_id='a'*32,implementation='QueryPerformanceCounter()',resolution_seconds=1e-7,monotonic=True,adjustable=False,timestamp_uncertainty_ns=None,authenticated=False,measured_timing=False))
  f.activate();self.assertEqual(m._SCHEDULES[0]['origin'],f.phase.upper_qpc_ns)
  t=f.candidate();f.offer();e=m._produce_original_command(f.c,t,command_seq=1,window_index=0);f.tx(e)
  self.assertEqual(json.loads(m._consume(f.c,e,f.boot,slot=False).raw)['host_issue_monotonic_ns'],f.finite.host_issue_ns)
if __name__=='__main__':unittest.main(verbosity=2)
