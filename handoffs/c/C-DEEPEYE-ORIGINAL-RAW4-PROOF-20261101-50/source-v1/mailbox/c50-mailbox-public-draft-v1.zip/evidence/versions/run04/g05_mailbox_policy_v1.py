"""Root-private policy and original-event retention; never an authority API.

No default producer is installed. Python privacy is not an isolation boundary.
The original runtime, mailbox, progress gate and executor still decide admission.
"""
from dataclasses import dataclass
import json
import threading

MAX_NS = (1 << 63) - 1
_SCHEDULES = []
_COMPLETIONS = []
_COMMANDS = []


def _need(ok, reason):
    if not ok:
        raise ValueError(reason)


def _uint(value, label, minimum=0):
    _need(type(value) is int and minimum <= value <= MAX_NS, label)
    return value


def _raw(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=True, allow_nan=False).encode('ascii')


def _plain(value):
    # C43 retains nested mapping proxies and tuples, not mutable input JSON.
    if hasattr(value, 'items'):
        return {k: _plain(v) for k, v in value.items()}
    if type(value) in (tuple, list):
        return [_plain(v) for v in value]
    return value


@dataclass(frozen=True, slots=True)
class TransferPolicy:
    usb_upper_ns: int
    packing_upper_ns: int
    basis: str
    scope: str

    def check(self):
        _need(type(self) is TransferPolicy, 'exact explicit transfer policy')
        _uint(self.usb_upper_ns, 'positive selected USB bound', 1)
        _uint(self.packing_upper_ns, 'positive selected packing bound', 1)
        _uint(self.usb_upper_ns + self.packing_upper_ns, 'transfer bound sum')
        _need(self.basis == 'selected_policy', 'software policy basis required')
        _need(type(self.scope) is str and 1 <= len(self.scope) <= 256
              and all(32 <= ord(c) <= 126 for c in self.scope), 'explicit policy scope')


class _Token:
    __slots__ = ()


def _schedule_signature(operation, config, policy):
    r = operation.receipt
    return (r.request_raw, r.response_raw, r.lower_qpc_ns, r.upper_qpc_ns,
            _raw(operation._legacy), _raw(operation._c42),
            _raw(_plain(operation.clock.metadata)), config.g05p_profile.policy_raw,
            config.pc_direct_window_v2.consume_window_ns,
            policy.usb_upper_ns, policy.packing_upper_ns, policy.basis, policy.scope)


def _retain_original_schedule(operation, config, *, transfer_policy, enabled=False):
    """Root calls once after actual init, before original factory claim/child.

    The exact original init.upper QPC is a selected SOFTWARE schedule anchor,
    not a measured BOOT timestamp. No time is sampled to choose a new origin.
    """
    from .g05p_runtime_v1 import G05Profile, _original_types
    from .actor_composition import AuthorityConfig
    from ...integration.candidate_mailbox import PcDirectWindowV2
    _need(type(enabled) is bool and enabled, 'mailbox policy is default disabled')
    _need(len(_SCHEDULES) < 64, 'finite retained operation budget')
    _need(not any(r['operation'] is operation or r['config'] is config for r in _SCHEDULES),
          'schedule attachment already attempted')
    row = dict(operation=operation, config=config, failed=True, channel=None,
               binding=None, activation_attempted=False, thread=threading.get_ident())
    _SCHEDULES.append(row)  # Failed attachment cannot be retried with new policy.
    _, Phase, Operation, _, _ = _original_types()
    _need(type(operation) is Operation and type(config) is AuthorityConfig
          and operation.config is config, 'original same-config operation')
    _need(not operation._claim_attempted, 'schedule must precede factory claim')
    _need(type(config.g05p_profile) is G05Profile, 'original selected G05 profile')
    config.g05p_profile.check()
    _need(type(transfer_policy) is TransferPolicy, 'explicit transfer policy missing')
    transfer_policy.check()
    _need(type(config.pc_direct_window_v2) is PcDirectWindowV2,
          'explicit fixed PC_DIRECT consume-window policy required')
    operation._check()
    r = operation.receipt
    _need(type(r) is Phase and len(operation.chain.phase_receipts) == 1
          and operation.chain.phase_receipts[0] is r, 'original init before later phases')
    _uint(r.lower_qpc_ns, 'init lower'); _uint(r.upper_qpc_ns, 'init upper')
    _need(r.lower_qpc_ns <= r.upper_qpc_ns, 'init bracket order')
    context = operation._legacy
    _need(context['topology_id'] == 2, 'PC_DIRECT policy only')
    # Exact A046 docs/boot_profiles.json control_primary offset/window_ms.
    first, period = {1: (210_000_000, 500_000_000),
                     2: (2_050_000_000, 8_000_000_000)}[context['transport_profile_id']]
    width = _uint(config.pc_direct_window_v2.consume_window_ns, 'window width', 1)
    _need(width < period, 'window width must be below fixed period')
    _uint(r.upper_qpc_ns + first + width, 'first close overflow')
    row.update(policy=transfer_policy, receipt=r, clock=operation.clock,
               profile=config.g05p_profile, window=config.pc_direct_window_v2,
               signature=_schedule_signature(operation, config, transfer_policy),
               origin=r.upper_qpc_ns, first=first, period=period, width=width,
               failed=False, attempts=[])


def _schedule(channel, binding):
    from .g05p_runtime_v1 import G05Channels, is_original_binding
    _need(type(channel) is G05Channels and is_original_binding(binding)
          and binding._channel is channel, 'original live channel/binding')
    rows = [r for r in _SCHEDULES if r['operation'] is channel._operation]
    _need(len(rows) == 1, 'original schedule unavailable')
    r = rows[0]
    _need(not r['failed'] and threading.get_ident() == r['thread'], 'schedule retired/thread')
    _need(channel._config is r['config'] and channel._clock is r['clock']
          and r['operation'].receipt is r['receipt']
          and r['operation'].clock is r['clock']
          and channel._init_receipt is r['receipt']
          and r['config'].g05p_profile is r['profile']
          and r['config'].pc_direct_window_v2 is r['window'], 'schedule refs replaced')
    _need(_schedule_signature(r['operation'], r['config'], r['policy']) == r['signature'],
          'selected schedule bytes/policy/clock changed')
    _need(json.loads(binding.context_json) == r['operation']._legacy,
          'original binding context mismatch')
    now = channel.checkpoint()
    r['operation'].check_source_config()
    _need(r['origin'] <= now < channel._session_deadline_ns, 'original finite session')
    if r['channel'] is not None:
        _need(r['channel'] is channel and r['binding'] is binding, 'schedule already bound')
        _need(channel._session_deadline_ns == r['session_deadline'], 'session cap replaced')
    return r, now


def _fail(channel):
    # No process/board effect and no retry. Original Root owns cleanup.
    channel.revoke()
    for r in _SCHEDULES:
        if r['operation'] is channel._operation:
            r['failed'] = True


def _activation(channel, binding):
    from .candidate_owner import _MailboxActivation
    try:
        r, _ = _schedule(channel, binding)
        _need(not r['activation_attempted'], 'activation already attempted')
        r['activation_attempted'] = True
        r['channel'], r['binding'] = channel, binding
        r['session_deadline'] = channel._session_deadline_ns
        return _MailboxActivation(binding, channel, r['clock'], r['origin'],
                                  r['policy'].usb_upper_ns, r['policy'].packing_upper_ns)
    except BaseException:
        _fail(channel); raise


def _owner(channel):
    from .actor_composition import ActorComposition
    from .owned_invocation_v1.adapter import _OwnedInvocationAdapter
    o = channel._capability.composition
    a = o._owned_invocations
    _need(type(o) is ActorComposition and type(a) is _OwnedInvocationAdapter,
          'original composition-owned adapter required')
    _need(o._channels is channel and o._clock is channel._clock
          and o._host_clock is channel._clock and o._config is channel._config
          and o._boot is channel._binding and o._state == 'ACTIVE'
          and a.owner is o and a.source is channel and a.clock is channel._clock
          and not a.failed and a.actor is o._actor, 'original owner refs/liveness')
    o._active()
    return o, a


def _retain_original_completion(channel, event):
    """Original Root callsite, BEFORE accept_completion consumes C46._retained.

    Takes no candidate/finite/JSON argument. inspect uses the original C46 gate;
    this module independently retains its exact proof, bytes and associations.
    """
    try:
        s, _ = _schedule(channel, channel._binding)
        _need(s['channel'] is channel, 'original activation required')
        o, a = _owner(channel)
        _need(len(s['attempts']) < 16 and not any(e is event for e in s['attempts']),
              'completion retention already attempted/budget')
        s['attempts'].append(event)
        finite = o.inspect_owned_candidate(event)
        held = a._retained
        _need(type(held) is tuple and len(held) == 7 and held[0] is event
              and held[3] is finite and a.ready is event, 'original inspected tuple lost')
        _, record, proof, _, p, raw, bounds = held
        from ...integration.completion_interval import FiniteActionCandidate
        from .candidate_owner import _CompletedInference
        _need(type(finite) is FiniteActionCandidate and type(proof) is _CompletedInference,
              'original finite/proof types')
        token = _Token()
        row = dict(token=token, channel=channel, owner=o, adapter=a, event=event,
                   record=record, proof=proof, finite=finite, pending=p,
                   raw=raw, bounds=bounds, association=p['association'],
                   wire=p['wire'], caps=p['caps'], guard=p['guard'],
                   doc=_raw(_plain(finite.candidate.document)),
                   issue=finite.host_issue_ns, deadline=finite.deadline_ns,
                   valid_until=finite.candidate.valid_until_ns,
                   proof_times=(proof.invocation_id, proof.dispatch_lower_ns,
                                proof.completion_lower_ns, proof.completion_upper_ns),
                   attempted=False, failed=False)
        _check_completion(row, offered=False)
        _COMPLETIONS.append(row)
        return token
    except BaseException:
        _fail(channel); raise


def _check_completion(r, *, offered, duplicate=False):
    from .owned_invocation_v1.adapter import _same_root
    c, o, a = r['channel'], r['owner'], r['adapter']
    _, now = _schedule(c, c._binding)
    actual_o, actual_a = _owner(c)
    _need(actual_o is o and actual_a is a and not r['failed'], 'retained owner retired')
    p, proof, f, record, assoc = r['pending'], r['proof'], r['finite'], r['record'], r['association']
    a.actor._invocation_check()
    _need(record is a.records[-1] is a.actor._invocation and record.request == r['wire']
          and record.owner is a.actor and record._close_attempted
          and record._close_error is None, 'original sealed record replaced')
    ticket = a.series.ledger.tickets[-1]
    _need(ticket.record is record and ticket.sealed_pair is not None
          and ticket.observed_qpc_ns == proof.completion_upper_ns, 'original pair seal replaced')
    _need(p['record'] is record and p['association'] is assoc and p['wire'] == r['wire']
          and p['caps'] == r['caps'] and p['guard'] is r['guard']
          and any(x is assoc for x in a.associations), 'original retained producer membership')
    _need(proof.boot is c._binding and proof.source is c and proof.clock_domain is c._clock
          and proof.candidate_raw == r['raw'] and proof.observed_interval_v2 is r['bounds']
          and _raw(_plain(f.candidate.document)) == r['doc']
          and json.loads(r['raw']) == json.loads(r['doc'])
          and f.host_issue_ns == r['issue'] and f.deadline_ns == r['deadline']
          and f.candidate.valid_until_ns == r['valid_until'], 'finite candidate fields changed')
    _need((proof.invocation_id, proof.dispatch_lower_ns, proof.completion_lower_ns,
           proof.completion_upper_ns) == r['proof_times'], 'retained completion interval changed')
    _need(assoc.owner is o and assoc.source is c and assoc.clock is c._clock
          and assoc.boot is c._binding and assoc.record.raw == assoc.observation_bytes,
          'original observation association changed')
    assoc.session._check()
    captures = [v for v in assoc.session._producer._captures if v[0] is assoc.capture_ref]
    _need(len(captures) == 1 and captures[0][1] is assoc.sample_ref
          and _raw(captures[0][2]) == _raw(json.loads(assoc.candidate_bytes))
          and captures[0][3]['capture_raw'].encode() == assoc.capture_bytes,
          'original capture/sample retention changed')
    obs = json.loads(assoc.observation_bytes)
    stored = o._runtime._observations.get(obs['observed_seq'])
    _need(stored is not None and stored.raw == assoc.record.raw
          and stored.sample_lower_ns == assoc.record.sample_lower_ns,
          'original runtime-admitted observation lost')
    doc = json.loads(r['doc'])
    _need(doc['observation'] == json.loads(assoc.observation_key)
          and doc['context'] == json.loads(c._binding.context_json), 'candidate observation/context changed')
    _need((assoc.source_deadline_ns, assoc.dispatch_deadline_ns, assoc.previous_deadline_ns)
          == r['caps'], 'original source/dispatch/previous caps changed')
    _need(r['issue'] <= now < min(r['valid_until'], *(v for v in r['caps'] if v is not None)),
          'original candidate validity expired')
    _need(r['deadline'] is None or now < r['deadline'], 'fixed full-duration deadline expired')
    if not duplicate:
        _same_root(o, assoc, r['guard'])
    if offered:
        _need(o._candidates._pending is proof, 'original offered proof missing/replaced')
    return now, doc


def _produce_original_command(channel, completion, *, command_seq, window_index):
    """Root broker AFTER successful original offer. No raw command input.

    Retains exact original issue/target/duration; never issues later or shortens.
    window_index is an explicit policy choice, not measured transfer evidence.
    """
    row = None
    try:
        rows = [r for r in _COMPLETIONS if r['token'] is completion]
        _need(len(rows) == 1, 'original completion retention missing')
        row = rows[0]
        _need(not row['attempted'], 'command production already attempted')
        row['attempted'] = True
        _need(row['channel'] is channel, 'foreign completion channel')
        _need(sum(r['channel'] is channel for r in _COMMANDS) < 2, 'finite two-command budget')
        _uint(command_seq, 'command sequence'); _need(command_seq <= 65535, 'command sequence range')
        _uint(window_index, 'explicit window index')
        now, doc = _check_completion(row, offered=True)
        s, _ = _schedule(channel, channel._binding)
        raw = _raw(dict(schema_version=1, kind='motion_request', context=doc['context'],
                        candidate_id=doc['candidate_id'], command_seq=command_seq,
                        observation=doc['observation'], target=doc['target'],
                        host_issue_monotonic_ns=row['issue']))
        from ...integration import host_envelope
        checked = host_envelope.validate_message(raw, producer='control_broker',
                    consumer='world_authority', context=doc['context'], now_ns=now)
        _need(checked.kind == 'motion_request', 'original broker schema')
        event = _Token()
        entry = dict(token=event, channel=channel, completion=row, raw=raw, window=window_index,
                     command_attempted=False, slot_attempted=False, failed=False,
                     command_tx=None, slot_tx=None)
        _window(entry, s, now, doc)
        _COMMANDS.append(entry)
        return event
    except BaseException:
        if row is not None: row['failed'] = True
        _fail(channel); raise


def _window(e, s, now, doc):
    if doc['target']['action'] == 0:
        return  # Original STOP retires; it has no positive slot/lease.
    owner = e['completion']['owner']
    box = owner._candidates._mailbox
    _need(box._origin == s['origin'] and box._window_first == s['first']
          and box._window_period == s['period']
          and box._pc_direct_window_v2 is s['window'], 'original mailbox policy changed')
    start = _uint(s['origin'] + s['first'] + e['window'] * s['period'], 'slot overflow')
    close = _uint(start + s['width'], 'window close overflow')
    ready = _uint(e['completion']['proof'].completion_upper_ns + s['policy'].usb_upper_ns
                  + s['policy'].packing_upper_ns, 'selected policy ready overflow')
    _need(ready <= start <= now < close, 'fixed selected window not usable')


def _consume(channel, event, binding, *, slot):
    from .candidate_owner import _InputTransaction, _VerifiedSlot
    from .pc_direct_runtime import VerifiedEnvelope
    entry = None
    try:
        rows = [r for r in _COMMANDS if r['token'] is event]
        _need(len(rows) == 1, 'original command event unavailable')
        entry = rows[0]
        o = entry['completion']['owner']
        tx = o._input_transaction
        # Only byte-identical already committed commands use the unchanged
        # duplicate path; they never consume a second window or renew issue.
        committed = o._candidates._current
        duplicate = (not slot and entry['command_attempted'] and committed is not None
                     and committed[0] == entry['raw']
                     and committed[1] is entry['completion']['proof'])
        key = 'slot_attempted' if slot else 'command_attempted'
        was_attempted = entry[key]
        entry[key] = True  # Every attempt, including failed validation, is terminal.
        _need(not entry['failed'] and (not was_attempted or duplicate), 'event replay/failed')
        _need(entry['channel'] is channel and binding is channel._binding, 'foreign command/binding')
        _need(o._busy and type(tx) is _InputTransaction and tx.kind == 'command'
              and tx.slot_event is event, 'original active command/slot transaction')
        if slot:
            _need(entry['command_tx'] is tx and entry['command_attempted'], 'slot before verified command')
        else:
            _need(entry['command_tx'] is not tx, 'same transaction repeated command verification')
            entry['command_tx'] = tx
        now, doc = _check_completion(entry['completion'], offered=not duplicate, duplicate=duplicate)
        if not duplicate:
            s, _ = _schedule(channel, binding)
            _window(entry, s, now, doc)
        if slot:
            _need(doc['target']['action'] != 0, 'STOP does not consume a motion slot')
            entry['slot_tx'] = tx
            return _VerifiedSlot(binding, channel, channel._clock, entry['window'])
        return VerifiedEnvelope(binding, entry['raw'])
    except BaseException:
        if entry is not None: entry['failed'] = True
        _fail(channel); raise
