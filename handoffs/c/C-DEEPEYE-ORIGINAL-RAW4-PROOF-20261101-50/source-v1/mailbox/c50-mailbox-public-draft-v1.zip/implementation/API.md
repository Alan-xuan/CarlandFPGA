# API (Root private, not IPC)

| Function/type | Required original inputs | Output / effect |
|---|---|---|
| TransferPolicy(usb_upper_ns, packing_upper_ns, basis, scope) | Explicit finite positive policy values, basis='selected_policy', bounded printable scope | Frozen policy; construction grants nothing |
| _retain_original_schedule(operation, config, *, transfer_policy, enabled=False) | Exact original operation/config/init and fixed QPC, before factory claim | None; bounded strong retention, failure cannot be retried |
| _activation(channel, binding) | Exact G05 channel and retained G05SessionBinding after source-config attachment | Original _MailboxActivation consistency record; selected origin=original init.upper |
| _retain_original_completion(channel, event) | Original C46 completion still in adapter._retained, actual owner inspection succeeds | Opaque token; strongly holds exact original finite/proof/record/capture association |
| _produce_original_command(channel, completion, *, command_seq, window_index) | Original offer retained as pending; fixed legal window; original finite/action/session bounds | Opaque event with internally held immutable motion_request; original issue retained |
| _consume(channel, event, binding, *, slot=False/True) | Exact original active command transaction; same event as slot_event | VerifiedEnvelope first, _VerifiedSlot once for positive command; failures revoke |

Root integration calls, when genuine upstream dependencies exist:

```python
_retain_original_schedule(operation, config, transfer_policy=selected_policy, enabled=True)
# Original factory/BOOT flow, still blocked by unchanged preallocation fence
# until a separately reviewed complete integration exists.
retained = _retain_original_completion(channel, original_completion_event)
accepted = owner.accept_completion(original_completion_event)
# Only if accepted; no retry on false/failure.
event = _produce_original_command(channel, retained,
                                  command_seq=original_broker_sequence,
                                  window_index=chosen_fixed_window)
owner.accept_command(event, slot_event=event)
```

This sequence consumes no time to select a new origin. It cannot be used as an authentication API for arbitrary caller objects. A-owned provider is responsible for original Root/native/source custody; current default remains unavailable. No class here is a motion grant. Product has no configurable verifier/callback path.
