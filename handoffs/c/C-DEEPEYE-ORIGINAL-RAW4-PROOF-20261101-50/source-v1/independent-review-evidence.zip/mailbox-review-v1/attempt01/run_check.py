import hashlib,json,subprocess,sys,time
from pathlib import Path
D=Path(__file__).resolve().parent;A=D.parent/'mailbox-implementation-v1';script=D/'independent_mailbox_check.py';module=A/'g05_mailbox_policy_v1.py'
argv=[sys.executable,'-B',str(script),str(module),str(D/'run01')]
(D/'command.json').write_text(json.dumps(dict(argv=argv,cwd=str(D),timeout_seconds=30,pins=[dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size)for p in (script,module)]),indent=2),encoding='utf8')
t=time.perf_counter();p=subprocess.run(argv,cwd=D,timeout=30,stdout=subprocess.PIPE,stderr=subprocess.PIPE);(D/'stdout.bin').write_bytes(p.stdout);(D/'stderr.bin').write_bytes(p.stderr)
r=dict(exit_code=p.returncode,elapsed_seconds=time.perf_counter()-t,pins={n:hashlib.sha256((D/n).read_bytes()).hexdigest()for n in ('command.json','stdout.bin','stderr.bin')},subprocesses=[])
(D/'exit.json').write_text(json.dumps(r,indent=2),encoding='utf8');print(p.stdout.decode());print(p.stderr.decode());print(json.dumps(r));raise SystemExit(p.returncode)
