"""One NEW combined pure control. No original owner/native/core module executes.
python -B independent_mailbox_check.py CANDIDATE_FILE OUTPUT_DIR
All dependency objects are explicitly synthetic; real ABI was audited statically.
"""
import dataclasses,hashlib,importlib.util,json,sys,types
from pathlib import Path
file,out=map(Path,sys.argv[1:]);out.mkdir(exist_ok=True);sys.dont_write_bytecode=True
assert hashlib.sha256(file.read_bytes()).hexdigest()=='5dfafb756959cc57af696ffa08c9d30267aaf5fc2bf5ed96421a8a050bb7ef3e'
S=types.SimpleNamespace;MP=types.MappingProxyType;P='review.deepeye.simulation.authority';I='review.deepeye.integration'
def mod(n,**items):
 m=types.ModuleType(n);m.__path__=[];m.__dict__.update(items);sys.modules[n]=m;return m
for n in ('review','review.deepeye','review.deepeye.simulation',P,I,P+'.owned_invocation_v1'):mod(n)
def raw(x):return json.dumps(x,sort_keys=True,separators=(',',':')).encode()
def freeze(x):
 if type(x)is dict:return MP({k:freeze(v)for k,v in x.items()})
 if type(x)is list:return tuple(freeze(v)for v in x)
 return x
class Config:pass
class Profile:
 def check(self):assert self.policy_raw==b'explicit-synthetic-policy-not-measured'
class Window:
 def __init__(self):self.consume_window_ns=20_000_000
class Phase:pass
class Op:
 def _check(self):assert self.config is cfg and self.clock is clock
 def check_source_config(self):self._check()
class Channel:
 def checkpoint(self):
  assert not self.revoked and self.last<=clock.now<self._session_deadline_ns
  self.last=clock.now;return clock.now
 def revoke(self):self.revoked=True
class Owner:
 def _active(self):assert self._state=='ACTIVE'
 def inspect_owned_candidate(self,e):
  assert adapter.ready is e and adapter._retained[0] is e
  trace.append('inspect-before-offer');return adapter._retained[3]
class Adapter:pass
class Clock:
 def __init__(self):self.now=base;self.metadata=MP({'domain_id':'a'*32,'timestamp_uncertainty_ns':None,'measured_timing':False})
 def __call__(self):return self.now
@dataclasses.dataclass(frozen=True)
class Activation:
 boot:object;source:object;clock_domain:object;slot_origin_ns:int;usb_upper_ns:int;packing_upper_ns:int
@dataclasses.dataclass(frozen=True)
class Slot:
 boot:object;source:object;clock_domain:object;window_index:int
@dataclasses.dataclass(frozen=True)
class Proof:
 boot:object;source:object;clock_domain:object;candidate_raw:bytes;invocation_id:int;dispatch_lower_ns:int;completion_lower_ns:int;completion_upper_ns:int;observed_interval_v2:object
@dataclasses.dataclass(frozen=True,slots=True)
class Finite:
 candidate:object;host_issue_ns:int;deadline_ns:object;authority:str='none'
@dataclasses.dataclass
class Tx:
 kind:str;slot_event:object
@dataclasses.dataclass(frozen=True)
class Envelope:
 boot:object;raw:bytes

def same_root(o,a,g):assert o.root is g[0]
def validate(b,**kw):
 doc=json.loads(b);assert doc['context']==context and doc['target']==target and doc['observation']==observation_key
 assert kw==dict(producer='control_broker',consumer='world_authority',context=context,now_ns=clock.now)
 assert doc['host_issue_monotonic_ns']==issue
 return S(kind='motion_request',document=doc)
mod(P+'.g05p_runtime_v1',G05Profile=Profile,G05Channels=Channel,_original_types=lambda:(object,Phase,Op,object,object),is_original_binding=lambda b:b is boot)
mod(P+'.actor_composition',AuthorityConfig=Config,ActorComposition=Owner)
mod(I+'.candidate_mailbox',PcDirectWindowV2=Window)
mod(P+'.candidate_owner',_MailboxActivation=Activation,_CompletedInference=Proof,_InputTransaction=Tx,_VerifiedSlot=Slot)
mod(P+'.pc_direct_runtime',VerifiedEnvelope=Envelope)
mod(P+'.owned_invocation_v1.adapter',_OwnedInvocationAdapter=Adapter,_same_root=same_root)
mod(I+'.completion_interval',FiniteActionCandidate=Finite);mod(I+'.host_envelope',validate_message=validate)
sp=importlib.util.spec_from_file_location(P+'.g05_mailbox_policy_v1',file);m=importlib.util.module_from_spec(sp);sys.modules[sp.name]=m;sp.loader.exec_module(m)
base=2**53+137;clock=Clock();cfg=Config();cfg.g05p_profile=Profile();cfg.g05p_profile.policy_raw=b'explicit-synthetic-policy-not-measured';cfg.pc_direct_window_v2=Window()
context=dict(session=73,config_epoch=4,boot_sha256='b'*64,transport_profile_id=1,source_id=4,topology_id=2,acquisition_profile_id=1)
op=Op();op.config=cfg;op.clock=clock;op._claim_attempted=False;op._legacy=context;op._c42=dict(operation_id='new-synthetic-review',clock_domain_id='a'*32)
receipt=Phase();receipt.lower_qpc_ns=base-100;receipt.upper_qpc_ns=base;receipt.request_raw=raw({'payload':{'max_commands':1}});receipt.response_raw=b'synthetic-response';op.receipt=receipt;op.chain=S(phase_receipts=[receipt])
channel=Channel();channel._config=cfg;channel._clock=clock;channel._operation=op;channel._init_receipt=receipt;channel._session_deadline_ns=base+1_000_000_000;channel.last=base;channel.revoked=False
boot=S(_channel=channel,generation=3,context_json=raw(context));channel._binding=boot
policy=m.TransferPolicy(700_000,300_000,'selected_policy','NEW bounded synthetic control')
m._retain_original_schedule(op,cfg,transfer_policy=policy,enabled=True);activation=m._activation(channel,boot);assert activation.slot_origin_ns==base
owner=Owner();owner._state='ACTIVE';owner._channels=channel;owner._clock=owner._host_clock=clock;owner._config=cfg;owner._boot=boot;owner._busy=False;owner.root=object();channel._capability=S(composition=owner)
record=S(request=b'new-independent-fixed-request',_close_attempted=True,_close_error=None)
actor=S(_invocation=record,_invocation_check=lambda:None);record.owner=actor;owner._actor=actor
adapter=Adapter();adapter.owner=owner;adapter.source=channel;adapter.clock=clock;adapter.actor=actor;adapter.failed=False;adapter.records=[record];owner._owned_invocations=adapter
observation_key=dict(context=context,observed_seq=9);observed=S(raw=raw(observation_key),sample_lower_ns=base+180_000_000);owner._runtime=S(_observations={9:observed})
assoc=S(owner=owner,source=channel,clock=clock,boot=boot,record=observed,observation_bytes=observed.raw,observation_key=observed.raw,source_deadline_ns=base+280_000_000,dispatch_deadline_ns=base+295_000_000,previous_deadline_ns=None,capture_ref=object(),sample_ref=object(),candidate_bytes=b'{}',capture_bytes=b'explicit-synthetic-capture')
assoc.session=S(_check=lambda:None,_producer=S(_captures=[(assoc.capture_ref,assoc.sample_ref,{},dict(capture_raw='explicit-synthetic-capture'))]));adapter.associations=[assoc]
target=dict(action=1,yaw_q=0,pitch_q=0,speed_code=1,duration_ms=60)
doc=dict(schema_version=2,kind='model_candidate',context=context,candidate_id=1,model_sha256='f'*64,observation=observation_key,target=target,basis='host_dispatch_to_complete_result_observed_v1',completion_observed_interval_ns=dict(lower_ns=base+190_000_000,upper_ns=base+209_000_000))
issue=base+209_500_000;deadline=issue+60_000_000;bounds=object();finite=Finite(S(document=freeze(doc),valid_until_ns=base+280_000_000),issue,deadline)
proof=Proof(boot,channel,clock,raw(doc),1,base+190_000_000,base+191_000_000,base+209_000_000,bounds)
adapter.series=S(ledger=S(tickets=[S(record=record,sealed_pair=(b'ready',b'result'),observed_qpc_ns=proof.completion_upper_ns)]))
pending=dict(record=record,association=assoc,wire=record.request,caps=(assoc.source_deadline_ns,assoc.dispatch_deadline_ns,None),guard=(owner.root,))
event=object();adapter.ready=event;adapter._retained=(event,record,proof,finite,pending,proof.candidate_raw,bounds)
box=S(_origin=base,_window_first=210_000_000,_window_period=500_000_000,_pc_direct_window_v2=cfg.pc_direct_window_v2,_bounds=S(usb_upper_ns=policy.usb_upper_ns,packing_upper_ns=policy.packing_upper_ns),_source=channel,_clock_domain=clock,_generation=boot.generation,_context_raw=boot.context_json)
owner._candidates=S(_pending=None,_current=None,_mailbox=box);trace=[];clock.now=issue
saved=m._retain_original_completion(channel,event)
assert adapter._retained is not None
# Simulate exactly the audited original effect: verify clears held tuple, offer sets pending.
adapter.ready=None;adapter._retained=None;owner._candidates._pending=proof;trace.append('original-verify-clear-and-offer-simulated');clock.now=base+210_000_000
command=m._produce_original_command(channel,saved,command_seq=11,window_index=0)
owner._busy=True;owner._input_transaction=Tx('command',command)
first=m._consume(channel,command,boot,slot=False);grant=m._consume(channel,command,boot,slot=True);assert grant.window_index==0
owner._candidates._pending=None;owner._candidates._current=(first.raw,proof);owner._busy=False;owner.root=object();trace.append('original-selection-and-commit-simulated')
# A new transaction after fixed window close; exact committed duplicate must not need another slot.
clock.now=base+235_000_000;owner._busy=True;owner._input_transaction=Tx('command',command)
duplicate=m._consume(channel,command,boot,slot=False);assert duplicate.raw is first.raw and len(m._COMMANDS)==1 and m._COMMANDS[0]['slot_attempted'] is True
assert json.loads(first.raw)['host_issue_monotonic_ns']==issue and json.loads(first.raw)['target']==target
# Original finite action expiry is inclusive and cannot be renewed by duplicate.
clock.now=deadline;owner._input_transaction=Tx('command',command)
try:m._consume(channel,command,boot,slot=False)
except ValueError as e:failure=str(e)
else:raise AssertionError('expired committed duplicate accepted')
assert channel.revoked and failure == 'fixed full-duration deadline expired'
result=dict(control='NEW high-QPC frozen-document retain-offer-consume committed-duplicate-after-window-close and exact-action-expiry',passed=True,scope='synthetic fake dependencies only; actual ABI source reviewed separately',base_qpc_ns=base,host_issue_ns=issue,duplicate_now_ns=base+235_000_000,window_close_ns=base+230_000_000,deadline_ns=deadline,expiry_reason=failure,original_candidate_sha256=hashlib.sha256(proof.candidate_raw).hexdigest(),command_sha256=hashlib.sha256(first.raw).hexdigest(),trace=trace,authority='none',original_runtime_executed=False)
(out/'command-output.json').write_bytes(first.raw);(out/'candidate-input.json').write_bytes(proof.candidate_raw);(out/'result.json').write_bytes(raw(result));print(json.dumps(result))
