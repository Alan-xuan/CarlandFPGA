"""Exact R1/R2 replay + three new adjacent controls. No old suite/fixture import.
CLI: python -B independent_repair_checks.py PACKAGE_PARENT INPUT_BUNDLE OUTPUT_DIR
"""
import binascii,copy,gzip,hashlib,json,struct,sys
from pathlib import Path
sys.dont_write_bytecode=True
pkg,bundle,out=map(Path,sys.argv[1:]);out.mkdir(exist_ok=True)
def sha(b):return hashlib.sha256(b).hexdigest()
def raw(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
for n,h in [('projector.py','cfa1611e4f95ca261964a71d2712d4972f7c2be5227ead83494db93c9edb38a1'),('transport.py','613b10bd6b9bdc8da6c63aa9bc762df11742f86e39b4e4248f4adef8407385d6')]:assert sha((pkg/'raw4_proof_v1'/n).read_bytes())==h
items=json.loads(gzip.decompress(bundle.read_bytes()));cases=[]
for item in items['reds']:
 b=item['utf8'].encode();assert sha(b)==item['sha256']and len(b)==item['bytes'];cases.append((item['name'],'REJECTED',b,'exact original RED bytes'))
held=items['held']['utf8'].encode();assert sha(held)==items['held']['sha256']
x=json.loads(held);x['enabled']=True;x['root_receipt']['config']['goal_m']=[0.625,0.25,2.5]
cases.append(('adjacent-new-enabled-held-relative-source','PROJECTED',raw(x),'NEW enabled held valid'))
y=json.loads(next(item['utf8']for item in items['reds']if item['name']=='new-two-request-only-sessions-no-config'))
for i,r in enumerate(y['root_receipt']['captures']):
 p=r['raw4'];req=json.loads(bytes.fromhex(p['request_hex']));req['lineage']['session_id']=7
 for lane in req['scan']['lanes']:lane['session']=7
 req['lineage'].update(request_id='independent-per-capture-'+str(i),request_seq=11+i,trigger_id=21+i,capture_seq=31+i)
 p['request_hex']=raw(req).hex()
cases.append(('adjacent-new-partial-variable-per-capture-ids','INPUT_UNAVAILABLE',raw(y),'NEW different per-capture IDs remain valid missing evidence'))
sys.path.insert(0,str(pkg));from raw4_proof_v1 import project_raw4_json,Rejected
from raw4_proof_v1 import transport as T
z=copy.deepcopy(x);z['root_receipt']['config']=None;r=z['root_receipt']['captures'][-1];p=r['raw4'];p['request_hex']=None
wire=bytes.fromhex(p['wire_hex']);n=wire[4]+14;frame=wire[:n];payload=frame[12:-2];session=struct.unpack_from('<I',payload,5)[0];view=frame[5];e=T.CODEC.E_BY_CODE[payload[1]&7]
pt=T.CODEC.decode_payload(bytes([1])+payload[1:],dict(session=session,config_epoch=view,e=e))['points'][0]
assert pt['held'] and pt['source_tick_ms']<pt['tick_ms'];pt['source_tick_ms']+=1
encoded=T.CODEC.encode_payload([pt],dict(session=session,config_epoch=view,e=e),0);encoded=bytes([2])+encoded[1:];header=bytearray(frame[:12]);header[4]=len(encoded)
mutated=bytes(header)+encoded;mutated+=struct.pack('<H',binascii.crc_hqx(mutated[2:],0xffff));mutated+=wire[n:];assert len(mutated)==len(wire)
p['wire_hex']=mutated.hex();r['capture_sha256']=sha(mutated);z['candidate']['observation_identity']['capture_sha256']=sha(mutated)
cases.append(('adjacent-new-held-source-relative-tick-plus-one-us','REJECTED',raw(z),'NEW CRC-correct source tick contradiction without request/config'))
rows=[]
for name,expected,b,origin in cases:
 (out/(name+'.input.json')).write_bytes(b);before=sha(b)
 try:
  response=project_raw4_json(b);doc=json.loads(response);status=doc['input_status'];assert doc['authorization']=='none'and doc['core_ran']is False
  if status=='PROJECTED':
   candidate=json.loads(b)['candidate'];pub=doc['public_input'];assert pub['observation']['quality']==candidate['quality']and pub['observation']['counts']==candidate['channel_counts']
   assert pub['observation']['em_qpc_ns']<pub['observation']['adc_qpc_ns']
 except Rejected as error:status='REJECTED';response=raw(dict(exception='Rejected',reason=str(error)))
 except Exception as error:status='UNEXPECTED_EXCEPTION';response=raw(dict(exception=type(error).__name__,reason=str(error)))
 assert sha(b)==before;(out/(name+'.output.json')).write_bytes(response)
 row=dict(name=name,expected=expected,observed=status,passed=status==expected,origin=origin,input_sha256=before,input_bytes=len(b),output_sha256=sha(response));rows.append(row);print(json.dumps(row),flush=True)
(out/'results.json').write_bytes(raw(rows));assert not any('frozen_c28'in n or 'check_repair'in n for n in sys.modules)
raise SystemExit(0 if all(r['passed']for r in rows)else 1)
