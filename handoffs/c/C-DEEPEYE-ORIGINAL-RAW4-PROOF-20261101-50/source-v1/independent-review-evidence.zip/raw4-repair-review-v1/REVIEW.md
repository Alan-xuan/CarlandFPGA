# C50 raw4 R1/R2 independent closure review

**R1 and R2 closed; bounded detached-source approval.** The original four exact failing byte strings now raise Rejected on final projector `cfa1611e4f95ca261964a71d2712d4972f7c2be5227ead83494db93c9edb38a1` and transport `613b10bd6b9bdc8da6c63aa9bc762df11742f86e39b4e4248f4adef8407385d6`. No open finding in this narrow repair. Original failures and rejected-version evidence are unchanged.

Verified author FINAL `188aa54262bbc08831ca27a245cca6f5093dddfb145e63084a98dca200bc2b02`, all 71 frozen files, final source pins, raw command/output/exit and version ZIP. Exact repair.diff is reproduced with line endings normalized only for text comparison. Only projector.py and transport.py change; request/public schemas, partial113, frozen predicates and all four exact pure dependencies remain byte-identical. AST changes are _source_checks/_wire_checks plus new _trace_shared, and inspect plus new source_frames/lineage_namespace. No core, factory, actor, runtime hook or authority path is added.

R1 repair directly compares available decoded wire values/flags/acquisition and source relative ticks with each supplied source, companion payload and candidate. Original A046 constructor `original_source_trace_scan_a.py:51-71,81-89` uses source counts, mapped quality and nominal source grid to produce those facts. The new comparisons do not need a fabricated request. Invalid lanes retain null source times; valid held lanes retain their original EM source tick. Candidate comparison uses its represented source-start tick; original source/companion construction uses the actual zero-based source grid. These are representational equalities, not physical sample measurements or clock authentication.

R2 repair collects only available fields per proof. Shared TRACE keys are operation_id, request_hash, tested_commit, boot_id, session_id, tag, generation, clock_domain_id and source_origin_qpc_ns. Config and SourceTime origin fields are nonnullable bounded integers in the unchanged schema, so missing config is not silently replaced by a null anchor. Companion lineage is validated with original B113 field predicates. The shared tuple is exactly the new config TRACE namespace plus source origin; it does not alias C42 context or generation. request_id/request_seq/trigger_id/capture_seq remain per-capture fields. build_id_hex128 is type-checked but not added as a new global equality. Exclusion from this repair's shared comparison is not a claim that genuine installed build custody can vary arbitrarily: original per-record build binding and later real producer gates remain required. The original constructor `:44-47,73-76,106-110` preserves full request/companion lineage per capture; no stronger operation-wide rule is invented here.

One independent bounded process executed **four exact original RED inputs + three NEW adjacent controls**, all seven PASS, exit0, 0.351s, empty stderr:

- Exact wire-value, wire-quality, companion/config-session and two-request-session contradictions all reject.
- A newly enabled held input projects successfully while preserving EM time earlier than ADC time.
- A partial request-only proof with equal TRACE namespace and distinct request IDs, request/trigger/capture sequences remains INPUT_UNAVAILABLE.
- A CRC-correct held wire with source tick increased by one microsecond rejects even without request/config.

Exact input/output bytes and hashes are under run01 and recorded in its results. Original four input hashes match the earlier independent RED manifest and the repair's retained inputs. The complete final input still has independent C42 and B113 generations. No previous passing reviewer group or author suite was replayed; the author ten-input exit0 was audited as separate evidence, not counted as independent confirmation. No new failure occurred. Prior source-wide review and author histories remain version-specific and are not relabeled as a final full-suite run.

`independent_repair_checks.py` is portable with `inputs.json.gz`; the bundle stores the original four UTF-8 strings and hashes, restored without reserializing the replay inputs. The held seed is retained synthetic JSON data; no author fixture or test code is imported. The script constructs the three new adjacent inputs and imports only the new pure package/codecs:

```
python -B independent_repair_checks.py PACKAGE_PARENT inputs.json.gz NEW_OUTPUT_DIRECTORY
```

All outputs remain `core_ran=false` and `authorization=none`; hashes and JSON consistency never authenticate original custody. Approval is restricted to this detached numerical projection source. Actual Root/C46 raw4 admission and production broker/factory integration are absent; preallocation refusal and formal task/board/H12 boundaries remain unchanged. No native/model/PDE/C28/A actor or board operation was executed. Main owns integration and publication. All writes stayed within this new private review directory; the active package and all other source/evidence were read-only.
