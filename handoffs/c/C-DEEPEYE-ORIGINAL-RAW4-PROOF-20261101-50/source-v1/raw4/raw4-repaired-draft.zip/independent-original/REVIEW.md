# C50 raw4 detached projector independent review

**Not approved: two P2 consistency findings, four NEW counterexamples.** The four counterexamples remain `INPUT_UNAVAILABLE / STOP`, with `public_input=null`, `core_ran=false`, and `authorization=none`. This is a malformed-versus-missing contract failure, not an observed execution or authorization bypass.

Reviewed final projector SHA-256 `7468a1d32e3c160e9af8d77900b10672d36ab85973320667bfa1454da2dd14ee`, author FINAL `e68b1c7ff44ca1fa66b970df94290e0e4161ba0febe98dcd6fd53a13b8cff9b7`. Exact inputs/outputs and their sizes/hashes are retained in `run01/` and `case-pins.json`. The script and raw command/stdout/stderr/exit are retained unchanged.

## Findings and minimal repair boundaries

**C50-R1 — supplied E4/source contradictions hidden by missing request.** `transport.py:114-119` compares decoded frames to scan lanes only when a request is available. `projector.py:285-310` similarly relies on request lanes for candidate and source comparisons. In two NEW inputs the request and config are absent, but source bytes, all four companions, candidate counts/quality, wire bytes with corrected CRC, result rows, and matching capture hashes remain supplied. Changing lane 0's value by one, or flipping its saturated flag, returns unavailable at `projector.py:717` instead of rejecting the known disagreement.

This relationship is concrete in exact A046 `original_source_trace_scan_a.py:51-71,81-89`: original source counts and quality determine scan lane values/flags and companion quality. Original `adapter128.py:172-173` checks the decoded value/source time and every quality flag. A missing request prevents full preparation, but cannot erase the already supplied direct count/flag contradiction. Repair should compare available decoded values/flags and source/acquisition time facts to actual source, companion and candidate evidence without manufacturing a request. Do not invent an epoch, nominal acquisition, valid flag or source origin where absent. Keep all other missing proof missing.

**C50-R2 — available B113 namespaces not mutually checked.** `projector.py:292-298` checks config's trace namespace only inside the request branch, and `:338-341` checks companion lineage only against a present request. With request absent, companion `session_id=8` conflicts with supplied config's `session_id=7` yet returns unavailable. A second NEW input has no config, candidate or history, but two well-formed request-only captures declare session 7 versus 8; `_source_checks:367-386` collects C42 contexts only and does not compare the supplied B113 namespaces.

The original constructor uses the same exact `lineage` for request and companion (`original_source_trace_scan_a.py:44-46,71-76,105-110`). The new schema's single config `trace_namespace` specifies the shared B113 operation/request hash/commit/boot/session/tag/generation/clock namespace. Compare known shared fields across actual requests, companion contexts and config even when one is missing. Do not conflate the independent C42 generation/context or force varying per-request request ID/sequence/capture ID to be equal. No new provenance authority follows from those equalities.

## Evidence and coverage

Independently verified 158 frozen files, 17 exact A046 source SHA-256/Git-blob pairs, four frozen C36 baseline hashes, and all seven author version ZIPs against their command pins. Original author exits are **[1,0,1,0,0,1,0]**, 20 distinct names / 27 executions. Run01's two unsupported-provenance fixture failures, run03's four product failures, and run06's fifth product failure remain intact. Run07 alone exercised the final version's two targeted author cases; earlier PASS records are version-specific, not a final-version suite result.

Exact numerical-rules.diff reproduces the frozen C36 `7defaee...` to final C50 source delta. Existing `Check`, `_captures`, `_actors`, `_receipt` and pose/time/interval functions retain their AST. Existing changed functions are `_source_checks` and `_project`; the legacy raw capture/counter path is explicitly removed and replaced by raw4 parsing. The compact public schema and frozen pure predicates are byte-identical. The full schema's differences are enumerated in `audit.json`; no copy of C28 is executed or substituted. Loader pins and the sole AST import-seam replacement in the pure adapter were read directly.

One NEW bounded process ran seven controls against the final bytes: **3 PASS / 4 RED, exit 1, 0.433 seconds**, empty stderr. This is not a replay of the author suite. Seed files are retained JSON data only, originating from the author's run02; no author fixture/test code is imported. Each independent input is newly changed and retained. The three passing controls are:

- Complete fresh input with a different goal and an opaque private clock-metadata sentinel reaches PROJECTED on final source; exact counts and integer QPC are preserved, output stays within 16,380 bytes, input bytes remain unchanged, and the sentinel does not enter public output.
- Held input with the new goal and omitted enable flag remains DISABLED.
- Coherent missing-config plus missing-request input remains INPUT_UNAVAILABLE.

The four failing controls and exact byte hashes are in FINDINGS.json/case-pins.json. No unexpected exception or hidden output leakage occurred in these controls. No candidate rerun followed the first RED process. This narrow evidence does not claim exhaustive quality, budget, alias, freshness or parser coverage. Those unchanged gates were reviewed statically, and previous author logs remain scoped to their recorded versions. Native/held original-EM receipts and closed-span timing remain C36's unchanged numerical rules; all QPC arithmetic here is integer, without origin reset or floating conversion. Original A RootSourceBook `finish_sample:560-599` canonicalizes `asdict(record)` and records actual call/pose/held spans; the new companion check compares that canonical original separately from transport source bytes.

## Scope and reproduction

Only detached numerical projection source was reviewed. Hash/JSON consistency, synthetic data, and PROJECTED do not authenticate original custody, current getter, actual Root receipts, active transaction, source producer, hardware or motion. Actual raw4-to-Root/C46 factory wiring is not installed. Separate mailbox work was not read or changed. Fixed H01-H15 requirements hash was recomputed; neither H12 nor any formal whole-task/board acceptance is claimed. Existing E0 is a pinned representability fact, not an added general demo requirement.

Reproduce only these independent controls with stdlib and the frozen pure package:

```
python -B independent_checks.py PACKAGE_PARENT native-seed.json held-seed.json NEW_OUTPUT_DIRECTORY
```

The script deliberately pins this reviewed version. It imports only the new package and its exact pure data codecs/predicates. It never calls an A actor/source pump, C28, C36 runtime, native handle, model, PDE, board, service, network, or legacy test suite. All writes in this review are under its assigned private directory; author/main/public/old evidence remain unchanged. Main owns repair decisions and publication.

Raw native tool records are saved at finalization, including the earlier mistaken read of a nonexistent immutable-scope path (PowerShell reported a read error; its enclosing multi-command invocation ended exit 0). The correct fixed contract was subsequently fully read and its requirements hash independently recomputed. That read error is not a product test result. Audit/hash work is verification, not additional functional controls.
