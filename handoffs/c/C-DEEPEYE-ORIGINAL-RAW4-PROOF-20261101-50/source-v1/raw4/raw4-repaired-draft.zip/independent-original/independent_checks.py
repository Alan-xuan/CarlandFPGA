"""NEW detached projection controls; no author fixture/suite import or live effects.
CLI: python -B independent_checks.py PACKAGE_PARENT SEED_NATIVE SEED_HELD OUTPUT_DIR
Seeds are retained JSON data, never executable fixtures. Each case makes a new mutation.
"""
import binascii,copy,hashlib,json,struct,sys
from pathlib import Path
sys.dont_write_bytecode=True
package,native,held,out=map(Path,sys.argv[1:]);out.mkdir(exist_ok=True)
assert hashlib.sha256((package/'raw4_proof_v1/projector.py').read_bytes()).hexdigest()=='7468a1d32e3c160e9af8d77900b10672d36ab85973320667bfa1454da2dd14ee'
sys.path.insert(0,str(package));from raw4_proof_v1 import project_raw4_json,Rejected
from raw4_proof_v1 import transport as T
def raw(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def sha(b):return hashlib.sha256(b).hexdigest()
def seed(isheld=False):return json.loads((held if isheld else native).read_bytes())
def baseline(isheld=False):
 x=seed(isheld);x['root_receipt']['config']['goal_m']=[0.375,0.125,2.25];return x
marker='C50_REVIEW_PRIVATE_MARKER_NOT_A_GRANT'
def private_complete():
 x=baseline();r=x['root_receipt']['captures'][-1];p=r['raw4'];request=json.loads(bytes.fromhex(p['request_hex']))
 bodies=[json.loads(bytes.fromhex(b))for b in p['companions_hex']]
 for body in bodies:body['source_context']['clock_metadata']={'private_marker':marker}
 p['companions_hex']=[raw(body).hex()for body in bodies]
 for d,b in zip(request['companions'],p['companions_hex']):d.update(bytes=len(bytes.fromhex(b)),sha256=sha(bytes.fromhex(b)))
 request['association']['source_context_sha256']=sha(raw(bodies[0]['source_context']))
 p['request_hex']=raw(request).hex();x['candidate']['observation_identity']['request_sha256']=sha(raw(request));return x

def changed_wire(field):
 x=baseline();x['root_receipt']['config']=None;r=x['root_receipt']['captures'][-1];p=r['raw4'];p['request_hex']=None
 original=bytes.fromhex(p['wire_hex']);n=original[4]+14;frame=original[:n];payload=frame[12:-2]
 session=struct.unpack_from('<I',payload,5)[0];view=frame[5];e=T.CODEC.E_BY_CODE[payload[1]&7]
 point=T.CODEC.decode_payload(bytes([1])+payload[1:],dict(session=session,config_epoch=view,e=e))['points'][0]
 if field=='value':point['value']=(point['value']+1)%4096
 else:point['saturated']=not point['saturated']
 b=T.CODEC.encode_payload([point],dict(session=session,config_epoch=view,e=e),0);b=bytes([2])+b[1:]
 header=bytearray(frame[:12]);header[4]=len(b);new=bytes(header)+b;new+=struct.pack('<H',binascii.crc_hqx(new[2:],0xffff));wire=new+original[n:]
 assert len(wire)==len(original)
 p['wire_hex']=wire.hex();old=r['capture_sha256'];r['capture_sha256']=sha(wire);x['candidate']['observation_identity']['capture_sha256']=sha(wire)
 if r['em_origin_capture_sha256']==old:r['em_origin_capture_sha256']=sha(wire)
 return x

def companion_namespace():
 x=baseline();p=x['root_receipt']['captures'][-1]['raw4'];p['request_hex']=None
 bodies=[json.loads(bytes.fromhex(b))for b in p['companions_hex']]
 for body in bodies:body['source_context']['lineage']['session_id']+=1
 p['companions_hex']=[raw(body).hex()for body in bodies];return x

def partial_two_namespaces():
 x=baseline();x['candidate']=None;x['history']=[];x['root_receipt']['config']=None
 for i,r in enumerate(x['root_receipt']['captures']):
  p=r['raw4'];req=json.loads(bytes.fromhex(p['request_hex']))
  if i:
   req['lineage']['session_id']+=1
   for lane in req['scan']['lanes']:lane['session']+=1
  for k in p:p[k]=None
  p['request_hex']=raw(req).hex()
 return x
x=baseline(True);x.pop('enabled',None)
y=baseline();y['root_receipt']['config']=None;y['root_receipt']['captures'][-1]['raw4']['request_hex']=None
cases=[('new-private-metadata-complete-goal','PROJECTED',private_complete()),('new-held-default-off-goal','DISABLED',x),('new-missing-config-and-request-coherent','INPUT_UNAVAILABLE',y),('new-missing-request-wire-value-conflict','REJECTED',changed_wire('value')),('new-missing-request-wire-quality-conflict','REJECTED',changed_wire('saturated')),('new-companion-session-vs-config-no-request','REJECTED',companion_namespace()),('new-two-request-only-sessions-no-config','REJECTED',partial_two_namespaces())]
results=[]
for name,expected,x in cases:
 b=raw(x);before=sha(b);(out/(name+'.input.json')).write_bytes(b)
 try:
  response=project_raw4_json(b);doc=json.loads(response);actual=doc['input_status']
  assert doc['authorization']=='none' and doc['core_ran'] is False and doc['diagnostic_only'] is True
  assert marker.encode() not in response and sha(b)==before
  if actual=='PROJECTED':
   pub=doc['public_input'];assert len(raw(pub))<=16380 and pub['goal_m']==[0.375,0.125,2.25]
   assert pub['observation']['counts']==x['candidate']['channel_counts']
   assert pub['observation']['adc_qpc_ns']==x['candidate']['source_time']['source_start_monotonic_ns']+x['candidate']['source_time']['adc_tick_ms']*1000000
 except Rejected as e:actual='REJECTED';response=raw(dict(exception='Rejected',reason=str(e)))
 except Exception as e:actual='UNEXPECTED_EXCEPTION';response=raw(dict(exception=type(e).__name__,reason=str(e)))
 (out/(name+'.output.json')).write_bytes(response)
 row=dict(name=name,expected=expected,observed=actual,passed=actual==expected,input_bytes=len(b),input_sha256=before,output_sha256=sha(response));results.append(row);print(json.dumps(row),flush=True)
assert not any('c28' in k.lower() or 'fixtures_new' in k or 'checks_new' in k for k in sys.modules)
(out/'results.json').write_bytes(raw(results));raise SystemExit(0 if all(r['passed']for r in results)else 1)
