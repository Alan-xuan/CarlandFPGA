"""Independent original-byte checks, never retained correlation summaries.

The four fixed pure dependencies are private module instances. Only adapter128's
single import statement is replaced by its exact pinned data dependencies; no
provider/caller import hook, registration or live resource is accepted.
"""
import ast
import binascii
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import struct
import sys
import types

_BASE=Path(__file__).resolve().parent
_PINS={'input113.py':'95b46940767d3be4dbe3d885a4852119161ea5e4567ab3bda51798c39109ea49',
 'codec.py':'a489ac34b49976532803b34f006f8bc24103548f34ddd55cc2ecaedc529a9642',
 'adapter128.py':'12d975c2841edb65ef427121d098cd6ed27f600edd922f1a63fc5d6b5908ea41',
 'sensor_source.py':'0d3dbd0f74609131cf858b4214a708bde7251bfba7640e225c0040260de1f5db'}

def _fixed(name, injected=None):
    raw=(_BASE/'deps'/name).read_bytes()
    if hashlib.sha256(raw).hexdigest()!=_PINS[name]:raise ImportError('C50 exact dependency mismatch')
    key=__name__+'._'+name[:-3]
    module=types.ModuleType(key);module.__file__=str(_BASE/'deps'/name);sys.modules[key]=module
    if injected:
        tree=ast.parse(raw); removed=[n for n in tree.body if isinstance(n,ast.ImportFrom) and n.module=='dependencies128']
        if len(removed)!=1 or [a.name for a in removed[0].names]!=['input113','codec','INPUT_SHA','CODEC_SHA']:
            raise ImportError('C50 adapter import seam changed')
        tree.body.remove(removed[0]);code=compile(tree,module.__file__,'exec');module.__dict__.update(injected)
    else:code=compile(raw,module.__file__,'exec')
    exec(code,module.__dict__);return module

INPUT=_fixed('input113.py');CODEC=_fixed('codec.py');SOURCE=_fixed('sensor_source.py')
ADAPTER=_fixed('adapter128.py',dict(input113=INPUT,codec=CODEC,INPUT_SHA=_PINS['input113.py'],CODEC_SHA=_PINS['codec.py']))

class Invalid(ValueError):pass
def need(ok):
    if not ok:raise Invalid('RAW4_CONTRADICTION')
def digest(b):return hashlib.sha256(b).hexdigest()
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def parse(b):
    def pairs(items):
        out={}
        for k,v in items:need(k not in out);out[k]=v
        return out
    def constant(_):raise Invalid('RAW4_CONTRADICTION')
    try:return json.loads(b.decode('utf8'),object_pairs_hook=pairs,parse_constant=constant)
    except (ValueError,UnicodeError,RecursionError):raise Invalid('RAW4_CONTRADICTION') from None
def exact(obj,keys):need(type(obj)is dict and set(obj)==set(keys))

def frames(wire):
    """Decode actual headers/payload/CRC even when other evidence is missing.

    The binding below is derived from this untrusted packet for decoding only;
    it is not a producer or expected-session authentication assertion.
    """
    need(type(wire)is bytes and 0<len(wire)<=252);off=0;out=[]
    while off<len(wire):
        need(len(wire)-off>=35)
        magic,version,kind,length,view,seq,tick=struct.unpack_from('<2sBBBBHI',wire,off)
        size=length+14;need(magic==b'\xa5\x5a' and version==3 and kind==0xe4 and 21<=length<=32 and off+size<=len(wire))
        frame=wire[off:off+size];off+=size
        need(struct.unpack_from('<H',frame,size-2)[0]==binascii.crc_hqx(frame[2:-2],0xffff))
        payload=frame[12:-2];need(payload[0]==2)
        code=payload[1]&7;need(code in CODEC.E_BY_CODE)
        session=struct.unpack_from('<I',payload,5)[0]
        decoded=CODEC.decode_payload(bytes([1])+payload[1:],dict(session=session,config_epoch=view,e=CODEC.E_BY_CODE[code]))
        need(decoded['count']==1 and decoded['channel']==len(out))
        point=decoded['points'][0];need(point['tick_ms']==tick)
        out.append(dict(view=view,seq=seq,session=session,point=point,bytes=size,sha256=digest(frame)))
    need(len(out)==4)
    need(len({x['session'] for x in out})==1 and len({x['view'] for x in out})==1)
    need(len({x['point']['index'] for x in out})==1 and len({x['point']['tick_ms'] for x in out})==1)
    need(all(a['seq']<b['seq'] for a,b in zip(out,out[1:])))
    return out

def source_frames(decoded, counts, quality, adc_tick_ms, em_tick_ms, start_tick_ms=0):
    """Original constructor's relative-us/value/flag mapping, with actual facts only."""
    if decoded is None:return
    for i,frame in enumerate(decoded):
        point=frame['point'];valid=bool(quality&(1<<i))
        source_tick=em_tick_ms if i<3 else adc_tick_ms
        expected_source=None if not valid else (source_tick-start_tick_ms)*1000
        need(point['value']==counts[i])
        need(point['tick_ms']==(adc_tick_ms-start_tick_ms)*1000)
        need(point['source_tick_ms']==expected_source)
        flags=dict(valid=valid,saturated=bool(quality&(16<<i)),held=bool(quality&(256<<i)),source_fault=bool(quality&4096))
        need(all(type(point[k])is bool and point[k]==v for k,v in flags.items()))

def lineage_namespace(lineage,clock,origin):
    """Original B113 typed fields; no request or authority is manufactured."""
    INPUT._obj(lineage,INPUT.LINEAGE_KEYS,'$.lineage')
    for k in ('operation_id','request_id','boot_id'):INPUT._text(lineage[k],'$.lineage.'+k,1,192,True)
    INPUT._sha256(lineage['request_hash'],'$.lineage.request_hash')
    INPUT._fixed_hex(lineage['tested_commit'],40,'$.lineage.tested_commit')
    INPUT._fixed_hex(lineage['build_id_hex128'],32,'$.lineage.build_id_hex128')
    for k in ('session_id','tag','trigger_id','generation','request_seq','capture_seq'):INPUT._int(lineage[k],0,(1<<32)-1,'$.lineage.'+k)
    INPUT._text(clock,'$.scan.clock_domain_id',1,192,True)
    INPUT._int(origin,0,(1<<63)-1,'$.scan.origin_qpc_ns')
    return dict({k:lineage[k] for k in ('operation_id','request_hash','tested_commit','boot_id','session_id','tag','generation')},clock_domain_id=clock,source_origin_qpc_ns=origin)

def inspect(packet):
    """All available original components are checked; absent components stay None."""
    if packet is None:return dict(missing=True)
    raw={k:(None if packet[k] is None else bytes.fromhex(packet[k])) for k in ('request_hex','source_hex','wire_hex')}
    companions=None if packet['companions_hex'] is None else tuple(bytes.fromhex(x) for x in packet['companions_hex'])
    request=None; source=None; decoded=None; bodies=None
    if raw['request_hex'] is not None:
        from . import partial113
        request=INPUT._parse_request(raw['request_hex'])
        INPUT._obj(request,INPUT.TOP_KEYS,'$')
        need(request['schema']==INPUT.REQUEST_SCHEMA)
        INPUT._obj(request['scan'],INPUT.SCAN_KEYS,'$.scan')
        INPUT._obj(request['lineage'],INPUT.LINEAGE_KEYS,'$.lineage')
        INPUT._obj(request['association'],INPUT.ASSOCIATION_KEYS,'$.association')
        need(type(request['scan']['lanes'])is list and len(request['scan']['lanes'])==4)
        for i,lane in enumerate(request['scan']['lanes']):INPUT._parse_lane(lane,i,'$.scan.lanes')
        need(canonical(request)==raw['request_hex'])
        partial113.validate(request,raw['source_hex'],companions)
    if raw['source_hex'] is not None:
        source=parse(raw['source_hex']);SOURCE.validate_record(source)
        need(canonical(source)==raw['source_hex'])
        if request is not None:need(request['source_payload']['sha256']==digest(raw['source_hex']) and request['source_payload']['bytes']==len(raw['source_hex']))
    if raw['wire_hex'] is not None:decoded=frames(raw['wire_hex'])
    rows=packet['result_rows']
    if rows is not None:
        previous=None
        for i,row in enumerate(rows):
            need(row['id']>0 and row['error']==0 and row['rx_end']==row['rx_before']+row['bytes'])
            need(row.get('refusal',0)==0 and ('status' not in row or row['status']&16 and not row['status']&4))
            if previous is not None:need(row['id']==previous['id']+1 and row['rx_before']==previous['rx_end'])
            if decoded is not None:
                need(row['bytes']==decoded[i]['bytes'])
                if 'channel' in row:need(row['channel']==i)
                if 'frame_seq' in row:need(row['frame_seq']==decoded[i]['seq'])
            previous=row
    if decoded is not None and request is not None:
        for i,(frame,lane) in enumerate(zip(decoded,request['scan']['lanes'])):
            point=frame['point']
            need(frame['view']==lane['view'] and frame['seq']==lane['frame_seq'] and frame['session']==lane['session'])
            need(point['index']==lane['index'] and point['tick_ms']==lane['acquisition_tick_us'] and point['source_tick_ms']==lane['source_tick_us'] and point['value']==lane['raw_sample_uint16'])
            need(all(point[k]==lane['mapped_flags'][k] for k in ('valid','saturated','held','source_fault')))
    if companions is not None:
        bodies=[]
        for i,b in enumerate(companions):
            item=parse(b);exact(item,('schema','channel','payload_utf8_hex','book_draft','source_context','timestamp_record','quality_record'))
            need(item['schema']=='original-source-trace-companion-v1' and type(item['channel'])is int and item['channel']==i and canonical(item)==b)
            payload=bytes.fromhex(item['payload_utf8_hex']);sp=parse(payload);SOURCE.validate_record(sp);need(canonical(sp)==payload)
            if source is not None:need(payload==raw['source_hex'])
            draft=item['book_draft'];need(type(draft)is dict and draft.get('status')=='complete')
            need(type(draft.get('canonical_source_hex'))is str)
            original=bytes.fromhex(draft['canonical_source_hex'])
            record=SOURCE.validate_record(sp)
            need(original==canonical(asdict(record)) and draft.get('source_sha256')==digest(original) and draft.get('payload')==sp)
            need(draft.get('tick_ms')==sp['adc_tick_ms'])
            if request is not None:
                desc=request['companions'][i];need(desc['channel']==i and desc['sha256']==digest(b) and desc['bytes']==len(b))
            if bodies:
                for key in ('payload_utf8_hex','book_draft','source_context','timestamp_record','quality_record'):need(item[key]==bodies[0][key])
            bodies.append(item)
    # Each supplied source representation independently constrains the real wire.
    # Companion-only evidence does not need an invented request or source packet.
    sources=([source] if source is not None else [])
    if bodies is not None:sources.append(parse(bytes.fromhex(bodies[0]['payload_utf8_hex'])))
    for sp in sources:source_frames(decoded,sp['channel_counts'],sp['quality'],sp['adc_tick_ms'],sp['em_tick_ms'])
    # Correlation is recomputed from original bytes, never from C49 frames caches.
    complete=all(v is not None for v in raw.values()) and companions is not None and packet['build_binding'] is not None and packet['result_rows'] is not None
    correlated=None
    if complete:
        prepared=ADAPTER.prepare_bytes(raw['request_hex'],raw['source_hex'],companions,build_binding=packet['build_binding'])
        need(prepared.plan is not None)
        correlated=ADAPTER.correlate_collected(prepared.plan,raw['wire_hex'],companions,packet['result_rows'])
        need(correlated['status']=='FOUR_FRAME_CORRELATION_CONSISTENT')
    return dict(missing=not complete,raw=raw,request=request,source=source,bodies=bodies,frames=decoded)
