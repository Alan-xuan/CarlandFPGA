"""Explicit partial B113 derivative: absent bytes are never manufactured.
Only byte-dependent digest comparisons are skipped for None; all supplied envelope
shape and original intrinsic QPC/session/view/sequence rules still run.
"""
import hashlib
from .transport import INPUT
ASSOCIATION_KEYS=INPUT.ASSOCIATION_KEYS
COMPANION_KEYS=INPUT.COMPANION_KEYS
FRESHNESS_LIMIT_NS=INPUT.FRESHNESS_LIMIT_NS
LINEAGE_KEYS=INPUT.LINEAGE_KEYS
MAX_COMPANION_BYTES=INPUT.MAX_COMPANION_BYTES
MAX_SOURCE_BYTES=INPUT.MAX_SOURCE_BYTES
MAX_UINT32=INPUT.MAX_UINT32
MAX_UINT63=INPUT.MAX_UINT63
PROVENANCE_CLASSES=INPUT.PROVENANCE_CLASSES
PROVENANCE_KEYS=INPUT.PROVENANCE_KEYS
REQUEST_SCHEMA=INPUT.REQUEST_SCHEMA
REQUIREMENTS_SHA256=INPUT.REQUIREMENTS_SHA256
SCAN_KEYS=INPUT.SCAN_KEYS
SOURCE_KEYS=INPUT.SOURCE_KEYS
TASK_ID=INPUT.TASK_ID
TASK_KEYS=INPUT.TASK_KEYS
TASK_VERSION=INPUT.TASK_VERSION
TOP_KEYS=INPUT.TOP_KEYS
_enum=INPUT._enum
_fixed_hex=INPUT._fixed_hex
_int=INPUT._int
_obj=INPUT._obj
_parse_lane=INPUT._parse_lane
_qpc_sum=INPUT._qpc_sum
_refuse=INPUT._refuse
_sha256=INPUT._sha256
_text=INPUT._text

def _parse_envelope_partial(request, source_bytes, companion_bytes):
    root = _obj(request, TOP_KEYS, "$")
    _enum(root["schema"], (REQUEST_SCHEMA,), "$.schema")
    task = _obj(root["task"], TASK_KEYS, "$.task")
    task_id = _text(task["task_id"], "$.task.task_id", 1, 192, True)
    if task_id != TASK_ID:
        _refuse("TASK_ID", "$.task.task_id")
    version = _int(task["task_version"], TASK_VERSION, TASK_VERSION, "$.task.task_version")
    if version != TASK_VERSION:
        _refuse("TASK_VERSION", "$.task.task_version")
    work_id = _text(task["work_id"], "$.task.work_id", 1, 192, True)
    req_hash = _sha256(task["requirements_sha256"], "$.task.requirements_sha256")
    if req_hash != REQUIREMENTS_SHA256:
        _refuse("TASK_REQUIREMENTS", "$.task.requirements_sha256")

    provenance = _obj(root["source_provenance"], PROVENANCE_KEYS, "$.source_provenance")
    source_class = _enum(provenance["class"], PROVENANCE_CLASSES, "$.source_provenance.class")
    declared_by = _text(provenance["declared_by"], "$.source_provenance.declared_by", 1, 192, True)
    source_note = _text(provenance["source_note"], "$.source_provenance.source_note", 0, 1024, False)
    mapping_state = _enum(provenance["mapping_state"], ("B_NEUTRAL_AWAITING_A_MAPPING",),
                          "$.source_provenance.mapping_state")

    source_desc = _obj(root["source_payload"], SOURCE_KEYS, "$.source_payload")
    source_format = _text(source_desc["format_label"], "$.source_payload.format_label", 1, 192, True)
    declared_source_length = _int(source_desc["bytes"], 1, MAX_SOURCE_BYTES, "$.source_payload.bytes")
    declared_source_sha = _sha256(source_desc["sha256"], "$.source_payload.sha256")
    actual_source_sha = None if source_bytes is None else hashlib.sha256(source_bytes).hexdigest()
    if source_bytes is not None and declared_source_length != len(source_bytes):
        _refuse("SOURCE_LENGTH", "$.source_payload.bytes")
    if source_bytes is not None and declared_source_sha != actual_source_sha:
        _refuse("SOURCE_SHA", "$.source_payload.sha256")

    scan_raw = _obj(root["scan"], SCAN_KEYS, "$.scan")
    scan_id = _int(scan_raw["scan_id_uint63"], 0, MAX_UINT63, "$.scan.scan_id_uint63")
    origin = _int(scan_raw["origin_qpc_ns"], 0, MAX_UINT63, "$.scan.origin_qpc_ns")
    acquisition = _int(scan_raw["acquisition_qpc_ns"], 0, MAX_UINT63, "$.scan.acquisition_qpc_ns")
    clock_domain = _text(scan_raw["clock_domain_id"], "$.scan.clock_domain_id", 1, 192, True)
    lane_raw = scan_raw["lanes"]
    if type(lane_raw) is not list:
        _refuse("TYPE", "$.scan.lanes")
    if len(lane_raw) != 4:
        _refuse("LANES_LENGTH", "$.scan.lanes")
    lanes = tuple(_parse_lane(item, index, f"$.scan.lanes[{index}]") for index, item in enumerate(lane_raw))

    lineage_raw = _obj(root["lineage"], LINEAGE_KEYS, "$.lineage")
    operation_id = _text(lineage_raw["operation_id"], "$.lineage.operation_id", 1, 192, True)
    request_id = _text(lineage_raw["request_id"], "$.lineage.request_id", 1, 192, True)
    lineage_request_hash = _sha256(lineage_raw["request_hash"], "$.lineage.request_hash")
    tested_commit = _fixed_hex(lineage_raw["tested_commit"], 40, "$.lineage.tested_commit")
    build_id = _fixed_hex(lineage_raw["build_id_hex128"], 32, "$.lineage.build_id_hex128")
    boot_id = _text(lineage_raw["boot_id"], "$.lineage.boot_id", 1, 192, True)
    session_id = _int(lineage_raw["session_id"], 0, MAX_UINT32, "$.lineage.session_id")
    tag = _int(lineage_raw["tag"], 0, MAX_UINT32, "$.lineage.tag")
    trigger_id = _int(lineage_raw["trigger_id"], 0, MAX_UINT32, "$.lineage.trigger_id")
    generation = _int(lineage_raw["generation"], 0, MAX_UINT32, "$.lineage.generation")
    request_seq = _int(lineage_raw["request_seq"], 0, MAX_UINT32, "$.lineage.request_seq")
    capture_seq = _int(lineage_raw["capture_seq"], 0, MAX_UINT32, "$.lineage.capture_seq")
    lineage = {
        "operation_id": operation_id, "request_id": request_id, "request_hash": lineage_request_hash,
        "tested_commit": tested_commit, "build_id_hex128": build_id, "boot_id": boot_id,
        "session_id": session_id, "tag": tag, "trigger_id": trigger_id, "generation": generation,
        "request_seq": request_seq, "capture_seq": capture_seq,
    }

    assoc_raw = _obj(root["association"], ASSOCIATION_KEYS, "$.association")
    profile_id = _text(assoc_raw["profile_id"], "$.association.profile_id", 1, 192, True)
    binding_receipt_id = _text(assoc_raw["binding_receipt_id"], "$.association.binding_receipt_id", 1, 192, True)
    e_value = _int(assoc_raw["e"], 0, 8, "$.association.e")
    if e_value not in (0, 1, 2, 4, 8):
        _refuse("ASSOCIATION_E", "$.association.e")
    source_context_sha = _sha256(assoc_raw["source_context_sha256"], "$.association.source_context_sha256")
    timestamp_record_sha = _sha256(assoc_raw["timestamp_record_sha256"], "$.association.timestamp_record_sha256")
    quality_record_sha = _sha256(assoc_raw["quality_record_sha256"], "$.association.quality_record_sha256")
    receiver = _int(assoc_raw["receiver_qpc_ns"], 0, MAX_UINT63, "$.association.receiver_qpc_ns")
    evaluation = _int(assoc_raw["evaluation_now_qpc_ns"], 0, MAX_UINT63, "$.association.evaluation_now_qpc_ns")
    evaluation_clock = _text(assoc_raw["evaluation_clock_id"], "$.association.evaluation_clock_id", 1, 192, True)
    receiver_clock = _text(assoc_raw["receiver_clock_id"], "$.association.receiver_clock_id", 1, 192, True)
    freshness_limit = _int(assoc_raw["freshness_limit_ns"], FRESHNESS_LIMIT_NS, FRESHNESS_LIMIT_NS,
                          "$.association.freshness_limit_ns")
    association = {
        "profile_id": profile_id, "binding_receipt_id": binding_receipt_id, "e": e_value,
        "source_context_sha256": source_context_sha, "timestamp_record_sha256": timestamp_record_sha,
        "quality_record_sha256": quality_record_sha, "receiver_qpc_ns": receiver,
        "evaluation_now_qpc_ns": evaluation, "evaluation_clock_id": evaluation_clock,
        "receiver_clock_id": receiver_clock, "freshness_limit_ns": freshness_limit,
    }

    companion_raw = root["companions"]
    if type(companion_raw) is not list:
        _refuse("TYPE", "$.companions")
    if len(companion_raw) != 4:
        _refuse("COMPANIONS_LENGTH", "$.companions")
    companions = []
    for index, desc_raw in enumerate(companion_raw):
        body = None if companion_bytes is None else companion_bytes[index]
        path = f"$.companions[{index}]"
        desc = _obj(desc_raw, COMPANION_KEYS, path)
        channel = _int(desc["channel"], 0, MAX_UINT32, path + ".channel")
        if channel != index:
            _refuse("COMPANION_CHANNEL", path + ".channel")
        format_label = _text(desc["format_label"], path + ".format_label", 1, 192, True)
        length = _int(desc["bytes"], 1, MAX_COMPANION_BYTES, path + ".bytes")
        declared_sha = _sha256(desc["sha256"], path + ".sha256")
        actual_sha = None if body is None else hashlib.sha256(body).hexdigest()
        if body is not None and length != len(body):
            _refuse("COMPANION_LENGTH", path + ".bytes")
        if body is not None and declared_sha != actual_sha:
            _refuse("COMPANION_SHA", path + ".sha256")
        companions.append({"channel": channel, "format_label": format_label, "bytes": body,
                           "byte_length": None if body is None else len(body), "declared_sha256": declared_sha,
                           "computed_sha256": actual_sha, "matches": None if body is None else True})

    return {
        "work_id": work_id, "provenance": {"class": source_class, "declared_by": declared_by,
        "source_note": source_note, "mapping_state": mapping_state},
        "source": {"format_label": source_format, "bytes": source_bytes, "byte_length": None if source_bytes is None else len(source_bytes),
                   "declared_sha256": declared_source_sha, "computed_sha256": actual_source_sha, "matches": None if source_bytes is None else True},
        "scan": {"scan_id_uint63": scan_id, "origin_qpc_ns": origin, "acquisition_qpc_ns": acquisition,
                 "clock_domain_id": clock_domain, "lanes": lanes},
        "lineage": lineage, "association": association, "companions": tuple(companions),
    }

def validate(request,source_bytes,companion_bytes):
    envelope=_parse_envelope_partial(request,source_bytes,companion_bytes)
    scan = envelope["scan"]
    association = envelope["association"]
    lineage = envelope["lineage"]
    clock_domain = scan["clock_domain_id"]
    if association["receiver_clock_id"] != clock_domain:
        _refuse("CLOCK_DOMAIN_MISMATCH", "$.association.receiver_clock_id")
    if association["evaluation_clock_id"] != clock_domain:
        _refuse("CLOCK_DOMAIN_MISMATCH", "$.association.evaluation_clock_id")

    origin = scan["origin_qpc_ns"]
    acquisition = scan["acquisition_qpc_ns"]
    lanes = []
    for index, lane in enumerate(scan["lanes"]):
        path = f"$.scan.lanes[{index}]"
        if lane["acquisition_qpc_ns"] != acquisition:
            _refuse("ACQUISITION_MISMATCH", path + ".acquisition_qpc_ns")
        expected_acquisition = _qpc_sum(origin, lane["acquisition_tick_us"],
                                        lane["acquisition_remainder_ns"], path + ".acquisition_qpc_ns")
        if expected_acquisition != lane["acquisition_qpc_ns"]:
            _refuse("QPC_EQUATION", path + ".acquisition_qpc_ns")
        if lane["source_qpc_ns"] is not None:
            expected_source = _qpc_sum(origin, lane["source_tick_us"],
                                        lane["source_remainder_ns"], path + ".source_qpc_ns")
            if expected_source != lane["source_qpc_ns"]:
                _refuse("QPC_EQUATION", path + ".source_qpc_ns")
            if lane["source_qpc_ns"] > lane["acquisition_qpc_ns"]:
                _refuse("SOURCE_AFTER_ACQUISITION", path + ".source_qpc_ns")
            is_held = lane["source_qpc_ns"] < lane["acquisition_qpc_ns"]
            if lane["mapped_flags"]["held"] != is_held:
                _refuse("HELD_MISMATCH", path + ".mapped_flags.held")
        lanes.append(lane)

    if not (origin <= acquisition <= association["receiver_qpc_ns"] <= association["evaluation_now_qpc_ns"]):
        _refuse("TIMESTAMP_ORDER", "$.association")
    if any(item["session"] != lineage["session_id"] for item in lanes):
        _refuse("SESSION_MISMATCH", "$.lineage.session_id")
    if len({item["view"] for item in lanes}) != 1:
        _refuse("VIEW_MISMATCH", "$.scan.lanes")
    frames = [item["frame_seq"] for item in lanes]
    if not all(frames[index] < frames[index + 1] for index in range(3)):
        _refuse("FRAME_ORDER", "$.scan.lanes")
    return envelope
