# Per-version replay instructions (not executed by packaging)

Use Python 3.11+ standard library. Enforce an external 30-second bound per run.
First verify delivery bytes using verify_package.py; it does not import products.

Original seven author runs: extract history/original-unapproved-draft.zip to a
separate OLD directory and follow its REPLAY.md, using each run source-version
ZIP and the common exact inputs/ directory. Do not overlay the repaired module.
Historical expected exits are [1,0,1,0,0,1,0].

Original independent RED process: copy independent-original/independent_checks.py
and both seed JSON files to a new independent replay directory. Use the DERIVED
command there, substituting OLD_PACKAGE_DIRECTORY with the extracted OLD path
containing original raw4_proof_v1. The script pins the original projector hash;
do not change that pin or run it with the repaired package. Its original seven
case outputs and exit 1 remain under independent-original/run01 and exit.json.

Repair: extract repair/runs/run01/source-version.zip into a new empty VERSION.
This archive already includes check_repair.py, cases.json, every exact input and
the repaired module/dependencies. Create VERSION/runs/replay01, then from VERSION
run the argv in repair/runs/run01/command.DERIVED.json (local Python executable).
The checker creates runs/replay01/cases; it must not exist before replay. Expected
exit is 0 for ten cases. Preserve any new logs separately. The original output
is repair/runs/run01/cases; no test fixture-generation module is imported.

Every source-version ZIP is exact. Current final-source-pins and repair.diff
identify the repaired source against the rejected predecessor. These synthetic
controls do not authenticate original producer identity or demonstrate hardware.
