# C50 raw4 proof v1: detached numerical projection

Entry: `raw4_proof_v1.project_raw4_json(full_proof: bytes) -> bytes`.
Schema: `raw4_proof_v1/request.schema.json`. Public output schema is the exact
unchanged C36/C37 `public-view.schema.json`; the fixed C28 core is never loaded.
This is a new ABI (`schema_version=1`, `abi_id=raw4_full_proof_v1`), not a C36
compatible packet. Disabled is the default. A complete, enabled, coherent proof
can return PROJECTED; absent original facts return INPUT_UNAVAILABLE/STOP;
supplied contradictions raise dedicated Rejected before missing/default exits.

The result has authorization=none, diagnostic_only=true, core_ran=false,
claim=numerical_immutable_committed_root_only and native_interval_atomic=false.
JSON, receipt labels, enabled, schema validity and hashes never authenticate an
original owner, transport, board, source, getter, completion or dispatch grant.
The actual Root/C46 association hook is outside this module and remains open.

## Concrete changes from C36 host v2

- Candidate is `raw4_four_channel_observation_v1`; transport_source is
  `B113_E4_original_raw4`. No source_id=4 legacy wire assertion, fake injection
  times, old diagnostic flags or fabricated ACK/pipeline counters.
- `observation_identity.capture_lower_qpc_ns` is the actual original host phase
  lower QPC, required-nullable; receiver_upper is the original full-return upper.
  It is not four ADC injection timestamps. SourceTime remains the original
  nominal grid; its receiver ages are explicitly derived differences.
- Config omits original PL baseline_counters and initial_trigger_id. Its original
  C42 context remains intact. `trace_namespace` separately records B113 operation,
  request hash, tested commit, boot, numeric session, tag, generation and clock.
  No string-to-integer session aliasing or inferred identity is allowed.
  Candidate/config/current `generation` stays in the C42 namespace; TRACE
  generation is checked against `trace_namespace` separately. Positive synthetic
  controls deliberately use C42 generation 1 and TRACE generation 9.
- Capture retains its original numerical pose/call/held-EM and cause-action
  fields, adds `mapping_receipt_id`, and replaces request_raw/capture_raw with
  `raw4`: nullable original request_hex, source_hex, companions_hex[4], wire_hex,
  result_rows[4], build_binding. These are original bytes, not reserialized JSON
  represented as wire. No evidence is silently truncated.
- ActorBook targets exact A046; its root_source_book.py and custody source hashes
  equal the A108 pinned implementations. Same numerical interval rules apply.

## Field-to-source mapping

All original paths below are under `competition/deepeye/`, exact commit
0469345fd1eef2884de1417f0f4eb5b67688f84c. Full SHA256/Git blobs are in source-pins.

| New field or relation | Original source/callsite | Meaning and availability |
|---|---|---|
| request/source/companions bytes | `tools/diagnostic/original_source_trace_scan_a.py:_construct_bytes`, scanner `_attempt`/`_attempts`; actual preparation.original | Preserve exact bytes and original binding; declarations alone are not authenticity. |
| wire/result rows | `functional50_adapter128/adapter128.py:correlate_collected`; original phase response | E4 binary and board result facts; re-decode all original frames, lengths, CRC, channel/order/index/sequence/value/flags/source time. Retained C49 correlation summaries are not used. |
| build_binding | `adapter128.prepare_bytes`; original preparation Plan | Full build/closure digests and original operation/request match. This checks declared relationships, not remote artifact custody. |
| source payload | `integration/sensor_source.py:validate_record`; scanner source bytes | Exact nine fields, candidate profile/quality/calibration status, quantization, null/zero/held/saturation preserved. Never truth geometry. |
| book source SHA | `simulation/authority/root_source_book.py:finish_sample` | Hash of canonical `asdict(SourceRecord)` UTF-8. Validate its own original preimage in companion draft. It is not blindly equated with arbitrary wire/newline source hash. |
| source admission SHA/time/index | scanner `_admitted`: original admission, received, payload_bytes | Compare original source bytes and full prefix. No history dropped or guessed index. |
| per-lane source/acquisition QPC | scanner `_construct_bytes` request.scan.lanes | Nominal ADC/EM grid, not exact native call timestamp. Preserve all four flags/nullable source times and microsecond remainder. Each lane is checked; min(times) is insufficient. |
| ADC/EM actual read and calls | companion.book_draft and original SourceBook sample | Whitelist compare to corresponding full actor_book sample; validate original begin/end/postcheck/root/revoke and pose spans. |
| held EM | draft.held_em_association.original_em | Original old sample, pose, span and capture link retained. No moving held values to the latest pose. |
| current pose | `RootSourceBook.current_pose_interval()` real call | Actual at/pose/pose_read/valid_span mapped through original C42 mechanics. `evidence().current_pose_interval` alone is insufficient; ordered getter + evidence is not atomic. |
| motion/BOOT/COMMAND | original custody and original world link registry | Original from/to/candidate Roots, CAS lower/pre/post/completion, returned receipt, getter publication, revocation and successor state; no inferred exact action timestamp. |
| C42 namespace versus TRACE namespace | original config/current/registry versus B113 lineage | Separate fields. Root must retain actual one-source cross-format association; a matching label is only consistency. |

Every represented known field is compared without forwarding hidden Book data
to the planner. Source spans are closed: old through must be strictly before
the earliest original transition; new span begins no earlier than actual
completion. Gaps remain unavailable. BOOT/COMMAND retain lineage even at same
pose. Missing unrelated config must not hide supplied contradictory bytes,
current/read/transition or custody facts.

## Reused numerical rules and limits

`numerical-rules.diff` gives the complete derivative against frozen C36 host v2.
`derivation-pins.json` records original engine/schema/public-schema/predicate
hashes. Parsing shape bounds, source prefix/grid, original EM quantization,
current pose checks, strict spans, transition/custody/revocation/getter checks,
combined max(candidate count, capture count)+STEP actions <=32 and 16380-byte
public cap remain explicit source-derived rules. Original C36 is not imported
or called. Its extracted pure predicates are pinned data helpers only.

The exact B113 normalizer, TRACE codec, adapter128 and sensor_source are pure
local dependencies. Adapter128's sole dependency import is replaced in a private
module instance with these same pinned modules; functions are not monkeypatched.
No caller callback or module registration is an authorization mechanism.

`partial113.py` is an explicit source-derived validator, with `partial113.diff`
recording the changes to original `_parse_envelope`: only digest/length checks
that require absent source/companion bytes are deferred. Original declared-field
shape, contract, lineage, timestamp, lane equations, clock/session/view/sequence
checks still run. No placeholder byte object is passed to the original parser.
Four returned frames also have their independently decidable internal shared
session/view/index/acquisition and ordered-sequence relations checked without a
request. Companion's actual receive/evaluation order is checked without a
request. Missing data does not erase an already supplied contradiction.

Default full-proof freshness remains the fixed C28 source boundary. Existing
Root demo-age tokens can authorize only their actual scanner/selector budget;
this detached JSON API cannot extend final source/AI/action fences. E0 here is
the actual A046/B131 representable wire profile, not a new generic demonstration
requirement. No non-RAW, latency acceptance or 1% metric is invented as a gate.

## Original hook still needs a separately owned adaptation

`owned_invocation_v1/adapter.py:_retain_original_association` currently requires
an active original ActorComposition observation `_InputTransaction`, exact
VerifiedObservation and original ProjectionSession/Producer capture rows.
`OwnedInvocationAdapter.begin` parses host_envelope, checks original runtime
retention, calls C42 export and frozen C36, then retains full proof and exact
child request before dispatch. This cannot accept raw4 by replacing a class name.
C50 does not edit or bypass that path. Root must supply its real original
phase/preparation/source/admission/Book/current/registry attachment before a new
versioned hook can authenticate association and invoke this projector.


## Explicit repair-v1 consistency change

Schema and project_raw4_json(bytes) signature are unchanged. Malformed supplied
evidence is rejected before unavailable even with missing request/config/source.
transport.source_frames compares actual decoded values, all four quality flags,
and acquisition/source ticks separately against each available source payload,
companion payload and candidate. Original A046 _construct_bytes lines 51-71 use
source tick milliseconds times 1000 relative to source origin; candidate checks
use the candidate's actual source_start_tick_ms. No absolute QPC is manufactured.
The original adapter128 lines 172-173 require these value/time/flag equalities.

Within one proof, shared TRACE fields are operation_id, request_hash,
tested_commit, boot_id, session_id, tag, generation, clock_domain_id and actual
source_origin_qpc_ns. Supplied config, requests and companion source_context
contribute their own values; decoded frames contribute their actual session.
Equality is strict, including type. Original B113 typed lineage validators are
reused for companion fields without constructing a request. The actual original
constructor uses one lineage for each request/companion pair (lines 44-46,71-76,
105-110). Per-request identifiers and sequences may vary between captures.
C42 context/generation are not TRACE namespace aliases. These are necessary
consistency checks only: equality never proves producer custody or permission.
