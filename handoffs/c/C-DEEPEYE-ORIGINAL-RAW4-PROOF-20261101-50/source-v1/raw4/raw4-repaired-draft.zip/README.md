# C50 bounded partial-evidence repair v1

Pending independent repair review; detached numerical projection only. This
successor changes exactly projector.py and transport.py. Original implementation,
public draft and independent review remain immutable historical evidence.
The request/public schemas, frozen numerical predicates and fixed dependencies
remain byte-identical. No hook, original factory, authority or C28 call is added.

The four independent exact RED inputs now reject supplied contradictions before
missing-evidence return. Wire/source and wire/companion comparisons use original
constructor counts, per-channel flags and source/acquisition relative microsecond
ticks. Candidate-only evidence uses its actual source-start tick, never an
invented request, source origin or sample. A proof-local TRACE namespace compares
actual config/request/companion values and decoded session while leaving C42
context/generation independent. Variable request ID/sequence/trigger/capture
fields are type-checked but are not forced equal across different captures.

One NEW bounded repair process (30-second timeout) executed ten affected inputs,
exit 0. Four exact independent REDs now Rejected; complete, held default-disabled
and coherent missing evidence preserve their expected results. Three direct
adjacent checks cover companion-only value mismatch, candidate-only quality
mismatch, and consistent request-only namespaces. All exact input bytes are in
inputs/ and their hashes in cases.json; no fixture construction code was run.
The original independent RED outputs/stdout/stderr/exit are preserved under
review-original/, clearly separate from this successor run01. All synthetic
results remain core_ran=false/authorization=none. No old whole group was rerun.

The original reviewer evidence stays version-specific. Prior author logs and
original source inputs remain in the frozen original directory; this is not a
self-contained public delivery package. Main owns further independent review,
packaging and publication. Live Root/C46 association and production activation
remain incomplete, and no board/H12/final acceptance is claimed.

One read-only evidence lookup initially requested run01/stdout.bin at the wrong
review-relative path and returned shell exit 1. The correct original stdout is
at the review root and was copied unchanged. No product action was repeated.
Preparation and finalization are data/hash-only operations. All jobs are closed.
H01-H15, fixed contract and A-only physical-board ownership remain unchanged.
