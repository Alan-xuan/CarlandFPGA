from pathlib import Path
import hashlib,json,sys
from raw4_proof_v1 import project_raw4_json,Rejected
D=Path(__file__).resolve().parent;OUT=D/'runs'/sys.argv[1]/'cases';OUT.mkdir()
rows=[]
for case in json.loads((D/'cases.json').read_bytes()):
 b=(D/'inputs'/(case['name']+'.json')).read_bytes();assert hashlib.sha256(b).hexdigest()==case['sha256']
 try:
  response=project_raw4_json(b);result=json.loads(response);observed=result['input_status']
  assert result['core_ran'] is False and result['authorization']=='none'
 except Rejected as e:observed='REJECTED';response=json.dumps(dict(exception='Rejected',reason=str(e))).encode()
 except Exception as e:observed='UNEXPECTED_EXCEPTION';response=json.dumps(dict(exception=type(e).__name__,reason=str(e))).encode()
 (OUT/(case['name']+'.output.json')).write_bytes(response)
 row=dict(**case,observed=observed,passed=observed==case['expected']);rows.append(row);print(json.dumps(row),flush=True)
(OUT/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
assert not any('frozen_c28' in k for k in sys.modules)
raise SystemExit(0 if all(r['passed']for r in rows)else 1)
