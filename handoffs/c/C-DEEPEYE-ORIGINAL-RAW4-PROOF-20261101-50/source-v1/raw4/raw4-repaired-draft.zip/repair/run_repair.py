from pathlib import Path
import hashlib,json,subprocess,sys,time,zipfile
D=Path(__file__).resolve().parent;OUT=D/'runs'/sys.argv[1];OUT.mkdir(parents=True,exist_ok=False)
def sha(b):return hashlib.sha256(b).hexdigest()
def put(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
files=[D/'check_repair.py',D/'cases.json',*sorted((D/'inputs').rglob('*.json')),*sorted((D/'raw4_proof_v1').rglob('*'))];pins=[]
with zipfile.ZipFile(OUT/'source-version.zip','w',zipfile.ZIP_DEFLATED)as z:
 for f in files:
  if not f.is_file() or '__pycache__' in f.parts:continue
  b=f.read_bytes();n=f.relative_to(D).as_posix();z.writestr(n,b);pins.append(dict(path=n,bytes=len(b),sha256=sha(b)))
cmd=[sys.executable,'-X','utf8','-B',str(D/'check_repair.py'),sys.argv[1]]
put(OUT/'command.json',dict(argv=cmd,cwd=str(D),timeout_seconds=30,source_pins=pins))
start=time.monotonic()
try:
 p=subprocess.run(cmd,cwd=D,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30);code=p.returncode;stdout=p.stdout;stderr=p.stderr
except subprocess.TimeoutExpired as e:code=124;stdout=e.stdout or b'';stderr=e.stderr or b''
(OUT/'stdout.bin').write_bytes(stdout);(OUT/'stderr.bin').write_bytes(stderr)
put(OUT/'result.json',dict(exit_code=code,elapsed_seconds=time.monotonic()-start,pins={p.name:sha(p.read_bytes())for p in OUT.iterdir()if p.is_file()}))
print(stdout.decode());print(stderr.decode());print('EXIT',code);raise SystemExit(code)
