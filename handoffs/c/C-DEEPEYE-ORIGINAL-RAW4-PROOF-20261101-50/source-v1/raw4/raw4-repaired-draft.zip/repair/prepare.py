from pathlib import Path
import json,hashlib,shutil
D=Path(__file__).resolve().parent;OLD=D.parent/'implementation-v1';RV=D.parent/'raw4-review-v1'
def sha(b):return hashlib.sha256(b).hexdigest()
def put(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf8')
assert sha((OLD/'raw4_proof_v1/projector.py').read_bytes())=='7468a1d32e3c160e9af8d77900b10672d36ab85973320667bfa1454da2dd14ee'
assert sha((OLD/'raw4_proof_v1/transport.py').read_bytes())=='f8b808ded68408018ecf38e35fd97f9cbe96b41321c05aa95180d77cce605e32'
shutil.copytree(OLD/'raw4_proof_v1',D/'raw4_proof_v1')
for name in ('API.md','README.md','source-pins.json','derivation-pins.json','contract-check.json'):
 shutil.copyfile(OLD/name,D/name)
shutil.copytree(RV/'run01',D/'review-original/run01')
for name in ('stdout.bin','stderr.bin','exit.json','case-pins.json','FINDINGS.json'):
 shutil.copyfile(RV/name,D/'review-original'/name)
(D/'inputs').mkdir();cases=[]
for row in json.loads((RV/'run01/results.json').read_bytes()):
 name=row['name'];b=(RV/'run01'/f'{name}.input.json').read_bytes();assert sha(b)==row['input_sha256']
 (D/'inputs'/f'{name}.json').write_bytes(b);cases.append(dict(name=name,expected=row['expected'],sha256=sha(b),origin='exact independent input'))
def add(name,seed,change,expected='REJECTED'):
 x=json.loads((D/'inputs'/f'{seed}.json').read_bytes());change(x);b=json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode();(D/'inputs'/f'{name}.json').write_bytes(b);cases.append(dict(name=name,expected=expected,sha256=sha(b),origin='direct adjacent derived input'))
def only(x,source=False,companion=False):
 for rec in x['root_receipt']['captures']:
  rec['raw4']['source_hex']=None
  if not companion:rec['raw4']['companions_hex']=None
add('adjacent-companion-only-wire-value','new-missing-request-wire-value-conflict',lambda x:only(x,companion=True))
add('adjacent-candidate-only-wire-quality','new-missing-request-wire-quality-conflict',only)
def align(x):
 for rec in x['root_receipt']['captures']:
  packet=rec['raw4'];req=json.loads(bytes.fromhex(packet['request_hex']));req['lineage']['session_id']=7
  for lane in req['scan']['lanes']:lane['session']=7
  packet['request_hex']=json.dumps(req,sort_keys=True,separators=(',',':')).encode().hex()
add('adjacent-request-only-same-namespace','new-two-request-only-sessions-no-config',align,'INPUT_UNAVAILABLE')
put(D/'cases.json',cases)
put(D/'baseline-pins.json',[dict(path=p.relative_to(OLD).as_posix(),bytes=len(p.read_bytes()),sha256=sha(p.read_bytes()))for p in sorted((OLD/'raw4_proof_v1').rglob('*'))if p.is_file()])
print(json.dumps(dict(cases=len(cases),baseline='exact frozen original',tests_executed=0)))
